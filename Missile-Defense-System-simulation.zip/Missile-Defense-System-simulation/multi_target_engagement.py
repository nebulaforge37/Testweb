
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import random
import math
import threading
import time
from datetime import datetime

class MultiTargetEngagementSystem:
    """System for tracking and engaging multiple threats simultaneously"""
    
    def __init__(self, parent):
        self.parent = parent
        self.frame = parent.multi_target_tab if hasattr(parent, 'multi_target_tab') else None
        self.defense_os = parent.defense_os if hasattr(parent, 'defense_os') else None
        
        # Available resources
        self.max_simultaneous_tracks = 8  # Maximum threats that can be tracked simultaneously
        self.max_simultaneous_engagements = 4  # Maximum threats that can be engaged simultaneously
        self.current_tracks = []  # Currently tracked threats
        self.current_engagements = []  # Currently engaged threats
        
        # Track and engagement history
        self.track_history = []
        self.engagement_history = []
        
        # Prioritization rules
        self.prioritization_rules = {
            "Closest First": lambda threats: sorted(threats, key=lambda t: t.get('distance', 1000)),
            "Fastest First": lambda threats: sorted(threats, key=lambda t: t.get('speed', 0), reverse=True),
            "Ballistic First": lambda threats: sorted(threats, key=lambda t: 0 if t.get('type') == 'Ballistic Missile' else 1),
            "Threat Score": lambda threats: sorted(threats, key=self.calculate_threat_score, reverse=True)
        }
        self.current_priority_rule = "Threat Score"
        
        # Engagement strategy
        self.engagement_strategies = {
            "Sequential": self.engage_sequential,
            "Parallel": self.engage_parallel,
            "Optimized": self.engage_optimized,
            "Manual": self.engage_manual
        }
        self.current_strategy = "Optimized"
        
        # System status
        self.system_active = False
        self.system_status = "Standby"
        
        # Setup UI if frame exists
        if self.frame:
            self.setup_ui()
    
    def setup_ui(self):
        """Set up the multi-target engagement system UI"""
        # Header
        header_label = tk.Label(
            self.frame, 
            text="MULTI-TARGET ENGAGEMENT", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)
        
        # Create main layout - left panel for controls, right panel for visualization
        main_frame = tk.Frame(self.frame, bg="#0a192f")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Left control panel
        control_panel = tk.Frame(main_frame, bg="#0a192f", width=400)
        control_panel.pack(side="left", fill="y", padx=(0, 10))
        
        # System status section
        status_frame = tk.LabelFrame(
            control_panel, 
            text="System Status", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        status_frame.pack(fill="x", pady=(0, 10))
        
        # Status indicators
        self.status_var = tk.StringVar(value="Standby")
        self.tracks_var = tk.StringVar(value=f"0/{self.max_simultaneous_tracks}")
        self.engagements_var = tk.StringVar(value=f"0/{self.max_simultaneous_engagements}")
        
        status_label = tk.Label(
            status_frame, 
            text="Status:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240", 
            anchor="w"
        )
        status_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        
        status_value = tk.Label(
            status_frame, 
            textvariable=self.status_var, 
            font=("Arial", 11, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        status_value.grid(row=0, column=1, padx=10, pady=5, sticky="w")
        
        tracks_label = tk.Label(
            status_frame, 
            text="Active Tracks:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240", 
            anchor="w"
        )
        tracks_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        
        tracks_value = tk.Label(
            status_frame, 
            textvariable=self.tracks_var, 
            font=("Arial", 11), 
            fg="#64ffda", 
            bg="#112240"
        )
        tracks_value.grid(row=1, column=1, padx=10, pady=5, sticky="w")
        
        engage_label = tk.Label(
            status_frame, 
            text="Active Engagements:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240", 
            anchor="w"
        )
        engage_label.grid(row=2, column=0, padx=10, pady=5, sticky="w")
        
        engage_value = tk.Label(
            status_frame, 
            textvariable=self.engagements_var, 
            font=("Arial", 11), 
            fg="#64ffda", 
            bg="#112240"
        )
        engage_value.grid(row=2, column=1, padx=10, pady=5, sticky="w")
        
        # System operations
        operations_frame = tk.LabelFrame(
            control_panel, 
            text="Operations", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        operations_frame.pack(fill="x", pady=(0, 10))
        
        # Prioritization rules
        priority_frame = tk.Frame(operations_frame, bg="#112240")
        priority_frame.pack(fill="x", padx=10, pady=5)
        
        priority_label = tk.Label(
            priority_frame, 
            text="Prioritization Rule:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        priority_label.pack(side="left", padx=(0, 10))
        
        self.priority_var = tk.StringVar(value=self.current_priority_rule)
        priority_cb = ttk.Combobox(
            priority_frame,
            textvariable=self.priority_var,
            values=list(self.prioritization_rules.keys()),
            state="readonly",
            width=15
        )
        priority_cb.pack(side="left")
        priority_cb.bind("<<ComboboxSelected>>", self.change_priority_rule)
        
        # Engagement strategy
        strategy_frame = tk.Frame(operations_frame, bg="#112240")
        strategy_frame.pack(fill="x", padx=10, pady=5)
        
        strategy_label = tk.Label(
            strategy_frame, 
            text="Engagement Strategy:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        strategy_label.pack(side="left", padx=(0, 10))
        
        self.strategy_var = tk.StringVar(value=self.current_strategy)
        strategy_cb = ttk.Combobox(
            strategy_frame,
            textvariable=self.strategy_var,
            values=list(self.engagement_strategies.keys()),
            state="readonly",
            width=15
        )
        strategy_cb.pack(side="left")
        strategy_cb.bind("<<ComboboxSelected>>", self.change_engagement_strategy)
        
        # Control buttons
        buttons_frame = tk.Frame(operations_frame, bg="#112240")
        buttons_frame.pack(fill="x", padx=10, pady=10)
        
        self.activate_btn = ttk.Button(
            buttons_frame,
            text="Activate System",
            command=self.toggle_system
        )
        self.activate_btn.pack(side="left", padx=5)
        
        refresh_btn = ttk.Button(
            buttons_frame,
            text="Refresh Threats",
            command=self.refresh_threats
        )
        refresh_btn.pack(side="left", padx=5)
        
        clear_btn = ttk.Button(
            buttons_frame,
            text="Clear Tracks",
            command=self.clear_tracks
        )
        clear_btn.pack(side="right", padx=5)
        
        # Resource allocation section
        resource_frame = tk.LabelFrame(
            control_panel, 
            text="Resource Allocation", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        resource_frame.pack(fill="x", pady=(0, 10))
        
        # Track capacity
        track_frame = tk.Frame(resource_frame, bg="#112240")
        track_frame.pack(fill="x", padx=10, pady=5)
        
        track_label = tk.Label(
            track_frame, 
            text="Track Capacity:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        track_label.pack(side="left")
        
        track_progress = ttk.Progressbar(
            track_frame, 
            orient="horizontal", 
            length=200, 
            mode="determinate",
            maximum=self.max_simultaneous_tracks
        )
        track_progress['value'] = 0
        track_progress.pack(side="right", padx=10)
        self.track_progress = track_progress
        
        # Engagement capacity
        engage_frame = tk.Frame(resource_frame, bg="#112240")
        engage_frame.pack(fill="x", padx=10, pady=5)
        
        engage_label = tk.Label(
            engage_frame, 
            text="Engagement Capacity:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        engage_label.pack(side="left")
        
        engage_progress = ttk.Progressbar(
            engage_frame, 
            orient="horizontal", 
            length=200, 
            mode="determinate",
            maximum=self.max_simultaneous_engagements
        )
        engage_progress['value'] = 0
        engage_progress.pack(side="right", padx=10)
        self.engage_progress = engage_progress
        
        # System capacity settings
        capacity_frame = tk.Frame(resource_frame, bg="#112240")
        capacity_frame.pack(fill="x", padx=10, pady=10)
        
        # Track capacity setting
        track_setting_frame = tk.Frame(capacity_frame, bg="#112240")
        track_setting_frame.pack(fill="x", pady=2)
        
        track_setting_label = tk.Label(
            track_setting_frame, 
            text="Max Tracks:", 
            font=("Arial", 10), 
            fg="white", 
            bg="#112240"
        )
        track_setting_label.pack(side="left")
        
        track_spinbox = ttk.Spinbox(
            track_setting_frame,
            from_=4,
            to=12,
            width=5,
            textvariable=tk.IntVar(value=self.max_simultaneous_tracks),
            command=lambda: self.update_capacity("tracks", int(track_spinbox.get()))
        )
        track_spinbox.pack(side="left", padx=5)
        
        # Engagement capacity setting
        engage_setting_frame = tk.Frame(capacity_frame, bg="#112240")
        engage_setting_frame.pack(fill="x", pady=2)
        
        engage_setting_label = tk.Label(
            engage_setting_frame, 
            text="Max Engagements:", 
            font=("Arial", 10), 
            fg="white", 
            bg="#112240"
        )
        engage_setting_label.pack(side="left")
        
        engage_spinbox = ttk.Spinbox(
            engage_setting_frame,
            from_=2,
            to=8,
            width=5,
            textvariable=tk.IntVar(value=self.max_simultaneous_engagements),
            command=lambda: self.update_capacity("engagements", int(engage_spinbox.get()))
        )
        engage_spinbox.pack(side="left", padx=5)
        
        # Threat list section
        threat_list_frame = tk.LabelFrame(
            control_panel, 
            text="Tracked Threats", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        threat_list_frame.pack(fill="both", expand=True)
        
        # Threat treeview
        columns = ("id", "type", "distance", "speed", "priority", "status")
        self.threat_tree = ttk.Treeview(
            threat_list_frame, 
            columns=columns, 
            show="headings", 
            height=10,
            selectmode="browse"
        )
        
        # Define headings
        self.threat_tree.heading("id", text="ID")
        self.threat_tree.heading("type", text="Type")
        self.threat_tree.heading("distance", text="Distance")
        self.threat_tree.heading("speed", text="Speed")
        self.threat_tree.heading("priority", text="Priority")
        self.threat_tree.heading("status", text="Status")
        
        # Define column widths
        self.threat_tree.column("id", width=40, anchor="center")
        self.threat_tree.column("type", width=120)
        self.threat_tree.column("distance", width=70, anchor="center")
        self.threat_tree.column("speed", width=70, anchor="center")
        self.threat_tree.column("priority", width=70, anchor="center")
        self.threat_tree.column("status", width=100, anchor="center")
        
        # Add scrollbar
        tree_scrollbar = ttk.Scrollbar(
            threat_list_frame, 
            orient="vertical", 
            command=self.threat_tree.yview
        )
        self.threat_tree.configure(yscrollcommand=tree_scrollbar.set)
        
        # Pack elements
        self.threat_tree.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        tree_scrollbar.pack(side="right", fill="y", pady=5)
        
        # Manual engagement button (for Manual strategy)
        manual_frame = tk.Frame(threat_list_frame, bg="#112240")
        manual_frame.pack(fill="x", padx=5, pady=5)
        
        self.manual_engage_btn = ttk.Button(
            manual_frame,
            text="Engage Selected",
            command=self.manually_engage_threat,
            state="disabled"
        )
        self.manual_engage_btn.pack(side="left", padx=5)
        
        # Right visualization panel
        visual_panel = tk.Frame(main_frame, bg="#0a192f", width=400)
        visual_panel.pack(side="right", fill="both", expand=True)
        
        # Radar display area
        radar_frame = tk.LabelFrame(
            visual_panel, 
            text="Radar Display", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        radar_frame.pack(fill="both", expand=True, pady=(0, 10))
        
        # Create canvas for radar display
        self.radar_canvas = tk.Canvas(
            radar_frame,
            width=400,
            height=400,
            bg="#030e1f",
            highlightthickness=0
        )
        self.radar_canvas.pack(padx=10, pady=10)
        
        # System console output
        console_frame = tk.LabelFrame(
            visual_panel, 
            text="System Console", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        console_frame.pack(fill="both", expand=True)
        
        self.console = scrolledtext.ScrolledText(
            console_frame, 
            width=40, 
            height=10, 
            font=("Courier", 10), 
            bg="#030e1f", 
            fg="#64ffda"
        )
        self.console.pack(fill="both", expand=True, padx=10, pady=10)
        self.console.config(state=tk.DISABLED)
        
        # Log initial status
        self.log_to_console("Multi-Target Engagement System initialized")
        self.log_to_console(f"Max Tracks: {self.max_simultaneous_tracks}, Max Engagements: {self.max_simultaneous_engagements}")
        self.log_to_console(f"Priority: {self.current_priority_rule}, Strategy: {self.current_strategy}")
        self.log_to_console("System in standby mode")
        
        # Initialize radar display
        self.initialize_radar()
    
    def log_to_console(self, message):
        """Log a message to the system console"""
        if hasattr(self, 'console'):
            self.console.config(state=tk.NORMAL)
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.console.insert(tk.END, f"[{timestamp}] {message}\n")
            self.console.see(tk.END)
            self.console.config(state=tk.DISABLED)
    
    def initialize_radar(self):
        """Draw initial radar display"""
        if not hasattr(self, 'radar_canvas'):
            return
            
        # Clear canvas
        self.radar_canvas.delete("all")
        
        # Get canvas dimensions
        width = self.radar_canvas.winfo_width()
        height = self.radar_canvas.winfo_height()
        
        # Center point
        center_x = width / 2
        center_y = height / 2
        
        # Draw radar circles
        for radius in range(50, 251, 50):
            # Scale radius for display (radar range is 0-500km)
            scaled_radius = radius * (min(width, height) / 2) / 250
            
            self.radar_canvas.create_oval(
                center_x - scaled_radius,
                center_y - scaled_radius,
                center_x + scaled_radius, 
                center_y + scaled_radius,
                outline="#1a3050",
                width=1,
                tags="radar_grid"
            )
            
            # Add range label
            self.radar_canvas.create_text(
                center_x,
                center_y - scaled_radius,
                text=f"{radius}km",
                fill="#1a3050",
                font=("Arial", 8),
                tags="radar_labels"
            )
        
        # Draw radar sweeping line (initial position)
        self.sweep_angle = 0
        self.sweep_line = self.radar_canvas.create_line(
            center_x, center_y,
            center_x, center_y - min(width, height) / 2,
            fill="#64ffda",
            width=2,
            tags="sweep"
        )
        
        # Start radar animation
        self.animate_radar()
    
    def animate_radar(self):
        """Animate the radar sweep"""
        if not hasattr(self, 'radar_canvas') or not hasattr(self, 'sweep_line'):
            return
            
        # Get canvas dimensions
        width = self.radar_canvas.winfo_width()
        height = self.radar_canvas.winfo_height()
        
        # Center point
        center_x = width / 2
        center_y = height / 2
        
        # Calculate sweep endpoint
        radius = min(width, height) / 2
        end_x = center_x + radius * math.sin(math.radians(self.sweep_angle))
        end_y = center_y - radius * math.cos(math.radians(self.sweep_angle))
        
        # Update sweep line
        self.radar_canvas.coords(
            self.sweep_line,
            center_x, center_y, end_x, end_y
        )
        
        # Update sweep angle
        self.sweep_angle = (self.sweep_angle + 3) % 360
        
        # Continue animation
        self.radar_canvas.after(50, self.animate_radar)
    
    def update_radar_display(self):
        """Update radar display with current tracks and engagements"""
        if not hasattr(self, 'radar_canvas'):
            return
            
        # Clear existing tracks and engagements
        self.radar_canvas.delete("track")
        self.radar_canvas.delete("engagement")
        
        # Get canvas dimensions
        width = self.radar_canvas.winfo_width()
        height = self.radar_canvas.winfo_height()
        
        # Center point
        center_x = width / 2
        center_y = height / 2
        
        # Draw active tracks
        for track in self.current_tracks:
            # Convert polar coordinates (distance, heading) to cartesian
            distance = track.get('distance', 0)
            heading = track.get('heading', 'North')
            
            # Scale distance for display
            scaled_distance = distance * (min(width, height) / 2) / 500
            
            # Convert heading to angle in degrees
            heading_angles = {
                "North": 90, "Northeast": 45, "East": 0, 
                "Southeast": 315, "South": 270, "Southwest": 225, 
                "West": 180, "Northwest": 135
            }
            angle = heading_angles.get(heading, 0)
            
            # Calculate position
            x = center_x + scaled_distance * math.cos(math.radians(angle))
            y = center_y - scaled_distance * math.sin(math.radians(angle))
            
            # Determine color based on status
            if track.get('engaged', False):
                color = "#e74c3c"  # Red for engaged threats
                outline = "#ffffff"
                width = 2
            else:
                color = "#f39c12"  # Orange for tracked threats
                outline = "#ffffff"
                width = 1
            
            # Draw track marker
            self.radar_canvas.create_oval(
                x - 5, y - 5, x + 5, y + 5,
                fill=color,
                outline=outline,
                width=width,
                tags="track"
            )
            
            # Add track ID
            self.radar_canvas.create_text(
                x, y - 10,
                text=str(track.get('id', '')),
                fill="#ffffff",
                font=("Arial", 8),
                tags="track"
            )
            
            # Draw engagement line for engaged threats
            if track.get('engaged', False):
                self.radar_canvas.create_line(
                    center_x, center_y, x, y,
                    fill="#3498db",  # Blue for engagement lines
                    width=2,
                    dash=(5, 3),
                    tags="engagement"
                )
    
    def toggle_system(self):
        """Toggle the multi-target engagement system on/off"""
        if self.system_active:
            # Deactivate system
            self.system_active = False
            self.status_var.set("Standby")
            self.activate_btn.config(text="Activate System")
            
            # Update manual engagement button
            if self.current_strategy == "Manual":
                self.manual_engage_btn.config(state="disabled")
                
            self.log_to_console("System deactivated, entering standby mode")
        else:
            # Activate system
            self.system_active = True
            self.status_var.set("Active")
            self.activate_btn.config(text="Deactivate System")
            
            # Update manual engagement button
            if self.current_strategy == "Manual":
                self.manual_engage_btn.config(state="normal")
                
            self.log_to_console("System activated")
            
            # Start tracking thread if active
            self.start_tracking()
    
    def start_tracking(self):
        """Start the threat tracking and engagement thread"""
        if self.system_active:
            # Update tracks and engagements
            self.update_tracks()
            
            # Continue updating if system is still active
            if self.system_active:
                self.parent.root.after(1000, self.start_tracking)
    
    def update_tracks(self):
        """Update tracked threats based on current threats in the system"""
        if not self.defense_os:
            return
            
        # Get all current active threats
        all_threats = [t for t in self.defense_os.threats if not t.get('intercepted', False)]
        
        # Clear expired tracks
        self.current_tracks = [t for t in self.current_tracks if any(t['id'] == threat['id'] for threat in all_threats)]
        
        # Update existing tracks
        for track in self.current_tracks:
            for threat in all_threats:
                if track['id'] == threat['id']:
                    # Update track with latest threat data
                    track['distance'] = threat['distance']
                    track['speed'] = threat['speed']
                    track['heading'] = threat['heading']
                    
                    # Check if threat has been intercepted
                    if threat.get('intercepted', False):
                        track['engaged'] = False
                        track['status'] = "Intercepted"
        
        # Add new tracks (up to max capacity)
        tracked_ids = [t['id'] for t in self.current_tracks]
        new_threats = [t for t in all_threats if t['id'] not in tracked_ids]
        
        # Prioritize new threats if we exceed capacity
        if new_threats:
            # Apply current prioritization rule
            prioritize_func = self.prioritization_rules.get(
                self.current_priority_rule, 
                self.prioritization_rules["Threat Score"]
            )
            prioritized_threats = prioritize_func(new_threats)
            
            # Add new tracks up to capacity
            available_slots = self.max_simultaneous_tracks - len(self.current_tracks)
            for threat in prioritized_threats[:available_slots]:
                # Calculate threat score
                score = self.calculate_threat_score(threat)
                
                # Create new track
                new_track = {
                    'id': threat['id'],
                    'type': threat['type'],
                    'distance': threat['distance'],
                    'speed': threat['speed'],
                    'heading': threat['heading'],
                    'priority_score': score,
                    'engaged': False,
                    'status': "Tracked",
                    'track_time': datetime.now()
                }
                
                self.current_tracks.append(new_track)
                self.log_to_console(f"New track: ID {threat['id']} ({threat['type']}) - Priority: {score:.1f}")
        
        # Update track list in UI
        self.update_track_list()
        
        # Update resource indicators
        self.update_resource_indicators()
        
        # Update radar display
        self.update_radar_display()
        
        # Execute engagement strategy if system is active
        if self.system_active and self.current_strategy != "Manual":
            engage_func = self.engagement_strategies.get(
                self.current_strategy, 
                self.engage_sequential
            )
            engage_func()
    
    def update_track_list(self):
        """Update the tracked threats list in the UI"""
        if not hasattr(self, 'threat_tree'):
            return
            
        # Clear existing items
        for item in self.threat_tree.get_children():
            self.threat_tree.delete(item)
            
        # Add current tracks to the list
        for track in self.current_tracks:
            # Format values
            track_id = track.get('id', '')
            track_type = track.get('type', '')
            distance = f"{track.get('distance', 0)} km"
            speed = f"{track.get('speed', 0)} km/h"
            priority = f"{track.get('priority_score', 0):.1f}"
            status = track.get('status', 'Tracked')
            
            # Add to treeview
            self.threat_tree.insert(
                "", "end",
                values=(track_id, track_type, distance, speed, priority, status)
            )
    
    def update_resource_indicators(self):
        """Update resource allocation indicators"""
        if hasattr(self, 'track_progress'):
            self.track_progress['value'] = len(self.current_tracks)
            
        if hasattr(self, 'engage_progress'):
            engaged_count = sum(1 for t in self.current_tracks if t.get('engaged', False))
            self.engage_progress['value'] = engaged_count
            
        # Update status text
        if hasattr(self, 'tracks_var'):
            self.tracks_var.set(f"{len(self.current_tracks)}/{self.max_simultaneous_tracks}")
            
        if hasattr(self, 'engagements_var'):
            engaged_count = sum(1 for t in self.current_tracks if t.get('engaged', False))
            self.engagements_var.set(f"{engaged_count}/{self.max_simultaneous_engagements}")
    
    def calculate_threat_score(self, threat):
        """Calculate a threat priority score based on multiple factors"""
        if not threat:
            return 0
            
        # Extract threat parameters
        distance = threat.get('distance', 1000)
        speed = threat.get('speed', 0)
        threat_type = threat.get('type', 'Unknown')
        
        # Type-based threat coefficient
        type_coefficient = {
            "Ballistic Missile": 10.0,
            "Cruise Missile": 8.0,
            "Aircraft": 6.0,
            "Drone": 4.0,
            "Unknown": 5.0
        }.get(threat_type, 5.0)
        
        # Calculate time to impact (in seconds)
        time_to_impact = (distance / max(speed, 1)) * 3600
        
        # Calculate priority score (higher is more urgent)
        # Formula: type_coefficient * (speed / distance) * (1 / time_to_impact)
        priority = type_coefficient * (speed / max(distance, 1)) * (1000 / max(time_to_impact, 1))
        
        return priority
    
    def engage_sequential(self):
        """Engage threats sequentially (one after another)"""
        # Check if we're currently at max engagement capacity
        engaged_threats = [t for t in self.current_tracks if t.get('engaged', False)]
        if len(engaged_threats) >= self.max_simultaneous_engagements:
            return
            
        # Find unengaged threats
        unengaged_threats = [t for t in self.current_tracks if not t.get('engaged', False)]
        if not unengaged_threats:
            return
            
        # Sort by priority score
        prioritized = sorted(unengaged_threats, key=lambda t: t.get('priority_score', 0), reverse=True)
        
        # Determine how many new engagements we can start
        available_slots = self.max_simultaneous_engagements - len(engaged_threats)
        to_engage = prioritized[:available_slots]
        
        # Start engagements
        for track in to_engage:
            self.start_engagement(track)
    
    def engage_parallel(self):
        """Engage multiple threats in parallel up to capacity"""
        # Find unengaged threats
        unengaged_threats = [t for t in self.current_tracks if not t.get('engaged', False)]
        if not unengaged_threats:
            return
            
        # Sort by priority score
        prioritized = sorted(unengaged_threats, key=lambda t: t.get('priority_score', 0), reverse=True)
        
        # Determine how many new engagements we can start
        engaged_count = sum(1 for t in self.current_tracks if t.get('engaged', False))
        available_slots = self.max_simultaneous_engagements - engaged_count
        
        # Start engagements for all available slots
        for track in prioritized[:available_slots]:
            self.start_engagement(track)
    
    def engage_optimized(self):
        """Optimized engagement strategy based on threat score and resource allocation"""
        # Check if any defense system is available
        if not self.defense_os or not self.defense_os.active_system:
            self.log_to_console("ERROR: No active defense system available for engagement")
            return
            
        defense_system = self.defense_os.active_system
        
        # Check ammunition
        if defense_system.ammo <= 0:
            self.log_to_console("WARNING: Defense system is out of ammunition")
            return
            
        # Find unengaged threats
        unengaged_threats = [t for t in self.current_tracks if not t.get('engaged', False)]
        if not unengaged_threats:
            return
            
        # Calculate optimal engagement allocation
        # This advanced algorithm considers:
        # 1. Threat priority scores
        # 2. Available engagement slots
        # 3. Defense system capabilities
        # 4. Estimated probability of successful intercept
        
        # Sort threats by priority
        prioritized = sorted(unengaged_threats, key=lambda t: t.get('priority_score', 0), reverse=True)
        
        # Determine how many new engagements we can start
        engaged_count = sum(1 for t in self.current_tracks if t.get('engaged', False))
        available_slots = min(self.max_simultaneous_engagements - engaged_count, defense_system.ammo)
        
        if available_slots <= 0:
            return
            
        # For optimization, we need to determine if there's a better allocation than just
        # taking the top N highest priority threats
        
        # Simple optimization for demonstration:
        # Check if we have threats in formations (similar distance/heading)
        formations = self.identify_formations(unengaged_threats)
        
        if formations:
            # We have formations - prioritize engaging entire formations if possible
            for formation in formations:
                # Check if we can engage the entire formation
                if len(formation) <= available_slots:
                    self.log_to_console(f"Detected formation with {len(formation)} threats - engaging as group")
                    
                    # Start engagements for entire formation
                    for track in formation:
                        self.start_engagement(track)
                        available_slots -= 1
                        
                    # If we've used all slots, stop
                    if available_slots <= 0:
                        break
        
        # If we still have available slots, engage highest priority individual threats
        if available_slots > 0:
            # Filter out threats already engaged via formations
            remaining = [t for t in prioritized if not t.get('engaged', False)]
            
            # Engage highest priority remaining threats
            for track in remaining[:available_slots]:
                self.start_engagement(track)
    
    def engage_manual(self):
        """Manual engagement mode - user selects threats to engage"""
        # This is handled by manually_engage_threat method
        pass
    
    def manually_engage_threat(self):
        """Manually engage a selected threat"""
        # Get selected threat
        selected = self.threat_tree.selection()
        if not selected:
            messagebox.showinfo("Selection", "Please select a threat to engage.")
            return
            
        # Get threat ID
        values = self.threat_tree.item(selected[0])['values']
        threat_id = values[0]
        
        # Find track with matching ID
        track = next((t for t in self.current_tracks if t['id'] == threat_id), None)
        if not track:
            messagebox.showinfo("Error", "Selected threat not found in tracking system.")
            return
            
        # Check if already engaged
        if track.get('engaged', False):
            messagebox.showinfo("Already Engaged", "This threat is already being engaged.")
            return
            
        # Check if we're at max engagement capacity
        engaged_count = sum(1 for t in self.current_tracks if t.get('engaged', False))
        if engaged_count >= self.max_simultaneous_engagements:
            messagebox.showinfo(
                "Engagement Capacity", 
                f"Maximum engagement capacity ({self.max_simultaneous_engagements}) reached."
            )
            return
            
        # Start engagement
        self.start_engagement(track)
    
    def start_engagement(self, track):
        """Start engagement process for a tracked threat"""
        # Check if defense system is available
        if not self.defense_os or not self.defense_os.active_system:
            self.log_to_console("ERROR: No active defense system available for engagement")
            return False
            
        defense_system = self.defense_os.active_system
        
        # Check ammunition
        if defense_system.ammo <= 0:
            self.log_to_console("WARNING: Defense system is out of ammunition")
            return False
            
        # Check if already engaged
        if track.get('engaged', False):
            return False
            
        # Mark as engaged
        track['engaged'] = True
        track['status'] = "Engaging"
        track['engagement_start'] = datetime.now()
        
        self.log_to_console(f"Engaging threat ID {track['id']} ({track['type']}) at {track['distance']} km")
        
        # Add to current engagements list
        self.current_engagements.append(track)
        
        # Update UI
        self.update_track_list()
        self.update_resource_indicators()
        self.update_radar_display()
        
        # Start engagement thread
        engagement_thread = threading.Thread(
            target=self._engagement_process,
            args=(track, defense_system)
        )
        engagement_thread.daemon = True
        engagement_thread.start()
        
        return True
    
    def _engagement_process(self, track, defense_system):
        """Execute the engagement process (in a separate thread)"""
        # Simulated engagement time (3-5 seconds)
        engagement_time = random.uniform(3, 5)
        time.sleep(engagement_time)
        
        # Check if the system is still active
        if not self.system_active:
            # System was deactivated during engagement
            track['engaged'] = False
            track['status'] = "Tracked"
            
            # Update UI from main thread
            self.parent.root.after(0, self.update_track_list)
            self.parent.root.after(0, self.update_resource_indicators)
            self.parent.root.after(0, self.update_radar_display)
            return
        
        # Find corresponding threat in the defense system
        if self.defense_os and self.defense_os.threats:
            target_threat = next(
                (t for t in self.defense_os.threats if t['id'] == track['id']), 
                None
            )
            
            if target_threat:
                # Fire the missile
                defense_system.fire(f"Threat #{target_threat['id']} ({target_threat['type']})")
                
                # Determine outcome (use the same logic as in the main system)
                from military_algorithms import DefenseOptimization
                
                # Calculate success probability
                success_prob = DefenseOptimization.calculate_success_probability(
                    target_threat, defense_system, target_threat['distance']
                )
                
                # Apply probability
                success = random.random() < success_prob
                
                if success:
                    # Mark as intercepted
                    target_threat['intercepted'] = True
                    track['status'] = "Intercepted"
                    
                    # Log success
                    self.parent.root.after(
                        0, 
                        lambda: self.log_to_console(f"TARGET NEUTRALIZED: Threat #{track['id']} successfully intercepted!")
                    )
                else:
                    # Mark as missed
                    track['status'] = "Intercept Failed"
                    
                    # Log failure
                    self.parent.root.after(
                        0, 
                        lambda: self.log_to_console(f"TARGET MISSED: Failed to intercept Threat #{track['id']}. Target is still active.")
                    )
            else:
                # Threat not found in defense system
                track['status'] = "Target Lost"
                
                self.parent.root.after(
                    0, 
                    lambda: self.log_to_console(f"ERROR: Target #{track['id']} lost during engagement process")
                )
        
        # Mark as no longer engaged
        track['engaged'] = False
        
        # Record engagement
        self.engagement_history.append({
            'threat_id': track['id'],
            'threat_type': track['type'],
            'distance': track['distance'],
            'start_time': track.get('engagement_start', datetime.now()),
            'end_time': datetime.now(),
            'result': track['status']
        })
        
        # Remove from current engagements
        if track in self.current_engagements:
            self.current_engagements.remove(track)
        
        # Update UI from main thread
        self.parent.root.after(0, self.update_track_list)
        self.parent.root.after(0, self.update_resource_indicators)
        self.parent.root.after(0, self.update_radar_display)
    
    def identify_formations(self, threats, threshold=30):
        """Identify groups of threats that may be in formation"""
        if len(threats) < 2:
            return []
            
        formations = []
        assigned = set()
        
        for i, t1 in enumerate(threats):
            if t1['id'] in assigned:
                continue
                
            # Start a new potential formation
            formation = [t1]
            assigned.add(t1['id'])
            
            # Look for similar threats
            for j, t2 in enumerate(threats):
                if i == j or t2['id'] in assigned:
                    continue
                    
                # Check if threats have similar parameters
                distance_diff = abs(t1['distance'] - t2['distance'])
                
                # Convert headings to angles for comparison
                heading_map = {
                    "North": 0, "Northeast": 45, "East": 90, "Southeast": 135,
                    "South": 180, "Southwest": 225, "West": 270, "Northwest": 315
                }
                
                # Get angles
                angle1 = heading_map.get(t1.get('heading', 'North'), 0)
                angle2 = heading_map.get(t2.get('heading', 'North'), 0)
                
                # Calculate angle difference (accounting for 360-degree wrap)
                angle_diff = min(abs(angle1 - angle2), 360 - abs(angle1 - angle2))
                
                # Check if threats appear to be in formation
                if distance_diff < threshold and angle_diff < 30:
                    formation.append(t2)
                    assigned.add(t2['id'])
            
            # Only consider as formation if contains multiple threats
            if len(formation) > 1:
                formations.append(formation)
        
        return formations
    
    def refresh_threats(self):
        """Refresh tracked threats from defense system"""
        self.log_to_console("Refreshing threat data...")
        self.update_tracks()
    
    def clear_tracks(self):
        """Clear all current tracks"""
        if self.current_tracks:
            self.current_tracks = []
            self.current_engagements = []
            self.log_to_console("All tracks cleared")
            
            # Update UI
            self.update_track_list()
            self.update_resource_indicators()
            self.update_radar_display()
    
    def change_priority_rule(self, event=None):
        """Change the threat prioritization rule"""
        new_rule = self.priority_var.get()
        self.current_priority_rule = new_rule
        self.log_to_console(f"Prioritization rule changed to: {new_rule}")
    
    def change_engagement_strategy(self, event=None):
        """Change the engagement strategy"""
        new_strategy = self.strategy_var.get()
        self.current_strategy = new_strategy
        self.log_to_console(f"Engagement strategy changed to: {new_strategy}")
        
        # Update manual engagement button state
        if hasattr(self, 'manual_engage_btn'):
            if new_strategy == "Manual" and self.system_active:
                self.manual_engage_btn.config(state="normal")
            else:
                self.manual_engage_btn.config(state="disabled")
    
    def update_capacity(self, capacity_type, new_value):
        """Update system capacity settings"""
        if capacity_type == "tracks":
            self.max_simultaneous_tracks = new_value
            if hasattr(self, 'track_progress'):
                self.track_progress.configure(maximum=new_value)
        elif capacity_type == "engagements":
            self.max_simultaneous_engagements = new_value
            if hasattr(self, 'engage_progress'):
                self.engage_progress.configure(maximum=new_value)
                
        self.log_to_console(f"System capacity updated: Max {capacity_type} = {new_value}")
        self.update_resource_indicators()
    
    def get_system_status(self):
        """Get the current status of the multi-target engagement system"""
        return {
            "active": self.system_active,
            "status": self.status_var.get() if hasattr(self, 'status_var') else "Unknown",
            "tracks": len(self.current_tracks),
            "max_tracks": self.max_simultaneous_tracks,
            "engagements": len(self.current_engagements),
            "max_engagements": self.max_simultaneous_engagements,
            "priority_rule": self.current_priority_rule,
            "strategy": self.current_strategy
        }

# Function to integrate multi-target system with main GUI
def integrate_multi_target(missile_defense_gui):
    """Integrate multi-target engagement system with the main GUI"""
    # Add tab
    missile_defense_gui.multi_target_tab = ttk.Frame(missile_defense_gui.tab_control)
    missile_defense_gui.tab_control.add(missile_defense_gui.multi_target_tab, text="Multi-Target")
    
    # Create multi-target system
    missile_defense_gui.multi_target = MultiTargetEngagementSystem(missile_defense_gui)
    
    return missile_defense_gui
