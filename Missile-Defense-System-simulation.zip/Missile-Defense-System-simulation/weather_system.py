
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import random
import numpy as np
import datetime
import math
import time
import threading

class WeatherSystem:
    def __init__(self, parent):
        self.parent = parent
        self.frame = parent.weather_tab if hasattr(parent, 'weather_tab') else None
        
        # Weather conditions that can affect missile defense
        self.weather_types = [
            "Clear", "Partly Cloudy", "Cloudy", "Rain", "Heavy Rain", 
            "Thunderstorm", "Snow", "Fog", "Sandstorm", "High Winds"
        ]
        
        # Current and forecast weather
        self.current_weather = {
            "condition": "Clear",
            "temperature": 20,  # in Celsius
            "wind_speed": 5,    # in m/s
            "wind_direction": "North",
            "visibility": 10,   # in km
            "humidity": 50,     # in %
            "pressure": 1013,   # in hPa
            "precipitation": 0  # in mm/h
        }
        
        # Forecast for next 24 hours (hourly)
        self.forecast = self.generate_forecast()
        
        # Impact factors for different weather conditions on defense systems
        self.impact_factors = {
            "Clear": {"radar": 1.0, "targeting": 1.0, "missile_speed": 1.0},
            "Partly Cloudy": {"radar": 0.95, "targeting": 0.98, "missile_speed": 1.0},
            "Cloudy": {"radar": 0.9, "targeting": 0.95, "missile_speed": 0.98},
            "Rain": {"radar": 0.8, "targeting": 0.9, "missile_speed": 0.95},
            "Heavy Rain": {"radar": 0.7, "targeting": 0.8, "missile_speed": 0.9},
            "Thunderstorm": {"radar": 0.6, "targeting": 0.7, "missile_speed": 0.85},
            "Snow": {"radar": 0.75, "targeting": 0.85, "missile_speed": 0.92},
            "Fog": {"radar": 0.5, "targeting": 0.6, "missile_speed": 0.95},
            "Sandstorm": {"radar": 0.4, "targeting": 0.5, "missile_speed": 0.8},
            "High Winds": {"radar": 0.85, "targeting": 0.7, "missile_speed": 0.75}
        }
        
        # Weather update interval (in seconds)
        self.update_interval = 60  # 1 minute
        
        # Last update time
        self.last_update = datetime.datetime.now()
        
        # Setup UI if frame exists
        if self.frame:
            self.setup_weather_ui()
            
        # Start weather simulation
        self.weather_thread = None
        self.running = False
        self.start_weather_simulation()
    
    def setup_weather_ui(self):
        """Set up the weather system UI"""
        # Header
        header_label = tk.Label(
            self.frame, 
            text="ENVIRONMENTAL CONDITIONS", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)
        
        # Create main content frame
        content_frame = tk.Frame(self.frame, bg="#0a192f")
        content_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Left panel - Current conditions
        left_panel = tk.LabelFrame(
            content_frame, 
            text="Current Conditions", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        left_panel.pack(side="left", fill="both", expand=True, padx=5, pady=10)
        
        # Current weather display
        current_frame = tk.Frame(left_panel, bg="#112240")
        current_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Weather icon and condition
        self.condition_var = tk.StringVar(value=self.current_weather["condition"])
        self.temperature_var = tk.StringVar(value=f"{self.current_weather['temperature']}°C")
        self.wind_var = tk.StringVar(value=f"{self.current_weather['wind_speed']} m/s {self.current_weather['wind_direction']}")
        
        condition_frame = tk.Frame(current_frame, bg="#112240")
        condition_frame.pack(fill="x", pady=10)
        
        # Weather icon (can be replaced with actual icons)
        icon_text = self.get_weather_icon(self.current_weather["condition"])
        icon_label = tk.Label(
            condition_frame, 
            text=icon_text, 
            font=("Arial", 40), 
            fg="#64ffda", 
            bg="#112240"
        )
        icon_label.pack(side="left", padx=20)
        
        # Weather condition and temperature
        info_frame = tk.Frame(condition_frame, bg="#112240")
        info_frame.pack(side="left", padx=10)
        
        condition_label = tk.Label(
            info_frame, 
            textvariable=self.condition_var, 
            font=("Arial", 16, "bold"), 
            fg="white", 
            bg="#112240"
        )
        condition_label.pack(anchor="w")
        
        temp_label = tk.Label(
            info_frame, 
            textvariable=self.temperature_var, 
            font=("Arial", 24), 
            fg="#64ffda", 
            bg="#112240"
        )
        temp_label.pack(anchor="w")
        
        wind_label = tk.Label(
            info_frame, 
            textvariable=self.wind_var, 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240"
        )
        wind_label.pack(anchor="w")
        
        # Other weather parameters
        params_frame = tk.Frame(current_frame, bg="#112240")
        params_frame.pack(fill="x", pady=10)
        
        # Create variables for other weather parameters
        self.visibility_var = tk.StringVar(value=f"{self.current_weather['visibility']} km")
        self.humidity_var = tk.StringVar(value=f"{self.current_weather['humidity']}%")
        self.pressure_var = tk.StringVar(value=f"{self.current_weather['pressure']} hPa")
        self.precipitation_var = tk.StringVar(value=f"{self.current_weather['precipitation']} mm/h")
        
        # Parameter labels
        param_labels = [
            ("Visibility", self.visibility_var),
            ("Humidity", self.humidity_var),
            ("Pressure", self.pressure_var),
            ("Precipitation", self.precipitation_var)
        ]
        
        for i, (label_text, var) in enumerate(param_labels):
            param_frame = tk.Frame(params_frame, bg="#112240")
            param_frame.grid(row=i//2, column=i%2, padx=10, pady=5, sticky="w")
            
            label = tk.Label(
                param_frame, 
                text=f"{label_text}:", 
                font=("Arial", 10), 
                fg="#64ffda", 
                bg="#112240",
                width=12,
                anchor="w"
            )
            label.pack(side="left")
            
            value_label = tk.Label(
                param_frame, 
                textvariable=var, 
                font=("Arial", 10), 
                fg="white", 
                bg="#112240",
                width=10,
                anchor="w"
            )
            value_label.pack(side="left")
        
        # Configure grid columns
        params_frame.columnconfigure(0, weight=1)
        params_frame.columnconfigure(1, weight=1)
        
        # Defense impact section
        impact_frame = tk.LabelFrame(
            current_frame, 
            text="Impact on Defense Systems", 
            font=("Arial", 10), 
            fg="white", 
            bg="#112240", 
            bd=1
        )
        impact_frame.pack(fill="x", pady=10)
        
        # Impact factors for current weather
        factors = self.impact_factors.get(self.current_weather["condition"], 
                                         {"radar": 1.0, "targeting": 1.0, "missile_speed": 1.0})
        
        # Create variables for impact factors
        self.radar_var = tk.StringVar(value=f"{factors['radar']*100:.0f}%")
        self.targeting_var = tk.StringVar(value=f"{factors['targeting']*100:.0f}%")
        self.missile_speed_var = tk.StringVar(value=f"{factors['missile_speed']*100:.0f}%")
        
        # Impact factor bars
        impact_types = [
            ("Radar Effectiveness", self.radar_var, factors["radar"]),
            ("Targeting Accuracy", self.targeting_var, factors["targeting"]),
            ("Missile Speed", self.missile_speed_var, factors["missile_speed"])
        ]
        
        for i, (label_text, var, value) in enumerate(impact_types):
            factor_frame = tk.Frame(impact_frame, bg="#112240")
            factor_frame.pack(fill="x", pady=5)
            
            label = tk.Label(
                factor_frame, 
                text=label_text, 
                font=("Arial", 10), 
                fg="white", 
                bg="#112240",
                width=15,
                anchor="w"
            )
            label.pack(side="left", padx=5)
            
            # Progress bar for visual representation
            factor_bar = ttk.Progressbar(
                factor_frame, 
                orient="horizontal", 
                length=150, 
                mode="determinate"
            )
            factor_bar["value"] = value * 100
            factor_bar.pack(side="left", padx=5)
            
            # Value label
            value_label = tk.Label(
                factor_frame, 
                textvariable=var, 
                font=("Arial", 10), 
                fg="#64ffda", 
                bg="#112240",
                width=5,
                anchor="w"
            )
            value_label.pack(side="left", padx=5)
        
        # Right panel - Forecast and wind map
        right_panel = tk.Frame(content_frame, bg="#0a192f")
        right_panel.pack(side="right", fill="both", expand=True, padx=5, pady=10)
        
        # Forecast section
        forecast_frame = tk.LabelFrame(
            right_panel, 
            text="24-Hour Forecast", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        forecast_frame.pack(fill="both", expand=True, padx=0, pady=(0, 5))
        
        # Create forecast chart
        fig1, ax1 = plt.subplots(figsize=(8, 3), facecolor="#112240")
        self.forecast_canvas = FigureCanvasTkAgg(fig1, master=forecast_frame)
        self.forecast_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        # Plot forecast data
        hours = list(range(24))
        temps = [forecast["temperature"] for forecast in self.forecast]
        wind_speeds = [forecast["wind_speed"] for forecast in self.forecast]
        conditions = [forecast["condition"] for forecast in self.forecast]
        
        # Primary y-axis for temperature
        ax1.plot(hours, temps, 'o-', color="#64ffda", label="Temperature")
        ax1.set_xlabel("Hours from now", color="white")
        ax1.set_ylabel("Temperature (°C)", color="#64ffda")
        ax1.tick_params(axis='y', colors="#64ffda")
        ax1.tick_params(axis='x', colors="white")
        ax1.set_facecolor("#1a2d3d")
        
        # Secondary y-axis for wind speed
        ax2 = ax1.twinx()
        ax2.plot(hours, wind_speeds, 'o-', color="#f39c12", label="Wind Speed")
        ax2.set_ylabel("Wind Speed (m/s)", color="#f39c12")
        ax2.tick_params(axis='y', colors="#f39c12")
        
        # Add markers for weather conditions
        for i, condition in enumerate(conditions):
            if condition != "Clear" and condition != "Partly Cloudy":
                ax1.annotate(
                    self.get_weather_icon(condition),
                    xy=(i, temps[i]),
                    xytext=(0, 10),
                    textcoords="offset points",
                    ha='center',
                    fontsize=12,
                    color="white"
                )
        
        # Add legend
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', 
                  facecolor="#112240", edgecolor="white", labelcolor="white")
        
        # Clean up plot
        for spine in ax1.spines.values():
            spine.set_edgecolor("white")
        
        fig1.tight_layout()
        
        # Wind map section
        wind_frame = tk.LabelFrame(
            right_panel, 
            text="Wind Map", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        wind_frame.pack(fill="both", expand=True, padx=0, pady=(5, 0))
        
        # Create wind map
        fig2, ax2 = plt.subplots(figsize=(6, 5), facecolor="#112240")
        self.wind_canvas = FigureCanvasTkAgg(fig2, master=wind_frame)
        self.wind_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        # Generate wind field data
        x = np.linspace(0, 10, 20)
        y = np.linspace(0, 10, 20)
        X, Y = np.meshgrid(x, y)
        
        # Create vector field for wind
        # This is a simplified model - would be more complex in a real system
        U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.1
        V = np.ones(Y.shape) * 0.0
        
        # Adjust based on wind direction
        if self.current_weather["wind_direction"] == "North":
            U = np.zeros(X.shape)
            V = np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.1
        elif self.current_weather["wind_direction"] == "South":
            U = np.zeros(X.shape)
            V = -np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.1
        elif self.current_weather["wind_direction"] == "East":
            U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.1
            V = np.zeros(Y.shape)
        elif self.current_weather["wind_direction"] == "West":
            U = -np.ones(X.shape) * self.current_weather["wind_speed"] * 0.1
            V = np.zeros(Y.shape)
        elif self.current_weather["wind_direction"] == "Northeast":
            U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
            V = np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
        elif self.current_weather["wind_direction"] == "Northwest":
            U = -np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
            V = np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
        elif self.current_weather["wind_direction"] == "Southeast":
            U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
            V = -np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
        elif self.current_weather["wind_direction"] == "Southwest":
            U = -np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
            V = -np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
        
        # Add some variation
        U = U + np.random.uniform(-0.2, 0.2, U.shape)
        V = V + np.random.uniform(-0.2, 0.2, V.shape)
        
        # Plot wind vectors
        ax2.quiver(X, Y, U, V, color="#3498db", scale=1.0, pivot='mid')
        
        # Add defense system at center
        ax2.plot(5, 5, 'ro', markersize=10, color="#e74c3c")
        ax2.text(5, 5.5, "Defense System", ha='center', va='bottom', color="white")
        
        # Plot a few sample missile trajectories affected by wind
        # These are simplistic and illustrative only
        for i in range(4):
            # Random starting position near edge
            if i == 0:  # North
                start_x, start_y = 5, 10
            elif i == 1:  # East
                start_x, start_y = 10, 5
            elif i == 2:  # South
                start_x, start_y = 5, 0
            else:  # West
                start_x, start_y = 0, 5
            
            # Target is defense system
            target_x, target_y = 5, 5
            
            # Calculate direction vector
            dx = target_x - start_x
            dy = target_y - start_y
            dist = math.sqrt(dx*dx + dy*dy)
            dx /= dist
            dy /= dist
            
            # Generate path with wind influence
            path_x = [start_x]
            path_y = [start_y]
            
            current_x = start_x
            current_y = start_y
            
            wind_influence = min(1.0, self.current_weather["wind_speed"] / 20.0)
            
            for step in range(20):
                # Movement towards target
                current_x += dx * 0.5
                current_y += dy * 0.5
                
                # Influence of wind (approximate position in grid)
                grid_x = min(19, max(0, int(current_x)))
                grid_y = min(19, max(0, int(current_y)))
                
                # Apply wind vector
                current_x += U[grid_y, grid_x] * wind_influence
                current_y += V[grid_y, grid_x] * wind_influence
                
                path_x.append(current_x)
                path_y.append(current_y)
                
                # Stop if reached target vicinity
                if abs(current_x - target_x) < 0.2 and abs(current_y - target_y) < 0.2:
                    break
            
            # Plot missile path
            ax2.plot(path_x, path_y, '--', color="#f39c12", alpha=0.7)
            ax2.plot(start_x, start_y, 'o', color="#64ffda", markersize=6)
        
        # Add compass for direction reference
        self.add_compass(ax2, 8.5, 8.5, 1.0)
        
        # Set plot properties
        ax2.set_facecolor("#1a2d3d")
        ax2.set_xlim(0, 10)
        ax2.set_ylim(0, 10)
        ax2.set_xticks([])
        ax2.set_yticks([])
        
        # Add title with current wind info
        ax2.set_title(
            f"Wind: {self.current_weather['wind_speed']} m/s from {self.current_weather['wind_direction']}", 
            color="white"
        )
        
        for spine in ax2.spines.values():
            spine.set_edgecolor("white")
        
        fig2.tight_layout()
        
        # Control panel
        control_frame = tk.Frame(self.frame, bg="#0a192f")
        control_frame.pack(fill="x", pady=10)
        
        # Refresh button
        refresh_btn = ttk.Button(
            control_frame, 
            text="Refresh Weather Data", 
            command=self.update_weather
        )
        refresh_btn.pack(side="left", padx=10)
        
        # Simulation control
        self.sim_var = tk.BooleanVar(value=True)
        sim_cb = ttk.Checkbutton(
            control_frame,
            text="Auto-update weather",
            variable=self.sim_var,
            command=self.toggle_simulation
        )
        sim_cb.pack(side="left", padx=10)
        
        # Weather scenario dropdown
        scenario_frame = tk.Frame(control_frame, bg="#0a192f")
        scenario_frame.pack(side="right", padx=10)
        
        scenario_label = tk.Label(
            scenario_frame,
            text="Weather Scenario:",
            bg="#0a192f",
            fg="white"
        )
        scenario_label.pack(side="left", padx=(0, 5))
        
        self.scenario_var = tk.StringVar(value="Dynamic")
        scenarios = ["Dynamic", "Clear", "Stormy", "Foggy", "Windy", "Extreme"]
        
        scenario_cb = ttk.Combobox(
            scenario_frame,
            textvariable=self.scenario_var,
            values=scenarios,
            state="readonly",
            width=10
        )
        scenario_cb.pack(side="left")
        scenario_cb.bind("<<ComboboxSelected>>", self.change_scenario)
    
    def get_weather_icon(self, condition):
        """Return a text icon for weather condition"""
        icons = {
            "Clear": "☀️",
            "Partly Cloudy": "⛅",
            "Cloudy": "☁️",
            "Rain": "🌧️",
            "Heavy Rain": "⛈️",
            "Thunderstorm": "🌩️",
            "Snow": "❄️",
            "Fog": "🌫️",
            "Sandstorm": "🌪️",
            "High Winds": "💨"
        }
        return icons.get(condition, "☀️")
    
    def add_compass(self, ax, x, y, size):
        """Add a compass indicator to the plot"""
        # Directions
        directions = [
            ("N", 0, size), 
            ("E", size, 0), 
            ("S", 0, -size), 
            ("W", -size, 0)
        ]
        
        # Draw circle
        circle = plt.Circle((x, y), size*0.8, fill=False, color="white", alpha=0.5)
        ax.add_artist(circle)
        
        # Draw direction markers
        for label, dx, dy in directions:
            ax.plot([x, x+dx*0.7], [y, y+dy*0.7], '-', color="white", alpha=0.5)
            ax.text(x+dx*0.8, y+dy*0.8, label, ha='center', va='center', color="white")
    
    def generate_forecast(self):
        """Generate a 24-hour weather forecast"""
        forecast = []
        
        # Start with current conditions
        prev_condition = self.current_weather["condition"]
        prev_temp = self.current_weather["temperature"]
        prev_wind_speed = self.current_weather["wind_speed"]
        prev_wind_dir = self.current_weather["wind_direction"]
        
        # Direction change options
        wind_dirs = ["North", "Northeast", "East", "Southeast", 
                    "South", "Southwest", "West", "Northwest"]
        
        for hour in range(24):
            # Temperature typically varies by time of day
            # Simple model: coolest at 5am, warmest at 2pm
            hour_of_day = (datetime.datetime.now().hour + hour) % 24
            temp_offset = -3 if (hour_of_day < 6) else 3 if (10 <= hour_of_day <= 16) else 0
            
            # Add some randomness to weather changes
            if random.random() < 0.3:  # 30% chance of condition change each hour
                # Weighted change based on current condition
                if prev_condition in ["Clear", "Partly Cloudy"]:
                    # Good weather more likely to stay good
                    new_condition = random.choices(
                        self.weather_types,
                        weights=[0.5, 0.3, 0.1, 0.05, 0.02, 0.01, 0.01, 0.01, 0, 0],
                        k=1
                    )[0]
                elif prev_condition in ["Rain", "Heavy Rain", "Thunderstorm"]:
                    # Bad weather tends to persist
                    new_condition = random.choices(
                        self.weather_types,
                        weights=[0.05, 0.1, 0.2, 0.3, 0.2, 0.1, 0.02, 0.02, 0.01, 0],
                        k=1
                    )[0]
                else:
                    # Other conditions
                    new_condition = random.choices(
                        self.weather_types,
                        weights=[0.2, 0.2, 0.2, 0.1, 0.05, 0.05, 0.05, 0.1, 0.03, 0.02],
                        k=1
                    )[0]
            else:
                new_condition = prev_condition
            
            # Temperature variations
            temp_change = random.uniform(-1, 1)
            new_temp = prev_temp + temp_change + temp_offset * 0.1
            
            # Wind variations
            wind_change = random.uniform(-1, 1)
            new_wind_speed = max(0, min(25, prev_wind_speed + wind_change))
            
            # Wind direction sometimes changes
            if random.random() < 0.2:  # 20% chance each hour
                current_idx = wind_dirs.index(prev_wind_dir) if prev_wind_dir in wind_dirs else 0
                # Usually shifts by one direction at most
                direction_shift = random.choice([-1, 0, 1])
                new_idx = (current_idx + direction_shift) % len(wind_dirs)
                new_wind_dir = wind_dirs[new_idx]
            else:
                new_wind_dir = prev_wind_dir
            
            # Create forecast entry
            forecast.append({
                "hour": hour,
                "condition": new_condition,
                "temperature": round(new_temp, 1),
                "wind_speed": round(new_wind_speed, 1),
                "wind_direction": new_wind_dir
            })
            
            # Update previous values for next iteration
            prev_condition = new_condition
            prev_temp = new_temp
            prev_wind_speed = new_wind_speed
            prev_wind_dir = new_wind_dir
        
        return forecast
    
    def update_weather(self):
        """Update current weather conditions"""
        # Update time
        self.last_update = datetime.datetime.now()
        
        # Get next forecast hour
        next_forecast = self.forecast[0]
        
        # Update current weather from forecast
        self.current_weather["condition"] = next_forecast["condition"]
        self.current_weather["temperature"] = next_forecast["temperature"]
        self.current_weather["wind_speed"] = next_forecast["wind_speed"]
        self.current_weather["wind_direction"] = next_forecast["wind_direction"]
        
        # Update other parameters based on condition
        self.update_derived_parameters()
        
        # Shift forecast (remove first hour, add new last hour)
        self.forecast = self.forecast[1:] + [self.generate_next_forecast_hour()]
        
        # Update UI if available
        if hasattr(self, 'condition_var'):
            self.update_weather_ui()
    
    def update_derived_parameters(self):
        """Update weather parameters derived from primary conditions"""
        condition = self.current_weather["condition"]
        
        # Visibility based on condition
        if condition == "Clear":
            self.current_weather["visibility"] = round(random.uniform(20, 30), 1)
        elif condition == "Partly Cloudy":
            self.current_weather["visibility"] = round(random.uniform(15, 25), 1)
        elif condition == "Cloudy":
            self.current_weather["visibility"] = round(random.uniform(10, 20), 1)
        elif condition == "Rain":
            self.current_weather["visibility"] = round(random.uniform(5, 10), 1)
        elif condition == "Heavy Rain":
            self.current_weather["visibility"] = round(random.uniform(2, 5), 1)
        elif condition == "Thunderstorm":
            self.current_weather["visibility"] = round(random.uniform(1, 3), 1)
        elif condition == "Snow":
            self.current_weather["visibility"] = round(random.uniform(2, 7), 1)
        elif condition == "Fog":
            self.current_weather["visibility"] = round(random.uniform(0.5, 2), 1)
        elif condition == "Sandstorm":
            self.current_weather["visibility"] = round(random.uniform(0.1, 1), 1)
        elif condition == "High Winds":
            self.current_weather["visibility"] = round(random.uniform(5, 15), 1)
        
        # Humidity based on condition
        if condition in ["Rain", "Heavy Rain", "Thunderstorm"]:
            self.current_weather["humidity"] = random.randint(80, 100)
        elif condition in ["Snow", "Fog"]:
            self.current_weather["humidity"] = random.randint(70, 95)
        elif condition in ["Clear", "Partly Cloudy"]:
            self.current_weather["humidity"] = random.randint(30, 70)
        else:
            self.current_weather["humidity"] = random.randint(40, 80)
        
        # Pressure - typically lower in storms
        if condition in ["Thunderstorm", "Heavy Rain"]:
            self.current_weather["pressure"] = random.randint(970, 1000)
        elif condition in ["Rain", "Snow"]:
            self.current_weather["pressure"] = random.randint(990, 1010)
        elif condition == "High Winds":
            self.current_weather["pressure"] = random.randint(980, 1020)
        else:
            self.current_weather["pressure"] = random.randint(1000, 1030)
        
        # Precipitation
        if condition == "Heavy Rain":
            self.current_weather["precipitation"] = round(random.uniform(10, 30), 1)
        elif condition == "Rain":
            self.current_weather["precipitation"] = round(random.uniform(2, 10), 1)
        elif condition == "Thunderstorm":
            self.current_weather["precipitation"] = round(random.uniform(5, 40), 1)
        elif condition == "Snow":
            self.current_weather["precipitation"] = round(random.uniform(1, 5), 1)
        else:
            self.current_weather["precipitation"] = 0
    
    def generate_next_forecast_hour(self):
        """Generate a new forecast hour to add to the end of the forecast"""
        # Get the last forecast hour
        last = self.forecast[-1]
        
        # Hour of day for the new forecast (for temperature patterns)
        hour_of_day = (datetime.datetime.now().hour + 24) % 24
        temp_offset = -3 if (hour_of_day < 6) else 3 if (10 <= hour_of_day <= 16) else 0
        
        # Similar logic to generate_forecast, but for just one hour
        if random.random() < 0.3:
            if last["condition"] in ["Clear", "Partly Cloudy"]:
                new_condition = random.choices(
                    self.weather_types,
                    weights=[0.5, 0.3, 0.1, 0.05, 0.02, 0.01, 0.01, 0.01, 0, 0],
                    k=1
                )[0]
            elif last["condition"] in ["Rain", "Heavy Rain", "Thunderstorm"]:
                new_condition = random.choices(
                    self.weather_types,
                    weights=[0.05, 0.1, 0.2, 0.3, 0.2, 0.1, 0.02, 0.02, 0.01, 0],
                    k=1
                )[0]
            else:
                new_condition = random.choices(
                    self.weather_types,
                    weights=[0.2, 0.2, 0.2, 0.1, 0.05, 0.05, 0.05, 0.1, 0.03, 0.02],
                    k=1
                )[0]
        else:
            new_condition = last["condition"]
        
        # Temperature variations
        temp_change = random.uniform(-1, 1)
        new_temp = last["temperature"] + temp_change + temp_offset * 0.1
        
        # Wind variations
        wind_change = random.uniform(-1, 1)
        new_wind_speed = max(0, min(25, last["wind_speed"] + wind_change))
        
        # Wind direction
        wind_dirs = ["North", "Northeast", "East", "Southeast", 
                    "South", "Southwest", "West", "Northwest"]
        if random.random() < 0.2:
            current_idx = wind_dirs.index(last["wind_direction"]) if last["wind_direction"] in wind_dirs else 0
            direction_shift = random.choice([-1, 0, 1])
            new_idx = (current_idx + direction_shift) % len(wind_dirs)
            new_wind_dir = wind_dirs[new_idx]
        else:
            new_wind_dir = last["wind_direction"]
        
        # Create and return new forecast entry
        return {
            "hour": 24,  # Will be the last hour in the forecast
            "condition": new_condition,
            "temperature": round(new_temp, 1),
            "wind_speed": round(new_wind_speed, 1),
            "wind_direction": new_wind_dir
        }
    
    def update_weather_ui(self):
        """Update the weather UI with current conditions"""
        # Update weather condition text and icon
        self.condition_var.set(self.current_weather["condition"])
        self.temperature_var.set(f"{self.current_weather['temperature']}°C")
        self.wind_var.set(f"{self.current_weather['wind_speed']} m/s {self.current_weather['wind_direction']}")
        
        # Update other parameters
        self.visibility_var.set(f"{self.current_weather['visibility']} km")
        self.humidity_var.set(f"{self.current_weather['humidity']}%")
        self.pressure_var.set(f"{self.current_weather['pressure']} hPa")
        self.precipitation_var.set(f"{self.current_weather['precipitation']} mm/h")
        
        # Update impact factors
        factors = self.impact_factors.get(self.current_weather["condition"], 
                                       {"radar": 1.0, "targeting": 1.0, "missile_speed": 1.0})
        
        self.radar_var.set(f"{factors['radar']*100:.0f}%")
        self.targeting_var.set(f"{factors['targeting']*100:.0f}%")
        self.missile_speed_var.set(f"{factors['missile_speed']*100:.0f}%")
        
        # Update forecast chart
        if hasattr(self, 'forecast_canvas'):
            # Get the figure from the canvas
            fig = self.forecast_canvas.figure
            ax1 = fig.axes[0]
            ax2 = fig.axes[1]
            
            # Clear the axes
            ax1.clear()
            ax2.clear()
            
            # Plot forecast data
            hours = list(range(24))
            temps = [forecast["temperature"] for forecast in self.forecast]
            wind_speeds = [forecast["wind_speed"] for forecast in self.forecast]
            conditions = [forecast["condition"] for forecast in self.forecast]
            
            # Primary y-axis for temperature
            ax1.plot(hours, temps, 'o-', color="#64ffda", label="Temperature")
            ax1.set_xlabel("Hours from now", color="white")
            ax1.set_ylabel("Temperature (°C)", color="#64ffda")
            ax1.tick_params(axis='y', colors="#64ffda")
            ax1.tick_params(axis='x', colors="white")
            ax1.set_facecolor("#1a2d3d")
            
            # Secondary y-axis for wind speed
            ax2.plot(hours, wind_speeds, 'o-', color="#f39c12", label="Wind Speed")
            ax2.set_ylabel("Wind Speed (m/s)", color="#f39c12")
            ax2.tick_params(axis='y', colors="#f39c12")
            
            # Add markers for weather conditions
            for i, condition in enumerate(conditions):
                if condition != "Clear" and condition != "Partly Cloudy":
                    ax1.annotate(
                        self.get_weather_icon(condition),
                        xy=(i, temps[i]),
                        xytext=(0, 10),
                        textcoords="offset points",
                        ha='center',
                        fontsize=12,
                        color="white"
                    )
            
            # Add legend
            lines1, labels1 = ax1.get_legend_handles_labels()
            lines2, labels2 = ax2.get_legend_handles_labels()
            ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', 
                      facecolor="#112240", edgecolor="white", labelcolor="white")
            
            # Clean up plot
            for spine in ax1.spines.values():
                spine.set_edgecolor("white")
            
            fig.tight_layout()
            self.forecast_canvas.draw()
        
        # Update wind map
        if hasattr(self, 'wind_canvas'):
            # Get the figure from the canvas
            fig = self.wind_canvas.figure
            ax = fig.axes[0]
            
            # Clear the axes
            ax.clear()
            
            # Generate wind field data
            x = np.linspace(0, 10, 20)
            y = np.linspace(0, 10, 20)
            X, Y = np.meshgrid(x, y)
            
            # Create vector field for wind
            U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.1
            V = np.ones(Y.shape) * 0.0
            
            # Adjust based on wind direction
            if self.current_weather["wind_direction"] == "North":
                U = np.zeros(X.shape)
                V = np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.1
            elif self.current_weather["wind_direction"] == "South":
                U = np.zeros(X.shape)
                V = -np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.1
            elif self.current_weather["wind_direction"] == "East":
                U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.1
                V = np.zeros(Y.shape)
            elif self.current_weather["wind_direction"] == "West":
                U = -np.ones(X.shape) * self.current_weather["wind_speed"] * 0.1
                V = np.zeros(Y.shape)
            elif self.current_weather["wind_direction"] == "Northeast":
                U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
                V = np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
            elif self.current_weather["wind_direction"] == "Northwest":
                U = -np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
                V = np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
            elif self.current_weather["wind_direction"] == "Southeast":
                U = np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
                V = -np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
            elif self.current_weather["wind_direction"] == "Southwest":
                U = -np.ones(X.shape) * self.current_weather["wind_speed"] * 0.07
                V = -np.ones(Y.shape) * self.current_weather["wind_speed"] * 0.07
            
            # Add some variation
            U = U + np.random.uniform(-0.2, 0.2, U.shape)
            V = V + np.random.uniform(-0.2, 0.2, V.shape)
            
            # Plot wind vectors
            ax.quiver(X, Y, U, V, color="#3498db", scale=1.0, pivot='mid')
            
            # Add defense system at center
            ax.plot(5, 5, 'ro', markersize=10, color="#e74c3c")
            ax.text(5, 5.5, "Defense System", ha='center', va='bottom', color="white")
            
            # Plot a few sample missile trajectories affected by wind
            for i in range(4):
                # Random starting position near edge
                if i == 0:  # North
                    start_x, start_y = 5, 10
                elif i == 1:  # East
                    start_x, start_y = 10, 5
                elif i == 2:  # South
                    start_x, start_y = 5, 0
                else:  # West
                    start_x, start_y = 0, 5
                
                # Target is defense system
                target_x, target_y = 5, 5
                
                # Calculate direction vector
                dx = target_x - start_x
                dy = target_y - start_y
                dist = math.sqrt(dx*dx + dy*dy)
                dx /= dist
                dy /= dist
                
                # Generate path with wind influence
                path_x = [start_x]
                path_y = [start_y]
                
                current_x = start_x
                current_y = start_y
                
                wind_influence = min(1.0, self.current_weather["wind_speed"] / 20.0)
                
                for step in range(20):
                    # Movement towards target
                    current_x += dx * 0.5
                    current_y += dy * 0.5
                    
                    # Influence of wind (approximate position in grid)
                    grid_x = min(19, max(0, int(current_x)))
                    grid_y = min(19, max(0, int(current_y)))
                    
                    # Apply wind vector
                    current_x += U[grid_y, grid_x] * wind_influence
                    current_y += V[grid_y, grid_x] * wind_influence
                    
                    path_x.append(current_x)
                    path_y.append(current_y)
                    
                    # Stop if reached target vicinity
                    if abs(current_x - target_x) < 0.2 and abs(current_y - target_y) < 0.2:
                        break
                
                # Plot missile path
                ax.plot(path_x, path_y, '--', color="#f39c12", alpha=0.7)
                ax.plot(start_x, start_y, 'o', color="#64ffda", markersize=6)
            
            # Add compass for direction reference
            self.add_compass(ax, 8.5, 8.5, 1.0)
            
            # Set plot properties
            ax.set_facecolor("#1a2d3d")
            ax.set_xlim(0, 10)
            ax.set_ylim(0, 10)
            ax.set_xticks([])
            ax.set_yticks([])
            
            # Add title with current wind info
            ax.set_title(
                f"Wind: {self.current_weather['wind_speed']} m/s from {self.current_weather['wind_direction']}", 
                color="white"
            )
            
            for spine in ax.spines.values():
                spine.set_edgecolor("white")
            
            fig.tight_layout()
            self.wind_canvas.draw()
    
    def change_scenario(self, event=None):
        """Change the weather scenario based on selection"""
        scenario = self.scenario_var.get()
        
        if scenario == "Clear":
            self.current_weather["condition"] = "Clear"
            self.current_weather["wind_speed"] = random.uniform(0, 5)
            self.current_weather["temperature"] = random.uniform(15, 25)
        elif scenario == "Stormy":
            self.current_weather["condition"] = random.choice(["Heavy Rain", "Thunderstorm"])
            self.current_weather["wind_speed"] = random.uniform(10, 20)
            self.current_weather["temperature"] = random.uniform(10, 20)
        elif scenario == "Foggy":
            self.current_weather["condition"] = "Fog"
            self.current_weather["wind_speed"] = random.uniform(0, 5)
            self.current_weather["temperature"] = random.uniform(5, 15)
        elif scenario == "Windy":
            self.current_weather["condition"] = "High Winds"
            self.current_weather["wind_speed"] = random.uniform(15, 25)
            self.current_weather["temperature"] = random.uniform(10, 20)
        elif scenario == "Extreme":
            self.current_weather["condition"] = random.choice(["Thunderstorm", "Sandstorm", "Heavy Rain"])
            self.current_weather["wind_speed"] = random.uniform(20, 30)
            self.current_weather["temperature"] = random.uniform(0, 35)
        
        # Random wind direction
        directions = ["North", "Northeast", "East", "Southeast", "South", "Southwest", "West", "Northwest"]
        self.current_weather["wind_direction"] = random.choice(directions)
        
        # Update derived parameters
        self.update_derived_parameters()
        
        # Generate new forecast based on current conditions
        self.forecast = self.generate_forecast()
        
        # Update UI
        if hasattr(self, 'condition_var'):
            self.update_weather_ui()
    
    def toggle_simulation(self):
        """Toggle weather simulation on/off"""
        if self.sim_var.get():
            self.start_weather_simulation()
        else:
            self.stop_weather_simulation()
    
    def start_weather_simulation(self):
        """Start the weather simulation thread"""
        self.running = True
        self.weather_thread = threading.Thread(target=self._weather_simulation_loop)
        self.weather_thread.daemon = True
        self.weather_thread.start()
    
    def stop_weather_simulation(self):
        """Stop the weather simulation thread"""
        self.running = False
        if self.weather_thread:
            self.weather_thread.join(timeout=1.0)
            self.weather_thread = None
    
    def _weather_simulation_loop(self):
        """Main loop for weather simulation thread"""
        while self.running:
            # Check if update interval has passed
            now = datetime.datetime.now()
            time_diff = (now - self.last_update).total_seconds()
            
            if time_diff >= self.update_interval:
                # Update weather in main thread
                if hasattr(self.parent, 'root'):
                    self.parent.root.after(0, self.update_weather)
                else:
                    self.update_weather()
            
            # Sleep for a bit to avoid consuming too much CPU
            time.sleep(1)
    
    def get_current_weather_impact(self):
        """Get the impact factors of current weather on defense systems"""
        return self.impact_factors.get(self.current_weather["condition"], 
                                    {"radar": 1.0, "targeting": 1.0, "missile_speed": 1.0})
    
    def apply_weather_effects(self, threat):
        """Apply weather effects to a threat's trajectory and speed"""
        if not threat:
            return threat
        
        # Get current weather impact
        impact = self.get_current_weather_impact()
        
        # Create a copy of the threat to modify
        modified_threat = dict(threat)
        
        # Apply wind effects to heading (simplified model)
        heading_map = {
            "North": 0, "Northeast": 45, "East": 90, "Southeast": 135,
            "South": 180, "Southwest": 225, "West": 270, "Northwest": 315
        }
        
        # Convert threat heading to degrees
        threat_heading_deg = heading_map.get(threat.get('heading', 'North'), 0)
        
        # Wind direction is where it's coming from, so add 180 degrees
        wind_dir_deg = (heading_map.get(self.current_weather['wind_direction'], 0) + 180) % 360
        
        # Calculate angle between wind and threat trajectory
        angle_diff = abs(((wind_dir_deg - threat_heading_deg) + 180) % 360 - 180)
        
        # Wind effect is maximum when it's a crosswind (90 degrees)
        crosswind_factor = math.sin(math.radians(angle_diff))
        
        # Calculate wind deflection
        wind_strength = min(1.0, self.current_weather['wind_speed'] / 15.0)
        deflection = crosswind_factor * wind_strength * 30  # max 30 degrees deflection
        
        # Apply deflection to trajectory - this would be handled by the missile path calculation
        # Just storing the deflection value for now
        modified_threat['wind_deflection'] = deflection
        
        # Adjust speed based on weather
        # Headwinds slow down, tailwinds speed up (simplified)
        tailwind_factor = math.cos(math.radians(angle_diff))
        speed_adjustment = tailwind_factor * wind_strength * 0.1  # +/- 10%
        
        # Apply missile speed factor from weather conditions
        modified_threat['speed'] = threat.get('speed', 500) * (impact['missile_speed'] + speed_adjustment)
        
        # Return modified threat
        return modified_threat
    
    def adjust_intercept_probability(self, base_probability, intercept_distance):
        """Adjust intercept success probability based on weather conditions"""
        if not hasattr(self, 'current_weather'):
            return base_probability
            
        # Get current weather impact
        impact = self.get_current_weather_impact()
        
        # Different impact based on distance
        # Targeting is more affected at longer distances
        distance_factor = min(1.0, intercept_distance / 300)  # Normalized to 300km max
        targeting_impact = 1.0 - distance_factor * (1.0 - impact['targeting'])
        
        # Radar is constantly affected
        radar_impact = impact['radar']
        
        # Combined weather impact (weighted average)
        combined_impact = radar_impact * 0.4 + targeting_impact * 0.6
        
        # Apply to base probability
        adjusted_probability = base_probability * combined_impact
        
        # Cap the probability
        return max(0.1, min(0.95, adjusted_probability))

# Function to integrate weather system with main GUI
def integrate_weather(missile_defense_gui):
    """Integrate weather system with the main GUI"""
    # Add weather tab
    missile_defense_gui.weather_tab = ttk.Frame(missile_defense_gui.tab_control)
    missile_defense_gui.tab_control.add(missile_defense_gui.weather_tab, text="Weather")
    
    # Create weather system
    missile_defense_gui.weather = WeatherSystem(missile_defense_gui)
    
    # Modify intercept_threat method to account for weather
    original_intercept = missile_defense_gui._intercept_threat_thread
    
    def intercept_with_weather(self, target):
        # Apply weather effects
        if hasattr(self, 'weather'):
            modified_target = self.weather.apply_weather_effects(target)
            
            # Note the modification in logs if significant
            if abs(modified_target.get('speed', 0) - target.get('speed', 0)) > 50:
                speed_diff = modified_target.get('speed', 0) - target.get('speed', 0)
                self.write_to_console(
                    self.intercept_console,
                    f"Weather affecting threat: Speed {speed_diff:.1f} km/h due to wind conditions\n"
                )
            
            if abs(modified_target.get('wind_deflection', 0)) > 5:
                self.write_to_console(
                    self.intercept_console,
                    f"Weather affecting threat: Trajectory deflected by {modified_target.get('wind_deflection', 0):.1f}° due to crosswinds\n"
                )
            
            # Call original method with modified target
            return original_intercept(modified_target)
        else:
            # Call original method without modification
            return original_intercept(target)
    
    # Replace the method
    missile_defense_gui._intercept_threat_thread = intercept_with_weather.__get__(missile_defense_gui, type(missile_defense_gui))
    
    # Modify calculate_success_probability to account for weather
    from military_algorithms import DefenseOptimization
    original_calculate = DefenseOptimization.calculate_success_probability
    
    def calculate_with_weather(threat, defense_system, intercept_distance):
        # Calculate base probability
        base_probability = original_calculate(threat, defense_system, intercept_distance)
        
        # Adjust for weather if the GUI has a weather system
        if hasattr(missile_defense_gui, 'weather'):
            adjusted_probability = missile_defense_gui.weather.adjust_intercept_probability(
                base_probability, intercept_distance
            )
            return adjusted_probability
        else:
            return base_probability
    
    # Replace the method
    DefenseOptimization.calculate_success_probability = staticmethod(calculate_with_weather)
    
    return missile_defense_gui
