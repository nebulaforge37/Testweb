
import os
import time
import random
from datetime import datetime
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

class MissileDefenseSystem:
    def __init__(self, name, country, type, range_class):
        self.name = name
        self.country = country
        self.type = type  # Surface-to-air, anti-ballistic, etc.
        self.range_class = range_class  # Short, medium, long range
        self.operational = True
        self.ammo = 100
        self.battery_level = 100
        self.last_maintenance = datetime.now()

    def __str__(self):
        return f"{self.name} ({self.country}): {self.type}, {self.range_class}"
    
    def fire(self, target):
        if not self.operational:
            return False, f"ERROR: {self.name} is not operational"
        if self.ammo <= 0:
            return False, f"ERROR: {self.name} is out of ammunition"
        
        self.ammo -= 1
        self.battery_level -= 2
        hit_chance = random.random()
        
        # Simulate system effectiveness
        success = hit_chance > 0.3
        
        return success, f"{'TARGET NEUTRALIZED' if success else 'TARGET MISSED'}: {self.name} fired at {target}"
    
    def perform_maintenance(self):
        self.operational = True
        self.battery_level = 100
        self.last_maintenance = datetime.now()
        return f"Maintenance complete on {self.name}"
        
    def reload(self, amount=100):
        self.ammo = min(self.ammo + amount, 100)
        return f"Reload complete. {self.name} now has {self.ammo} missiles"

class MissileDefenseGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Missile Defense System")
        self.root.geometry("900x600")
        self.root.configure(bg="#2c3e50")  # Dark blue background
        
        # Initialize missile defense system
        self.defense_os = MissileDefenseOS()
        
        # Set up the main frame
        self.setup_ui()
        
        # Start with welcome screen
        self.show_welcome_screen()
        
    def setup_ui(self):
        # Main container
        self.main_frame = tk.Frame(self.root, bg="#2c3e50")
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Header frame
        self.header_frame = tk.Frame(self.main_frame, bg="#34495e")
        self.header_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.title_label = tk.Label(self.header_frame, text="MISSILE DEFENSE SYSTEM", font=("Arial", 16, "bold"), 
                                    bg="#34495e", fg="#ecf0f1")
        self.title_label.pack(pady=10)
        
        self.status_frame = tk.Frame(self.header_frame, bg="#34495e")
        self.status_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Left status info
        self.left_status = tk.Frame(self.status_frame, bg="#34495e")
        self.left_status.pack(side=tk.LEFT)
        
        self.date_label = tk.Label(self.left_status, text=f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 
                                  bg="#34495e", fg="#ecf0f1")
        self.date_label.pack(anchor=tk.W)
        
        self.threat_label = tk.Label(self.left_status, text="Threat Level: Low", bg="#34495e", fg="#2ecc71")
        self.threat_label.pack(anchor=tk.W)
        
        # Right status info
        self.right_status = tk.Frame(self.status_frame, bg="#34495e")
        self.right_status.pack(side=tk.RIGHT)
        
        self.active_system_label = tk.Label(self.right_status, text="Active System: None", 
                                          bg="#34495e", fg="#ecf0f1")
        self.active_system_label.pack(anchor=tk.E)
        
        # Content frame that will be replaced based on the selected option
        self.content_frame = tk.Frame(self.main_frame, bg="#2c3e50")
        self.content_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Bottom controls frame
        self.controls_frame = tk.Frame(self.main_frame, bg="#34495e")
        self.controls_frame.pack(fill=tk.X, side=tk.BOTTOM, padx=5, pady=5)
        
        # Log display
        self.log_frame = tk.Frame(self.main_frame, bg="#34495e")
        self.log_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.log_label = tk.Label(self.log_frame, text="System Log", font=("Arial", 10, "bold"), 
                                 bg="#34495e", fg="#ecf0f1")
        self.log_label.pack(anchor=tk.W, padx=5)
        
        self.log_text = scrolledtext.ScrolledText(self.log_frame, height=8, bg="#1c2e3e", fg="#ecf0f1")
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.log_text.config(state=tk.DISABLED)
        
    def clear_content_frame(self):
        # Remove all widgets from the content frame
        for widget in self.content_frame.winfo_children():
            widget.destroy()
            
    def update_status_bar(self):
        # Update date and time
        self.date_label.config(text=f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Update threat level with color
        threat_colors = {"Low": "#2ecc71", "Medium": "#f39c12", "High": "#e74c3c"}
        self.threat_label.config(text=f"Threat Level: {self.defense_os.threat_level}", 
                               fg=threat_colors[self.defense_os.threat_level])
        
        # Update active system
        if self.defense_os.active_system:
            self.active_system_label.config(text=f"Active System: {self.defense_os.active_system.name}")
        else:
            self.active_system_label.config(text="Active System: None")
            
    def log_message(self, message):
        # Enable the text widget temporarily to insert text
        self.log_text.config(state=tk.NORMAL)
        
        # Add timestamp to the message
        timestamp = datetime.now().strftime("%H:%M:%S")
        full_message = f"[{timestamp}] {message}\n"
        
        # Insert message at the end
        self.log_text.insert(tk.END, full_message)
        
        # Scroll to the end
        self.log_text.see(tk.END)
        
        # Disable text widget again
        self.log_text.config(state=tk.DISABLED)
        
    def show_welcome_screen(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        # Welcome message
        welcome_label = tk.Label(self.content_frame, text="Welcome to the Missile Defense System", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        welcome_label.pack(pady=20)
        
        subtitle_label = tk.Label(self.content_frame, text="Select an operation from the main menu", 
                                font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
        subtitle_label.pack(pady=10)
        
        # Create a frame for the buttons
        button_frame = tk.Frame(self.content_frame, bg="#2c3e50")
        button_frame.pack(pady=30)
        
        # Create main menu buttons
        menu_options = [
            ("Select Defense System", self.show_select_system),
            ("System Status Report", self.show_system_status),
            ("Threat Detection", self.run_threat_detection),
            ("Intercept Mode", self.show_intercept_mode),
            ("Maintenance Operations", self.show_maintenance),
            ("Simulation Mode", self.run_simulation)
        ]
        
        for text, command in menu_options:
            btn = tk.Button(button_frame, text=text, command=command, font=("Arial", 11),
                          bg="#3498db", fg="white", width=20, height=2)
            btn.pack(pady=5)
        
        # Exit button
        exit_btn = tk.Button(button_frame, text="Exit", command=self.root.destroy, font=("Arial", 11),
                            bg="#e74c3c", fg="white", width=20, height=2)
        exit_btn.pack(pady=5)
        
        self.log_message("System initialized. Ready for operations.")
            
    def show_select_system(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        # Header
        header_label = tk.Label(self.content_frame, text="Select Defense System", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        header_label.pack(pady=10)
        
        # Create a frame for the system list
        list_frame = tk.Frame(self.content_frame, bg="#34495e")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create a treeview to display systems
        columns = ("Name", "Country", "Type", "Range", "Status")
        tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=15)
        
        # Define column headings
        for col in columns:
            tree.heading(col, text=col)
            width = 120 if col != "Type" else 180
            tree.column(col, width=width)
        
        # Insert systems into the treeview
        for i, system in enumerate(self.defense_os.systems):
            status = "OPERATIONAL" if system.operational else "OFFLINE"
            tree.insert("", tk.END, values=(system.name, system.country, system.type, 
                                           system.range_class, status))
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Frame for the selection button
        button_frame = tk.Frame(self.content_frame, bg="#2c3e50")
        button_frame.pack(fill=tk.X, pady=10)
        
        # Function to handle system selection
        def select_system():
            selected_items = tree.selection()
            if not selected_items:
                messagebox.showwarning("No Selection", "Please select a defense system from the list.")
                return
                
            index = tree.index(selected_items[0])
            self.defense_os.active_system = self.defense_os.systems[index]
            self.update_status_bar()
            self.log_message(f"System {self.defense_os.active_system.name} activated.")
            messagebox.showinfo("System Activated", f"{self.defense_os.active_system.name} is now the active defense system.")
        
        # Selection button
        select_btn = tk.Button(button_frame, text="Activate Selected System", command=select_system,
                             bg="#27ae60", fg="white", font=("Arial", 10))
        select_btn.pack(side=tk.LEFT, padx=10)
        
        # Back button
        back_btn = tk.Button(button_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                            bg="#7f8c8d", fg="white", font=("Arial", 10))
        back_btn.pack(side=tk.RIGHT, padx=10)
        
    def show_system_status(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        if not self.defense_os.active_system:
            # If no system is selected, show warning
            warning_label = tk.Label(self.content_frame, text="No defense system selected!", 
                                   font=("Arial", 14, "bold"), bg="#2c3e50", fg="#e74c3c")
            warning_label.pack(pady=20)
            
            info_label = tk.Label(self.content_frame, text="Please select a defense system first.", 
                                font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
            info_label.pack(pady=10)
            
            back_btn = tk.Button(self.content_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                               bg="#7f8c8d", fg="white", font=("Arial", 10))
            back_btn.pack(pady=20)
            return
        
        # Get the active system
        system = self.defense_os.active_system
        
        # Header
        header_label = tk.Label(self.content_frame, text=f"System Status: {system.name}", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        header_label.pack(pady=10)
        
        # Status panel
        status_panel = tk.Frame(self.content_frame, bg="#34495e", padx=15, pady=15)
        status_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # System details
        details_frame = tk.Frame(status_panel, bg="#34495e")
        details_frame.pack(fill=tk.X, pady=5)
        
        details = [
            ("System Name", system.name),
            ("Country of Origin", system.country),
            ("Type", system.type),
            ("Range Class", system.range_class),
            ("Status", "OPERATIONAL" if system.operational else "OFFLINE"),
            ("Last Maintenance", system.last_maintenance.strftime("%Y-%m-%d %H:%M:%S"))
        ]
        
        for row, (label_text, value) in enumerate(details):
            label = tk.Label(details_frame, text=f"{label_text}:", font=("Arial", 10, "bold"),
                           bg="#34495e", fg="#3498db", anchor="w")
            label.grid(row=row, column=0, sticky="w", pady=3)
            
            value_label = tk.Label(details_frame, text=value, font=("Arial", 10),
                                 bg="#34495e", fg="#ecf0f1", anchor="w")
            value_label.grid(row=row, column=1, sticky="w", padx=10, pady=3)
        
        # System metrics
        metrics_frame = tk.Frame(status_panel, bg="#34495e", pady=10)
        metrics_frame.pack(fill=tk.X, pady=10)
        
        # Ammunition gauge
        ammo_label = tk.Label(metrics_frame, text="Ammunition:", font=("Arial", 10, "bold"),
                            bg="#34495e", fg="#ecf0f1")
        ammo_label.grid(row=0, column=0, sticky="w")
        
        ammo_progress = ttk.Progressbar(metrics_frame, orient=tk.HORIZONTAL, length=200, mode='determinate')
        ammo_progress['value'] = system.ammo
        ammo_progress.grid(row=0, column=1, padx=10)
        
        ammo_value = tk.Label(metrics_frame, text=f"{system.ammo}/100", font=("Arial", 10),
                            bg="#34495e", fg="#ecf0f1")
        ammo_value.grid(row=0, column=2)
        
        # Battery gauge
        battery_label = tk.Label(metrics_frame, text="Battery Level:", font=("Arial", 10, "bold"),
                               bg="#34495e", fg="#ecf0f1")
        battery_label.grid(row=1, column=0, sticky="w", pady=5)
        
        battery_progress = ttk.Progressbar(metrics_frame, orient=tk.HORIZONTAL, length=200, mode='determinate')
        battery_progress['value'] = system.battery_level
        battery_progress.grid(row=1, column=1, padx=10, pady=5)
        
        battery_value = tk.Label(metrics_frame, text=f"{system.battery_level}%", font=("Arial", 10),
                               bg="#34495e", fg="#ecf0f1")
        battery_value.grid(row=1, column=2, pady=5)
        
        # Action buttons
        buttons_frame = tk.Frame(self.content_frame, bg="#2c3e50")
        buttons_frame.pack(fill=tk.X, pady=10)
        
        # Maintenance button
        def do_maintenance():
            result = system.perform_maintenance()
            self.log_message(result)
            # Update battery progress
            battery_progress['value'] = system.battery_level
            battery_value.config(text=f"{system.battery_level}%")
            messagebox.showinfo("Maintenance", result)
        
        maintenance_btn = tk.Button(buttons_frame, text="Perform Maintenance", command=do_maintenance,
                                  bg="#e67e22", fg="white", font=("Arial", 10))
        maintenance_btn.pack(side=tk.LEFT, padx=10)
        
        # Reload button
        def do_reload():
            result = system.reload()
            self.log_message(result)
            # Update ammo progress
            ammo_progress['value'] = system.ammo
            ammo_value.config(text=f"{system.ammo}/100")
            messagebox.showinfo("Reload", result)
        
        reload_btn = tk.Button(buttons_frame, text="Reload Ammunition", command=do_reload,
                             bg="#e67e22", fg="white", font=("Arial", 10))
        reload_btn.pack(side=tk.LEFT, padx=10)
        
        # Back button
        back_btn = tk.Button(buttons_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                           bg="#7f8c8d", fg="white", font=("Arial", 10))
        back_btn.pack(side=tk.RIGHT, padx=10)
        
    def run_threat_detection(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        # Header
        header_label = tk.Label(self.content_frame, text="Threat Detection", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        header_label.pack(pady=10)
        
        # Status display
        status_display = scrolledtext.ScrolledText(self.content_frame, height=15, bg="#1c2e3e", fg="#ecf0f1")
        status_display.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        status_display.insert(tk.END, "Initiating threat detection scan...\n")
        
        # Function to simulate scanning progress
        def simulate_scan():
            for i in range(5):
                status_display.insert(tk.END, f"Scanning sector {i+1}...\n")
                status_display.see(tk.END)
                status_display.update()
                time.sleep(0.5)
                
            # Generate random threats
            num_threats = random.randint(0, 5)
            threat_types = ["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone"]
            self.defense_os.threats = []
            
            for i in range(num_threats):
                threat = {
                    "id": i+1,
                    "type": random.choice(threat_types),
                    "distance": random.randint(50, 500),
                    "speed": random.randint(300, 2000),
                    "heading": random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"]),
                    "intercepted": False
                }
                self.defense_os.threats.append(threat)
            
            # Update threat level
            if num_threats == 0:
                self.defense_os.threat_level = "Low"
            elif num_threats <= 2:
                self.defense_os.threat_level = "Medium"
            else:
                self.defense_os.threat_level = "High"
                
            status_display.insert(tk.END, "\nSCAN COMPLETE\n")
            status_display.insert(tk.END, f"Detected {num_threats} threats\n")
            status_display.insert(tk.END, f"Threat level set to {self.defense_os.threat_level}\n")
            
            if num_threats > 0:
                status_display.insert(tk.END, "\nTHREAT DETAILS:\n")
                for threat in self.defense_os.threats:
                    status_display.insert(tk.END, f"ID: {threat['id']} | Type: {threat['type']} | " +
                                       f"Distance: {threat['distance']}km | " +
                                       f"Speed: {threat['speed']}km/h | " +
                                       f"Heading: {threat['heading']}\n")
            else:
                status_display.insert(tk.END, "\nNo threats detected in the vicinity.\n")
                
            status_display.see(tk.END)
            self.update_status_bar()
            
            # Enable the buttons after scan is complete
            for btn in buttons:
                btn.config(state=tk.NORMAL)
                
            self.log_message(f"Threat detection complete. Level: {self.defense_os.threat_level}")
        
        # Create frame for buttons
        button_frame = tk.Frame(self.content_frame, bg="#2c3e50")
        button_frame.pack(fill=tk.X, pady=10)
        
        # Back button
        back_btn = tk.Button(button_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                           bg="#7f8c8d", fg="white", font=("Arial", 10), state=tk.DISABLED)
        back_btn.pack(side=tk.RIGHT, padx=10)
        
        # Intercept button
        intercept_btn = tk.Button(button_frame, text="Go to Intercept Mode", command=self.show_intercept_mode,
                                bg="#3498db", fg="white", font=("Arial", 10), state=tk.DISABLED)
        intercept_btn.pack(side=tk.LEFT, padx=10)
        
        # Store buttons to enable them later
        buttons = [back_btn, intercept_btn]
        
        # Start scan in a separate thread to keep UI responsive
        self.root.after(100, simulate_scan)
        
    def show_intercept_mode(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        if not self.defense_os.active_system:
            # If no system is selected, show warning
            warning_label = tk.Label(self.content_frame, text="No defense system selected!", 
                                   font=("Arial", 14, "bold"), bg="#2c3e50", fg="#e74c3c")
            warning_label.pack(pady=20)
            
            info_label = tk.Label(self.content_frame, text="Please select a defense system first.", 
                                font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
            info_label.pack(pady=10)
            
            back_btn = tk.Button(self.content_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                               bg="#7f8c8d", fg="white", font=("Arial", 10))
            back_btn.pack(pady=20)
            return
            
        if not self.defense_os.threats:
            # If no threats detected, show warning
            warning_label = tk.Label(self.content_frame, text="No threats detected!", 
                                   font=("Arial", 14, "bold"), bg="#2c3e50", fg="#e74c3c")
            warning_label.pack(pady=20)
            
            info_label = tk.Label(self.content_frame, text="Run threat detection first.", 
                                font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
            info_label.pack(pady=10)
            
            detect_btn = tk.Button(self.content_frame, text="Run Threat Detection", command=self.run_threat_detection,
                                 bg="#3498db", fg="white", font=("Arial", 10))
            detect_btn.pack(pady=10)
            
            back_btn = tk.Button(self.content_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                               bg="#7f8c8d", fg="white", font=("Arial", 10))
            back_btn.pack(pady=10)
            return
        
        # Header
        header_label = tk.Label(self.content_frame, text="Intercept Mode", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        header_label.pack(pady=10)
        
        # System info
        system = self.defense_os.active_system
        system_frame = tk.Frame(self.content_frame, bg="#34495e", padx=10, pady=10)
        system_frame.pack(fill=tk.X, padx=10, pady=5)
        
        system_label = tk.Label(system_frame, text=f"Active System: {system.name}", 
                              font=("Arial", 10, "bold"), bg="#34495e", fg="#ecf0f1")
        system_label.pack(side=tk.LEFT)
        
        ammo_label = tk.Label(system_frame, text=f"Ammunition: {system.ammo}/100", 
                            font=("Arial", 10), bg="#34495e", fg="#ecf0f1")
        ammo_label.pack(side=tk.RIGHT)
        
        # List of threats
        threats_frame = tk.Frame(self.content_frame, bg="#2c3e50")
        threats_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        threats_label = tk.Label(threats_frame, text="Current Threats:", 
                               font=("Arial", 12, "bold"), bg="#2c3e50", fg="#ecf0f1")
        threats_label.pack(anchor=tk.W, pady=5)
        
        # Check if there are active threats
        active_threats = [t for t in self.defense_os.threats if not t['intercepted']]
        
        if not active_threats:
            no_threats_label = tk.Label(threats_frame, text="All threats have been neutralized.", 
                                      font=("Arial", 12), bg="#2c3e50", fg="#2ecc71")
            no_threats_label.pack(pady=20)
            
            back_btn = tk.Button(threats_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                               bg="#7f8c8d", fg="white", font=("Arial", 10))
            back_btn.pack(pady=10)
            return
        
        # Create a treeview to display threats
        columns = ("ID", "Type", "Distance", "Speed", "Heading")
        tree = ttk.Treeview(threats_frame, columns=columns, show="headings", height=10)
        
        # Define column headings
        for col in columns:
            tree.heading(col, text=col)
            width = 80 if col != "Type" else 150
            tree.column(col, width=width)
        
        # Insert threats into the treeview
        for threat in active_threats:
            tree.insert("", tk.END, values=(
                threat['id'], 
                threat['type'], 
                f"{threat['distance']} km", 
                f"{threat['speed']} km/h", 
                threat['heading']
            ))
        
        tree.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Control panel
        control_frame = tk.Frame(self.content_frame, bg="#34495e", padx=10, pady=10)
        control_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Function to handle interception
        def intercept_threat():
            selected_items = tree.selection()
            if not selected_items:
                messagebox.showwarning("No Selection", "Please select a threat to intercept.")
                return
                
            # Get threat ID from the selection
            selected_row = tree.item(selected_items[0])['values']
            threat_id = selected_row[0]
            
            # Find the threat by ID
            target_threats = [t for t in self.defense_os.threats if t['id'] == threat_id and not t['intercepted']]
            
            if not target_threats:
                messagebox.showwarning("Error", "Invalid threat selection.")
                return
                
            target = target_threats[0]
            success, result = system.fire(f"Threat #{target['id']} ({target['type']})")
            
            self.log_message(result)
            
            if success:
                target['intercepted'] = True
                messagebox.showinfo("Success", f"Threat #{target['id']} successfully intercepted!")
                # Remove from the treeview
                tree.delete(selected_items[0])
                # Update ammo display
                ammo_label.config(text=f"Ammunition: {system.ammo}/100")
                
                # Check if all threats are intercepted
                remaining_threats = [t for t in self.defense_os.threats if not t['intercepted']]
                if not remaining_threats:
                    messagebox.showinfo("Mission Complete", "All threats have been neutralized!")
                    self.show_intercept_mode()  # Refresh the screen
            else:
                messagebox.showwarning("Failed", f"Failed to intercept Threat #{target['id']}. Target is still active.")
                # Update ammo display
                ammo_label.config(text=f"Ammunition: {system.ammo}/100")
        
        # Intercept button
        intercept_btn = tk.Button(control_frame, text="Intercept Selected Threat", command=intercept_threat,
                                bg="#e74c3c", fg="white", font=("Arial", 10, "bold"))
        intercept_btn.pack(side=tk.LEFT, padx=10)
        
        # Back button
        back_btn = tk.Button(control_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                           bg="#7f8c8d", fg="white", font=("Arial", 10))
        back_btn.pack(side=tk.RIGHT, padx=10)
        
    def show_maintenance(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        if not self.defense_os.active_system:
            # If no system is selected, show warning
            warning_label = tk.Label(self.content_frame, text="No defense system selected!", 
                                   font=("Arial", 14, "bold"), bg="#2c3e50", fg="#e74c3c")
            warning_label.pack(pady=20)
            
            info_label = tk.Label(self.content_frame, text="Please select a defense system first.", 
                                font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
            info_label.pack(pady=10)
            
            back_btn = tk.Button(self.content_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                               bg="#7f8c8d", fg="white", font=("Arial", 10))
            back_btn.pack(pady=20)
            return
        
        # Get the active system
        system = self.defense_os.active_system
        
        # Header
        header_label = tk.Label(self.content_frame, text="Maintenance Operations", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        header_label.pack(pady=10)
        
        system_label = tk.Label(self.content_frame, text=f"Active System: {system.name}", 
                              font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
        system_label.pack(pady=5)
        
        # Maintenance panel
        maintenance_panel = tk.Frame(self.content_frame, bg="#34495e", padx=15, pady=15)
        maintenance_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # System status indicators
        status_frame = tk.Frame(maintenance_panel, bg="#34495e")
        status_frame.pack(fill=tk.X, pady=10)
        
        # Operational status
        op_label = tk.Label(status_frame, text="Operational Status:", 
                          font=("Arial", 10, "bold"), bg="#34495e", fg="#ecf0f1")
        op_label.grid(row=0, column=0, sticky="w", pady=5)
        
        op_status = tk.Label(status_frame, text="OPERATIONAL" if system.operational else "OFFLINE", 
                           font=("Arial", 10), bg="#34495e", 
                           fg="#2ecc71" if system.operational else "#e74c3c")
        op_status.grid(row=0, column=1, sticky="w", padx=10, pady=5)
        
        # Battery level
        battery_label = tk.Label(status_frame, text="Battery Level:", 
                               font=("Arial", 10, "bold"), bg="#34495e", fg="#ecf0f1")
        battery_label.grid(row=1, column=0, sticky="w", pady=5)
        
        battery_frame = tk.Frame(status_frame, bg="#34495e")
        battery_frame.grid(row=1, column=1, sticky="w", padx=10, pady=5)
        
        battery_progress = ttk.Progressbar(battery_frame, orient=tk.HORIZONTAL, length=200, mode='determinate')
        battery_progress['value'] = system.battery_level
        battery_progress.pack(side=tk.LEFT)
        
        battery_value = tk.Label(battery_frame, text=f"{system.battery_level}%", 
                               font=("Arial", 10), bg="#34495e", fg="#ecf0f1")
        battery_value.pack(side=tk.LEFT, padx=5)
        
        # Ammunition level
        ammo_label = tk.Label(status_frame, text="Ammunition:", 
                            font=("Arial", 10, "bold"), bg="#34495e", fg="#ecf0f1")
        ammo_label.grid(row=2, column=0, sticky="w", pady=5)
        
        ammo_frame = tk.Frame(status_frame, bg="#34495e")
        ammo_frame.grid(row=2, column=1, sticky="w", padx=10, pady=5)
        
        ammo_progress = ttk.Progressbar(ammo_frame, orient=tk.HORIZONTAL, length=200, mode='determinate')
        ammo_progress['value'] = system.ammo
        ammo_progress.pack(side=tk.LEFT)
        
        ammo_value = tk.Label(ammo_frame, text=f"{system.ammo}/100", 
                            font=("Arial", 10), bg="#34495e", fg="#ecf0f1")
        ammo_value.pack(side=tk.LEFT, padx=5)
        
        # Last maintenance
        maint_label = tk.Label(status_frame, text="Last Maintenance:", 
                             font=("Arial", 10, "bold"), bg="#34495e", fg="#ecf0f1")
        maint_label.grid(row=3, column=0, sticky="w", pady=5)
        
        maint_value = tk.Label(status_frame, text=system.last_maintenance.strftime("%Y-%m-%d %H:%M:%S"), 
                             font=("Arial", 10), bg="#34495e", fg="#ecf0f1")
        maint_value.grid(row=3, column=1, sticky="w", padx=10, pady=5)
        
        # Maintenance operations buttons
        button_frame = tk.Frame(maintenance_panel, bg="#34495e", pady=15)
        button_frame.pack(fill=tk.X)
        
        # Full maintenance
        def do_full_maintenance():
            result = system.perform_maintenance()
            self.log_message(result)
            # Update UI
            op_status.config(text="OPERATIONAL", fg="#2ecc71")
            battery_progress['value'] = system.battery_level
            battery_value.config(text=f"{system.battery_level}%")
            maint_value.config(text=system.last_maintenance.strftime("%Y-%m-%d %H:%M:%S"))
            messagebox.showinfo("Maintenance", result)
        
        maint_btn = tk.Button(button_frame, text="Perform Full Maintenance", command=do_full_maintenance,
                            bg="#e67e22", fg="white", font=("Arial", 10), width=25)
        maint_btn.pack(pady=5)
        
        # Reload ammunition
        def do_reload():
            result = system.reload()
            self.log_message(result)
            # Update UI
            ammo_progress['value'] = system.ammo
            ammo_value.config(text=f"{system.ammo}/100")
            messagebox.showinfo("Reload", result)
        
        reload_btn = tk.Button(button_frame, text="Reload Ammunition", command=do_reload,
                             bg="#e67e22", fg="white", font=("Arial", 10), width=25)
        reload_btn.pack(pady=5)
        
        # Run diagnostics
        def run_diagnostics():
            # Create diagnostic window
            diag_window = tk.Toplevel(self.root)
            diag_window.title("System Diagnostics")
            diag_window.geometry("400x300")
            diag_window.configure(bg="#34495e")
            
            diag_label = tk.Label(diag_window, text=f"Running Diagnostics on {system.name}", 
                                font=("Arial", 12, "bold"), bg="#34495e", fg="#ecf0f1")
            diag_label.pack(pady=10)
            
            diag_text = scrolledtext.ScrolledText(diag_window, height=12, bg="#1c2e3e", fg="#ecf0f1")
            diag_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            # Function to simulate diagnostics
            def simulate_diagnostics():
                components = ["Power Systems", "Targeting Computer", "Radar Array", 
                             "Missile Launch Systems", "Communication Systems"]
                
                for i, comp in enumerate(components):
                    diag_text.insert(tk.END, f"Checking {comp}...\n")
                    diag_text.see(tk.END)
                    diag_text.update()
                    time.sleep(0.7)
                    
                    # Random chance of issue
                    if random.random() < 0.2:
                        diag_text.insert(tk.END, f"WARNING: {comp} showing slight degradation. " +
                                       "Maintenance recommended.\n")
                    else:
                        diag_text.insert(tk.END, f"{comp} check complete. Status: Optimal\n")
                    
                    diag_text.see(tk.END)
                    diag_text.update()
                    time.sleep(0.3)
                
                diag_text.insert(tk.END, "\nDiagnostics complete. System operational.\n")
                diag_text.see(tk.END)
                
                self.log_message(f"Diagnostics completed on {system.name}")
                
                # Enable close button
                close_btn.config(state=tk.NORMAL)
            
            # Start diagnostics in a separate thread
            diag_window.after(100, simulate_diagnostics)
            
            # Close button (disabled until diagnostics complete)
            close_btn = tk.Button(diag_window, text="Close", command=diag_window.destroy,
                                bg="#7f8c8d", fg="white", state=tk.DISABLED)
            close_btn.pack(pady=10)
            
            # Make sure the window stays on top and disable resizing
            diag_window.transient(self.root)
            diag_window.grab_set()
            diag_window.resizable(False, False)
        
        diag_btn = tk.Button(button_frame, text="Run System Diagnostics", command=run_diagnostics,
                           bg="#3498db", fg="white", font=("Arial", 10), width=25)
        diag_btn.pack(pady=5)
        
        # Back button
        back_frame = tk.Frame(self.content_frame, bg="#2c3e50")
        back_frame.pack(fill=tk.X, pady=10)
        
        back_btn = tk.Button(back_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                           bg="#7f8c8d", fg="white", font=("Arial", 10))
        back_btn.pack(side=tk.RIGHT, padx=10)
        
    def run_simulation(self):
        self.clear_content_frame()
        self.update_status_bar()
        
        # Header
        header_label = tk.Label(self.content_frame, text="Simulation Mode", 
                               font=("Arial", 14, "bold"), bg="#2c3e50", fg="#ecf0f1")
        header_label.pack(pady=10)
        
        # Confirm simulation
        confirm_frame = tk.Frame(self.content_frame, bg="#34495e", padx=15, pady=15)
        confirm_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        warning_label = tk.Label(confirm_frame, text="Warning: This will run a simulated attack scenario.",
                               font=("Arial", 12, "bold"), bg="#34495e", fg="#f39c12")
        warning_label.pack(pady=10)
        
        info_label = tk.Label(confirm_frame, text="The simulation will generate random threats and test your defensive systems.",
                            font=("Arial", 10), bg="#34495e", fg="#ecf0f1")
        info_label.pack(pady=5)
        
        # Check if a system is selected
        if not self.defense_os.active_system:
            system_warning = tk.Label(confirm_frame, text="No defense system is currently selected.\n" +
                                   "A random system will be chosen for the simulation.",
                                   font=("Arial", 10), bg="#34495e", fg="#e74c3c")
            system_warning.pack(pady=10)
        else:
            system_info = tk.Label(confirm_frame, text=f"Active system: {self.defense_os.active_system.name}",
                                 font=("Arial", 10), bg="#34495e", fg="#ecf0f1")
            system_info.pack(pady=10)
        
        # Button frame
        button_frame = tk.Frame(confirm_frame, bg="#34495e")
        button_frame.pack(pady=20)
        
        # Cancel button
        cancel_btn = tk.Button(button_frame, text="Cancel", command=self.show_welcome_screen,
                             bg="#7f8c8d", fg="white", font=("Arial", 10), width=15)
        cancel_btn.pack(side=tk.LEFT, padx=10)
        
        # Function to start simulation
        def start_simulation():
            # Clear content and show simulation screen
            self.clear_content_frame()
            
            # Select random system if none active
            if not self.defense_os.active_system:
                self.defense_os.active_system = random.choice(self.defense_os.systems)
                self.update_status_bar()
            
            # Header
            sim_header = tk.Label(self.content_frame, text="Simulation in Progress", 
                                font=("Arial", 14, "bold"), bg="#2c3e50", fg="#e74c3c")
            sim_header.pack(pady=10)
            
            # Display
            sim_display = scrolledtext.ScrolledText(self.content_frame, height=15, bg="#1c2e3e", fg="#ecf0f1")
            sim_display.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            sim_display.insert(tk.END, "INITIALIZING SIMULATION\n\n")
            
            # Generate random threats
            num_threats = random.randint(3, 8)
            self.defense_os.threats = []
            threat_types = ["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone"]
            
            for i in range(num_threats):
                threat = {
                    "id": i+1,
                    "type": random.choice(threat_types),
                    "distance": random.randint(50, 500),
                    "speed": random.randint(300, 2000),
                    "heading": random.choice(["North", "South", "East", "West"]),
                    "intercepted": False
                }
                self.defense_os.threats.append(threat)
            
            self.defense_os.threat_level = "High"
            self.update_status_bar()
            
            # Function to run the simulation steps
            def run_sim_steps():
                system = self.defense_os.active_system
                
                sim_display.insert(tk.END, f"EMERGENCY ALERT: {num_threats} incoming hostile projectiles detected!\n")
                sim_display.insert(tk.END, f"Defense system {system.name} activated\n\n")
                sim_display.see(tk.END)
                sim_display.update()
                time.sleep(1)
                
                success_count = 0
                for threat in self.defense_os.threats:
                    sim_display.insert(tk.END, f"Threat #{threat['id']} - {threat['type']} approaching from {threat['heading']}\n")
                    sim_display.insert(tk.END, f"Distance: {threat['distance']}km - Speed: {threat['speed']}km/h\n")
                    sim_display.see(tk.END)
                    sim_display.update()
                    time.sleep(0.5)
                    
                    success, result = system.fire(f"Threat #{threat['id']} ({threat['type']})")
                    sim_display.insert(tk.END, f"{result}\n\n")
                    sim_display.see(tk.END)
                    sim_display.update()
                    
                    if success:
                        threat['intercepted'] = True
                        success_count += 1
                    
                    time.sleep(0.5)
                
                # Simulation results
                success_rate = (success_count / num_threats) * 100
                sim_display.insert(tk.END, "\n" + "=" * 50 + "\n")
                sim_display.insert(tk.END, "SIMULATION COMPLETE\n")
                sim_display.insert(tk.END, f"Threats neutralized: {success_count}/{num_threats} ({success_rate:.1f}%)\n\n")
                
                if success_rate == 100:
                    result_text = "Mission Status: COMPLETE SUCCESS"
                    result_color = "#2ecc71"  # Green
                elif success_rate >= 70:
                    result_text = "Mission Status: PARTIAL SUCCESS"
                    result_color = "#f39c12"  # Orange
                else:
                    result_text = "Mission Status: FAILURE - DEFENSIVE CAPABILITIES INADEQUATE"
                    result_color = "#e74c3c"  # Red
                
                sim_display.insert(tk.END, result_text + "\n")
                sim_display.insert(tk.END, "=" * 50 + "\n")
                sim_display.see(tk.END)
                
                # Create a result label with appropriate color
                result_label = tk.Label(self.content_frame, text=result_text, 
                                     font=("Arial", 12, "bold"), bg="#2c3e50", fg=result_color)
                result_label.pack(pady=5)
                
                # Enable the back button
                back_btn.config(state=tk.NORMAL)
                
                self.log_message(f"Simulation completed. Success rate: {success_rate:.1f}%")
            
            # Start simulation in a separate thread
            self.root.after(100, run_sim_steps)
            
            # Back button (disabled until simulation completes)
            back_btn = tk.Button(self.content_frame, text="Back to Main Menu", command=self.show_welcome_screen,
                               bg="#7f8c8d", fg="white", font=("Arial", 10), state=tk.DISABLED)
            back_btn.pack(pady=10)
        
        # Start simulation button
        start_btn = tk.Button(button_frame, text="Start Simulation", command=start_simulation,
                            bg="#e74c3c", fg="white", font=("Arial", 10, "bold"), width=15)
        start_btn.pack(side=tk.RIGHT, padx=10)

class MissileDefenseOS:
    def __init__(self):
        self.systems = self.initialize_systems()
        self.active_system = None
        self.threat_level = "Low"
        self.threats = []
        
    def initialize_systems(self):
        # Create a database of missile defense systems
        return [
            MissileDefenseSystem("Akash", "India", "Surface-to-air", "Medium range"),
            MissileDefenseSystem("Arrow", "Israel", "Anti-ballistic missile", "Long range"),
            MissileDefenseSystem("Chū-SAM", "Japan", "Surface-to-air", "Medium range"),
            MissileDefenseSystem("David's Sling", "Israel", "Air defense", "Medium to long range"),
            MissileDefenseSystem("HQ-9", "China", "Air defense/Anti-ballistic", "Long range"),
            MissileDefenseSystem("Iron Dome", "Israel", "Air defense", "Short range"),
            MissileDefenseSystem("SAMP/T", "Italy/France", "Air defense", "Medium range"),
            MissileDefenseSystem("KS-1", "China", "Air defense", "Medium range"),
            MissileDefenseSystem("L-SAM", "South Korea", "Anti-ballistic missile", "Long range"),
            MissileDefenseSystem("MEADS", "USA/Germany/Italy", "Air defense", "Medium range"),
            MissileDefenseSystem("Patriot", "USA", "Surface-to-air", "Medium to long range"),
            MissileDefenseSystem("Hawk", "USA", "Surface-to-air", "Medium range"),
            MissileDefenseSystem("RIM-161 Standard Missile 3", "USA", "Anti-ballistic missile", "Long range"),
            MissileDefenseSystem("A-135", "Russia", "Anti-ballistic missile", "Long range"),
            MissileDefenseSystem("S-400 Triumf", "Russia", "Air defense", "Long range"),
            MissileDefenseSystem("Skyguard", "USA", "Air defense", "Short range"),
            MissileDefenseSystem("Sky Bow", "Taiwan", "Air defense", "Medium range"),
            MissileDefenseSystem("THAAD", "USA", "Anti-ballistic missile", "Long range"),
            MissileDefenseSystem("Vigilant Eagle", "USA", "Air defense", "Airport protection"),
            MissileDefenseSystem("Bavar-373", "Iran", "Air defense", "Long range"),
            MissileDefenseSystem("Arman", "Iran", "Anti-ballistic missile", "Long range"),
            MissileDefenseSystem("Khordad 15", "Iran", "Air defense", "Medium range")
        ]

def main():
    root = tk.Tk()
    root.title("Missile Defense System")
    
    # Set icon (if available)
    try:
        root.iconbitmap("missile.ico")
    except:
        pass
    
    # Create the GUI application
    app = MissileDefenseGUI(root)
    
    # Run the application
    root.mainloop()

if __name__ == "__main__":
    main()
