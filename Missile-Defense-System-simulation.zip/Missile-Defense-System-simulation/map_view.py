
import tkinter as tk
from tkinter import ttk
import random
import math
from PIL import Image, ImageTk, ImageDraw, ImageFont

class ThreatMap:
    def __init__(self, parent):
        self.parent = parent
        self.frame = parent.map_tab
        
        # Header
        header_label = tk.Label(
            self.frame, 
            text="GLOBAL DEFENSE MAP", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)
        
        # Create tabs for different map views
        self.map_tabs = ttk.Notebook(self.frame)
        self.map_tabs.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Threat tracking map tab
        self.threat_tab = ttk.Frame(self.map_tabs)
        self.map_tabs.add(self.threat_tab, text="Threat Tracking")
        
        # Country map tab
        self.country_tab = ttk.Frame(self.map_tabs)
        self.map_tabs.add(self.country_tab, text="Country Map")
        
        # Setup threat tracking map
        self.setup_threat_tracking_map()
        
        # Setup country map
        self.setup_country_map()
        
        # Initialize maps
        self.create_base_map()
        self.create_country_map()
        self.defense_system_position = (self.canvas_width // 2, self.canvas_height // 2)
        self.threats = []
        self.threat_paths = []
        self.interception_paths = []
        self.auto_refresh_id = None
        
        # Start auto-refresh
        self.toggle_auto_refresh()
    
    def setup_threat_tracking_map(self):
        # Map canvas
        self.canvas_frame = tk.Frame(self.threat_tab, bg="#112240", bd=2, relief=tk.GROOVE)
        self.canvas_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.canvas_width = 700
        self.canvas_height = 500
        self.canvas = tk.Canvas(
            self.canvas_frame, 
            width=self.canvas_width, 
            height=self.canvas_height, 
            bg="#030e1f",
            bd=0,
            highlightthickness=0
        )
        self.canvas.pack(padx=10, pady=10)
        
        # Map legend
        legend_frame = tk.Frame(self.threat_tab, bg="#112240", bd=2, relief=tk.GROOVE)
        legend_frame.pack(fill="x", padx=10, pady=5)
        
        # Legend items
        legend_items = [
            ("Defense System", "#64ffda", "■"),
            ("Active Threat", "#e74c3c", "▲"),
            ("Intercepted Threat", "#2ecc71", "X"),
            ("Interception Path", "#3498db", "---")
        ]
        
        for i, (label_text, color, symbol) in enumerate(legend_items):
            symbol_label = tk.Label(
                legend_frame, 
                text=symbol, 
                font=("Arial", 12, "bold"), 
                fg=color, 
                bg="#112240"
            )
            symbol_label.grid(row=i//2, column=(i%2)*2, padx=5, pady=5, sticky="e")
            
            text_label = tk.Label(
                legend_frame, 
                text=label_text, 
                font=("Arial", 10), 
                fg="white", 
                bg="#112240"
            )
            text_label.grid(row=i//2, column=(i%2)*2+1, padx=5, pady=5, sticky="w")
        
        # Configure grid
        legend_frame.columnconfigure(1, weight=1)
        legend_frame.columnconfigure(3, weight=1)
        
        # Controls
        controls_frame = tk.Frame(self.threat_tab, bg="#0a192f")
        controls_frame.pack(fill="x", pady=10)
        
        # Refresh button
        refresh_btn = ttk.Button(
            controls_frame, 
            text="Refresh Map", 
            command=self.refresh_map
        )
        refresh_btn.pack(side="left", padx=10)
        
        # Auto-refresh checkbox
        self.auto_refresh_var = tk.BooleanVar(value=True)
        auto_refresh_cb = ttk.Checkbutton(
            controls_frame,
            text="Auto-refresh",
            variable=self.auto_refresh_var,
            command=self.toggle_auto_refresh
        )
        auto_refresh_cb.pack(side="left", padx=10)
    
    def setup_country_map(self):
        # Country map canvas
        self.country_frame = tk.Frame(self.country_tab, bg="#112240", bd=2, relief=tk.GROOVE)
        self.country_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.country_canvas_width = 800
        self.country_canvas_height = 500
        self.country_canvas = tk.Canvas(
            self.country_frame, 
            width=self.country_canvas_width, 
            height=self.country_canvas_height, 
            bg="#030e1f",
            bd=0,
            highlightthickness=0
        )
        self.country_canvas.pack(padx=10, pady=10)
        
        # Country map legend
        legend_frame = tk.Frame(self.country_tab, bg="#112240", bd=2, relief=tk.GROOVE)
        legend_frame.pack(fill="x", padx=10, pady=5)
        
        # Legend items
        legend_items = [
            ("Your Country", "#64ffda", "■"),
            ("Allied Country", "#3498db", "■"),
            ("Neutral Country", "#f39c12", "■"),
            ("Hostile Country", "#e74c3c", "■"),
            ("Missile Defense System", "#ffffff", "★")
        ]
        
        for i, (label_text, color, symbol) in enumerate(legend_items):
            symbol_label = tk.Label(
                legend_frame, 
                text=symbol, 
                font=("Arial", 12, "bold"), 
                fg=color, 
                bg="#112240"
            )
            symbol_label.grid(row=i//3, column=(i%3)*2, padx=5, pady=5, sticky="e")
            
            text_label = tk.Label(
                legend_frame, 
                text=label_text, 
                font=("Arial", 10), 
                fg="white", 
                bg="#112240"
            )
            text_label.grid(row=i//3, column=(i%3)*2+1, padx=5, pady=5, sticky="w")
        
        # Configure grid
        legend_frame.columnconfigure(1, weight=1)
        legend_frame.columnconfigure(3, weight=1)
        legend_frame.columnconfigure(5, weight=1)
        
        # Controls
        controls_frame = tk.Frame(self.country_tab, bg="#0a192f")
        controls_frame.pack(fill="x", pady=10)
        
        # Refresh button
        refresh_country_btn = ttk.Button(
            controls_frame, 
            text="Refresh Country Map", 
            command=self.refresh_country_map
        )
        refresh_country_btn.pack(side="left", padx=10)
        
        # Filter systems dropdown
        self.filter_var = tk.StringVar(value="All Systems")
        filter_label = tk.Label(
            controls_frame, 
            text="Filter by Country:", 
            bg="#0a192f", 
            fg="white"
        )
        filter_label.pack(side="left", padx=(20, 5))
        
        # Get unique countries from systems
        self.country_options = ["All Systems"]
        if hasattr(self.parent, 'defense_os') and self.parent.defense_os.systems:
            countries = set(system.country for system in self.parent.defense_os.systems)
            self.country_options.extend(sorted(countries))
        
        filter_dropdown = ttk.Combobox(
            controls_frame, 
            textvariable=self.filter_var, 
            values=self.country_options,
            state="readonly",
            width=15
        )
        filter_dropdown.pack(side="left", padx=5)
        filter_dropdown.bind("<<ComboboxSelected>>", lambda e: self.refresh_country_map())
        
    def create_base_map(self):
        # Create a base map image with a grid and compass
        self.map_image = Image.new('RGB', (self.canvas_width, self.canvas_height), color='#030e1f')
        draw = ImageDraw.Draw(self.map_image)
        
        # Draw grid lines
        grid_spacing = 50
        
        # Draw grid lines
        for x in range(0, self.canvas_width, grid_spacing):
            draw.line([(x, 0), (x, self.canvas_height)], fill='#1a3050', width=1)
        
        for y in range(0, self.canvas_height, grid_spacing):
            draw.line([(0, y), (self.canvas_width, y)], fill='#1a3050', width=1)
        
        # Draw compass
        compass_radius = 30
        compass_x = self.canvas_width - compass_radius - 20
        compass_y = compass_radius + 20
        
        # Draw compass circle
        draw.ellipse(
            [(compass_x - compass_radius, compass_y - compass_radius),
             (compass_x + compass_radius, compass_y + compass_radius)],
            outline='#64ffda', width=2
        )
        
        # Draw compass directions
        directions = [('N', 0, -1), ('E', 1, 0), ('S', 0, 1), ('W', -1, 0)]
        for label, dx, dy in directions:
            draw.text(
                (compass_x + dx * (compass_radius - 10), 
                 compass_y + dy * (compass_radius - 10)),
                label,
                fill='#64ffda'
            )
        
        # Draw range rings around the center
        center_x = self.canvas_width // 2
        center_y = self.canvas_height // 2
        
        for radius in range(50, 301, 50):
            draw.ellipse(
                [(center_x - radius, center_y - radius),
                 (center_x + radius, center_y + radius)],
                outline='#1a3050', width=1
            )
            # Add distance label to the topmost point of each ring
            draw.text(
                (center_x, center_y - radius - 10),
                f"{radius}km",
                fill='#64ffda'
            )
        
        # Convert image to PhotoImage for tkinter
        self.base_map_image = ImageTk.PhotoImage(self.map_image)
        
    def create_country_map(self):
        """Create a world map with country outlines"""
        # Base map image
        self.country_map_image = Image.new('RGB', (self.country_canvas_width, self.country_canvas_height), color='#030e1f')
        draw = ImageDraw.Draw(self.country_map_image)
        
        # Define country regions (simplified shapes for demonstration)
        # These are approximations for visual representation
        countries = {
            "USA": {
                "points": [(100, 150), (100, 200), (300, 200), (300, 150)],
                "status": "your",
                "systems": ["Patriot", "THAAD", "Hawk", "RIM-161 Standard Missile 3"]
            },
            "Russia": {
                "points": [(450, 100), (700, 100), (700, 150), (450, 150)],
                "status": "hostile", 
                "systems": ["A-135", "S-400 Triumf"]
            },
            "China": {
                "points": [(600, 180), (700, 180), (700, 250), (600, 250)],
                "status": "hostile",
                "systems": ["HQ-9", "KS-1"]
            },
            "India": {
                "points": [(550, 250), (600, 250), (600, 300), (550, 300)],
                "status": "neutral",
                "systems": ["Akash"]
            },
            "Israel": {
                "points": [(450, 230), (470, 230), (470, 250), (450, 250)],
                "status": "allied",
                "systems": ["Arrow", "David's Sling", "Iron Dome"]
            },
            "Japan": {
                "points": [(680, 180), (700, 180), (700, 200), (680, 200)],
                "status": "allied",
                "systems": ["Chū-SAM"]
            },
            "South Korea": {
                "points": [(670, 200), (680, 200), (680, 210), (670, 210)],
                "status": "allied",
                "systems": ["L-SAM"]
            },
            "Iran": {
                "points": [(500, 220), (530, 220), (530, 250), (500, 250)],
                "status": "hostile",
                "systems": ["Bavar-373", "Arman", "Khordad 15"]
            },
            "UK": {
                "points": [(400, 150), (420, 150), (420, 170), (400, 170)],
                "status": "allied",
                "systems": []
            },
            "France": {
                "points": [(400, 180), (430, 180), (430, 200), (400, 200)],
                "status": "allied",
                "systems": ["SAMP/T"]
            },
            "Germany": {
                "points": [(430, 160), (450, 160), (450, 180), (430, 180)],
                "status": "allied",
                "systems": ["MEADS"]
            },
            "Italy": {
                "points": [(430, 190), (450, 190), (450, 210), (430, 210)],
                "status": "allied",
                "systems": ["SAMP/T", "MEADS"]
            },
            "Taiwan": {
                "points": [(660, 220), (670, 220), (670, 230), (660, 230)],
                "status": "allied",
                "systems": ["Sky Bow"]
            }
        }
        
        # Draw map grid
        grid_spacing = 100
        for x in range(0, self.country_canvas_width, grid_spacing):
            draw.line([(x, 0), (x, self.country_canvas_height)], fill='#1a3050', width=1)
        
        for y in range(0, self.country_canvas_height, grid_spacing):
            draw.line([(0, y), (self.country_canvas_width, y)], fill='#1a3050', width=1)
        
        # Draw country shapes (simplified)
        for country, data in countries.items():
            # Determine color based on status
            color = "#64ffda"  # your country
            if data["status"] == "allied":
                color = "#3498db"  # allied
            elif data["status"] == "hostile":
                color = "#e74c3c"  # hostile
            elif data["status"] == "neutral":
                color = "#f39c12"  # neutral
            
            # Draw country shape
            draw.polygon(data["points"], outline="white", fill=color)
            
            # Add country name
            # Find center of polygon
            x_coords = [p[0] for p in data["points"]]
            y_coords = [p[1] for p in data["points"]]
            center_x = sum(x_coords) / len(x_coords)
            center_y = sum(y_coords) / len(y_coords)
            
            # Draw country name
            draw.text((center_x, center_y), country, fill="white")
        
        # Add title and legend
        draw.text((20, 20), "World Missile Defense Systems", fill="white")
        
        # Convert to PhotoImage
        self.country_map_image_tk = ImageTk.PhotoImage(self.country_map_image)
        
        # Store country data for later use
        self.countries = countries
    
    def draw_map(self):
        # Clear canvas
        self.canvas.delete("all")
        
        # Draw base map
        self.canvas.create_image(0, 0, image=self.base_map_image, anchor=tk.NW)
        
        # Draw defense system
        x, y = self.defense_system_position
        self.canvas.create_rectangle(
            x-10, y-10, x+10, y+10,
            fill="#64ffda", outline="#ffffff", width=2, tags="defense"
        )
        
        # Draw threat paths
        for path in self.threat_paths:
            self.canvas.create_line(
                path, fill="#e74c3c", width=1, dash=(4, 2), tags="path"
            )
        
        # Draw interception paths
        for path in self.interception_paths:
            self.canvas.create_line(
                path, fill="#3498db", width=2, dash=(6, 3), tags="intercept"
            )
        
        # Draw threats
        for threat in self.threats:
            x, y = threat["position"]
            if threat["intercepted"]:
                # Draw X for intercepted threats
                self.canvas.create_line(
                    x-8, y-8, x+8, y+8, 
                    fill="#2ecc71", width=2, tags="threat"
                )
                self.canvas.create_line(
                    x-8, y+8, x+8, y-8, 
                    fill="#2ecc71", width=2, tags="threat"
                )
            else:
                # Draw triangle for active threats
                self.canvas.create_polygon(
                    x, y-8, x-8, y+8, x+8, y+8,
                    fill="#e74c3c", outline="#ffffff", width=1, tags="threat"
                )
            
            # Add threat info
            self.canvas.create_text(
                x, y+15, 
                text=f"#{threat['id']}", 
                fill="#ffffff", 
                font=("Arial", 8), 
                tags="threat"
            )
        
        # Update canvas
        self.canvas.update()
    
    def draw_country_map(self):
        # Clear canvas
        self.country_canvas.delete("all")
        
        # Draw base country map
        self.country_canvas.create_image(0, 0, image=self.country_map_image_tk, anchor=tk.NW)
        
        # Get selected country filter
        selected_country = self.filter_var.get()
        
        # Draw defense systems
        if hasattr(self.parent, 'defense_os') and self.parent.defense_os.systems:
            for system in self.parent.defense_os.systems:
                # Skip if filtering by country and system is not from that country
                if selected_country != "All Systems" and system.country != selected_country:
                    continue
                
                # Find country for this system
                country_found = False
                for country_name, country_data in self.countries.items():
                    if system.country == country_name or system.name in country_data["systems"]:
                        # Find a position within the country
                        x_coords = [p[0] for p in country_data["points"]]
                        y_coords = [p[1] for p in country_data["points"]]
                        center_x = sum(x_coords) / len(x_coords)
                        center_y = sum(y_coords) / len(y_coords)
                        
                        # Add some random offset to prevent systems stacking
                        offset_x = random.randint(-15, 15)
                        offset_y = random.randint(-15, 15)
                        
                        # Draw system star
                        self.draw_star(
                            self.country_canvas, 
                            center_x + offset_x, 
                            center_y + offset_y, 
                            8, 
                            "#ffffff", 
                            system_name=system.name
                        )
                        
                        country_found = True
                        break
                
                # If country not found in our map, place at a default location
                if not country_found:
                    default_x = random.randint(100, 700)
                    default_y = random.randint(100, 400)
                    self.draw_star(
                        self.country_canvas, 
                        default_x, 
                        default_y, 
                        8, 
                        "#ffffff", 
                        system_name=system.name
                    )
        
        # Update canvas
        self.country_canvas.update()
    
    def draw_star(self, canvas, x, y, size, color, system_name=""):
        """Draw a star shape for defense systems"""
        # Star points (5-pointed star)
        points = []
        for i in range(10):
            # Outer point or inner point
            if i % 2 == 0:
                r = size
            else:
                r = size / 2
            # Calculate point coordinates
            angle = math.pi / 2 + i * math.pi / 5
            px = x + r * math.cos(angle)
            py = y + r * math.sin(angle)
            points.extend([px, py])
        
        # Draw star
        star_id = canvas.create_polygon(
            points, 
            fill=color, 
            outline='#ffffff',
            tags=("system", system_name)
        )
        
        # Add tooltip on hover
        canvas.tag_bind(star_id, "<Enter>", lambda e, name=system_name: self.show_system_tooltip(e, name))
        canvas.tag_bind(star_id, "<Leave>", self.hide_system_tooltip)
        
        # Add system label
        label_id = canvas.create_text(
            x, y + size + 5,
            text=system_name,
            fill="#ffffff",
            font=("Arial", 7),
            tags=("label", system_name)
        )
    
    def show_system_tooltip(self, event, system_name):
        """Show tooltip with system details"""
        # Find the system in the defense_os
        if not hasattr(self.parent, 'defense_os') or not self.parent.defense_os.systems:
            return
            
        system = next((s for s in self.parent.defense_os.systems if s.name == system_name), None)
        if not system:
            return
            
        # Create tooltip window
        self.tooltip = tk.Toplevel(self.parent.root)
        self.tooltip.wm_overrideredirect(True)  # Remove window decorations
        
        # Position near mouse
        x, y = event.x_root, event.y_root
        self.tooltip.geometry(f"+{x+10}+{y+10}")
        
        # Set background and border
        self.tooltip.configure(bg="#34495e", bd=1, relief="solid")
        
        # Add system details
        details = f"{system.name}\n{system.country}\n{system.type}\n{system.range_class}"
        label = tk.Label(
            self.tooltip, 
            text=details, 
            bg="#34495e", 
            fg="#ffffff",
            justify="left",
            padx=5,
            pady=5
        )
        label.pack()
    
    def hide_system_tooltip(self, event):
        """Hide the system tooltip"""
        if hasattr(self, 'tooltip') and self.tooltip:
            self.tooltip.destroy()
            self.tooltip = None
    
    def refresh_map(self):
        if not hasattr(self.parent, 'defense_os'):
            return
        
        # Get threats from parent
        defense_os = self.parent.defense_os
        if not defense_os.threats:
            return
            
        # Clear existing threats
        self.threats.clear()
        self.threat_paths.clear()
        self.interception_paths.clear()
        
        # Center of the map
        center_x, center_y = self.defense_system_position
        
        # Process each threat
        for threat in defense_os.threats:
            # Calculate position based on distance and heading
            angle = self.heading_to_angle(threat["heading"])
            distance_pixels = threat["distance"] * 0.7  # Scale factor for display
            
            # Calculate end position
            x = center_x + distance_pixels * math.cos(angle)
            y = center_y - distance_pixels * math.sin(angle)
            
            # Ensure within bounds
            x = max(20, min(self.canvas_width - 20, x))
            y = max(20, min(self.canvas_height - 20, y))
            
            # Add to threats list
            self.threats.append({
                "id": threat["id"],
                "type": threat["type"],
                "position": (x, y),
                "intercepted": threat["intercepted"]
            })
            
            # Create path
            self.threat_paths.append([center_x, center_y, x, y])
            
            # If intercepted, create interception path
            if threat["intercepted"]:
                # Calculate interception point (somewhere along the path)
                intercept_factor = random.uniform(0.3, 0.7)
                intercept_x = center_x + (x - center_x) * intercept_factor
                intercept_y = center_y + (y - center_y) * intercept_factor
                
                self.interception_paths.append([center_x, center_y, intercept_x, intercept_y])
        
        # Redraw map
        self.draw_map()
    
    def refresh_country_map(self):
        """Refresh the country map with defense systems"""
        if not hasattr(self, 'countries'):
            self.create_country_map()
        
        # Draw the country map
        self.draw_country_map()
        
    def heading_to_angle(self, heading):
        # Convert cardinal direction to angle in radians
        heading_map = {
            "North": math.pi/2,
            "Northeast": math.pi/4,
            "East": 0,
            "Southeast": -math.pi/4,
            "South": -math.pi/2,
            "Southwest": -3*math.pi/4,
            "West": math.pi,
            "Northwest": 3*math.pi/4
        }
        return heading_map.get(heading, 0)
        
    def toggle_auto_refresh(self):
        # Cancel existing auto-refresh
        if self.auto_refresh_id:
            self.parent.root.after_cancel(self.auto_refresh_id)
            self.auto_refresh_id = None
            
        # If enabled, start auto-refresh
        if self.auto_refresh_var.get():
            self.auto_refresh()
            
    def auto_refresh(self):
        self.refresh_map()
        self.refresh_country_map()
        self.auto_refresh_id = self.parent.root.after(2000, self.auto_refresh)  # Refresh every 2 seconds
