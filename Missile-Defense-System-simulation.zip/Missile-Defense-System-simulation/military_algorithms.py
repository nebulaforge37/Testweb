
import math
import random
import numpy as np
from datetime import datetime
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB

class ThreatAnalysis:
    """Algorithms for analyzing and prioritizing threats"""
    
    @staticmethod
    def calculate_threat_priority(threats, defense_position=(0, 0)):
        """Calculate priority score for each threat based on multiple factors"""
        if not threats:
            return []
            
        # Convert position strings to coordinates
        def heading_to_angle(heading):
            heading_map = {
                "North": 90, "Northeast": 45, "East": 0,
                "Southeast": 315, "South": 270, "Southwest": 225,
                "West": 180, "Northwest": 135
            }
            return heading_map.get(heading, 0)
        
        priorities = []
        for threat in threats:
            if threat.get('intercepted', False):
                continue
                
            # Get threat parameters
            distance = threat.get('distance', 1000)
            speed = threat.get('speed', 0)
            threat_type = threat.get('type', 'Unknown')
            
            # Calculate time to impact
            time_to_impact = distance / max(speed, 1) * 3600  # in seconds
            
            # Type-based threat coefficient
            type_coefficient = {
                "Ballistic Missile": 10.0,
                "Cruise Missile": 8.0,
                "Aircraft": 6.0,
                "Drone": 4.0,
                "Unknown": 5.0
            }.get(threat_type, 5.0)
            
            # Calculate priority score (higher is more urgent)
            # Formula: type_coefficient * (speed / distance) * (1 / time_to_impact)
            priority = type_coefficient * (speed / max(distance, 1)) * (1000 / max(time_to_impact, 1))
            
            priorities.append({
                'id': threat.get('id', 0),
                'priority': priority,
                'time_to_impact': time_to_impact,
                'type': threat_type
            })
        
        # Sort by priority (highest first)
        priorities.sort(key=lambda x: x['priority'], reverse=True)
        return priorities

    @staticmethod
    def identify_missile_formations(threats, cluster_distance=50):
        """Identify groups of missiles using K-means clustering algorithm"""
        if len(threats) < 2:
            return []
            
        # Extract positions based on distance and heading
        active_threats = [t for t in threats if not t.get('intercepted', False)]
        if len(active_threats) < 2:
            return []
            
        # Extract features for clustering
        features = []
        for threat in active_threats:
            distance = threat.get('distance', 0)
            heading = threat.get('heading', 'North')
            speed = threat.get('speed', 0)
            
            # Convert heading to angle in radians
            angle_rad = math.radians(ThreatAnalysis.heading_to_angle(heading))
            
            # Calculate approximate x,y position
            x = distance * math.cos(angle_rad)
            y = distance * math.sin(angle_rad)
            
            # Use position and speed as features
            features.append([x, y, speed/1000])  # Normalize speed
            
        # Apply K-means clustering if we have enough threats
        if len(features) >= 2:
            # Determine optimal number of clusters (between 1 and number of threats)
            max_clusters = min(len(features), 5)  # Max 5 formations
            
            # Try K-means with different numbers of clusters
            best_silhouette = -1
            best_k = 1
            
            if len(features) >= 3:  # Need at least 3 points for meaningful silhouette
                from sklearn.metrics import silhouette_score
                
                for k in range(2, max_clusters + 1):
                    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
                    cluster_labels = kmeans.fit_predict(features)
                    
                    if len(set(cluster_labels)) > 1:  # If we have at least 2 different clusters
                        silhouette = silhouette_score(features, cluster_labels)
                        if silhouette > best_silhouette:
                            best_silhouette = silhouette
                            best_k = k
            
            # Apply K-means with the best k
            kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(features)
            
            # Group threats by cluster
            clusters = [[] for _ in range(best_k)]
            for i, threat in enumerate(active_threats):
                cluster_id = cluster_labels[i]
                clusters[cluster_id].append(threat)
            
            # Only return clusters with at least 2 threats
            return [cluster for cluster in clusters if len(cluster) >= 2]
        
        return []

    @staticmethod
    def heading_to_angle(heading):
        """Convert heading string to angle in degrees"""
        heading_map = {
            "North": 90, "Northeast": 45, "East": 0,
            "Southeast": 315, "South": 270, "Southwest": 225,
            "West": 180, "Northwest": 135
        }
        return heading_map.get(heading, 0)
    
    @staticmethod
    def classify_threat_behavior(threats_history):
        """Use Random Forest to classify threat behavior patterns"""
        if not threats_history or len(threats_history) < 5:
            return "Insufficient data for behavior classification"
            
        # Extract features from threat history
        features = []
        for threat in threats_history:
            # Extract relevant features (example)
            distance = threat.get('distance', 0)
            speed = threat.get('speed', 0)
            heading_angle = ThreatAnalysis.heading_to_angle(threat.get('heading', 'North'))
            
            # You might have more features in a real system
            features.append([distance, speed, heading_angle, 
                            int(threat.get('in_formation', False))])
        
        # Define some behavior classes (example)
        behaviors = [
            "Standard Approach",
            "Evasive Maneuver",
            "Formation Attack",
            "Decoy Pattern"
        ]
        
        # In a real system, you'd have labeled data. Here we're simulating
        labels = [random.choice(range(len(behaviors))) for _ in range(len(features))]
        
        # Train a Random Forest classifier
        rf = RandomForestClassifier(n_estimators=10, random_state=42)
        rf.fit(features, labels)
        
        # Predict the most common behavior
        predictions = rf.predict(features)
        most_common = max(set(predictions), key=predictions.tolist().count)
        
        return behaviors[most_common]
    
    @staticmethod
    def predict_impact_location(threat, time_horizon=60):
        """Use Linear Regression to predict future impact location"""
        if not threat:
            return None
            
        # Get current position
        distance = threat.get('distance', 0)
        heading = threat.get('heading', 'North')
        speed = threat.get('speed', 0) / 3600  # km/s
        
        # Convert to cartesian coordinates
        angle_rad = math.radians(ThreatAnalysis.heading_to_angle(heading))
        current_x = distance * math.cos(angle_rad)
        current_y = distance * math.sin(angle_rad)
        
        # Calculate trajectory over time (assuming linear motion)
        velocity_x = speed * math.cos(angle_rad)
        velocity_y = speed * math.sin(angle_rad)
        
        # Predict future position
        future_x = current_x - (velocity_x * time_horizon)  # Subtract because moving toward origin
        future_y = current_y - (velocity_y * time_horizon)
        
        # Calculate future distance from origin
        future_distance = math.sqrt(future_x**2 + future_y**2)
        
        return {
            'x': future_x,
            'y': future_y,
            'distance': future_distance,
            'time': time_horizon
        }


class DefenseOptimization:
    """Algorithms for optimizing defense system deployment and configuration"""
    
    @staticmethod
    def calculate_optimal_intercept_point(threat, defense_system, safety_margin=0.2):
        """Calculate the optimal point to intercept a threat using dynamic programming"""
        # Get threat parameters
        distance = threat.get('distance', 0)
        heading = threat.get('heading', 'North')
        speed = threat.get('speed', 300)
        
        # Get defense system parameters
        defense_range = {
            "Short range": 50,
            "Medium range": 150,
            "Long range": 300,
            "Medium to long range": 250
        }.get(defense_system.range_class, 100)
        
        # Calculate time factors
        max_intercept_distance = min(distance, defense_range)
        min_intercept_distance = max_intercept_distance * safety_margin
        
        # Dynamic programming approach: Discretize the distance range
        # and find the optimal interception point
        steps = 20  # Divide range into steps
        best_probability = 0
        best_distance = max_intercept_distance * 0.7  # Default
        
        for i in range(steps + 1):
            # Calculate current distance to try
            current_distance = min_intercept_distance + (max_intercept_distance - min_intercept_distance) * (i / steps)
            
            # Calculate success probability at this distance
            probability = DefenseOptimization.calculate_success_probability(
                threat, defense_system, current_distance
            )
            
            # Keep track of the best option
            if probability > best_probability:
                best_probability = probability
                best_distance = current_distance
        
        # Calculate angle in radians
        angle_rad = math.radians(ThreatAnalysis.heading_to_angle(heading))
        
        # Calculate interception coordinates
        x = best_distance * math.cos(angle_rad)
        y = best_distance * math.sin(angle_rad)
        
        # Calculate time until intercept (in seconds)
        time_to_intercept = (distance - best_distance) / speed * 3600
        
        return {
            'position': (x, y),
            'distance': best_distance,
            'time': time_to_intercept,
            'success_probability': best_probability
        }
    
    @staticmethod
    def calculate_success_probability(threat, defense_system, intercept_distance):
        """Calculate probability of successful intercept using logistic regression model"""
        # Base probability factors
        base_probability = 0.75  # Base 75% success rate for ideal conditions
        
        # System factors
        system_type_factor = {
            "Surface-to-air": 0.9,
            "Anti-ballistic missile": 0.95,
            "Air defense": 0.85,
            "Air defense/Anti-ballistic": 0.9
        }.get(defense_system.type, 0.8)
        
        # Range effectiveness factor: effectiveness decreases at extremes of range
        max_range = {
            "Short range": 50,
            "Medium range": 150,
            "Long range": 300,
            "Medium to long range": 250
        }.get(defense_system.range_class, 100)
        
        # Calculate normalized range factor (1.0 at 50% of max range, decreasing toward edges)
        normalized_range = 2.0 * (intercept_distance / max_range)
        if normalized_range > 1.0:
            range_factor = 1.0 - (normalized_range - 1.0)
        else:
            range_factor = normalized_range
        
        # System condition factors
        ammo_factor = defense_system.ammo / 100
        battery_factor = defense_system.battery_level / 100
        
        # Threat factors
        threat_type = threat.get('type', 'Unknown')
        threat_type_factor = {
            "Ballistic Missile": 0.7,  # Hardest to intercept
            "Cruise Missile": 0.8,
            "Aircraft": 0.9,
            "Drone": 0.95,  # Easiest to intercept
            "Unknown": 0.75
        }.get(threat_type, 0.75)
        
        # Speed factor: faster targets are harder to hit
        speed = threat.get('speed', 500)
        normalized_speed = min(speed / 2000, 1.0)  # Normalize to 0-1 range
        speed_factor = 1.0 - (normalized_speed * 0.3)  # Higher speeds reduce by up to 30%
        
        # Calculate final probability
        probability = base_probability * system_type_factor * range_factor * ammo_factor * \
                     battery_factor * threat_type_factor * speed_factor
                     
        # Clamp to valid probability range
        return min(max(probability, 0.1), 0.99)
    
    @staticmethod
    def svm_threat_classification(threat_data):
        """Use SVM to classify threats by danger level"""
        if not threat_data or len(threat_data) < 3:
            return []
            
        # Extract features from threats
        features = []
        for threat in threat_data:
            # Create feature vector [distance, speed, type_coefficient]
            type_coefficient = {
                "Ballistic Missile": 10.0,
                "Cruise Missile": 8.0,
                "Aircraft": 6.0,
                "Drone": 4.0
            }.get(threat.get('type', 'Unknown'), 5.0)
            
            distance = threat.get('distance', 500)
            speed = threat.get('speed', 500)
            
            features.append([distance, speed, type_coefficient])
        
        # Create arbitrary labels for demo (in reality these would be expertly labeled)
        # 0: Low danger, 1: Medium danger, 2: High danger
        labels = []
        for feature in features:
            distance, speed, type_coef = feature
            # Simple rule-based labeling
            if distance < 100 and type_coef > 7:
                labels.append(2)  # High danger
            elif distance < 200 or (type_coef > 7 and speed > 1000):
                labels.append(1)  # Medium danger
            else:
                labels.append(0)  # Low danger
        
        # Train SVM
        clf = SVC(kernel='rbf', probability=True)
        clf.fit(features, labels)
        
        # Classify each threat
        predictions = clf.predict(features)
        probabilities = clf.predict_proba(features)
        
        # Create classification results
        results = []
        danger_levels = ["Low", "Medium", "High"]
        
        for i, threat in enumerate(threat_data):
            threat_id = threat.get('id', i)
            prediction = predictions[i]
            prob = max(probabilities[i])
            
            results.append({
                'id': threat_id,
                'danger_level': danger_levels[prediction],
                'confidence': prob,
                'features': features[i]
            })
            
        return results
        
    @staticmethod
    def knn_deployment_strategy(defense_systems, threats, k=3):
        """Use KNN to match threats with most suitable defense systems"""
        if not defense_systems or not threats:
            return {}
            
        # Create defense system features
        ds_features = []
        for system in defense_systems:
            # Convert range class to numeric value
            range_value = {
                "Short range": 1,
                "Medium range": 2,
                "Long range": 3,
                "Medium to long range": 2.5
            }.get(system.range_class, 2)
            
            # Convert type to numeric value
            type_value = {
                "Surface-to-air": 1,
                "Anti-ballistic missile": 2,
                "Air defense": 3,
                "Air defense/Anti-ballistic": 2.5
            }.get(system.type, 1.5)
            
            ds_features.append([
                range_value, 
                type_value,
                system.ammo / 100,  # Normalize to 0-1
                system.battery_level / 100  # Normalize to 0-1
            ])
        
        # Create threat features
        threat_features = []
        for threat in threats:
            distance = threat.get('distance', 500) / 500  # Normalize to 0-1
            speed = threat.get('speed', 1000) / 2000  # Normalize to 0-1
            
            # Convert type to numeric value
            type_value = {
                "Ballistic Missile": 2,
                "Cruise Missile": 1.5,
                "Aircraft": 1,
                "Drone": 0.5
            }.get(threat.get('type', 'Unknown'), 1)
            
            threat_features.append([distance, speed, type_value, 0])  # Last feature is placeholder
        
        # Train KNN model on defense systems
        knn = KNeighborsClassifier(n_neighbors=min(k, len(ds_features)))
        # Create labels (just the index of each system)
        labels = list(range(len(ds_features)))
        knn.fit(ds_features, labels)
        
        # Find best defense system for each threat
        assignments = {}
        
        for i, threat in enumerate(threats):
            # Find k nearest defense systems
            distances, indices = knn.kneighbors([threat_features[i]], n_neighbors=min(k, len(ds_features)))
            
            # Get the best match (first one)
            best_system_idx = indices[0][0]
            
            # Store assignment
            threat_id = threat.get('id', i)
            assignments[threat_id] = {
                'system_index': best_system_idx,
                'system_name': defense_systems[best_system_idx].name,
                'match_score': 1 - (distances[0][0] / 4)  # Normalize distance to a 0-1 score
            }
            
        return assignments


class InterceptStrategy:
    """Algorithms for strategic threat interception"""
    
    @staticmethod
    def optimize_resource_allocation(threats, defense_systems, max_missiles_per_threat=2):
        """
        Allocate defense resources optimally using a greedy algorithm
        
        This algorithm prioritizes threats and allocates the best defense systems
        to the highest priority threats first.
        """
        if not threats or not defense_systems:
            return []
            
        # Get prioritized threats
        prioritized_threats = ThreatAnalysis.calculate_threat_priority(threats)
        if not prioritized_threats:
            return []
            
        # Filter operational systems with ammo
        available_systems = [sys for sys in defense_systems 
                            if sys.operational and sys.ammo > 0]
        if not available_systems:
            return []
            
        # Calculate system effectiveness scores
        system_scores = {}
        for system in available_systems:
            # Consider ammo, battery, and overall effectiveness
            score = system.ammo * 0.4 + system.battery_level * 0.3
            
            # Add range factor
            range_factor = {
                "Short range": 1.0,
                "Medium range": 2.0,
                "Long range": 3.0,
                "Medium to long range": 2.5
            }.get(system.range_class, 1.0)
            
            system_scores[system.name] = score * range_factor
        
        # Greedy algorithm: allocate best resources to highest threats first
        allocations = []
        missiles_allocated = {system.name: 0 for system in available_systems}
        
        for threat in prioritized_threats:
            # Determine how many missiles to allocate based on threat priority
            threat_priority = threat['priority']
            
            # Higher priority threats get more missiles, up to max
            if threat_priority > 8:
                missiles_needed = min(max_missiles_per_threat, 2)
            else:
                missiles_needed = 1
                
            # Find best systems for this threat
            best_systems = sorted(
                available_systems,
                key=lambda s: system_scores[s.name] * (s.ammo > missiles_allocated[s.name]),
                reverse=True
            )
            
            allocated_systems = []
            for system in best_systems:
                if missiles_allocated[system.name] + missiles_needed <= system.ammo:
                    # System has enough ammo
                    allocated_systems.append({
                        'system': system.name,
                        'missiles': missiles_needed
                    })
                    missiles_allocated[system.name] += missiles_needed
                    break
                elif system.ammo > missiles_allocated[system.name]:
                    # System has some ammo left
                    available = system.ammo - missiles_allocated[system.name]
                    allocated_systems.append({
                        'system': system.name,
                        'missiles': available
                    })
                    missiles_allocated[system.name] += available
                    missiles_needed -= available
                    if missiles_needed <= 0:
                        break
            
            if allocated_systems:
                allocations.append({
                    'threat_id': threat['id'],
                    'priority': threat['priority'],
                    'time_to_impact': threat['time_to_impact'],
                    'systems': allocated_systems
                })
        
        return allocations
    
    @staticmethod
    def decision_tree_intercept_strategy(threats, defense_system):
        """Use decision tree to decide interception strategy for each threat"""
        if not threats or not defense_system:
            return []
            
        # Create dataset for training
        X = []
        y = []
        
        # Create simulated historical data (in a real system, this would be actual data)
        for _ in range(50):  # 50 simulated historical cases
            # Random threat parameters
            distance = random.uniform(50, 500)
            speed = random.uniform(300, 2000)
            time_to_impact = distance / (speed / 3600)
            
            formation = random.choice([True, False])
            threat_type_value = random.choice([0, 1, 2, 3])  # 0:Drone, 1:Aircraft, 2:Cruise, 3:Ballistic
            
            # Defense system state
            ammo = random.uniform(0.2, 1.0)  # Normalized
            battery = random.uniform(0.2, 1.0)  # Normalized
            
            X.append([distance, speed, time_to_impact, formation, threat_type_value, ammo, battery])
            
            # Strategy label
            # 0: Wait for closer approach
            # 1: Immediate intercept
            # 2: Salvo fire
            # 3: Request backup
            
            # Simple rule-based labeling (this would be expert-labeled data in reality)
            if formation:
                y.append(2)  # Salvo fire for formations
            elif ammo < 0.3 or battery < 0.3:
                y.append(3)  # Request backup if low resources
            elif distance < 100 or time_to_impact < 60:
                y.append(1)  # Immediate intercept if close/imminent
            else:
                y.append(0)  # Otherwise wait
        
        # Train decision tree
        clf = DecisionTreeClassifier(max_depth=5, random_state=42)
        clf.fit(X, y)
        
        # Analyze each threat
        strategies = []
        strategy_names = [
            "Wait for closer approach",
            "Immediate intercept",
            "Salvo fire",
            "Request backup"
        ]
        
        for threat in threats:
            if threat.get('intercepted', False):
                continue
                
            # Get threat parameters
            distance = threat.get('distance', 0)
            speed = threat.get('speed', 0)
            time_to_impact = distance / (speed / 3600) if speed > 0 else 9999
            
            formation = threat.get('in_formation', False)
            
            # Map threat type to numeric value
            threat_type_value = {
                "Drone": 0, 
                "Aircraft": 1, 
                "Cruise Missile": 2, 
                "Ballistic Missile": 3
            }.get(threat.get('type', 'Unknown'), 1)
            
            # Defense system state
            ammo = defense_system.ammo / 100
            battery = defense_system.battery_level / 100
            
            # Make prediction
            features = [distance, speed, time_to_impact, formation, threat_type_value, ammo, battery]
            strategy = clf.predict([features])[0]
            
            # Feature importance for this decision
            feature_importance = {}
            for i, feature_name in enumerate([
                "Distance", "Speed", "Time to Impact", 
                "Formation", "Threat Type", "Ammo", "Battery"
            ]):
                feature_importance[feature_name] = clf.feature_importances_[i]
            
            strategies.append({
                'threat_id': threat.get('id', 0),
                'recommended_strategy': strategy_names[strategy],
                'strategy_code': strategy,
                'feature_importance': feature_importance
            })
        
        return strategies
    
    @staticmethod
    def salvo_intercept_planning(threats, defense_system):
        """Plan a salvo (multiple simultaneous launches) for grouped threats"""
        if not threats:
            return []
            
        # Identify threat clusters/formations
        formations = ThreatAnalysis.identify_missile_formations(threats)
        
        # If no formations found, return empty list
        if not formations:
            return []
            
        salvo_plans = []
        for formation in formations:
            # Skip if not enough missiles
            if len(formation) > defense_system.ammo:
                continue
                
            # Calculate best interception timing
            # We want to intercept all threats in the formation with a single salvo
            
            # Get average distance and speed of formation
            avg_distance = sum(t.get('distance', 0) for t in formation) / len(formation)
            
            # Calculate optimal intercept distance
            intercept_point = DefenseOptimization.calculate_optimal_intercept_point(
                {'distance': avg_distance, 'heading': formation[0].get('heading', 'North')},
                defense_system
            )
            
            # Create salvo plan
            salvo_plans.append({
                'formation_size': len(formation),
                'threat_ids': [t['id'] for t in formation],
                'intercept_distance': intercept_point['distance'],
                'intercept_time': intercept_point['time'],
                'missiles_required': len(formation),
                'success_probability': intercept_point['success_probability']
            })
            
        return salvo_plans

    @staticmethod
    def gradient_boosting_outcome_prediction(threat_data, defense_system_data):
        """Use gradient boosting to predict interception success probability"""
        if not threat_data or not defense_system_data:
            return None
            
        # Create features from threat and defense system data
        features = []
        for threat in threat_data:
            for system in defense_system_data:
                # Create feature vector
                distance = threat.get('distance', 500)
                speed = threat.get('speed', 1000)
                
                # Convert threat type to numeric value
                threat_type_value = {
                    "Ballistic Missile": 3,
                    "Cruise Missile": 2,
                    "Aircraft": 1,
                    "Drone": 0,
                    "Unknown": 1.5
                }.get(threat.get('type', 'Unknown'), 1.5)
                
                # Convert defense system type to numeric value
                system_type_value = {
                    "Surface-to-air": 1,
                    "Anti-ballistic missile": 3,
                    "Air defense": 2,
                    "Air defense/Anti-ballistic": 2.5
                }.get(system.get('type', 'Unknown'), 1.5)
                
                # Convert range class to numeric value
                range_value = {
                    "Short range": 1,
                    "Medium range": 2,
                    "Long range": 3,
                    "Medium to long range": 2.5
                }.get(system.get('range_class', 'Unknown'), 2)
                
                # System conditions
                ammo = system.get('ammo', 50) / 100
                battery = system.get('battery_level', 50) / 100
                
                features.append([
                    distance, speed, threat_type_value, 
                    system_type_value, range_value, ammo, battery
                ])
        
        # Generate synthetic outcomes for training
        # In reality, this would be historical data
        outcomes = []
        for feature in features:
            distance, speed, threat_type, system_type, range_val, ammo, battery = feature
            
            # Simple rule-based success probability
            base_prob = 0.75
            distance_factor = 1 - (distance / 1000)  # Closer is better
            speed_factor = 1 - (speed / 3000)  # Slower is easier to hit
            type_match = 1 - abs(system_type - threat_type) / 3  # Better if system matches threat
            condition_factor = (ammo + battery) / 2  # Better if system is in good condition
            
            success_prob = base_prob * distance_factor * speed_factor * type_match * condition_factor
            
            # Add some noise
            success_prob = max(0.1, min(0.95, success_prob + random.uniform(-0.1, 0.1)))
            
            # Convert to binary outcome with probability
            outcome = 1 if random.random() < success_prob else 0
            outcomes.append(outcome)
        
        # Train gradient boosting model
        gb = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
        gb.fit(features, outcomes)
        
        # Return the trained model for predictions
        return gb

    @staticmethod
    def simulate_engagement(threats, defense_systems, duration_seconds=120):
        """Simulate an entire engagement over time to predict outcomes"""
        if not threats or not defense_systems:
            return {'success_rate': 0, 'remaining_threats': len(threats)}
            
        # Make copies to avoid modifying originals
        sim_threats = [dict(t) for t in threats]
        sim_systems = {s.name: {'ammo': s.ammo, 'battery': s.battery_level, 'operational': s.operational} 
                      for s in defense_systems}
        active_system = next((s for s in defense_systems if s.name == getattr(defense_systems[0], 'active_system', {}).name), 
                            defense_systems[0])
        
        # Track simulation results
        intercepted_count = 0
        
        # Time steps in seconds
        for current_time in range(duration_seconds):
            # Update threat positions based on speed
            for threat in sim_threats:
                if threat.get('intercepted', False):
                    continue
                    
                # Calculate new distance
                speed_km_per_sec = threat['speed'] / 3600  # Convert km/h to km/s
                threat['distance'] -= speed_km_per_sec
                
                # Check if threat has reached target
                if threat['distance'] <= 0:
                    threat['reached_target'] = True
            
            # Attempt interception of highest priority threats
            priorities = ThreatAnalysis.calculate_threat_priority(sim_threats)
            
            # Try to intercept highest priority threat if system has ammo
            if priorities and sim_systems[active_system.name]['ammo'] > 0 and sim_systems[active_system.name]['operational']:
                top_threat_id = priorities[0]['id']
                
                # Find this threat in our simulation
                for threat in sim_threats:
                    if threat['id'] == top_threat_id and not threat.get('intercepted', False):
                        # Calculate intercept probability
                        success_prob = DefenseOptimization.calculate_success_probability(
                            threat, active_system, threat['distance']
                        )
                        
                        # Attempt intercept
                        if random.random() < success_prob:
                            threat['intercepted'] = True
                            intercepted_count += 1
                        
                        # Use ammo and battery regardless of outcome
                        sim_systems[active_system.name]['ammo'] -= 1
                        sim_systems[active_system.name]['battery'] -= 2
                        
                        # Check if system is still operational
                        if sim_systems[active_system.name]['battery'] <= 0:
                            sim_systems[active_system.name]['operational'] = False
                        
                        break
        
        # Calculate final results
        remaining_threats = sum(1 for t in sim_threats if not t.get('intercepted', False))
        success_rate = intercepted_count / len(sim_threats) if sim_threats else 0
        
        return {
            'intercepted': intercepted_count,
            'total_threats': len(sim_threats),
            'success_rate': success_rate,
            'remaining_threats': remaining_threats,
            'systems_status': sim_systems
        }

class SearchAlgorithms:
    """Collection of search algorithms for various defense applications"""
    
    @staticmethod
    def binary_search_defense_system(systems, target_capability):
        """
        Use binary search to find a defense system matching target capability
        
        Args:
            systems: List of defense systems sorted by capability score
            target_capability: Target capability score to search for
            
        Returns:
            Index of the system with closest capability or -1 if not found
        """
        if not systems:
            return -1
            
        left, right = 0, len(systems) - 1
        
        while left <= right:
            mid = (left + right) // 2
            
            # Get capability score of the middle system
            mid_score = systems[mid].get('capability_score', 0)
            
            if mid_score == target_capability:
                return mid
            elif mid_score < target_capability:
                left = mid + 1
            else:
                right = mid - 1
        
        # If we didn't find exact match, return closest
        if left >= len(systems):
            return right
        if right < 0:
            return left
            
        # Return the closer one
        if abs(systems[left].get('capability_score', 0) - target_capability) < \
           abs(systems[right].get('capability_score', 0) - target_capability):
            return left
        return right
    
    @staticmethod
    def depth_first_search_interception_path(grid, start, target):
        """
        Use DFS to find a path through a grid with obstacles
        
        Args:
            grid: 2D grid where 0 represents open space and 1 represents obstacles
            start: (x, y) starting coordinates
            target: (x, y) target coordinates
            
        Returns:
            List of coordinates representing path or empty list if no path exists
        """
        if not grid or not start or not target:
            return []
            
        rows, cols = len(grid), len(grid[0])
        
        # Check if start or target are invalid
        if not (0 <= start[0] < cols and 0 <= start[1] < rows) or \
           not (0 <= target[0] < cols and 0 <= target[1] < rows) or \
           grid[start[1]][start[0]] == 1 or grid[target[1]][target[0]] == 1:
            return []
            
        # Define movements (up, right, down, left)
        directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        
        # Track visited cells
        visited = set()
        
        # Stack for DFS
        stack = [(start, [start])]
        
        while stack:
            (x, y), path = stack.pop()
            
            # Skip if already visited
            if (x, y) in visited:
                continue
                
            # Mark as visited
            visited.add((x, y))
            
            # Check if we reached the target
            if (x, y) == target:
                return path
                
            # Try all directions
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                
                # Check if valid move
                if 0 <= nx < cols and 0 <= ny < rows and grid[ny][nx] == 0 and (nx, ny) not in visited:
                    # Add to stack with updated path
                    new_path = path + [(nx, ny)]
                    stack.append(((nx, ny), new_path))
        
        # No path found
        return []
    
    @staticmethod
    def breadth_first_search_sector_scan(grid, start, max_distance):
        """
        Use BFS to scan sectors around a position
        
        Args:
            grid: 2D grid where each cell is a sector
            start: (x, y) starting coordinates
            max_distance: Maximum distance to scan
            
        Returns:
            List of coordinates visited in BFS order and their distance
        """
        if not grid or not start:
            return []
            
        rows, cols = len(grid), len(grid[0])
        
        # Check if start is invalid
        if not (0 <= start[0] < cols and 0 <= start[1] < rows):
            return []
            
        # Define movements (up, right, down, left)
        directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        
        # Track visited cells
        visited = {start: 0}  # (x, y) -> distance
        
        # Queue for BFS
        queue = [start]
        
        results = []
        
        while queue:
            x, y = queue.pop(0)
            distance = visited[(x, y)]
            
            # Add to results
            results.append(((x, y), distance))
            
            # Stop if reached max distance
            if distance >= max_distance:
                continue
                
            # Try all directions
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                
                # Check if valid move
                if 0 <= nx < cols and 0 <= ny < rows and (nx, ny) not in visited:
                    # Add to queue and mark as visited
                    queue.append((nx, ny))
                    visited[(nx, ny)] = distance + 1
        
        return results

class SortingAlgorithms:
    """Collection of sorting algorithms for defense applications"""
    
    @staticmethod
    def merge_sort_threats_by_priority(threats):
        """
        Sort threats by priority using merge sort algorithm
        
        Args:
            threats: List of threat objects with 'priority' property
            
        Returns:
            Sorted list of threats
        """
        if not threats:
            return []
            
        # Create copies with priority values
        threat_items = []
        for threat in threats:
            # Calculate priority if not present
            if 'priority' not in threat:
                distance = threat.get('distance', 1000)
                speed = threat.get('speed', 0)
                
                # Simple priority calculation
                priority = speed / max(distance, 1)
            else:
                priority = threat['priority']
                
            threat_items.append((threat, priority))
            
        # Define merge sort function
        def merge_sort(items):
            if len(items) <= 1:
                return items
                
            # Split list in half
            mid = len(items) // 2
            left = merge_sort(items[:mid])
            right = merge_sort(items[mid:])
            
            # Merge sorted halves
            return merge(left, right)
            
        def merge(left, right):
            result = []
            i = j = 0
            
            # Compare items from both lists
            while i < len(left) and j < len(right):
                # Sort by priority (descending)
                if left[i][1] > right[j][1]:
                    result.append(left[i])
                    i += 1
                else:
                    result.append(right[j])
                    j += 1
            
            # Add remaining items
            result.extend(left[i:])
            result.extend(right[j:])
            return result
            
        # Sort and return threats only
        sorted_items = merge_sort(threat_items)
        return [item[0] for item in sorted_items]
    
    @staticmethod
    def naive_bayes_classifier(threat_data, labels=None):
        """
        Use Naive Bayes algorithm to classify threats
        
        Args:
            threat_data: List of threats with features
            labels: Optional predefined labels
            
        Returns:
            Classified threats with labels
        """
        if not threat_data:
            return []
            
        # Extract features from threats
        features = []
        for threat in threat_data:
            # Create feature vector
            distance = threat.get('distance', 500) / 500  # Normalize
            speed = threat.get('speed', 1000) / 2000  # Normalize
            
            # Convert threat type to numeric value
            threat_type_value = {
                "Ballistic Missile": 1.0,
                "Cruise Missile": 0.8,
                "Aircraft": 0.5,
                "Drone": 0.3,
                "Unknown": 0.7
            }.get(threat.get('type', 'Unknown'), 0.7)
            
            features.append([distance, speed, threat_type_value])
        
        # Create or use labels
        if not labels:
            # Simple rule-based labeling (0: Low, 1: Medium, 2: High)
            labels = []
            for feature in features:
                distance, speed, type_val = feature
                if distance < 0.2 or (type_val > 0.7 and speed > 0.7):
                    labels.append(2)  # High threat
                elif distance < 0.4 or speed > 0.6:
                    labels.append(1)  # Medium threat
                else:
                    labels.append(0)  # Low threat
        
        # Train Naive Bayes classifier
        nb = GaussianNB()
        nb.fit(features, labels)
        
        # Classify each threat
        predictions = nb.predict(features)
        probabilities = nb.predict_proba(features)
        
        # Create classification results
        results = []
        threat_levels = ["Low", "Medium", "High"]
        
        for i, threat in enumerate(threat_data):
            threat_id = threat.get('id', i)
            prediction = predictions[i]
            prob = max(probabilities[i])
            
            results.append({
                'id': threat_id,
                'threat_level': threat_levels[prediction],
                'confidence': prob,
                'features': features[i]
            })
            
        return results
    
    @staticmethod
    def quicksort_defense_systems(systems, key='effectiveness'):
        """
        Sort defense systems using quicksort algorithm
        
        Args:
            systems: List of defense system objects
            key: Attribute to sort by
            
        Returns:
            Sorted list of defense systems
        """
        if not systems:
            return []
            
        # Extract key values
        items = []
        for i, system in enumerate(systems):
            # Get value to sort by
            if key == 'effectiveness':
                # Calculate effectiveness score
                ammo = system.ammo / 100
                battery = system.battery_level / 100
                
                # Range factor
                range_factor = {
                    "Short range": 1.0,
                    "Medium range": 2.0,
                    "Long range": 3.0,
                    "Medium to long range": 2.5
                }.get(system.range_class, 1.0)
                
                value = ammo * 0.4 + battery * 0.3 + range_factor * 0.3
            else:
                # Use attribute directly
                value = getattr(system, key, 0)
                
            items.append((i, value))
            
        # Define quicksort function
        def quicksort(items, low, high):
            if low < high:
                # Partition and get pivot index
                pivot_index = partition(items, low, high)
                
                # Sort recursively
                quicksort(items, low, pivot_index - 1)
                quicksort(items, pivot_index + 1, high)
                
        def partition(items, low, high):
            # Use high element as pivot
            pivot_value = items[high][1]
            
            # Index of smaller element
            i = low - 1
            
            for j in range(low, high):
                # If current element <= pivot
                if items[j][1] <= pivot_value:
                    i += 1
                    items[i], items[j] = items[j], items[i]
            
            # Swap pivot to correct position
            items[i + 1], items[high] = items[high], items[i + 1]
            return i + 1
            
        # Sort the items (ascending order)
        quicksort(items, 0, len(items) - 1)
        
        # Reverse for descending order and return original objects
        return [systems[item[0]] for item in reversed(items)]

class AprioriAlgorithm:
    """Association rule mining for threat pattern analysis"""
    
    @staticmethod
    def find_threat_patterns(historical_threats, min_support=0.3, min_confidence=0.6):
        """
        Find patterns in threat data using Apriori algorithm
        
        Args:
            historical_threats: List of threat events, each with multiple attributes
            min_support: Minimum support threshold
            min_confidence: Minimum confidence threshold
            
        Returns:
            Association rules between threat attributes
        """
        if not historical_threats:
            return []
            
        # Extract itemsets from threats
        transactions = []
        for threat in historical_threats:
            itemset = set()
            
            # Add threat attributes as items
            if threat.get('type'):
                itemset.add(f"type:{threat['type']}")
                
            if threat.get('speed'):
                speed = threat['speed']
                if speed < 500:
                    itemset.add("speed:slow")
                elif speed < 1000:
                    itemset.add("speed:medium")
                else:
                    itemset.add("speed:fast")
                    
            if threat.get('heading'):
                itemset.add(f"heading:{threat['heading']}")
                
            if threat.get('in_formation', False):
                itemset.add("formation:yes")
            else:
                itemset.add("formation:no")
                
            # Add result if available
            if 'intercepted' in threat:
                itemset.add(f"result:{'intercepted' if threat['intercepted'] else 'missed'}")
                
            transactions.append(itemset)
            
        # Generate frequent itemsets
        min_support_count = min_support * len(transactions)
        
        # Generate single items first
        item_counts = {}
        for transaction in transactions:
            for item in transaction:
                item_counts[item] = item_counts.get(item, 0) + 1
                
        # Filter by minimum support
        frequent_1_itemsets = {frozenset([item]): count 
                               for item, count in item_counts.items() 
                               if count >= min_support_count}
                               
        # Generate all frequent itemsets
        k = 2
        frequent_itemsets = dict(frequent_1_itemsets)
        current_frequent = frequent_1_itemsets
        
        while current_frequent:
            # Generate candidates
            candidates = AprioriAlgorithm.generate_candidates(current_frequent.keys(), k)
            
            # Count support for candidates
            candidate_counts = {}
            for transaction in transactions:
                for candidate in candidates:
                    if candidate.issubset(transaction):
                        candidate_counts[candidate] = candidate_counts.get(candidate, 0) + 1
                        
            # Filter by minimum support
            current_frequent = {itemset: count 
                               for itemset, count in candidate_counts.items() 
                               if count >= min_support_count}
                               
            # Add to frequent itemsets
            frequent_itemsets.update(current_frequent)
            k += 1
            
        # Generate association rules
        rules = []
        for itemset, support_count in frequent_itemsets.items():
            if len(itemset) < 2:
                continue
                
            # Calculate support
            support = support_count / len(transactions)
            
            # Generate all possible rules from this itemset
            for i in range(1, len(itemset)):
                for antecedent in AprioriAlgorithm.combinations(itemset, i):
                    antecedent = frozenset(antecedent)
                    consequent = itemset - antecedent
                    
                    # Skip if consequent is not in frequent itemsets
                    if consequent not in frequent_1_itemsets:
                        continue
                        
                    # Calculate confidence
                    antecedent_support = frequent_itemsets.get(antecedent, 0)
                    if antecedent_support == 0:
                        continue
                        
                    confidence = support_count / antecedent_support
                    
                    # Add rule if it meets minimum confidence
                    if confidence >= min_confidence:
                        rules.append({
                            'antecedent': list(antecedent),
                            'consequent': list(consequent),
                            'support': support,
                            'confidence': confidence
                        })
        
        return rules
    
    @staticmethod
    def generate_candidates(itemsets, k):
        """Generate k-size candidate itemsets from (k-1)-size frequent itemsets"""
        candidates = set()
        
        for itemset1 in itemsets:
            for itemset2 in itemsets:
                # Itemsets must have k-2 elements in common
                union = itemset1.union(itemset2)
                if len(union) == k:
                    candidates.add(union)
                    
        return candidates
    
    @staticmethod
    def combinations(items, r):
        """Generate all r-length combinations from items"""
        items = list(items)
        n = len(items)
        
        if r > n:
            return
            
        indices = list(range(r))
        yield tuple(items[i] for i in indices)
        
        while True:
            for i in reversed(range(r)):
                if indices[i] != i + n - r:
                    break
            else:
                return
                
            indices[i] += 1
            for j in range(i+1, r):
                indices[j] = indices[j-1] + 1
                
            yield tuple(items[i] for i in indices)
