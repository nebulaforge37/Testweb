
"""
Predefined Threat Scenarios for Missile Defense Simulation
"""

import random
from military_tactics import MilitaryTactics, MilitaryTargets

class ThreatScenarios:
    """Collection of realistic threat scenarios for simulation"""
    
    @staticmethod
    def generate_scenario(scenario_name, difficulty=2):
        """Generate a complete threat scenario based on predefined templates"""
        scenarios = {
            "border_skirmish": ThreatScenarios.border_skirmish_scenario,
            "surprise_attack": ThreatScenarios.surprise_attack_scenario,
            "strategic_strike": ThreatScenarios.strategic_strike_scenario,
            "terrorist_attack": ThreatScenarios.terrorist_attack_scenario,
            "full_scale_invasion": ThreatScenarios.full_scale_invasion_scenario,
            "saturation_attack": ThreatScenarios.saturation_attack_scenario,
            "decoy_and_strike": ThreatScenarios.decoy_and_strike_scenario,
            "electronic_warfare": ThreatScenarios.electronic_warfare_scenario,
            "random": ThreatScenarios.random_scenario
        }
        
        # Default to random if scenario not found
        scenario_generator = scenarios.get(scenario_name, ThreatScenarios.random_scenario)
        return scenario_generator(difficulty)
    
    @staticmethod
    def border_skirmish_scenario(difficulty=2):
        """Limited missile exchange in border area"""
        # Scale number of threats based on difficulty
        num_threats = 2 + difficulty
        
        threats = []
        
        # Add primarily short-range missiles
        for i in range(num_threats):
            threat_type = random.choice(["Cruise Missile", "Aircraft"] * 3 + ["Ballistic Missile"])
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": random.randint(100, 300),
                "speed": random.randint(300, 800),
                "heading": random.choice(["North", "South", "East", "West"]),
                "intercepted": False,
                "target": random.choice(MilitaryTargets.TARGET_CATEGORIES["Military"][:5])
            }
            threats.append(threat)
        
        return {
            "name": "Border Skirmish",
            "description": "Limited missile exchange in border area",
            "threat_level": "Medium",
            "threats": threats,
            "tactics": [MilitaryTactics.OFFENSIVE_TACTICS["Terrain Masking"]],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Point Defense"]
        }
    
    @staticmethod
    def surprise_attack_scenario(difficulty=2):
        """Unexpected attack with little warning"""
        # Scale number of threats based on difficulty
        num_threats = 3 + (difficulty * 2)
        
        threats = []
        
        # Add varied missile types with short warning time (close distance)
        for i in range(num_threats):
            threat_type = random.choice(["Cruise Missile", "Ballistic Missile", "Aircraft"])
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": random.randint(80, 200),  # Closer distance for surprise
                "speed": random.randint(600, 1200),
                "heading": random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"]),
                "intercepted": False,
                "target": random.choice(MilitaryTargets.TARGET_CATEGORIES["Military"] + 
                                     MilitaryTargets.TARGET_CATEGORIES["Strategic"][:5])
            }
            threats.append(threat)
        
        return {
            "name": "Surprise Attack",
            "description": "Unexpected attack with minimal warning time",
            "threat_level": "High",
            "threats": threats,
            "tactics": [
                MilitaryTactics.OFFENSIVE_TACTICS["Time-on-Target"],
                MilitaryTactics.OFFENSIVE_TACTICS["SEAD"]
            ],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Early Warning"]
        }
    
    @staticmethod
    def strategic_strike_scenario(difficulty=2):
        """Precision strike against high-value targets"""
        # Scale number of threats based on difficulty
        num_threats = 2 + difficulty
        
        threats = []
        
        # Mix of ballistic missiles and cruise missiles
        for i in range(num_threats):
            if i < num_threats // 2:
                threat_type = "Ballistic Missile"  # Strategic targets often use ballistic missiles
                speed = random.randint(1200, 2000)
                distance = random.randint(300, 500)
            else:
                threat_type = "Cruise Missile"  # Supplement with cruise missiles
                speed = random.randint(800, 1200)
                distance = random.randint(200, 400)
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": distance,
                "speed": speed,
                "heading": random.choice(["North", "East", "South", "West"]),
                "intercepted": False,
                "target": random.choice(MilitaryTargets.TARGET_CATEGORIES["Strategic"])
            }
            threats.append(threat)
        
        return {
            "name": "Strategic Strike",
            "description": "Precision attack against high-value strategic targets",
            "threat_level": "High",
            "threats": threats,
            "tactics": [
                MilitaryTactics.OFFENSIVE_TACTICS["Standoff Attack"],
                MilitaryTactics.OFFENSIVE_TACTICS["Electronic Warfare"]
            ],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Point Defense"]
        }
    
    @staticmethod
    def terrorist_attack_scenario(difficulty=2):
        """Small-scale but high-impact attack"""
        # Scale number of threats based on difficulty (but keep low)
        num_threats = 1 + difficulty // 2
        
        threats = []
        
        # Primarily cruise missiles or drones
        for i in range(num_threats):
            threat_type = random.choice(["Cruise Missile"] * 2 + ["Drone"])
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": random.randint(50, 150),  # Often launched from closer range
                "speed": random.randint(300, 700),  # Generally slower
                "heading": random.choice(["North", "South", "East", "West"]),
                "intercepted": False,
                "target": random.choice(
                    MilitaryTargets.TARGET_CATEGORIES["Infrastructure"] + 
                    MilitaryTargets.TARGET_CATEGORIES["Strategic"][:3]
                )
            }
            threats.append(threat)
        
        return {
            "name": "Terrorist Attack",
            "description": "Small-scale attack targeting civilian infrastructure",
            "threat_level": "Medium",
            "threats": threats,
            "tactics": [MilitaryTactics.OFFENSIVE_TACTICS["Terrain Masking"]],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Area Defense"]
        }
    
    @staticmethod
    def full_scale_invasion_scenario(difficulty=2):
        """Large-scale coordinated attack preceding invasion"""
        # Scale number of threats based on difficulty
        num_threats = 5 + (difficulty * 3)
        
        threats = []
        
        # Mix of all threat types with coordinated timing
        for i in range(num_threats):
            threat_type = random.choice(["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone"])
            
            # Create formations for similar threats
            in_formation = random.random() < 0.6  # 60% chance to be in formation
            
            # Similar parameters for formation threats
            if in_formation and i > 0 and threats[i-1].get("in_formation", False):
                # Copy parameters from previous threat with slight variations
                prev_threat = threats[i-1]
                distance = prev_threat["distance"] + random.randint(-20, 20)
                speed = prev_threat["speed"] + random.randint(-50, 50)
                heading = prev_threat["heading"]
                threat_type = prev_threat["type"]
            else:
                distance = random.randint(100, 400)
                speed = random.randint(500, 1500)
                heading = random.choice(["North", "South", "East", "West", 
                                      "Northeast", "Northwest", "Southeast", "Southwest"])
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": distance,
                "speed": speed,
                "heading": heading,
                "intercepted": False,
                "in_formation": in_formation,
                "target": random.choice(
                    MilitaryTargets.TARGET_CATEGORIES["Military"] + 
                    MilitaryTargets.TARGET_CATEGORIES["Infrastructure"]
                )
            }
            threats.append(threat)
        
        return {
            "name": "Full-Scale Invasion",
            "description": "Massive coordinated attack preceding ground invasion",
            "threat_level": "High",
            "threats": threats,
            "tactics": [
                MilitaryTactics.OFFENSIVE_TACTICS["Saturation Attack"],
                MilitaryTactics.OFFENSIVE_TACTICS["SEAD"],
                MilitaryTactics.OFFENSIVE_TACTICS["Missile Swarming"]
            ],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Defense in Depth"]
        }
    
    @staticmethod
    def saturation_attack_scenario(difficulty=2):
        """Overwhelming number of threats to saturate defenses"""
        # High number of threats regardless of difficulty
        num_threats = 8 + (difficulty * 2)
        
        threats = []
        
        # Many threats arriving simultaneously
        for i in range(num_threats):
            threat_type = random.choice(["Cruise Missile"] * 3 + ["Ballistic Missile", "Aircraft"])
            
            # Most threats arrive from similar distance for simultaneous arrival
            distance = random.randint(300, 350) + random.randint(-30, 30)
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": distance,
                "speed": random.randint(800, 1200),
                "heading": random.choice(["North", "South", "East", "West", 
                                       "Northeast", "Northwest", "Southeast", "Southwest"]),
                "intercepted": False,
                "target": random.choice(
                    MilitaryTargets.TARGET_CATEGORIES["Military"] + 
                    MilitaryTargets.TARGET_CATEGORIES["Infrastructure"]
                )
            }
            threats.append(threat)
        
        return {
            "name": "Saturation Attack",
            "description": "Overwhelming number of threats to exhaust defensive capabilities",
            "threat_level": "High",
            "threats": threats,
            "tactics": [
                MilitaryTactics.OFFENSIVE_TACTICS["Saturation Attack"],
                MilitaryTactics.OFFENSIVE_TACTICS["Time-on-Target"]
            ],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Distributed Defense"]
        }
    
    @staticmethod
    def decoy_and_strike_scenario(difficulty=2):
        """Decoys followed by actual threats"""
        # Scale number of threats based on difficulty
        num_threats = 4 + difficulty
        num_decoys = num_threats // 2
        
        threats = []
        
        # Add decoys first
        for i in range(num_decoys):
            threat = {
                "id": i + 1,
                "type": "Drone",  # Decoys are typically drones
                "distance": random.randint(200, 300),
                "speed": random.randint(400, 700),
                "heading": random.choice(["North", "South", "East", "West"]),
                "intercepted": False,
                "is_decoy": True
            }
            threats.append(threat)
        
        # Add actual threats
        for i in range(num_decoys, num_threats):
            threat_type = random.choice(["Cruise Missile", "Ballistic Missile"])
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": random.randint(250, 350),  # Arrive after decoys
                "speed": random.randint(800, 1500),
                "heading": random.choice(["North", "South", "East", "West"]),
                "intercepted": False,
                "is_decoy": False,
                "target": random.choice(
                    MilitaryTargets.TARGET_CATEGORIES["Military"] + 
                    MilitaryTargets.TARGET_CATEGORIES["Strategic"]
                )
            }
            threats.append(threat)
        
        return {
            "name": "Decoy and Strike",
            "description": "Decoys deployed to waste interceptors before main attack",
            "threat_level": "High",
            "threats": threats,
            "tactics": [
                MilitaryTactics.OFFENSIVE_TACTICS["Decoy Deployment"],
                MilitaryTactics.OFFENSIVE_TACTICS["Electronic Warfare"]
            ],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Shoot-Look-Shoot"]
        }
    
    @staticmethod
    def electronic_warfare_scenario(difficulty=2):
        """Attack combined with electronic warfare"""
        # Scale number of threats based on difficulty
        num_threats = 3 + difficulty
        
        threats = []
        
        # Add electronic warfare threat
        ew_threat = {
            "id": 1,
            "type": "Electronic Warfare Aircraft",
            "distance": random.randint(300, 400),
            "speed": random.randint(700, 900),
            "heading": random.choice(["North", "South", "East", "West"]),
            "intercepted": False,
            "is_electronic_warfare": True
        }
        threats.append(ew_threat)
        
        # Add regular threats taking advantage of degraded defenses
        for i in range(1, num_threats):
            threat_type = random.choice(["Cruise Missile", "Ballistic Missile", "Aircraft"])
            
            threat = {
                "id": i + 1,
                "type": threat_type,
                "distance": random.randint(200, 350),
                "speed": random.randint(600, 1200),
                "heading": random.choice(["North", "South", "East", "West"]),
                "intercepted": False,
                "defense_degradation": random.uniform(0.1, 0.3),  # Defense effectiveness reduction due to EW
                "target": random.choice(
                    MilitaryTargets.TARGET_CATEGORIES["Military"] + 
                    MilitaryTargets.TARGET_CATEGORIES["Infrastructure"]
                )
            }
            threats.append(threat)
        
        return {
            "name": "Electronic Warfare",
            "description": "Attack combined with radar jamming and electronic warfare",
            "threat_level": "High",
            "threats": threats,
            "tactics": [
                MilitaryTactics.OFFENSIVE_TACTICS["Electronic Warfare"],
                MilitaryTactics.OFFENSIVE_TACTICS["SEAD"]
            ],
            "recommended_defense": MilitaryTactics.DEFENSIVE_TACTICS["Passive Defense"]
        }
    
    @staticmethod
    def random_scenario(difficulty=2):
        """Generate completely random scenario"""
        # Choose a random scenario type
        scenario_types = [
            ThreatScenarios.border_skirmish_scenario,
            ThreatScenarios.surprise_attack_scenario,
            ThreatScenarios.strategic_strike_scenario,
            ThreatScenarios.terrorist_attack_scenario,
            ThreatScenarios.full_scale_invasion_scenario,
            ThreatScenarios.saturation_attack_scenario,
            ThreatScenarios.decoy_and_strike_scenario,
            ThreatScenarios.electronic_warfare_scenario
        ]
        
        chosen_scenario = random.choice(scenario_types)
        return chosen_scenario(difficulty)
