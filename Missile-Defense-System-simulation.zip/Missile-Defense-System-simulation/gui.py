import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import time
import threading
from main import MissileDefenseSystem, MissileDefenseOS
from datetime import datetime
import random
from multi_target_engagement import MultiTargetEngagementSystem, integrate_multi_target

class MissileDefenseGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Missile Defense System")
        self.root.geometry("1000x700")
        self.root.configure(bg="#0a192f")

        self.defense_os = MissileDefenseOS()
        self.active_system = None
        self.running_simulation = False

        # Create main frame with tabs
        self.tab_control = ttk.Notebook(root)

        # Create tabs
        self.home_tab = ttk.Frame(self.tab_control)
        self.systems_tab = ttk.Frame(self.tab_control)
        self.status_tab = ttk.Frame(self.tab_control)
        self.threat_tab = ttk.Frame(self.tab_control)
        self.intercept_tab = ttk.Frame(self.tab_control)
        self.simulation_tab = ttk.Frame(self.tab_control)
        self.map_tab = ttk.Frame(self.tab_control)

        self.tab_control.add(self.home_tab, text="Home")
        self.tab_control.add(self.systems_tab, text="Systems")
        self.tab_control.add(self.status_tab, text="Status")
        self.tab_control.add(self.threat_tab, text="Threat Detection")
        self.tab_control.add(self.intercept_tab, text="Intercept")
        self.tab_control.add(self.simulation_tab, text="Simulation")
        self.tab_control.add(self.map_tab, text="Threat Map")

        self.tab_control.pack(expand=1, fill="both")

        # Import and initialize threat map
        from map_view import ThreatMap
        self.threat_map = ThreatMap(self)

        # Set up each tab
        self.setup_home_tab()
        self.setup_systems_tab()
        self.setup_status_tab()
        self.setup_threat_tab()
        self.setup_intercept_tab()
        self.setup_simulation_tab()

        # Update status bar periodically
        self.update_status_bar()

    def setup_home_tab(self):
        frame = tk.Frame(self.home_tab, bg="#0a192f")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_label = tk.Label(
            frame, 
            text="MISSILE DEFENSE SYSTEM", 
            font=("Arial", 24, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=20)

        # Status overview
        status_frame = tk.LabelFrame(frame, text="System Overview", font=("Arial", 12), fg="white", bg="#112240", bd=2)
        status_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Active System
        self.active_system_var = tk.StringVar(value="None Selected")
        active_label = tk.Label(
            status_frame, 
            text="Active Defense System:", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240"
        )
        active_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        active_value = tk.Label(
            status_frame, 
            textvariable=self.active_system_var, 
            font=("Arial", 12, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        active_value.grid(row=0, column=1, padx=10, pady=10, sticky="w")

        # Threat Level
        self.threat_level_var = tk.StringVar(value="Low")
        threat_label = tk.Label(
            status_frame, 
            text="Current Threat Level:", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240"
        )
        threat_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        threat_value = tk.Label(
            status_frame, 
            textvariable=self.threat_level_var, 
            font=("Arial", 12, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        threat_value.grid(row=1, column=1, padx=10, pady=10, sticky="w")

        # Active Threats
        self.active_threats_var = tk.StringVar(value="0")
        threats_label = tk.Label(
            status_frame, 
            text="Active Threats:", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240"
        )
        threats_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        threats_value = tk.Label(
            status_frame, 
            textvariable=self.active_threats_var, 
            font=("Arial", 12, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        threats_value.grid(row=2, column=1, padx=10, pady=10, sticky="w")

        # Quick actions
        actions_frame = tk.LabelFrame(frame, text="Quick Actions", font=("Arial", 12), fg="white", bg="#112240", bd=2)
        actions_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Create button style
        style = ttk.Style()
        style.configure(
            "Action.TButton", 
            font=("Arial", 11), 
            background="#64ffda", 
            foreground="#0a192f"
        )

        # Action buttons
        select_btn = ttk.Button(
            actions_frame, 
            text="Select Defense System", 
            style="Action.TButton",
            command=lambda: self.tab_control.select(self.systems_tab)
        )
        select_btn.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        detect_btn = ttk.Button(
            actions_frame, 
            text="Run Threat Detection", 
            style="Action.TButton",
            command=lambda: self.tab_control.select(self.threat_tab)
        )
        detect_btn.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

        intercept_btn = ttk.Button(
            actions_frame, 
            text="Intercept Mode", 
            style="Action.TButton",
            command=lambda: self.tab_control.select(self.intercept_tab)
        )
        intercept_btn.grid(row=1, column=0, padx=10, pady=10, sticky="ew")

        simulation_btn = ttk.Button(
            actions_frame, 
            text="Run Simulation", 
            style="Action.TButton",
            command=lambda: self.tab_control.select(self.simulation_tab)
        )
        simulation_btn.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

        # Configure grid weights
        actions_frame.columnconfigure(0, weight=1)
        actions_frame.columnconfigure(1, weight=1)

    def setup_systems_tab(self):
        frame = tk.Frame(self.systems_tab, bg="#0a192f")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_label = tk.Label(
            frame, 
            text="SELECT DEFENSE SYSTEM", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)

        # Systems list frame
        list_frame = tk.Frame(frame, bg="#112240")
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Create columns
        columns = ("id", "name", "country", "type", "range", "status")
        self.systems_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=15)

        # Define headings
        self.systems_tree.heading("id", text="#")
        self.systems_tree.heading("name", text="System Name")
        self.systems_tree.heading("country", text="Country")
        self.systems_tree.heading("type", text="Type")
        self.systems_tree.heading("range", text="Range")
        self.systems_tree.heading("status", text="Status")

        # Define columns width
        self.systems_tree.column("id", width=30, anchor="center")
        self.systems_tree.column("name", width=150)
        self.systems_tree.column("country", width=100)
        self.systems_tree.column("type", width=150)
        self.systems_tree.column("range", width=100)
        self.systems_tree.column("status", width=100, anchor="center")

        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.systems_tree.yview)
        self.systems_tree.configure(yscrollcommand=scrollbar.set)

        # Pack elements
        self.systems_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Populate systems
        self.populate_systems_list()

        # Selection button
        select_btn = ttk.Button(
            frame, 
            text="Select System", 
            style="Action.TButton",
            command=self.select_system
        )
        select_btn.pack(pady=15)

        # Bind double-click to select
        self.systems_tree.bind("<Double-1>", lambda event: self.select_system())

    def setup_status_tab(self):
        frame = tk.Frame(self.status_tab, bg="#0a192f")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_label = tk.Label(
            frame, 
            text="SYSTEM STATUS", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)

        # No system selected message
        self.no_system_frame = tk.Frame(frame, bg="#0a192f")
        self.no_system_label = tk.Label(
            self.no_system_frame, 
            text="No system selected. Please select a system first.", 
            font=("Arial", 14), 
            fg="white", 
            bg="#0a192f"
        )
        self.no_system_label.pack(pady=50)

        # System info frame
        self.system_info_frame = tk.Frame(frame, bg="#0a192f")

        # System name
        self.system_name_var = tk.StringVar()
        system_name_label = tk.Label(
            self.system_info_frame, 
            textvariable=self.system_name_var, 
            font=("Arial", 16, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        system_name_label.pack(pady=10)

        # System details frame
        details_frame = tk.LabelFrame(
            self.system_info_frame, 
            text="System Details", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        details_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Details grid
        labels = ["Type:", "Range Class:", "Country:", "Status:", "Ammunition:", "Battery Level:", "Last Maintenance:"]
        self.detail_vars = []

        for i, label_text in enumerate(labels):
            label = tk.Label(
                details_frame, 
                text=label_text, 
                font=("Arial", 12), 
                fg="white", 
                bg="#112240", 
                anchor="w"
            )
            label.grid(row=i, column=0, padx=10, pady=5, sticky="w")

            var = tk.StringVar()
            self.detail_vars.append(var)

            value_label = tk.Label(
                details_frame, 
                textvariable=var, 
                font=("Arial", 12), 
                fg="#64ffda", 
                bg="#112240", 
                anchor="w"
            )
            value_label.grid(row=i, column=1, padx=10, pady=5, sticky="w")

        # Maintenance buttons frame
        maintenance_frame = tk.Frame(self.system_info_frame, bg="#0a192f")
        maintenance_frame.pack(fill="x", pady=15)

        # Maintenance buttons
        maintain_btn = ttk.Button(
            maintenance_frame, 
            text="Perform Maintenance", 
            style="Action.TButton",
            command=self.perform_maintenance
        )
        maintain_btn.pack(side="left", padx=10)

        reload_btn = ttk.Button(
            maintenance_frame, 
            text="Reload Ammunition", 
            style="Action.TButton",
            command=self.reload_ammunition
        )
        reload_btn.pack(side="left", padx=10)

        diagnostics_btn = ttk.Button(
            maintenance_frame, 
            text="Run Diagnostics", 
            style="Action.TButton",
            command=self.run_diagnostics
        )
        diagnostics_btn.pack(side="left", padx=10)

        # Initially show no system selected message
        self.no_system_frame.pack(fill="both", expand=True)

    def setup_threat_tab(self):
        frame = tk.Frame(self.threat_tab, bg="#0a192f")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_label = tk.Label(
            frame, 
            text="THREAT DETECTION", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)

        # Console output
        console_frame = tk.LabelFrame(
            frame, 
            text="Detection Console", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        console_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.threat_console = scrolledtext.ScrolledText(
            console_frame, 
            width=80, 
            height=20, 
            font=("Courier", 11), 
            bg="#030e1f", 
            fg="#64ffda", 
            bd=0
        )
        self.threat_console.pack(fill="both", expand=True, padx=5, pady=5)
        self.threat_console.insert(tk.END, "Threat detection console initialized.\n")
        self.threat_console.insert(tk.END, "Ready to scan for threats.\n")
        self.threat_console.config(state=tk.DISABLED)

        # Threat list frame
        list_frame = tk.LabelFrame(
            frame, 
            text="Detected Threats", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Create columns
        columns = ("id", "type", "distance", "speed", "heading", "status")
        self.threats_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=6)

        # Define headings
        self.threats_tree.heading("id", text="ID")
        self.threats_tree.heading("type", text="Type")
        self.threats_tree.heading("distance", text="Distance (km)")
        self.threats_tree.heading("speed", text="Speed (km/h)")
        self.threats_tree.heading("heading", text="Heading")
        self.threats_tree.heading("status", text="Status")

        # Define columns width
        self.threats_tree.column("id", width=30, anchor="center")
        self.threats_tree.column("type", width=120)
        self.threats_tree.column("distance", width=100, anchor="center")
        self.threats_tree.column("speed", width=100, anchor="center")
        self.threats_tree.column("heading", width=80, anchor="center")
        self.threats_tree.column("status", width=100, anchor="center")

        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.threats_tree.yview)
        self.threats_tree.configure(yscrollcommand=scrollbar.set)

        # Pack elements
        self.threats_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Button
        scan_btn = ttk.Button(
            frame, 
            text="Scan for Threats", 
            style="Action.TButton",
            command=self.detect_threats
        )
        scan_btn.pack(pady=15)

    def setup_intercept_tab(self):
        frame = tk.Frame(self.intercept_tab, bg="#0a192f")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_label = tk.Label(
            frame, 
            text="INTERCEPT MODE", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)

        # System status frame
        status_frame = tk.LabelFrame(
            frame, 
            text="Defense System Status", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        status_frame.pack(fill="x", padx=10, pady=10)

        # Active system
        self.intercept_system_var = tk.StringVar(value="None Selected")
        active_label = tk.Label(
            status_frame, 
            text="Active System:", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240"
        )
        active_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

        active_value = tk.Label(
            status_frame, 
            textvariable=self.intercept_system_var, 
            font=("Arial", 12, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        active_value.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        # Ammo
        self.intercept_ammo_var = tk.StringVar(value="0")
        ammo_label = tk.Label(
            status_frame, 
            text="Ammunition:", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240"
        )
        ammo_label.grid(row=0, column=2, padx=10, pady=5, sticky="w")

        ammo_value = tk.Label(
            status_frame, 
            textvariable=self.intercept_ammo_var, 
            font=("Arial", 12, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        ammo_value.grid(row=0, column=3, padx=10, pady=5, sticky="w")

        # Threat list frame
        list_frame = tk.LabelFrame(
            frame, 
            text="Active Threats", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Create columns
        columns = ("id", "type", "distance", "heading", "action")
        self.intercept_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=10)

        # Define headings
        self.intercept_tree.heading("id", text="ID")
        self.intercept_tree.heading("type", text="Type")
        self.intercept_tree.heading("distance", text="Distance (km)")
        self.intercept_tree.heading("heading", text="Heading")
        self.intercept_tree.heading("action", text="Action")

        # Define columns width
        self.intercept_tree.column("id", width=30, anchor="center")
        self.intercept_tree.column("type", width=150)
        self.intercept_tree.column("distance", width=100, anchor="center")
        self.intercept_tree.column("heading", width=100, anchor="center")
        self.intercept_tree.column("action", width=150, anchor="center")

        # Add intercept buttons to rows
        def add_intercept_button(item_id):
            button = ttk.Button(
                self.intercept_tree, 
                text="Intercept", 
                command=lambda: self.intercept_threat(item_id)
            )
            return button

        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.intercept_tree.yview)
        self.intercept_tree.configure(yscrollcommand=scrollbar.set)

        # Pack elements
        self.intercept_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Console output
        console_frame = tk.LabelFrame(
            frame, 
            text="Intercept Console", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        console_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.intercept_console = scrolledtext.ScrolledText(
            console_frame, 
            width=80, 
            height=8, 
            font=("Courier", 11), 
            bg="#030e1f", 
            fg="#64ffda", 
            bd=0
        )
        self.intercept_console.pack(fill="both", expand=True, padx=5, pady=5)
        self.intercept_console.insert(tk.END, "Intercept console initialized.\n")
        self.intercept_console.insert(tk.END, "Select a threat to intercept.\n")
        self.intercept_console.config(state=tk.DISABLED)

        # Button
        refresh_btn = ttk.Button(
            frame, 
            text="Refresh Threats", 
            style="Action.TButton",
            command=self.update_intercept_threats
        )
        refresh_btn.pack(pady=15)

    def setup_simulation_tab(self):
        frame = tk.Frame(self.simulation_tab, bg="#0a192f")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_label = tk.Label(
            frame, 
            text="SIMULATION MODE", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)

        # Description
        desc_label = tk.Label(
            frame, 
            text="Run a simulated attack scenario to test system effectiveness", 
            font=("Arial", 12), 
            fg="white", 
            bg="#0a192f"
        )
        desc_label.pack(pady=5)

        # Options frame
        options_frame = tk.LabelFrame(
            frame, 
            text="Simulation Options", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        options_frame.pack(fill="x", padx=10, pady=10)

        # Threats slider
        threats_label = tk.Label(
            options_frame, 
            text="Number of Threats:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        threats_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.threats_var = tk.IntVar(value=5)
        threats_slider = ttk.Scale(
            options_frame, 
            from_=1, 
            to=10, 
            orient="horizontal", 
            variable=self.threats_var,
            length=200,
            command=lambda s: self.threats_var.set(round(float(s)))
        )
        threats_slider.grid(row=0, column=1, padx=10, pady=10, sticky="w")

        threats_value = tk.Label(
            options_frame, 
            textvariable=self.threats_var, 
            font=("Arial", 11), 
            fg="#64ffda", 
            bg="#112240",
            width=2
        )
        threats_value.grid(row=0, column=2, padx=10, pady=10, sticky="w")

        # Difficulty slider
        difficulty_label = tk.Label(
            options_frame, 
            text="Difficulty Level:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        difficulty_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        self.difficulty_var = tk.IntVar(value=2)
        self.difficulty_text_var = tk.StringVar(value="Medium")

        def update_difficulty(val):
            val = round(float(val))
            self.difficulty_var.set(val)
            if val == 1:
                self.difficulty_text_var.set("Easy")
            elif val == 2:
                self.difficulty_text_var.set("Medium")
            else:
                self.difficulty_text_var.set("Hard")

        difficulty_slider = ttk.Scale(
            options_frame, 
            from_=1, 
            to=3, 
            orient="horizontal", 
            length=200,
            command=update_difficulty
        )
        difficulty_slider.set(2)
        difficulty_slider.grid(row=1, column=1, padx=10, pady=10, sticky="w")

        difficulty_value = tk.Label(
            options_frame, 
            textvariable=self.difficulty_text_var, 
            font=("Arial", 11), 
            fg="#64ffda", 
            bg="#112240",
            width=6
        )
        difficulty_value.grid(row=1, column=2, padx=10, pady=10, sticky="w")

        # Scenario selection
        scenario_label = tk.Label(
            options_frame, 
            text="Attack Scenario:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        scenario_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.scenario_var = tk.StringVar(value="random")
        scenario_options = [
            ("Random", "random"),
            ("Border Skirmish", "border_skirmish"),
            ("Surprise Attack", "surprise_attack"),
            ("Strategic Strike", "strategic_strike"),
            ("Full Scale Invasion", "full_scale_invasion"),
            ("Saturation Attack", "saturation_attack"),
            ("Decoy & Strike", "decoy_and_strike"),
            ("Electronic Warfare", "electronic_warfare")
        ]

        scenario_combo = ttk.Combobox(
            options_frame,
            textvariable=self.scenario_var,
            values=[opt[0] for opt in scenario_options],
            state="readonly",
            width=15
        )
        scenario_combo.current(0)
        scenario_combo.grid(row=2, column=1, padx=10, pady=10, sticky="w")

        # Active System
        active_label = tk.Label(
            options_frame, 
            text="Active System:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        active_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.sim_system_var = tk.StringVar(value="None Selected")
        active_value = tk.Label(
            options_frame, 
            textvariable=self.sim_system_var, 
            font=("Arial", 11, "bold"), 
            fg="#64ffda", 
            bg="#112240"
        )
        active_value.grid(row=2, column=1, columnspan=2, padx=10, pady=10, sticky="w")

        # Console output
        console_frame = tk.LabelFrame(
            frame, 
            text="Simulation Console", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        console_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.simulation_console = scrolledtext.ScrolledText(
            console_frame, 
            width=80, 
            height=15, 
            font=("Courier", 11), 
            bg="#030e1f", 
            fg="#64ffda", 
            bd=0
        )
        self.simulation_console.pack(fill="both", expand=True, padx=5, pady=5)
        self.simulation_console.insert(tk.END, "Simulation console initialized.\n")
        self.simulation_console.insert(tk.END, "Configure simulation parameters and press Start to begin.\n")
        self.simulation_console.config(state=tk.DISABLED)

        # Button frame
        button_frame = tk.Frame(frame, bg="#0a192f")
        button_frame.pack(fill="x", pady=15)

        # Start button
        start_btn = ttk.Button(
            button_frame, 
            text="Start Simulation", 
            style="Action.TButton",
            command=self.run_simulation
        )
        start_btn.pack(side="left", padx=10)

        # Reset button
        reset_btn = ttk.Button(
            button_frame, 
            text="Reset Console", 
            style="Action.TButton",
            command=self.reset_simulation
        )
        reset_btn.pack(side="left", padx=10)

    def populate_systems_list(self):
        # Clear existing items
        for item in self.systems_tree.get_children():
            self.systems_tree.delete(item)

        # Add systemsto the treeview
        for i, system in enumerate(self.defense_os.systems, 1):
            status = "OPERATIONAL" if system.operational else "OFFLINE"
            self.systems_tree.insert("", "end", values=(
                i, 
                system.name, 
                system.country, 
                system.type, 
                system.range_class, 
                status
            ))

    def select_system(self):
        selected = self.systems_tree.selection()
        if not selected:
            messagebox.showinfo("Selection", "Please select a system from the list.")
            return

        idx = int(self.systems_tree.item(selected[0])['values'][0]) - 1
        self.active_system = self.defense_os.systems[idx]
        self.defense_os.active_system = self.active_system

        # Update UI elements
        self.active_system_var.set(f"{self.active_system.name} ({self.active_system.country})")
        self.intercept_system_var.set(f"{self.active_system.name}")
        self.intercept_ammo_var.set(f"{self.active_system.ammo}")
        self.sim_system_var.set(f"{self.active_system.name} ({self.active_system.country})")

        # Update status tab
        self.update_system_status()

        # Show message
        messagebox.showinfo("System Selected", f"System {self.active_system.name} is now active.")

    def update_system_status(self):
        if self.active_system:
            # Hide no system message and show info
            self.no_system_frame.pack_forget()
            self.system_info_frame.pack(fill="both", expand=True)

            # Update system name
            self.system_name_var.set(f"{self.active_system.name} ({self.active_system.country})")

            # Update details
            status = "OPERATIONAL" if self.active_system.operational else "OFFLINE"
            details = [
                self.active_system.type,
                self.active_system.range_class,
                self.active_system.country,
                status,
                f"{self.active_system.ammo}/100",
                f"{self.active_system.battery_level}%",
                self.active_system.last_maintenance.strftime("%Y-%m-%d %H:%M:%S")
            ]

            for i, var in enumerate(self.detail_vars):
                var.set(details[i])
        else:
            # Hide info and show no system message
            self.system_info_frame.pack_forget()
            self.no_system_frame.pack(fill="both", expand=True)

    def perform_maintenance(self):
        if not self.active_system:
            messagebox.showinfo("No System", "Please select a defense system first.")
            return

        # Run maintenance
        self.write_to_console(self.threat_console, f"Performing maintenance on {self.active_system.name}...\n")
        self.active_system.perform_maintenance()
        self.write_to_console(self.threat_console, f"Maintenance complete on {self.active_system.name}\n")

        # Update status
        self.update_system_status()
        messagebox.showinfo("Maintenance", f"Maintenance on {self.active_system.name} completed successfully.")

    def reload_ammunition(self):
        if not self.active_system:
            messagebox.showinfo("No System", "Please select a defense system first.")
            return

        # Run reload
        self.write_to_console(self.threat_console, f"Reloading {self.active_system.name}...\n")
        self.active_system.reload()
        self.write_to_console(
            self.threat_console, 
            f"Reload complete. {self.active_system.name} now has {self.active_system.ammo} missiles\n"
        )

        # Update status
        self.update_system_status()
        self.intercept_ammo_var.set(f"{self.active_system.ammo}")
        messagebox.showinfo("Reload", f"{self.active_system.name} reloaded successfully.")

    def run_diagnostics(self):
        if not self.active_system:
            messagebox.showinfo("No System", "Please select a defense system first.")
            return

        # Run diagnostics in a separate thread
        threading.Thread(target=self._run_diagnostics_thread).start()

    def _run_diagnostics_thread(self):
        self.write_to_console(self.threat_console, f"Running diagnostics on {self.active_system.name}...\n")

        for i in range(5):
            self.write_to_console(self.threat_console, f"Checking system component {i+1}/5...\n")
            time.sleep(0.5)

        self.write_to_console(self.threat_console, "Diagnostics complete. All systems operational.\n")

        # Update UI from main thread
        self.root.after(0, lambda: messagebox.showinfo("Diagnostics", "System diagnostics completed successfully."))

    def detect_threats(self):
        # Run threat detection in a separate thread
        threading.Thread(target=self._detect_threats_thread).start()

    def _detect_threats_thread(self):
        # Import military algorithms for threat analysis
        from military_algorithms import ThreatAnalysis, DefenseOptimization, InterceptStrategy

        # Clear console
        self.write_to_console(self.threat_console, "", clear=True)
        self.write_to_console(self.threat_console, "INITIATING THREAT DETECTION SCAN...\n\n")

        # Scan sectors
        for i in range(5):
            self.write_to_console(self.threat_console, f"Scanning sector {i+1}...\n")
            time.sleep(0.5)

        # Generate threats
        num_threats = random.randint(0, 5)
        threat_types = ["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone"]

        # Clear existing threats
        self.defense_os.threats = []

        detection_time = datetime.now()

        # Generate patterns (sometimes threats come in formations)
        formation_chance = random.random()
        if formation_chance > 0.7 and num_threats >= 2:
            # Create a formation attack (same heading, similar distance)
            formation_heading = random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"])
            formation_distance_base = random.randint(200, 400)
            formation_type = random.choice(threat_types)

            for i in range(num_threats):
                threat = {
                    "id": i+1,
                    "type": formation_type,
                    "distance": formation_distance_base + random.randint(-20, 20),  # Slight variation
                    "speed": random.randint(800, 1200),  # Similar speeds
                    "heading": formation_heading,
                    "intercepted": False,
                    "detection_time": detection_time
                }
                self.defense_os.threats.append(threat)

            self.write_to_console(self.threat_console, f"WARNING: Formation attack detected from {formation_heading}!\n")
        else:
            # Generate random individual threats
            for i in range(num_threats):
                threat = {
                    "id": i+1,
                    "type": random.choice(threat_types),
                    "distance": random.randint(50, 500),
                    "speed": random.randint(300, 2000),
                    "heading": random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"]),
                    "intercepted": False,
                    "detection_time": detection_time
                }
                self.defense_os.threats.append(threat)

        # Update threat level
        if num_threats == 0:
            self.defense_os.threat_level = "Low"
        elif num_threats <= 2:
            self.defense_os.threat_level = "Medium"
        else:
            self.defense_os.threat_level = "High"

        # Update UI on main thread
        self.root.after(0, lambda: self.threat_level_var.set(self.defense_os.threat_level))
        self.root.after(0, lambda: self.active_threats_var.set(str(num_threats)))
        self.root.after(0, lambda: self.threat_map.refresh_map())

        # Report results
        self.write_to_console(self.threat_console, "\nSCAN COMPLETE\n")
        self.write_to_console(self.threat_console, f"Detected {num_threats} threats\n")
        self.write_to_console(self.threat_console, f"Threat level set to {self.defense_os.threat_level}\n")

        # Apply military algorithms if we have threats
        if num_threats > 0:
            # Analyze and prioritize threats
            priorities = ThreatAnalysis.calculate_threat_priority(self.defense_os.threats)

            self.write_to_console(self.threat_console, "\nTHREAT ANALYSIS:\n")
            for idx, priority in enumerate(priorities):
                self.write_to_console(
                    self.threat_console,
                    f"Priority #{idx+1}: Threat ID {priority['id']} ({priority['type']}) - "
                    f"Priority Score: {priority['priority']:.1f}, Time to Impact: {priority['time_to_impact']:.1f}s\n"
                )

            # Check for missile formations
            formations = ThreatAnalysis.identify_missile_formations(self.defense_os.threats)
            if formations:
                self.write_to_console(self.threat_console, "\nFORMATION ANALYSIS:\n")
                for i, formation in enumerate(formations):
                    self.write_to_console(
                        self.threat_console,
                        f"Formation #{i+1}: {len(formation)} threats detected - IDs: {[t['id'] for t in formation]}\n"
                    )

                # If we have an active system, plan salvo intercepts
                if hasattr(self, 'active_system') and self.active_system:
                    salvo_plans = InterceptStrategy.salvo_intercept_planning(
                        self.defense_os.threats, 
                        self.active_system
                    )

                    if salvo_plans:
                        self.write_to_console(self.threat_console, "\nSALVO INTERCEPT RECOMMENDATIONS:\n")
                        for plan in salvo_plans:
                            self.write_to_console(
                                self.threat_console,
                                f"Recommending salvo fire against threats {plan['threat_ids']} - "
                                f"Success probability: {plan['success_probability']:.1%}\n"
                            )

            # Display detailed threat information
            self.write_to_console(self.threat_console, "\nTHREAT DETAILS:\n")
            for threat in self.defense_os.threats:
                self.write_to_console(
                    self.threat_console,
                    f"ID: {threat['id']} | Type: {threat['type']} | "
                    f"Distance: {threat['distance']}km | Speed: {threat['speed']}km/h | "
                    f"Heading: {threat['heading']} | Detection Time: {threat['detection_time']}\n"
                )

            # Simulate engagement to predict outcome
            if hasattr(self, 'active_system') and self.active_system:
                sim_result = InterceptStrategy.simulate_engagement(
                    self.defense_os.threats, 
                    [self.active_system]
                )

                self.write_to_console(self.threat_console, "\nENGAGEMENT SIMULATION:\n")
                self.write_to_console(
                    self.threat_console,
                    f"Predicted outcome: {sim_result['success_rate']:.1%} success rate\n"
                    f"Intercepted: {sim_result['intercepted']}/{sim_result['total_threats']}\n"
                    f"Remaining threats: {sim_result['remaining_threats']}\n"
                )

        # Update threat list on main thread
        self.root.after(0, self.update_threat_list)
        self.root.after(0, self.update_intercept_threats)

    def update_threat_list(self):
        # Clear existing items
        for item in self.threats_tree.get_children():
            self.threats_tree.delete(item)

        # Add threats to the treeview
        for threat in self.defense_os.threats:
            status = "INTERCEPTED" if threat['intercepted'] else "ACTIVE"
            self.threats_tree.insert("", "end", values=(
                threat['id'], 
                threat['type'], 
                threat['distance'], 
                threat['speed'], 
                threat['heading'],
                status
            ))

    def update_intercept_threats(self):
        # Clear existing items
        for item in self.intercept_tree.get_children():
            self.intercept_tree.delete(item)

        # Update active system info
        if self.active_system:
            self.intercept_ammo_var.set(f"{self.active_system.ammo}")

        # Add active threats to the treeview
        active_threats = [t for t in self.defense_os.threats if not t['intercepted']]

        if not active_threats:
            self.write_to_console(
                self.intercept_console,
                "No active threats detected. Run threat detection first.\n",
                clear=True
            )
            return

        self.write_to_console(self.intercept_console, f"Found {len(active_threats)} active threats.\n", clear=True)
        self.write_to_console(self.intercept_console, "Select a threat to intercept.\n")

        for threat in active_threats:
            item_id = self.intercept_tree.insert("", "end", values=(
                threat['id'], 
                threat['type'], 
                threat['distance'], 
                threat['heading'],
                "INTERCEPT"
            ))

            # Create button widget - this approach creates a clickable text element
            self.intercept_tree.tag_bind(
                item_id, 
                '<ButtonRelease-1>', 
                lambda event, t_id=threat['id']: self.intercept_threat(t_id)
            )

    def intercept_threat(self, threat_id):
        if not self.active_system:
            messagebox.showinfo("No System", "Please select a defense system first.")
            return

        # Find the threat
        target_threats = [t for t in self.defense_os.threats if t['id'] == threat_id and not t['intercepted']]

        if not target_threats:
            self.write_to_console(
                self.intercept_console,
                "Invalid threat ID or threat already intercepted.\n"
            )
            return

        target = target_threats[0]

        # Check for formation attack and offer salvo option
        from military_algorithms import ThreatAnalysis, InterceptStrategy
        formations = ThreatAnalysis.identify_missile_formations(self.defense_os.threats)

        # Find if this threat is part of a formation
        target_formation = None
        for formation in formations:
            if any(t['id'] == target['id'] for t in formation):
                target_formation = formation
                break

        if target_formation and len(target_formation) > 1 and self.active_system.ammo >= len(target_formation):
            # Ask if user wants to intercept the entire formation
            response = messagebox.askyesno(
                "Formation Detected", 
                f"Threat #{target['id']} is part of a formation with {len(target_formation)} threats. "
                f"Would you like to execute a salvo intercept against all threats in this formation?"
            )

            if response:
                # Intercept all threats in formation
                threading.Thread(target=self._intercept_formation_thread, args=(target_formation,)).start()
                return

        # Intercept single threat in a thread
        threading.Thread(target=self._intercept_threat_thread, args=(target,)).start()

    def _intercept_formation_thread(self, formation):
        """Execute a salvo intercept against a formation of threats"""
        from military_algorithms import DefenseOptimization

        # Log start of salvo
        self.write_to_console(
            self.intercept_console,
            f"EXECUTING SALVO INTERCEPT against {len(formation)} threats...\n"
        )
        time.sleep(1)

        # Get threat IDs for display
        threat_ids = [t['id'] for t in formation]
        self.write_to_console(
            self.intercept_console,
            f"Targeting threats: {threat_ids}\n"
        )

        # Calculate success probabilities for each threat
        success_probs = []
        for threat in formation:
            prob = DefenseOptimization.calculate_success_probability(
                threat, self.active_system, threat['distance']
            )
            success_probs.append((threat['id'], prob))

        # Log probabilities
        self.write_to_console(self.intercept_console, "Calculating intercept probabilities:\n")
        for t_id, prob in success_probs:
            self.write_to_console(
                self.intercept_console,
                f"  Threat #{t_id}: {prob:.1%} success probability\n"
            )

        # Execute intercepts
        successes = 0
        for threat in formation:
            # Calculate individual success
            prob = next((p for tid, p in success_probs if tid == threat['id']), 0.6)
            success = random.random() < prob and self.active_system.ammo > 0

            if success and self.active_system.ammo > 0:
                self.active_system.ammo -= 1
                self.active_system.battery_level -= 2

                self.write_to_console(
                    self.intercept_console,
                    f"TARGET NEUTRALIZED: Threat #{threat['id']} successfully intercepted!\n"
                )
                threat['intercepted'] = True
                successes += 1
            else:
                if self.active_system.ammo <= 0:
                    self.write_to_console(
                        self.intercept_console,
                        f"ERROR: Out of ammunition. Cannot intercept Threat #{threat['id']}\n"
                    )
                else:
                    self.active_system.ammo -= 1
                    self.active_system.battery_level -= 2
                    self.write_to_console(
                        self.intercept_console,
                        f"TARGET MISSED: Failed to intercept Threat #{threat['id']}. Target is still active.\n"
                    )

            # Add slight delay between intercepts
            time.sleep(0.5)

        # Report salvo results
        success_rate = successes / len(formation) if formation else 0
        self.write_to_console(
            self.intercept_console,
            f"\nSALVO COMPLETE: {successes}/{len(formation)} threats neutralized ({success_rate:.1%})\n"
        )

        # Update UI from main thread
        self.root.after(0, lambda: self.intercept_ammo_var.set(f"{self.active_system.ammo}"))
        self.root.after(0, self.update_threat_list)
        self.root.after(0, self.update_intercept_threats)
        self.root.after(0, self.update_system_status)

    def _intercept_threat_thread(self, target):
        # Import algorithms for optimized interception
        from military_algorithms import DefenseOptimization

        # Calculate optimal intercept parameters
        intercept_params = DefenseOptimization.calculate_optimal_intercept_point(
            target, self.active_system
        )

        # Log interception details
        self.write_to_console(
            self.intercept_console,
            f"Engaging threat #{target['id']} ({target['type']})...\n"
        )
        self.write_to_console(
            self.intercept_console,
            f"Optimal intercept distance: {intercept_params['distance']:.1f}km\n"
            f"Success probability: {intercept_params['success_probability']:.1%}\n"
        )

        time.sleep(1)

        # Use calculated probability for more realistic outcome
        success_chance = intercept_params['success_probability']
        success = random.random() < success_chance and self.active_system.operational and self.active_system.ammo > 0

        # Fire the missile
        self.active_system.fire(f"Threat #{target['id']} ({target['type']})")

        if success:
            self.write_to_console(
                self.intercept_console,
                f"TARGET NEUTRALIZED: Threat #{target['id']} successfully intercepted!\n"
            )
            target['intercepted'] = True
        else:
            if not self.active_system.operational:
                self.write_to_console(
                    self.intercept_console,
                    f"INTERCEPT FAILED: System {self.active_system.name} is not operational.\n"
                )
            elif self.active_system.ammo <= 0:
                self.write_to_console(
                    self.intercept_console,
                    f"INTERCEPT FAILED: System {self.active_system.name} is out of ammunition.\n"
                )
            else:
                self.write_to_console(
                    self.intercept_console,
                    f"TARGET MISSED: Failed to intercept Threat #{target['id']}. Target is still active.\n"
                )

        # Update UI from main thread
        self.root.after(0, lambda: self.intercept_ammo_var.set(f"{self.active_system.ammo}"))
        self.root.after(0, self.update_threat_list)
        self.root.after(0, self.update_intercept_threats)
        self.root.after(0, self.update_system_status)

    def run_simulation(self):
        if self.running_simulation:
            messagebox.showinfo("Simulation Running", "A simulation is already in progress.")
            return

        if not self.active_system:
            messagebox.showinfo("No System", "Please select a defense system first.")
            return

        # Run simulation in a separate thread
        threading.Thread(target=self._run_simulation_thread).start()

    def _run_simulation_thread(self):
        self.running_simulation = True

        # Import military algorithms
        from military_algorithms import ThreatAnalysis, DefenseOptimization, InterceptStrategy
        # Import scenarios
        from threat_scenarios import ThreatScenarios
        from military_tactics import MilitaryTactics, MilitaryTargets

        # Clear console
        self.write_to_console(self.simulation_console, "", clear=True)
        self.write_to_console(self.simulation_console, "INITIALIZING SIMULATION\n\n")
        time.sleep(1)

        # Get simulation parameters
        num_threats = self.threats_var.get()
        difficulty = self.difficulty_var.get()
        scenario_name = self.scenario_var.get()

        # Generate scenario-based threats
        scenario = ThreatScenarios.generate_scenario(scenario_name, difficulty)
        self.defense_os.threats = scenario["threats"]

        # Make sure we have the right number of threats
        if len(self.defense_os.threats) < num_threats:
            # Add additional threats to match desired number
            threat_types = ["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone"]
            for i in range(len(self.defense_os.threats), num_threats):
                new_threat = {
                    "id": i + 1,
                    "type": random.choice(threat_types),
                    "distance": random.randint(100, 500),
                    "speed": random.randint(300, 2000),
                    "heading": random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"]),
                    "intercepted": False
                }
                self.defense_os.threats.append(new_threat)
        elif len(self.defense_os.threats) > num_threats:
            # Remove excess threats
            self.defense_os.threats = self.defense_os.threats[:num_threats]

        # Apply military algorithms to create realistic scenarios
        # Sometimes threats come in formations
        include_formations = random.random() > 0.4  # 60% chance for formations

        if include_formations:
            # Determine number of formations and individual threats
            num_formations = random.randint(1, min(3, num_threats // 2))
            threats_in_formations = 0
            formations = []

            for f in range(num_formations):
                formation_size = random.randint(2, min(4, num_threats - threats_in_formations))
                formation_type = random.choice(threat_types)
                formation_heading = random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"])
                formation_distance = random.randint(300, 450)
                formation_speed = random.randint(800, 1500)

                formation = {
                    "size": formation_size,
                    "type": formation_type,
                    "heading": formation_heading,
                    "base_distance": formation_distance,
                    "base_speed": formation_speed
                }
                formations.append(formation)
                threats_in_formations += formation_size

            # Create threats in formations
            threat_id = 1
            for formation in formations:
                for i in range(formation["size"]):
                    # Slight variations in distance and speed for realism
                    distance_variation = random.randint(-30, 30)
                    speed_variation = random.randint(-100, 100)

                    threat = {
                        "id": threat_id,
                        "type": formation["type"],
                        "distance": formation["base_distance"] + distance_variation,
                        "speed": formation["base_speed"] + speed_variation,
                        "heading": formation["heading"],
                        "intercepted": False,
                        "in_formation": True
                    }
                    self.defense_os.threats.append(threat)
                    threat_id += 1

            # Create remaining individual threats
            remaining_threats = num_threats - threats_in_formations
            for i in range(remaining_threats):
                threat = {
                    "id": threat_id,
                    "type": random.choice(threat_types),
                    "distance": random.randint(100, 500),
                    "speed": random.randint(300, 2000),
                    "heading": random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"]),
                    "intercepted": False,
                    "in_formation": False
                }
                self.defense_os.threats.append(threat)
                threat_id += 1
        else:
            # Create all individual threats
            for i in range(num_threats):
                threat = {
                    "id": i+1,
                    "type": random.choice(threat_types),
                    "distance": random.randint(100, 500),
                    "speed": random.randint(300, 2000),
                    "heading": random.choice(["North", "South", "East", "West", "Northeast", "Northwest", "Southeast", "Southwest"]),
                    "intercepted": False,
                    "in_formation": False
                }
                self.defense_os.threats.append(threat)

        self.defense_os.threat_level = "High"

        # Update UI on main thread
        self.root.after(0, lambda: self.threat_level_var.set(self.defense_os.threat_level))
        self.root.after(0, lambda: self.active_threats_var.set(str(num_threats)))
        self.root.after(0, self.update_threat_list)
        self.root.after(0, lambda: self.threat_map.refresh_map())

        # Run simulation with tactical information
        self.write_to_console(
            self.simulation_console,
            f"EMERGENCY ALERT: {scenario['name']} detected!\n"
        )
        self.write_to_console(
            self.simulation_console,
            f"{scenario['description']}\n"
        )
        self.write_to_console(
            self.simulation_console,
            f"Threat Level: {scenario['threat_level']}\n"
        )
        self.write_to_console(
            self.simulation_console,
            f"Defense system {self.active_system.name} activated\n\n"
        )

        # Display detected tactics
        if "tactics" in scenario and scenario["tactics"]:
            self.write_to_console(
                self.simulation_console,
                "TACTICAL ANALYSIS:\n"
            )
            for tactic in scenario["tactics"]:
                self.write_to_console(
                    self.simulation_console,
                    f"- Detected {tactic['description']} (Effectiveness: {tactic['effectiveness']*100:.0f}%)\n"
                )

            # Recommend counter-measures
            self.write_to_console(
                self.simulation_console,
                f"\nRECOMMENDED DEFENSE: {scenario['recommended_defense']['description']}\n\n"
            )

        # Analyze threats
        priorities = ThreatAnalysis.calculate_threat_priority(self.defense_os.threats)

        self.write_to_console(
            self.simulation_console,
            "THREAT ANALYSIS:\n"
        )

        for idx, priority in enumerate(priorities[:3]):  # Show top 3 threats
            self.write_to_console(
                self.simulation_console,
                f"Priority #{idx+1}: Threat ID {priority['id']} ({priority['type']}) - "
                f"Priority Score: {priority['priority']:.1f}\n"
            )

        # Check for formations
        formations = ThreatAnalysis.identify_missile_formations(self.defense_os.threats)
        if formations:
            self.write_to_console(
                self.simulation_console,
                f"\nWARNING: {len(formations)} missile formations detected!\n"
            )

            # Calculate salvo plans
            salvo_plans = InterceptStrategy.salvo_intercept_planning(
                self.defense_os.threats, 
                self.active_system
            )

            if salvo_plans:
                self.write_to_console(
                    self.simulation_console,
                    "TACTICAL RECOMMENDATION: Execute salvo intercepts against missile formations.\n"
                )

        time.sleep(1)

        # Adjust difficulty
        if difficulty == 1:  # Easy
            hit_modifier = 0.2  # Increases hit chance by 20%
        elif difficulty == 2:  # Medium
            hit_modifier = 0.0  # No change
        else:  # Hard
            hit_modifier = -0.2  # Decreases hit chance by 20%

        # Get simulation prediction
        sim_result = InterceptStrategy.simulate_engagement(
            self.defense_os.threats, 
            [self.active_system], 
            duration_seconds=180
        )

        self.write_to_console(
            self.simulation_console,
            f"\nSIMULATION PREDICTION: {sim_result['success_rate']:.1%} success rate\n\n"
        )

        # Run optimized engagement strategy
        self.write_to_console(self.simulation_console, "EXECUTING DEFENSE PROTOCOL\n")

        # Process threats in priority order
        active_threats = [t for t in self.defense_os.threats]
        threat_order = [p['id'] for p in priorities]

        # Process formations first if detected
        formation_threats_processed = set()
        if formations and random.random() < 0.7:  # 70% chance to use salvo strategy if formations exist
            for formation in formations:
                # Only process formations with at least 2 threats
                if len(formation) < 2:
                    continue

                formation_ids = [t['id'] for t in formation]
                self.write_to_console(
                    self.simulation_console,
                    f"EXECUTING SALVO INTERCEPT against formation: Threats {formation_ids}\n"
                )

                # Process all threats in this formation
                success_count = 0
                for threat in formation:
                    # Skip if already processed
                    if threat['id'] in formation_threats_processed:
                        continue

                    # Calculate success probability using military algorithm
                    success_prob = DefenseOptimization.calculate_success_probability(
                        threat, self.active_system, threat['distance']
                    )

                    # Apply difficulty modifier
                    success_prob = min(max(success_prob + hit_modifier, 0.1), 0.95)

                    # Determine outcome
                    success = random.random() < success_prob and self.active_system.ammo > 0

                    if success and self.active_system.operational:
                        self.active_system.ammo -= 1
                        self.active_system.battery_level -= 2

                        self.write_to_console(
                            self.simulation_console,
                            f"TARGET NEUTRALIZED: {self.active_system.name} fired at Threat #{threat['id']}\n"
                        )
                        threat['intercepted'] = True
                        success_count += 1
                    else:
                        if self.active_system.ammo <= 0:
                            self.write_to_console(
                                self.simulation_console,
                                f"ERROR: {self.active_system.name} is out of ammunition\n"
                            )
                        elif not self.active_system.operational:
                            self.write_to_console(
                                self.simulation_console,
                                f"ERROR: {self.active_system.name} is not operational\n"
                            )
                        else:
                            self.active_system.ammo -= 1
                            self.active_system.battery_level -= 2
                            self.write_to_console(
                                self.simulation_console,
                                f"TARGET MISSED: {self.active_system.name} fired at Threat #{threat['id']}\n"
                            )

                    # Mark as processed
                    formation_threats_processed.add(threat['id'])
                    time.sleep(0.3)

                # Report salvo results
                success_rate = success_count / len(formation) if formation else 0
                self.write_to_console(
                    self.simulation_console,
                    f"SALVO COMPLETE: {success_count}/{len(formation)} threats neutralized ({success_rate:.1%})\n\n"
                )

        # Process remaining threats by priority
        success_count = sum(1 for t in self.defense_os.threats if t.get('intercepted', False))
        remaining_threats = [t for t in self.defense_os.threats if t['id'] not in formation_threats_processed and not t.get('intercepted', False)]

        # Sort remaining threats by priority
        remaining_ids = [t['id'] for t in remaining_threats]
        ordered_threats = [t for t in remaining_threats if t['id'] in threat_order]
        ordered_threats.sort(key=lambda t: threat_order.index(t['id']) if t['id'] in threat_order else 999)

        for threat in ordered_threats:
            self.write_to_console(
                self.simulation_console,
                f"Threat #{threat['id']} - {threat['type']} approaching from {threat['heading']}\n"
            )
            self.write_to_console(
                self.simulation_console,
                f"Distance: {threat['distance']}km - Speed: {threat['speed']}km/h\n"
            )

            # Calculate optimal intercept parameters
            intercept_params = DefenseOptimization.calculate_optimal_intercept_point(
                threat, self.active_system
            )

            # Calculate success probability with difficulty modifier
            success_prob = intercept_params['success_probability'] + hit_modifier
            success_prob = min(max(success_prob, 0.1), 0.95)

            # Determine outcome
            success = random.random() < success_prob and self.active_system.ammo > 0 and self.active_system.operational

            if success:
                self.active_system.ammo -= 1
                self.active_system.battery_level -= 2

                self.write_to_console(
                    self.simulation_console,
                    f"TARGET NEUTRALIZED: {self.active_system.name} fired at Threat #{threat['id']} "
                    f"(P={success_prob:.2f})\n"
                )
                threat['intercepted'] = True
                success_count += 1
            else:
                if self.active_system.ammo <= 0:
                    self.write_to_console(
                        self.simulation_console,
                        f"ERROR: {self.active_system.name} is out of ammunition\n"
                    )
                elif not self.active_system.operational:
                    self.write_to_console(
                        self.simulation_console,
                        f"ERROR: {self.active_system.name} is not operational\n"
                    )
                else:
                    self.active_system.ammo -= 1
                    self.active_system.battery_level -= 2
                    self.write_to_console(
                        self.simulation_console,
                        f"TARGET MISSED: {self.active_system.name} fired at Threat #{threat['id']} "
                        f"(P={success_prob:.2f})\n"
                    )

            time.sleep(0.5)

        # Update UI from main thread
        self.root.after(0, lambda: self.intercept_ammo_var.set(f"{self.active_system.ammo}"))
        self.root.after(0, self.update_threat_list)
        self.root.after(0, self.update_system_status)
        self.root.after(0, lambda: self.threat_map.refresh_map())

        # Simulation results
        success_rate = (success_count / num_threats) * 100
        self.write_to_console(self.simulation_console, "\n" + "=" * 50 + "\n")
        self.write_to_console(self.simulation_console, "SIMULATION COMPLETE\n")
        self.write_to_console(
            self.simulation_console,
            f"Threats neutralized: {success_count}/{num_threats} ({success_rate:.1f}%)\n"
        )

        # Calculate efficiency metrics
        ammo_efficiency = success_count / (100 - self.active_system.ammo) if (100 - self.active_system.ammo) > 0 else 0
        battery_usage = (100 - self.active_system.battery_level)

        self.write_to_console(
            self.simulation_console,
            f"Ammunition efficiency: {ammo_efficiency:.2f} threats per missile\n"
            f"Battery usage: {battery_usage}%\n"
        )

        if success_rate == 100:
            self.write_to_console(self.simulation_console, "Mission Status: COMPLETE SUCCESS\n")
        elif success_rate >= 70:
            self.write_to_console(self.simulation_console, "Mission Status: PARTIAL SUCCESS\n")
        else:
            self.write_to_console(
                self.simulation_console,
                "Mission Status: FAILURE - DEFENSIVE CAPABILITIES INADEQUATE\n"
            )

        # Final recommendations
        self.write_to_console(self.simulation_console, "\nTACTICAL RECOMMENDATIONS:\n")

        if self.active_system.ammo < 20:
            self.write_to_console(
                self.simulation_console,
                "- Ammunition levels critical. Immediate resupply recommended.\n"
            )

        if self.active_system.battery_level < 30:
            self.write_to_console(
                self.simulation_console,
                "- Battery levels low. Schedule maintenance within 24 hours.\n"
            )

        if success_rate < 60:
            self.write_to_console(
                self.simulation_console,
                "- Consider deploying additional defense systems or requesting reinforcements.\n"
            )

        self.write_to_console(self.simulation_console, "=" * 50 + "\n")

        self.running_simulation = False

    def reset_simulation(self):
        self.write_to_console(self.simulation_console, "", clear=True)
        self.write_to_console(self.simulation_console, "Simulation console reset.\n")
        self.write_to_console(self.simulation_console, "Configure simulation parameters and press Start to begin.\n")

    def write_to_console(self, console, text, clear=False):
        # Update console from any thread
        def update():
            console.config(state=tk.NORMAL)
            if clear:
                console.delete(1.0, tk.END)
            console.insert(tk.END, text)
            console.see(tk.END)
            console.config(state=tk.DISABLED)

        # If called from main thread
        if threading.current_thread() is threading.main_thread():
            update()
        else:  # If called from another thread
            self.root.after(0, update)

    def update_status_bar(self):
        # Update status bar info
        if self.active_system:
            self.active_system_var.set(f"{self.active_system.name} ({self.active_system.country})")
        else:
            self.active_system_var.set("None Selected")

        self.threat_level_var.set(self.defense_os.threat_level)

        active_threats = len([t for t in self.defense_os.threats if not t['intercepted']])
        self.active_threats_var.set(str(active_threats))

        # Schedule next update
        self.root.after(1000, self.update_status_bar)

def main():
    root = tk.Tk()
    app = MissileDefenseGUI(root)
    # Integrate multi-target engagement system
    app = integrate_multi_target(app)
    # Integrate alert system
    from alert_system import integrate_alerts
    app = integrate_alerts(app)
    root.mainloop()

if __name__ == "__main__":
    main()