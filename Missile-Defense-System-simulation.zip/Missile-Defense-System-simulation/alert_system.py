
import tkinter as tk
from tkinter import ttk
import threading
import time
import datetime
import os
import winsound  # For Windows audio alerts
import platform

class AlertSystem:
    def __init__(self, parent):
        self.parent = parent
        self.frame = parent.alerts_tab if hasattr(parent, 'alerts_tab') else None
        self.defense_os = parent.defense_os if hasattr(parent, 'defense_os') else None
        
        # Alert configuration
        self.alert_levels = {
            "Critical": {"color": "#e74c3c", "sound": True, "duration": 5000},
            "Warning": {"color": "#f39c12", "sound": True, "duration": 3000},
            "Info": {"color": "#3498db", "sound": False, "duration": 0}
        }
        
        # Alert history
        self.alert_history = []
        
        # Alert settings
        self.visual_alerts_enabled = True
        self.audio_alerts_enabled = True
        self.popup_alerts_enabled = True
        
        # Active alerts
        self.active_alerts = []
        
        # Alert notification window
        self.notification_window = None
        
        # Setup UI if frame exists
        if self.frame:
            self.setup_ui()
    
    def setup_ui(self):
        """Set up the alert system UI"""
        # Header
        header_label = tk.Label(
            self.frame, 
            text="ALERT SYSTEM", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)
        
        # Settings panel
        settings_frame = tk.LabelFrame(
            self.frame, 
            text="Alert Settings", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        settings_frame.pack(fill="x", padx=10, pady=10)
        
        # Visual alerts toggle
        visual_frame = tk.Frame(settings_frame, bg="#112240")
        visual_frame.pack(fill="x", padx=10, pady=5)
        
        visual_label = tk.Label(
            visual_frame, 
            text="Visual Alerts:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        visual_label.pack(side="left", padx=(0, 10))
        
        self.visual_var = tk.BooleanVar(value=self.visual_alerts_enabled)
        visual_cb = ttk.Checkbutton(
            visual_frame,
            variable=self.visual_var,
            command=self.toggle_visual_alerts
        )
        visual_cb.pack(side="left")
        
        # Audio alerts toggle
        audio_frame = tk.Frame(settings_frame, bg="#112240")
        audio_frame.pack(fill="x", padx=10, pady=5)
        
        audio_label = tk.Label(
            audio_frame, 
            text="Audio Alerts:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        audio_label.pack(side="left", padx=(0, 10))
        
        self.audio_var = tk.BooleanVar(value=self.audio_alerts_enabled)
        audio_cb = ttk.Checkbutton(
            audio_frame,
            variable=self.audio_var,
            command=self.toggle_audio_alerts
        )
        audio_cb.pack(side="left")
        
        # Popup alerts toggle
        popup_frame = tk.Frame(settings_frame, bg="#112240")
        popup_frame.pack(fill="x", padx=10, pady=5)
        
        popup_label = tk.Label(
            popup_frame, 
            text="Popup Notifications:", 
            font=("Arial", 11), 
            fg="white", 
            bg="#112240"
        )
        popup_label.pack(side="left", padx=(0, 10))
        
        self.popup_var = tk.BooleanVar(value=self.popup_alerts_enabled)
        popup_cb = ttk.Checkbutton(
            popup_frame,
            variable=self.popup_var,
            command=self.toggle_popup_alerts
        )
        popup_cb.pack(side="left")
        
        # Test buttons
        test_frame = tk.Frame(settings_frame, bg="#112240")
        test_frame.pack(fill="x", padx=10, pady=10)
        
        test_critical = ttk.Button(
            test_frame,
            text="Test Critical Alert",
            command=lambda: self.trigger_alert("Critical", "Test Critical Alert", "This is a test of the critical alert system.")
        )
        test_critical.pack(side="left", padx=5)
        
        test_warning = ttk.Button(
            test_frame,
            text="Test Warning Alert",
            command=lambda: self.trigger_alert("Warning", "Test Warning Alert", "This is a test of the warning alert system.")
        )
        test_warning.pack(side="left", padx=5)
        
        test_info = ttk.Button(
            test_frame,
            text="Test Info Alert",
            command=lambda: self.trigger_alert("Info", "Test Info Alert", "This is a test of the information alert system.")
        )
        test_info.pack(side="left", padx=5)
        
        # Alert history panel
        history_frame = tk.LabelFrame(
            self.frame, 
            text="Alert History", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        history_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create columns for alert history
        columns = ("time", "level", "title", "message")
        self.alert_tree = ttk.Treeview(history_frame, columns=columns, show="headings", height=15)
        
        # Define headings
        self.alert_tree.heading("time", text="Time")
        self.alert_tree.heading("level", text="Level")
        self.alert_tree.heading("title", text="Title")
        self.alert_tree.heading("message", text="Message")
        
        # Define columns width
        self.alert_tree.column("time", width=150, anchor="center")
        self.alert_tree.column("level", width=100, anchor="center")
        self.alert_tree.column("title", width=200)
        self.alert_tree.column("message", width=400)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(history_frame, orient="vertical", command=self.alert_tree.yview)
        self.alert_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack elements
        self.alert_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Action buttons
        action_frame = tk.Frame(self.frame, bg="#0a192f")
        action_frame.pack(fill="x", pady=10)
        
        clear_btn = ttk.Button(
            action_frame,
            text="Clear History",
            command=self.clear_history
        )
        clear_btn.pack(side="right", padx=10)
    
    def toggle_visual_alerts(self):
        """Toggle visual alerts on/off"""
        self.visual_alerts_enabled = self.visual_var.get()
    
    def toggle_audio_alerts(self):
        """Toggle audio alerts on/off"""
        self.audio_alerts_enabled = self.audio_var.get()
    
    def toggle_popup_alerts(self):
        """Toggle popup alerts on/off"""
        self.popup_alerts_enabled = self.popup_var.get()
    
    def clear_history(self):
        """Clear alert history"""
        self.alert_history = []
        # Clear treeview
        if hasattr(self, 'alert_tree'):
            for item in self.alert_tree.get_children():
                self.alert_tree.delete(item)
    
    def trigger_alert(self, level, title, message):
        """Trigger an alert with the specified level, title, and message"""
        if level not in self.alert_levels:
            level = "Info"  # Default to Info level if invalid level provided
        
        timestamp = datetime.datetime.now()
        
        # Create alert record
        alert = {
            "level": level,
            "title": title,
            "message": message,
            "time": timestamp,
            "acknowledged": False
        }
        
        # Add to history
        self.alert_history.append(alert)
        
        # Add to treeview if UI exists
        if hasattr(self, 'alert_tree'):
            time_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
            
            # Use appropriate color based on level
            level_color = self.alert_levels[level]["color"]
            
            self.alert_tree.insert("", 0, values=(time_str, level, title, message), tags=(level,))
            
            # Configure tag colors
            self.alert_tree.tag_configure("Critical", background=self.alert_levels["Critical"]["color"], foreground="white")
            self.alert_tree.tag_configure("Warning", background=self.alert_levels["Warning"]["color"], foreground="black")
            self.alert_tree.tag_configure("Info", background=self.alert_levels["Info"]["color"], foreground="white")
        
        # Log message if parent has log_message method
        if hasattr(self.parent, 'log_message'):
            self.parent.log_message(f"ALERT [{level}]: {title} - {message}")
        
        # Visual alert
        if self.visual_alerts_enabled:
            self.show_visual_alert(alert)
        
        # Audio alert
        if self.audio_alerts_enabled and self.alert_levels[level]["sound"]:
            self.play_alert_sound(level)
        
        # Popup notification
        if self.popup_alerts_enabled and level in ["Critical", "Warning"]:
            self.show_popup_notification(alert)
    
    def show_visual_alert(self, alert):
        """Display a visual alert on the main interface"""
        if not hasattr(self.parent, 'root'):
            return
            
        # Create a frame for the alert at the top of the main window
        alert_frame = tk.Frame(
            self.parent.root, 
            bg=self.alert_levels[alert["level"]]["color"], 
            height=30
        )
        
        # Store this frame to remove it later
        alert["frame"] = alert_frame
        self.active_alerts.append(alert)
        
        # Add alert text
        alert_text = tk.Label(
            alert_frame,
            text=f"{alert['level']}: {alert['title']}",
            font=("Arial", 11, "bold"),
            bg=self.alert_levels[alert["level"]]["color"],
            fg="white" if alert["level"] in ["Critical", "Info"] else "black"
        )
        alert_text.pack(side="left", padx=10, pady=5)
        
        # Close button
        close_button = tk.Button(
            alert_frame,
            text="×",
            font=("Arial", 11, "bold"),
            bg=self.alert_levels[alert["level"]]["color"],
            fg="white" if alert["level"] in ["Critical", "Info"] else "black",
            bd=0,
            command=lambda a=alert: self.dismiss_alert(a)
        )
        close_button.pack(side="right", padx=10, pady=5)
        
        # Display alert at the top of the window
        alert_frame.pack(fill="x", side="top")
        
        # Auto-dismiss after a delay if specified
        if self.alert_levels[alert["level"]]["duration"] > 0:
            self.parent.root.after(
                self.alert_levels[alert["level"]]["duration"], 
                lambda a=alert: self.dismiss_alert(a)
            )
    
    def dismiss_alert(self, alert):
        """Dismiss an active visual alert"""
        if "frame" in alert and alert in self.active_alerts:
            alert["frame"].destroy()
            alert["acknowledged"] = True
            self.active_alerts.remove(alert)
    
    def play_alert_sound(self, level):
        """Play an audio alert based on the alert level"""
        # Run in a separate thread to avoid blocking UI
        threading.Thread(target=self._play_sound, args=(level,), daemon=True).start()
    
    def _play_sound(self, level):
        """Internal method to play sounds based on platform"""
        # Different sound patterns for different levels
        if platform.system() == "Windows":
            if level == "Critical":
                # Three short high beeps
                for _ in range(3):
                    winsound.Beep(1000, 200)
                    time.sleep(0.1)
            elif level == "Warning":
                # Two medium beeps
                for _ in range(2):
                    winsound.Beep(800, 300)
                    time.sleep(0.2)
            else:
                # One gentle beep
                winsound.Beep(600, 400)
        else:
            # For non-Windows platforms, can use os.system to play sounds
            # Example for Linux: os.system("aplay /path/to/sound.wav")
            # But for simplicity, we'll just pass
            pass
    
    def show_popup_notification(self, alert):
        """Show a popup notification window for important alerts"""
        if not hasattr(self.parent, 'root'):
            return
            
        # Close any existing notification window
        if self.notification_window is not None:
            try:
                self.notification_window.destroy()
            except:
                pass
        
        # Create a new toplevel window
        self.notification_window = tk.Toplevel(self.parent.root)
        self.notification_window.title(f"{alert['level']} Alert")
        self.notification_window.geometry("400x200")
        self.notification_window.configure(bg="#112240")
        
        # Make sure it appears on top
        self.notification_window.attributes("-topmost", True)
        
        # Prevent resizing
        self.notification_window.resizable(False, False)
        
        # Alert level icon/header
        header_frame = tk.Frame(self.notification_window, bg=self.alert_levels[alert["level"]]["color"], height=40)
        header_frame.pack(fill="x")
        
        header_label = tk.Label(
            header_frame,
            text=alert["level"].upper(),
            font=("Arial", 14, "bold"),
            bg=self.alert_levels[alert["level"]]["color"],
            fg="white" if alert["level"] == "Critical" else "black"
        )
        header_label.pack(pady=8)
        
        # Alert content
        content_frame = tk.Frame(self.notification_window, bg="#112240")
        content_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        title_label = tk.Label(
            content_frame,
            text=alert["title"],
            font=("Arial", 12, "bold"),
            bg="#112240",
            fg="white",
            anchor="w",
            justify="left"
        )
        title_label.pack(fill="x", pady=(5, 10))
        
        message_label = tk.Label(
            content_frame,
            text=alert["message"],
            font=("Arial", 11),
            bg="#112240",
            fg="white",
            anchor="w",
            justify="left",
            wraplength=360
        )
        message_label.pack(fill="x")
        
        # Time
        time_label = tk.Label(
            content_frame,
            text=alert["time"].strftime("%Y-%m-%d %H:%M:%S"),
            font=("Arial", 10),
            bg="#112240",
            fg="#999999"
        )
        time_label.pack(fill="x", pady=(10, 0), anchor="e")
        
        # Acknowledge button
        button_frame = tk.Frame(self.notification_window, bg="#112240")
        button_frame.pack(fill="x", padx=20, pady=10)
        
        acknowledge_btn = tk.Button(
            button_frame,
            text="Acknowledge",
            font=("Arial", 11),
            command=self.notification_window.destroy
        )
        acknowledge_btn.pack(side="right")

# Function to integrate alert system with main GUI
def integrate_alerts(missile_defense_gui):
    """Integrate alert system with the main GUI"""
    # Add alerts tab
    missile_defense_gui.alerts_tab = ttk.Frame(missile_defense_gui.tab_control)
    missile_defense_gui.tab_control.add(missile_defense_gui.alerts_tab, text="Alerts")
    
    # Create alert system
    missile_defense_gui.alert_system = AlertSystem(missile_defense_gui)
    
    # Add alerts for key events by modifying appropriate methods
    
    # Threat detection alerts
    original_detect = missile_defense_gui._detect_threats_thread
    
    def detect_with_alerts(self):
        # Call original method
        original_detect(self)
        
        # Add alerts based on threats
        num_threats = len(self.defense_os.threats)
        if num_threats > 0:
            if self.defense_os.threat_level == "High":
                self.alert_system.trigger_alert(
                    "Critical",
                    "High Threat Level Detected",
                    f"{num_threats} threats detected. Immediate action required."
                )
            elif self.defense_os.threat_level == "Medium":
                self.alert_system.trigger_alert(
                    "Warning",
                    "Medium Threat Level Detected",
                    f"{num_threats} potential threats identified. Monitor situation closely."
                )
            else:
                self.alert_system.trigger_alert(
                    "Info",
                    "Low Threat Level Detected",
                    f"{num_threats} minor threats detected. Situation normal."
                )
    
    # Replace the method
    missile_defense_gui._detect_threats_thread = detect_with_alerts.__get__(missile_defense_gui, type(missile_defense_gui))
    
    # Intercept alerts
    original_intercept = missile_defense_gui._intercept_threat_thread
    
    def intercept_with_alerts(self, target):
        # Call original method
        original_intercept(target)
        
        # Add alert based on result
        if target.get('intercepted', False):
            self.alert_system.trigger_alert(
                "Info",
                "Threat Neutralized",
                f"Threat #{target['id']} ({target['type']}) successfully intercepted."
            )
        else:
            self.alert_system.trigger_alert(
                "Critical",
                "Intercept Failed",
                f"Failed to neutralize Threat #{target['id']} ({target['type']}). Threat is still active."
            )
    
    # Replace the method
    missile_defense_gui._intercept_threat_thread = intercept_with_alerts.__get__(missile_defense_gui, type(missile_defense_gui))
    
    # System status alerts
    def system_status_monitor():
        """Periodically check system status and generate alerts as needed"""
        if missile_defense_gui.active_system:
            system = missile_defense_gui.active_system
            
            # Check ammunition levels
            if system.ammo < 10:
                missile_defense_gui.alert_system.trigger_alert(
                    "Warning",
                    "Low Ammunition",
                    f"System {system.name} ammunition critical: {system.ammo}/100. Reload recommended."
                )
            
            # Check battery levels
            if system.battery_level < 20:
                missile_defense_gui.alert_system.trigger_alert(
                    "Warning",
                    "Low Battery",
                    f"System {system.name} battery level low: {system.battery_level}%. Maintenance recommended."
                )
            
            # Check if system is offline
            if not system.operational:
                missile_defense_gui.alert_system.trigger_alert(
                    "Critical",
                    "System Offline",
                    f"Defense system {system.name} is currently non-operational. Immediate maintenance required."
                )
        
        # Schedule next check
        missile_defense_gui.root.after(60000, system_status_monitor)  # Check every minute
    
    # Start monitoring after a short delay to let the GUI initialize
    missile_defense_gui.root.after(5000, system_status_monitor)
    
    return missile_defense_gui
