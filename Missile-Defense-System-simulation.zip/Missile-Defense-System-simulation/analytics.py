
import tkinter as tk
from tkinter import ttk, scrolledtext
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import pandas as pd
import datetime
import json
import os
import random

class AnalyticsDashboard:
    def __init__(self, parent):
        self.parent = parent
        self.frame = parent.analytics_tab if hasattr(parent, 'analytics_tab') else None
        self.defense_os = parent.defense_os if hasattr(parent, 'defense_os') else None
        
        # Historical data storage
        self.threat_history = []
        self.interception_history = []
        self.system_performance = {}
        
        # Data file paths
        self.data_dir = "analysis_data"
        self.threat_data_file = os.path.join(self.data_dir, "threat_history.json")
        self.interception_data_file = os.path.join(self.data_dir, "interception_history.json")
        self.performance_data_file = os.path.join(self.data_dir, "system_performance.json")
        
        # Create data directory if it doesn't exist
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            
        # Load existing data if available
        self.load_data()
            
        # Set up the analytics UI
        if self.frame:
            self.setup_analytics_ui()
    
    def setup_analytics_ui(self):
        # Header
        header_label = tk.Label(
            self.frame, 
            text="DEFENSE ANALYTICS DASHBOARD", 
            font=("Arial", 18, "bold"), 
            fg="#64ffda", 
            bg="#0a192f"
        )
        header_label.pack(pady=10)
        
        # Create tabs for different analytics views
        self.analytics_tabs = ttk.Notebook(self.frame)
        self.analytics_tabs.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Summary dashboard tab
        self.summary_tab = ttk.Frame(self.analytics_tabs)
        self.analytics_tabs.add(self.summary_tab, text="Summary Dashboard")
        
        # Threat analysis tab
        self.threat_tab = ttk.Frame(self.analytics_tabs)
        self.analytics_tabs.add(self.threat_tab, text="Threat Analysis")
        
        # System performance tab
        self.system_tab = ttk.Frame(self.analytics_tabs)
        self.analytics_tabs.add(self.system_tab, text="System Performance")
        
        # Historical data tab
        self.history_tab = ttk.Frame(self.analytics_tabs)
        self.analytics_tabs.add(self.history_tab, text="Historical Data")
        
        # Setup each tab
        self.setup_summary_tab()
        self.setup_threat_tab()
        self.setup_system_tab()
        self.setup_history_tab()
    
    def setup_summary_tab(self):
        # Create frame for key metrics
        metrics_frame = tk.LabelFrame(
            self.summary_tab, 
            text="Key Performance Metrics", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        metrics_frame.pack(fill="x", padx=10, pady=10)
        
        # Create metric cards
        metrics = [
            ("Total Threats Detected", self.get_total_threats(), "threats"),
            ("Interception Success Rate", f"{self.get_success_rate():.1f}%", "rate"),
            ("Average Response Time", f"{self.get_avg_response_time():.2f}s", "time"),
            ("Current Operational Systems", self.get_operational_systems(), "systems")
        ]
        
        for i, (title, value, metric_type) in enumerate(metrics):
            metric_frame = tk.Frame(metrics_frame, bg="#112240", bd=1, relief=tk.RAISED, padx=10, pady=10)
            metric_frame.grid(row=0, column=i, padx=10, pady=10, sticky="nsew")
            
            title_label = tk.Label(
                metric_frame, 
                text=title, 
                font=("Arial", 10), 
                fg="white", 
                bg="#112240"
            )
            title_label.pack(anchor="w")
            
            # Set appropriate color based on metric type
            if metric_type == "rate":
                color = "#64ffda" if float(value.rstrip("%")) >= 70 else "#e74c3c"
            elif metric_type == "time":
                color = "#64ffda" if float(value.rstrip("s")) <= 5 else "#e74c3c"
            else:
                color = "#64ffda"
            
            value_label = tk.Label(
                metric_frame, 
                text=value, 
                font=("Arial", 16, "bold"), 
                fg=color, 
                bg="#112240"
            )
            value_label.pack(anchor="center", pady=5)
        
        # Configure grid weights
        for i in range(4):
            metrics_frame.columnconfigure(i, weight=1)
        
        # Threat trend chart
        chart_frame = tk.LabelFrame(
            self.summary_tab, 
            text="Threat Trend Analysis", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        chart_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create plot
        fig, ax = plt.subplots(figsize=(8, 4), facecolor="#112240")
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        # Generate trend data
        trend_data = self.get_threat_trend_data()
        
        # Plot data
        ax.plot(trend_data["dates"], trend_data["threats"], 'o-', color="#64ffda", label="Threats")
        ax.plot(trend_data["dates"], trend_data["intercepted"], 'o-', color="#3498db", label="Intercepted")
        
        # Configure plot
        ax.set_facecolor("#1a2d3d")
        ax.set_title("Recent Threat Activity", color="white", fontsize=12)
        ax.set_xlabel("Date", color="white")
        ax.set_ylabel("Count", color="white")
        ax.tick_params(colors="white")
        ax.legend(facecolor="#112240", edgecolor="#112240", labelcolor="white")
        ax.grid(True, linestyle="--", alpha=0.3)
        
        # Add prediction line if enough data
        if len(trend_data["dates"]) >= 3:
            # Simple linear extrapolation for next point
            next_date = trend_data["dates"][-1] + 1
            x = np.array(range(len(trend_data["dates"])))
            threat_z = np.polyfit(x, trend_data["threats"], 1)
            threat_p = np.poly1d(threat_z)
            next_threat = threat_p(len(x))
            
            ax.plot([trend_data["dates"][-1], next_date], 
                   [trend_data["threats"][-1], next_threat], 
                   '--', color="#64ffda", alpha=0.5)
            
            # Add annotation for prediction
            ax.annotate(f"Forecast: {int(next_threat)}", 
                      xy=(next_date, next_threat),
                      xytext=(next_date-0.5, next_threat+2),
                      color="white",
                      arrowprops=dict(facecolor="#64ffda", shrink=0.05, width=1.5, alpha=0.7))
        
        # Update figure aesthetics
        fig.tight_layout()
        for spine in ax.spines.values():
            spine.set_edgecolor("white")
        
        # System status panel
        status_frame = tk.LabelFrame(
            self.summary_tab, 
            text="Defense System Status", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        status_frame.pack(fill="x", padx=10, pady=10)
        
        # Add system status indicators
        if self.defense_os and self.defense_os.systems:
            # Show up to 5 systems
            for i, system in enumerate(self.defense_os.systems[:5]):
                status_color = "#2ecc71" if system.operational else "#e74c3c"
                status_text = "OPERATIONAL" if system.operational else "OFFLINE"
                
                system_frame = tk.Frame(status_frame, bg="#112240")
                system_frame.pack(fill="x", padx=10, pady=5)
                
                name_label = tk.Label(
                    system_frame, 
                    text=f"{system.name} ({system.country})", 
                    font=("Arial", 10), 
                    fg="white", 
                    bg="#112240",
                    width=30,
                    anchor="w"
                )
                name_label.pack(side="left", padx=5)
                
                status_label = tk.Label(
                    system_frame, 
                    text=status_text, 
                    font=("Arial", 10, "bold"), 
                    fg=status_color, 
                    bg="#112240",
                    width=15,
                    anchor="e"
                )
                status_label.pack(side="right", padx=5)
        else:
            no_data_label = tk.Label(
                status_frame, 
                text="No defense systems available", 
                font=("Arial", 10), 
                fg="white", 
                bg="#112240"
            )
            no_data_label.pack(pady=10)
    
    def setup_threat_tab(self):
        # Top frame for threat type distribution
        threat_type_frame = tk.LabelFrame(
            self.threat_tab, 
            text="Threat Type Distribution", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        threat_type_frame.pack(fill="x", padx=10, pady=10)
        
        # Create pie chart
        fig1, ax1 = plt.subplots(figsize=(5, 4), facecolor="#112240")
        canvas1 = FigureCanvasTkAgg(fig1, master=threat_type_frame)
        canvas1.get_tk_widget().pack(side="left", fill="both", expand=True, padx=10, pady=10)
        
        # Get threat distribution data
        threat_types, threat_counts = self.get_threat_distribution()
        
        # Colors for pie chart
        colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#c2c2f0']
        
        # Plot pie chart
        wedges, texts, autotexts = ax1.pie(
            threat_counts, 
            labels=None, 
            autopct='%1.1f%%',
            startangle=90,
            colors=colors,
            wedgeprops={'edgecolor': 'white', 'linewidth': 1, 'antialiased': True}
        )
        
        # Set properties for percentage text
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
        
        # Add legend
        ax1.legend(
            wedges, 
            threat_types,
            title="Threat Types",
            loc="center left",
            bbox_to_anchor=(1, 0, 0.5, 1),
            facecolor="#112240",
            edgecolor="#112240"
        )
        
        # Set legend text color
        plt.setp(ax1.get_legend().get_texts(), color='white')
        plt.setp(ax1.get_legend().get_title(), color='white')
        
        ax1.set_title("Threat Type Distribution", color="white")
        
        # Right side - Threat approach directions
        directions_frame = tk.Frame(threat_type_frame, bg="#112240")
        directions_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        
        # Create radar chart for approach directions
        fig2, ax2 = plt.subplots(figsize=(4, 4), facecolor="#112240", subplot_kw=dict(polar=True))
        canvas2 = FigureCanvasTkAgg(fig2, master=directions_frame)
        canvas2.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)
        
        # Get threat direction data
        directions, direction_counts = self.get_threat_directions()
        
        # Number of directions
        N = len(directions)
        
        # Angles for each direction (convert to radians)
        theta = np.linspace(0, 2*np.pi, N, endpoint=False)
        
        # Add the first value at the end to close the plot
        values = np.concatenate((direction_counts, [direction_counts[0]]))
        theta = np.concatenate((theta, [theta[0]]))
        
        # Plot radar chart
        ax2.plot(theta, values, 'o-', color="#64ffda", linewidth=2)
        ax2.fill(theta, values, color="#64ffda", alpha=0.25)
        
        # Set radar chart properties
        ax2.set_theta_zero_location("N")  # Set 0 degrees at the top
        ax2.set_theta_direction(-1)  # Clockwise
        ax2.set_thetagrids(np.degrees(theta[:-1]), directions)  # Set direction labels
        
        # Set tick colors
        ax2.tick_params(colors="white")
        
        # Set title
        ax2.set_title("Threat Approach Directions", color="white", pad=20)
        
        # Bottom frame for threat time analysis
        time_frame = tk.LabelFrame(
            self.threat_tab, 
            text="Threat Timing Analysis", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        time_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create time analysis plot
        fig3, ax3 = plt.subplots(figsize=(8, 3), facecolor="#112240")
        canvas3 = FigureCanvasTkAgg(fig3, master=time_frame)
        canvas3.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        # Get time analysis data
        time_buckets, time_counts = self.get_threat_timing()
        
        # Plot bar chart
        bars = ax3.bar(time_buckets, time_counts, color="#3498db", alpha=0.7, width=0.7)
        
        # Set chart properties
        ax3.set_facecolor("#1a2d3d")
        ax3.set_title("Threat Detection Timing", color="white")
        ax3.set_xlabel("Hour of Day", color="white")
        ax3.set_ylabel("Number of Threats", color="white")
        ax3.tick_params(colors="white")
        ax3.grid(True, linestyle="--", alpha=0.3, axis='y')
        
        # Highlight the peak hours
        if time_counts.any():
            idx_max = np.argmax(time_counts)
            bars[idx_max].set_color("#e74c3c")
            bars[idx_max].set_alpha(1.0)
            
            # Add annotation for peak
            ax3.annotate(
                f"Peak: {time_counts[idx_max]} threats",
                xy=(time_buckets[idx_max], time_counts[idx_max]),
                xytext=(0, 10),
                textcoords="offset points",
                ha='center',
                va='bottom',
                color="white",
                bbox=dict(boxstyle="round,pad=0.3", fc="#112240", ec="white", alpha=0.8)
            )
        
        # Update figure aesthetics
        fig3.tight_layout()
        for spine in ax3.spines.values():
            spine.set_edgecolor("white")
    
    def setup_system_tab(self):
        # Top frame for overall system performance
        overall_frame = tk.LabelFrame(
            self.system_tab, 
            text="Overall System Performance", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        overall_frame.pack(fill="x", padx=10, pady=10)
        
        # Create system performance chart
        fig1, ax1 = plt.subplots(figsize=(8, 3), facecolor="#112240")
        canvas1 = FigureCanvasTkAgg(fig1, master=overall_frame)
        canvas1.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        # Get system performance data
        systems, success_rates = self.get_system_performance()
        
        # Sort systems by success rate
        sorted_indices = np.argsort(success_rates)
        systems = [systems[i] for i in sorted_indices]
        success_rates = [success_rates[i] for i in sorted_indices]
        
        # Define colors based on success rate
        colors = ["#e74c3c" if rate < 50 else "#f39c12" if rate < 75 else "#2ecc71" for rate in success_rates]
        
        # Plot horizontal bar chart
        bars = ax1.barh(systems, success_rates, color=colors)
        
        # Add labels to the bars
        for i, bar in enumerate(bars):
            ax1.text(
                bar.get_width() + 2, 
                bar.get_y() + bar.get_height()/2,
                f"{success_rates[i]:.1f}%",
                va='center',
                color="white",
                fontweight='bold'
            )
        
        # Set chart properties
        ax1.set_facecolor("#1a2d3d")
        ax1.set_title("System Success Rates", color="white")
        ax1.set_xlabel("Intercept Success Rate (%)", color="white")
        ax1.tick_params(colors="white")
        ax1.set_xlim(0, 105)  # 0-100% with some padding
        ax1.grid(True, linestyle="--", alpha=0.3, axis='x')
        
        # Update figure aesthetics
        fig1.tight_layout()
        for spine in ax1.spines.values():
            spine.set_edgecolor("white")
        
        # Middle frame for system utilization
        util_frame = tk.LabelFrame(
            self.system_tab, 
            text="System Resource Utilization", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        util_frame.pack(fill="x", padx=10, pady=10)
        
        # Resource utilization gauges frame
        gauge_frame = tk.Frame(util_frame, bg="#112240")
        gauge_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Add gauges for active system if available
        if self.defense_os and self.defense_os.active_system:
            system = self.defense_os.active_system
            
            # Ammo gauge
            ammo_frame = tk.Frame(gauge_frame, bg="#112240")
            ammo_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)
            
            ammo_label = tk.Label(
                ammo_frame, 
                text="Ammunition Status", 
                font=("Arial", 10, "bold"), 
                fg="white", 
                bg="#112240"
            )
            ammo_label.pack(anchor="center")
            
            # Create ammo gauge
            fig_ammo, ax_ammo = plt.subplots(figsize=(3, 3), facecolor="#112240", subplot_kw=dict(polar=True))
            canvas_ammo = FigureCanvasTkAgg(fig_ammo, master=ammo_frame)
            canvas_ammo.get_tk_widget().pack(fill="both", expand=True)
            
            # Gauge settings
            gauge_min, gauge_max = 0, 100
            gauge_value = system.ammo
            
            # Convert to radians for polar plot
            theta = np.linspace(-np.pi/2, np.pi/2, 100)
            
            # Background arc (empty gauge)
            ax_ammo.plot(theta, [gauge_max] * 100, color='#333333', linewidth=10, alpha=0.5)
            
            # Value arc
            value_theta = np.linspace(-np.pi/2, (gauge_value/gauge_max) * np.pi - np.pi/2, 100)
            
            # Color based on value
            if gauge_value < 30:
                color = '#e74c3c'  # Red
            elif gauge_value < 70:
                color = '#f39c12'  # Orange
            else:
                color = '#2ecc71'  # Green
            
            ax_ammo.plot(value_theta, [gauge_max] * len(value_theta), color=color, linewidth=10)
            
            # Center text
            ax_ammo.text(0, 0, f"{gauge_value}%", ha='center', va='center', 
                       color='white', fontsize=18, fontweight='bold')
            
            # Clean up the plot
            ax_ammo.set_theta_direction(-1)
            ax_ammo.set_thetagrids([])
            ax_ammo.set_rgrids([])
            ax_ammo.spines['polar'].set_visible(False)
            ax_ammo.set_theta_zero_location("N")
            ax_ammo.set_ylim(0, gauge_max + 10)
            
            # Battery gauge
            battery_frame = tk.Frame(gauge_frame, bg="#112240")
            battery_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)
            
            battery_label = tk.Label(
                battery_frame, 
                text="Battery Level", 
                font=("Arial", 10, "bold"), 
                fg="white", 
                bg="#112240"
            )
            battery_label.pack(anchor="center")
            
            # Create battery gauge (similar to ammo gauge)
            fig_battery, ax_battery = plt.subplots(figsize=(3, 3), facecolor="#112240", subplot_kw=dict(polar=True))
            canvas_battery = FigureCanvasTkAgg(fig_battery, master=battery_frame)
            canvas_battery.get_tk_widget().pack(fill="both", expand=True)
            
            # Gauge settings
            gauge_value = system.battery_level
            
            # Background arc (empty gauge)
            ax_battery.plot(theta, [gauge_max] * 100, color='#333333', linewidth=10, alpha=0.5)
            
            # Value arc
            value_theta = np.linspace(-np.pi/2, (gauge_value/gauge_max) * np.pi - np.pi/2, 100)
            
            # Color based on value
            if gauge_value < 30:
                color = '#e74c3c'  # Red
            elif gauge_value < 70:
                color = '#f39c12'  # Orange
            else:
                color = '#2ecc71'  # Green
            
            ax_battery.plot(value_theta, [gauge_max] * len(value_theta), color=color, linewidth=10)
            
            # Center text
            ax_battery.text(0, 0, f"{gauge_value}%", ha='center', va='center', 
                          color='white', fontsize=18, fontweight='bold')
            
            # Clean up the plot
            ax_battery.set_theta_direction(-1)
            ax_battery.set_thetagrids([])
            ax_battery.set_rgrids([])
            ax_battery.spines['polar'].set_visible(False)
            ax_battery.set_theta_zero_location("N")
            ax_battery.set_ylim(0, gauge_max + 10)
            
            # System efficiency gauge
            efficiency_frame = tk.Frame(gauge_frame, bg="#112240")
            efficiency_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)
            
            efficiency_label = tk.Label(
                efficiency_frame, 
                text="System Efficiency", 
                font=("Arial", 10, "bold"), 
                fg="white", 
                bg="#112240"
            )
            efficiency_label.pack(anchor="center")
            
            # Create efficiency gauge
            fig_eff, ax_eff = plt.subplots(figsize=(3, 3), facecolor="#112240", subplot_kw=dict(polar=True))
            canvas_eff = FigureCanvasTkAgg(fig_eff, master=efficiency_frame)
            canvas_eff.get_tk_widget().pack(fill="both", expand=True)
            
            # Calculate efficiency value based on system performance
            efficiency = self.get_system_efficiency(system.name)
            
            # Background arc (empty gauge)
            ax_eff.plot(theta, [gauge_max] * 100, color='#333333', linewidth=10, alpha=0.5)
            
            # Value arc
            value_theta = np.linspace(-np.pi/2, (efficiency/gauge_max) * np.pi - np.pi/2, 100)
            
            # Color based on value
            if efficiency < 30:
                color = '#e74c3c'  # Red
            elif efficiency < 70:
                color = '#f39c12'  # Orange
            else:
                color = '#2ecc71'  # Green
            
            ax_eff.plot(value_theta, [gauge_max] * len(value_theta), color=color, linewidth=10)
            
            # Center text
            ax_eff.text(0, 0, f"{efficiency:.1f}%", ha='center', va='center', 
                       color='white', fontsize=18, fontweight='bold')
            
            # Clean up the plot
            ax_eff.set_theta_direction(-1)
            ax_eff.set_thetagrids([])
            ax_eff.set_rgrids([])
            ax_eff.spines['polar'].set_visible(False)
            ax_eff.set_theta_zero_location("N")
            ax_eff.set_ylim(0, gauge_max + 10)
            
        else:
            no_system_label = tk.Label(
                gauge_frame, 
                text="No active defense system selected", 
                font=("Arial", 12), 
                fg="white", 
                bg="#112240"
            )
            no_system_label.pack(pady=30)
        
        # Bottom frame for threat handling efficiency
        threat_eff_frame = tk.LabelFrame(
            self.system_tab, 
            text="Threat Handling Efficiency", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        threat_eff_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create threat efficiency chart
        fig4, ax4 = plt.subplots(figsize=(8, 3), facecolor="#112240")
        canvas4 = FigureCanvasTkAgg(fig4, master=threat_eff_frame)
        canvas4.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        # Get threat efficiency data
        threat_types, efficiencies = self.get_threat_efficiency()
        
        # Plot horizontal bar chart
        bars = ax4.barh(threat_types, efficiencies, color="#64ffda")
        
        # Add labels to the bars
        for i, bar in enumerate(bars):
            ax4.text(
                bar.get_width() + 2, 
                bar.get_y() + bar.get_height()/2,
                f"{efficiencies[i]:.1f}%",
                va='center',
                color="white",
                fontweight='bold'
            )
        
        # Set chart properties
        ax4.set_facecolor("#1a2d3d")
        ax4.set_title("Intercept Efficiency by Threat Type", color="white")
        ax4.set_xlabel("Success Rate (%)", color="white")
        ax4.tick_params(colors="white")
        ax4.set_xlim(0, 105)  # 0-100% with some padding
        ax4.grid(True, linestyle="--", alpha=0.3, axis='x')
        
        # Update figure aesthetics
        fig4.tight_layout()
        for spine in ax4.spines.values():
            spine.set_edgecolor("white")
    
    def setup_history_tab(self):
        # Create frames for data tables
        history_frame = tk.Frame(self.history_tab, bg="#0a192f")
        history_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Left frame for threat history
        threat_frame = tk.LabelFrame(
            history_frame, 
            text="Threat History", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        threat_frame.pack(side="left", fill="both", expand=True, padx=5, pady=10)
        
        # Create treeview for threat history
        columns = ("id", "date", "type", "distance", "speed", "heading", "intercepted")
        self.threat_tree = ttk.Treeview(threat_frame, columns=columns, show="headings", height=15)
        
        # Define headings
        self.threat_tree.heading("id", text="ID")
        self.threat_tree.heading("date", text="Date/Time")
        self.threat_tree.heading("type", text="Type")
        self.threat_tree.heading("distance", text="Distance")
        self.threat_tree.heading("speed", text="Speed")
        self.threat_tree.heading("heading", text="Heading")
        self.threat_tree.heading("intercepted", text="Intercepted")
        
        # Define columns width
        self.threat_tree.column("id", width=30, anchor="center")
        self.threat_tree.column("date", width=120)
        self.threat_tree.column("type", width=100)
        self.threat_tree.column("distance", width=70, anchor="center")
        self.threat_tree.column("speed", width=70, anchor="center")
        self.threat_tree.column("heading", width=80, anchor="center")
        self.threat_tree.column("intercepted", width=80, anchor="center")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(threat_frame, orient="vertical", command=self.threat_tree.yview)
        self.threat_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack elements
        self.threat_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Right frame for interception history
        intercept_frame = tk.LabelFrame(
            history_frame, 
            text="Interception History", 
            font=("Arial", 12), 
            fg="white", 
            bg="#112240", 
            bd=2
        )
        intercept_frame.pack(side="right", fill="both", expand=True, padx=5, pady=10)
        
        # Create treeview for interception history
        columns = ("id", "date", "system", "threat_id", "success", "response_time")
        self.intercept_tree = ttk.Treeview(intercept_frame, columns=columns, show="headings", height=15)
        
        # Define headings
        self.intercept_tree.heading("id", text="ID")
        self.intercept_tree.heading("date", text="Date/Time")
        self.intercept_tree.heading("system", text="System")
        self.intercept_tree.heading("threat_id", text="Threat ID")
        self.intercept_tree.heading("success", text="Success")
        self.intercept_tree.heading("response_time", text="Response Time")
        
        # Define columns width
        self.intercept_tree.column("id", width=30, anchor="center")
        self.intercept_tree.column("date", width=120)
        self.intercept_tree.column("system", width=100)
        self.intercept_tree.column("threat_id", width=70, anchor="center")
        self.intercept_tree.column("success", width=70, anchor="center")
        self.intercept_tree.column("response_time", width=100, anchor="center")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(intercept_frame, orient="vertical", command=self.intercept_tree.yview)
        self.intercept_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack elements
        self.intercept_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Action buttons
        button_frame = tk.Frame(self.history_tab, bg="#0a192f")
        button_frame.pack(fill="x", pady=10)
        
        # Refresh button
        refresh_btn = ttk.Button(
            button_frame, 
            text="Refresh Data", 
            command=self.refresh_historical_data
        )
        refresh_btn.pack(side="left", padx=10)
        
        # Export data button
        export_btn = ttk.Button(
            button_frame, 
            text="Export Data", 
            command=self.export_data
        )
        export_btn.pack(side="left", padx=10)
        
        # Clear history button
        clear_btn = ttk.Button(
            button_frame, 
            text="Clear History", 
            command=self.clear_history
        )
        clear_btn.pack(side="right", padx=10)
        
        # Populate data
        self.refresh_historical_data()
    
    def refresh_historical_data(self):
        """Refresh historical data displays"""
        # Clear existing items in threat tree
        for item in self.threat_tree.get_children():
            self.threat_tree.delete(item)
            
        # Add threats to the treeview
        for threat in self.threat_history:
            # Format date
            date_str = threat.get('detection_time', datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            if isinstance(date_str, datetime.datetime):
                date_str = date_str.strftime("%Y-%m-%d %H:%M:%S")
                
            # Format other fields
            intercepted = "YES" if threat.get('intercepted', False) else "NO"
            distance = f"{threat.get('distance', 0)} km"
            speed = f"{threat.get('speed', 0)} km/h"
            
            self.threat_tree.insert("", "end", values=(
                threat.get('id', 0),
                date_str,
                threat.get('type', 'Unknown'),
                distance,
                speed,
                threat.get('heading', 'Unknown'),
                intercepted
            ))
        
        # Clear existing items in intercept tree
        for item in self.intercept_tree.get_children():
            self.intercept_tree.delete(item)
            
        # Add interceptions to the treeview
        for intercept in self.interception_history:
            # Format date
            date_str = intercept.get('time', datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            if isinstance(date_str, datetime.datetime):
                date_str = date_str.strftime("%Y-%m-%d %H:%M:%S")
                
            # Format other fields
            success = "YES" if intercept.get('success', False) else "NO"
            response_time = f"{intercept.get('response_time', 0):.2f} s"
            
            self.intercept_tree.insert("", "end", values=(
                intercept.get('id', 0),
                date_str,
                intercept.get('system', 'Unknown'),
                intercept.get('threat_id', 0),
                success,
                response_time
            ))
    
    def record_threat(self, threat):
        """Record a new threat in the history"""
        # Deep copy to avoid reference issues
        threat_copy = dict(threat)
        
        # Add timestamp if not present
        if 'detection_time' not in threat_copy:
            threat_copy['detection_time'] = datetime.datetime.now()
            
        # Ensure the timestamp is a string
        if isinstance(threat_copy['detection_time'], datetime.datetime):
            threat_copy['detection_time'] = threat_copy['detection_time'].strftime("%Y-%m-%d %H:%M:%S")
            
        # Add to history
        self.threat_history.append(threat_copy)
        
        # Save updated data
        self.save_data()
        
        # Refresh visualization if analytics tab is active
        if hasattr(self, 'analytics_tabs') and self.frame.winfo_ismapped():
            self.refresh_historical_data()
    
    def record_interception(self, intercept_data):
        """Record an interception attempt in the history"""
        # Deep copy to avoid reference issues
        intercept_copy = dict(intercept_data)
        
        # Add timestamp if not present
        if 'time' not in intercept_copy:
            intercept_copy['time'] = datetime.datetime.now()
            
        # Ensure the timestamp is a string
        if isinstance(intercept_copy['time'], datetime.datetime):
            intercept_copy['time'] = intercept_copy['time'].strftime("%Y-%m-%d %H:%M:%S")
            
        # Add to history
        self.interception_history.append(intercept_copy)
        
        # Update system performance
        system_name = intercept_copy.get('system', 'Unknown')
        if system_name not in self.system_performance:
            self.system_performance[system_name] = {
                'attempts': 0,
                'successes': 0,
                'ammo_used': 0
            }
            
        self.system_performance[system_name]['attempts'] += 1
        if intercept_copy.get('success', False):
            self.system_performance[system_name]['successes'] += 1
        self.system_performance[system_name]['ammo_used'] += intercept_copy.get('ammo_used', 1)
        
        # Save updated data
        self.save_data()
        
        # Refresh visualization if analytics tab is active
        if hasattr(self, 'analytics_tabs') and self.frame.winfo_ismapped():
            self.refresh_historical_data()
    
    def get_total_threats(self):
        """Get total number of threats recorded"""
        return len(self.threat_history)
    
    def get_success_rate(self):
        """Calculate overall interception success rate"""
        if not self.interception_history:
            return 0.0
            
        successes = sum(1 for intercept in self.interception_history if intercept.get('success', False))
        return (successes / len(self.interception_history)) * 100
    
    def get_avg_response_time(self):
        """Calculate average response time for interceptions"""
        if not self.interception_history:
            return 0.0
            
        response_times = [intercept.get('response_time', 0) for intercept in self.interception_history]
        return sum(response_times) / len(response_times) if response_times else 0
    
    def get_operational_systems(self):
        """Get number of operational defense systems"""
        if not self.defense_os or not self.defense_os.systems:
            return 0
            
        return sum(1 for system in self.defense_os.systems if system.operational)
    
    def get_threat_trend_data(self):
        """Get data for threat trend chart"""
        # If we have real data
        if self.threat_history:
            # Use real dates and group by day
            dates = []
            threat_counts = []
            intercept_counts = []
            
            # Group threats by day
            threat_by_day = {}
            intercept_by_day = {}
            
            for threat in self.threat_history:
                # Parse date string
                date_str = threat.get('detection_time', '')
                if isinstance(date_str, str) and date_str:
                    try:
                        date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                        day = date_obj.strftime("%Y-%m-%d")
                        
                        if day not in threat_by_day:
                            threat_by_day[day] = 0
                            intercept_by_day[day] = 0
                            
                        threat_by_day[day] += 1
                        if threat.get('intercepted', False):
                            intercept_by_day[day] += 1
                    except:
                        pass
            
            # Sort days
            sorted_days = sorted(threat_by_day.keys())
            
            # Get last 7 days or all if less
            display_days = sorted_days[-7:] if len(sorted_days) > 7 else sorted_days
            
            # Extract data
            for day in display_days:
                dates.append(day)
                threat_counts.append(threat_by_day[day])
                intercept_counts.append(intercept_by_day.get(day, 0))
                
            # Convert dates to numeric for plotting
            numeric_dates = list(range(len(dates)))
            
            return {
                "dates": numeric_dates,
                "date_labels": dates,
                "threats": threat_counts,
                "intercepted": intercept_counts
            }
        else:
            # Generate dummy data for demonstration
            dates = list(range(7))
            threats = [random.randint(3, 10) for _ in range(7)]
            intercepted = [int(t * random.uniform(0.6, 0.9)) for t in threats]
            
            return {
                "dates": dates,
                "date_labels": [f"Day {i+1}" for i in range(7)],
                "threats": threats,
                "intercepted": intercepted
            }
    
    def get_threat_distribution(self):
        """Get data for threat type distribution chart"""
        # If we have real data
        if self.threat_history:
            # Count threats by type
            threat_types = {}
            
            for threat in self.threat_history:
                threat_type = threat.get('type', 'Unknown')
                if threat_type not in threat_types:
                    threat_types[threat_type] = 0
                threat_types[threat_type] += 1
                
            # Sort by count
            sorted_types = sorted(threat_types.items(), key=lambda x: x[1], reverse=True)
            
            # Separate into lists
            types = [t[0] for t in sorted_types]
            counts = [t[1] for t in sorted_types]
            
            return types, counts
        else:
            # Generate dummy data for demonstration
            types = ["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone", "Unknown"]
            counts = [random.randint(5, 15) for _ in range(len(types))]
            
            return types, counts
    
    def get_threat_directions(self):
        """Get data for threat approach directions chart"""
        # If we have real data
        if self.threat_history:
            # Count threats by heading
            directions = {
                "North": 0, "Northeast": 0, "East": 0, "Southeast": 0,
                "South": 0, "Southwest": 0, "West": 0, "Northwest": 0
            }
            
            for threat in self.threat_history:
                heading = threat.get('heading', 'Unknown')
                if heading in directions:
                    directions[heading] += 1
            
            # Extract data
            direction_labels = list(directions.keys())
            direction_counts = list(directions.values())
            
            return direction_labels, direction_counts
        else:
            # Generate dummy data for demonstration
            directions = ["North", "Northeast", "East", "Southeast", "South", "Southwest", "West", "Northwest"]
            counts = [random.randint(1, 8) for _ in range(len(directions))]
            
            return directions, counts
    
    def get_threat_timing(self):
        """Get data for threat timing analysis chart"""
        # If we have real data
        if self.threat_history and any('detection_time' in t for t in self.threat_history):
            # Group threats by hour of day
            hours = list(range(24))
            hour_counts = [0] * 24
            
            for threat in self.threat_history:
                date_str = threat.get('detection_time', '')
                if isinstance(date_str, str) and date_str:
                    try:
                        date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                        hour = date_obj.hour
                        hour_counts[hour] += 1
                    except:
                        pass
            
            return np.array(hours), np.array(hour_counts)
        else:
            # Generate dummy data for demonstration
            hours = list(range(24))
            
            # Create a pattern with peak times
            base = np.zeros(24)
            # Morning peak (8-10)
            base[8:11] = [3, 4, 3]
            # Evening peak (17-19)
            base[17:20] = [4, 5, 3]
            
            # Add random noise
            noise = np.random.randint(0, 3, 24)
            counts = base + noise
            
            return np.array(hours), counts
    
    def get_system_performance(self):
        """Get data for system performance chart"""
        # If we have real data
        if self.system_performance:
            systems = []
            success_rates = []
            
            for name, data in self.system_performance.items():
                attempts = data.get('attempts', 0)
                if attempts > 0:
                    success_rate = (data.get('successes', 0) / attempts) * 100
                    systems.append(name)
                    success_rates.append(success_rate)
            
            return systems, success_rates
        else:
            # Generate dummy data for demonstration
            systems = ["Patriot", "Iron Dome", "THAAD", "S-400", "Arrow"]
            success_rates = [random.uniform(60, 95) for _ in range(len(systems))]
            
            return systems, success_rates
    
    def get_system_efficiency(self, system_name):
        """Calculate efficiency score for a system"""
        # Check if we have real data
        if system_name in self.system_performance:
            data = self.system_performance[system_name]
            attempts = data.get('attempts', 0)
            successes = data.get('successes', 0)
            ammo_used = data.get('ammo_used', 0)
            
            if attempts > 0 and ammo_used > 0:
                # Calculate based on success rate and ammo efficiency
                success_rate = (successes / attempts) * 100
                ammo_efficiency = (successes / ammo_used) * 100
                
                # Weighted average
                return success_rate * 0.7 + ammo_efficiency * 0.3
        
        # Return default value if no data
        return random.uniform(60, 90)
    
    def get_threat_efficiency(self):
        """Get data for threat handling efficiency chart"""
        # If we have real data and enough interceptions
        if self.threat_history and self.interception_history:
            # Count interceptions by threat type
            efficiency_by_type = {}
            
            for threat in self.threat_history:
                threat_type = threat.get('type', 'Unknown')
                if threat_type not in efficiency_by_type:
                    efficiency_by_type[threat_type] = {'total': 0, 'intercepted': 0}
                
                efficiency_by_type[threat_type]['total'] += 1
                if threat.get('intercepted', False):
                    efficiency_by_type[threat_type]['intercepted'] += 1
            
            # Calculate success rates
            types = []
            rates = []
            
            for threat_type, data in efficiency_by_type.items():
                if data['total'] > 0:
                    success_rate = (data['intercepted'] / data['total']) * 100
                    types.append(threat_type)
                    rates.append(success_rate)
            
            return types, rates
        else:
            # Generate dummy data for demonstration
            types = ["Ballistic Missile", "Cruise Missile", "Aircraft", "Drone"]
            rates = [
                random.uniform(70, 85),
                random.uniform(75, 90),
                random.uniform(80, 95),
                random.uniform(85, 98)
            ]
            
            return types, rates
    
    def export_data(self):
        """Export analytics data to CSV files"""
        # Create export directory
        export_dir = "analytics_export"
        if not os.path.exists(export_dir):
            os.makedirs(export_dir)
            
        # Generate timestamp for filenames
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Export threat history
        if self.threat_history:
            threat_file = os.path.join(export_dir, f"threat_history_{timestamp}.csv")
            with open(threat_file, 'w') as f:
                f.write("ID,DateTime,Type,Distance,Speed,Heading,Intercepted\n")
                for threat in self.threat_history:
                    # Format date
                    date_str = threat.get('detection_time', '')
                    # Format other fields
                    intercepted = "1" if threat.get('intercepted', False) else "0"
                    
                    f.write(f"{threat.get('id', 0)},{date_str},{threat.get('type', 'Unknown')}," +
                           f"{threat.get('distance', 0)},{threat.get('speed', 0)}," +
                           f"{threat.get('heading', 'Unknown')},{intercepted}\n")
        
        # Export interception history
        if self.interception_history:
            intercept_file = os.path.join(export_dir, f"interception_history_{timestamp}.csv")
            with open(intercept_file, 'w') as f:
                f.write("ID,DateTime,System,ThreatID,Success,ResponseTime\n")
                for intercept in self.interception_history:
                    # Format date
                    date_str = intercept.get('time', '')
                    # Format other fields
                    success = "1" if intercept.get('success', False) else "0"
                    
                    f.write(f"{intercept.get('id', 0)},{date_str},{intercept.get('system', 'Unknown')}," +
                           f"{intercept.get('threat_id', 0)},{success},{intercept.get('response_time', 0)}\n")
        
        # Export system performance
        if self.system_performance:
            performance_file = os.path.join(export_dir, f"system_performance_{timestamp}.csv")
            with open(performance_file, 'w') as f:
                f.write("System,Attempts,Successes,SuccessRate,AmmoUsed\n")
                for name, data in self.system_performance.items():
                    attempts = data.get('attempts', 0)
                    successes = data.get('successes', 0)
                    success_rate = (successes / attempts) * 100 if attempts > 0 else 0
                    
                    f.write(f"{name},{attempts},{successes},{success_rate:.2f},{data.get('ammo_used', 0)}\n")
        
        # Notify user
        if hasattr(self.parent, 'root'):
            from tkinter import messagebox
            messagebox.showinfo(
                "Export Complete", 
                f"Data exported to {export_dir} directory."
            )
    
    def clear_history(self):
        """Clear all historical data"""
        # Confirm before clearing
        if hasattr(self.parent, 'root'):
            from tkinter import messagebox
            result = messagebox.askyesno(
                "Confirm Clear", 
                "Are you sure you want to clear all historical data? This cannot be undone."
            )
            
            if not result:
                return
        
        # Clear data
        self.threat_history = []
        self.interception_history = []
        self.system_performance = {}
        
        # Save empty data
        self.save_data()
        
        # Refresh displays
        self.refresh_historical_data()
        
        # Notify user
        if hasattr(self.parent, 'root'):
            from tkinter import messagebox
            messagebox.showinfo(
                "Data Cleared", 
                "All historical data has been cleared."
            )
    
    def load_data(self):
        """Load analytics data from files"""
        try:
            # Load threat history
            if os.path.exists(self.threat_data_file):
                with open(self.threat_data_file, 'r') as f:
                    self.threat_history = json.load(f)
            
            # Load interception history
            if os.path.exists(self.interception_data_file):
                with open(self.interception_data_file, 'r') as f:
                    self.interception_history = json.load(f)
            
            # Load system performance
            if os.path.exists(self.performance_data_file):
                with open(self.performance_data_file, 'r') as f:
                    self.system_performance = json.load(f)
        except:
            # If error loading, initialize empty data
            self.threat_history = []
            self.interception_history = []
            self.system_performance = {}
    
    def save_data(self):
        """Save analytics data to files"""
        try:
            # Save threat history
            with open(self.threat_data_file, 'w') as f:
                json.dump(self.threat_history, f)
            
            # Save interception history
            with open(self.interception_data_file, 'w') as f:
                json.dump(self.interception_history, f)
            
            # Save system performance
            with open(self.performance_data_file, 'w') as f:
                json.dump(self.system_performance, f)
        except:
            # If error saving, log it if possible
            if hasattr(self.parent, 'log_message'):
                self.parent.log_message("Error saving analytics data")

# Function to integrate analytics with main GUI
def integrate_analytics(missile_defense_gui):
    """Integrate analytics with the main GUI"""
    # Add analytics tab
    missile_defense_gui.analytics_tab = ttk.Frame(missile_defense_gui.tab_control)
    missile_defense_gui.tab_control.add(missile_defense_gui.analytics_tab, text="Analytics")
    
    # Create analytics dashboard
    missile_defense_gui.analytics = AnalyticsDashboard(missile_defense_gui)
    
    # Modify intercept_threat method to record data
    original_intercept = missile_defense_gui._intercept_threat_thread
    
    def intercept_with_analytics(self, target):
        # Record threat
        self.analytics.record_threat(target)
        
        # Get start time for response time calculation
        start_time = datetime.datetime.now()
        
        # Call original method
        result = original_intercept(target)
        
        # Calculate response time
        response_time = (datetime.datetime.now() - start_time).total_seconds()
        
        # Record interception
        intercept_data = {
            'id': len(self.analytics.interception_history) + 1,
            'time': datetime.datetime.now(),
            'system': self.active_system.name if self.active_system else "Unknown",
            'threat_id': target.get('id', 0),
            'success': target.get('intercepted', False),
            'response_time': response_time,
            'ammo_used': 1
        }
        self.analytics.record_interception(intercept_data)
        
        return result
    
    # Replace the method
    missile_defense_gui._intercept_threat_thread = intercept_with_analytics.__get__(missile_defense_gui, type(missile_defense_gui))
    
    # Modify simulation method to record data
    original_simulation = missile_defense_gui._run_simulation_thread
    
    def simulation_with_analytics(self):
        # Call original method
        result = original_simulation()
        
        # Record threats and interceptions from simulation
        if hasattr(self, 'defense_os') and self.defense_os.threats:
            for threat in self.defense_os.threats:
                # Record threat
                self.analytics.record_threat(threat)
                
                # If intercepted, record interception
                if threat.get('intercepted', False):
                    intercept_data = {
                        'id': len(self.analytics.interception_history) + 1,
                        'time': datetime.datetime.now(),
                        'system': self.active_system.name if self.active_system else "Unknown",
                        'threat_id': threat.get('id', 0),
                        'success': True,
                        'response_time': random.uniform(0.5, 3.0),
                        'ammo_used': 1
                    }
                    self.analytics.record_interception(intercept_data)
        
        return result
    
    # Replace the method
    missile_defense_gui._run_simulation_thread = simulation_with_analytics.__get__(missile_defense_gui, type(missile_defense_gui))
    
    return missile_defense_gui
