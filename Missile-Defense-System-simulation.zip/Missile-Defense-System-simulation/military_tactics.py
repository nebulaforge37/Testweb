
"""
Military Tactics and Targets Database for Missile Defense System
"""

class MilitaryTactics:
    """Collection of military tactics for offensive and defensive operations"""
    
    # Offensive Tactics
    OFFENSIVE_TACTICS = {
        "Saturation Attack": {
            "description": "Overwhelm defenses with multiple simultaneous threats",
            "effectiveness": 0.85,
            "counter_measures": ["Salvo Intercept", "Defense in Depth"]
        },
        "Decoy Deployment": {
            "description": "Use decoys to confuse defense systems and waste interceptors",
            "effectiveness": 0.75,
            "counter_measures": ["Threat Classification", "Sensor Fusion"]
        },
        "SEAD": {
            "description": "Suppression of Enemy Air Defenses - neutralize defenses before main attack",
            "effectiveness": 0.80,
            "counter_measures": ["Distributed Defense", "Hardened Shelters"]
        },
        "EMP Strike": {
            "description": "Electromagnetic pulse to disable electronic systems",
            "effectiveness": 0.90,
            "counter_measures": ["EMP Shielding", "Backup Systems"]
        },
        "Terrain Masking": {
            "description": "Use terrain to hide approach until late detection",
            "effectiveness": 0.70,
            "counter_measures": ["Elevated Sensors", "Forward Detection"]
        },
        "Missile Swarming": {
            "description": "Coordinated attack from multiple directions simultaneously",
            "effectiveness": 0.85,
            "counter_measures": ["Defense in Depth", "Sector Assignment"]
        },
        "Electronic Warfare": {
            "description": "Jam radar and communication systems",
            "effectiveness": 0.80,
            "counter_measures": ["Frequency Hopping", "Passive Sensors"]
        },
        "Standoff Attack": {
            "description": "Launch from beyond the range of defensive systems",
            "effectiveness": 0.75,
            "counter_measures": ["Forward Detection", "Long-Range Interceptors"]
        },
        "Time-on-Target": {
            "description": "Multiple missiles arrive at target simultaneously",
            "effectiveness": 0.90,
            "counter_measures": ["Salvo Intercept", "Early Detection"]
        },
        "Cruise Missile Raid": {
            "description": "Low-altitude cruise missiles approaching from multiple directions",
            "effectiveness": 0.80,
            "counter_measures": ["Layered Defense", "AWACS Support"]
        }
    }
    
    # Defensive Tactics
    DEFENSIVE_TACTICS = {
        "Defense in Depth": {
            "description": "Multiple layers of defense systems at various ranges",
            "effectiveness": 0.85,
            "suitable_against": ["Saturation Attack", "Missile Swarming"]
        },
        "Salvo Intercept": {
            "description": "Launch multiple interceptors at formation threats",
            "effectiveness": 0.80,
            "suitable_against": ["Saturation Attack", "Time-on-Target"]
        },
        "Shoot-Look-Shoot": {
            "description": "Fire, assess result, fire again if needed",
            "effectiveness": 0.75,
            "suitable_against": ["Decoy Deployment", "Standoff Attack"]
        },
        "Point Defense": {
            "description": "Focused defense of high-value targets",
            "effectiveness": 0.90,
            "suitable_against": ["SEAD", "Cruise Missile Raid"]
        },
        "Distributed Defense": {
            "description": "Spread defense assets to avoid single point of failure",
            "effectiveness": 0.80,
            "suitable_against": ["SEAD", "EMP Strike"]
        },
        "Area Defense": {
            "description": "Protect a large area rather than specific targets",
            "effectiveness": 0.70,
            "suitable_against": ["Terrain Masking", "Missile Swarming"]
        },
        "Sector Assignment": {
            "description": "Assign defense systems to specific sectors",
            "effectiveness": 0.75,
            "suitable_against": ["Missile Swarming", "Cruise Missile Raid"]
        },
        "Passive Defense": {
            "description": "Use of hardening, concealment, and camouflage",
            "effectiveness": 0.65,
            "suitable_against": ["Electronic Warfare", "Standoff Attack"]
        },
        "Early Warning": {
            "description": "Forward-deployed sensors to maximize response time",
            "effectiveness": 0.85,
            "suitable_against": ["Time-on-Target", "Terrain Masking"]
        },
        "Counter-Battery Fire": {
            "description": "Target enemy launch sites after detection",
            "effectiveness": 0.80,
            "suitable_against": ["Standoff Attack", "SEAD"]
        }
    }


class MilitaryTargets:
    """Database of military and strategic targets"""
    
    # Target Categories
    TARGET_CATEGORIES = {
        "Military": [
            "Air Base",
            "Naval Base",
            "Command & Control Center",
            "Radar Installation",
            "Missile Silo",
            "Ammunition Depot",
            "Military Port",
            "Air Defense Battery",
            "Military Headquarters",
            "Barracks",
            "Fuel Depot",
            "Airfield",
            "Military Communications Center",
            "Forward Operating Base",
            "Training Facility"
        ],
        "Infrastructure": [
            "Power Plant",
            "Electrical Grid",
            "Water Treatment Facility",
            "Bridge",
            "Highway Junction",
            "Railway Hub",
            "Airport",
            "Seaport",
            "Dam",
            "Fuel Storage",
            "Communications Hub",
            "Gas Pipeline",
            "Oil Refinery",
            "LNG Terminal",
            "Shipping Channel"
        ],
        "Industrial": [
            "Manufacturing Plant",
            "Defense Industry Factory",
            "Chemical Plant",
            "Steel Mill",
            "Aircraft Factory",
            "Shipyard",
            "Vehicle Production Facility",
            "Munitions Factory",
            "Military Electronics Factory",
            "Research & Development Center",
            "Industrial Port",
            "Mining Facility",
            "Logistics Hub",
            "Heavy Equipment Factory",
            "Pharmaceutical Plant"
        ],
        "Strategic": [
            "Government Building",
            "Leadership Bunker",
            "Satellite Ground Station",
            "Intelligence Facility",
            "Strategic Missile Base",
            "Early Warning Radar",
            "Nuclear Facility",
            "Military Research Center",
            "Strategic Material Storage",
            "Emergency Management Center",
            "Space Launch Facility",
            "Strategic Airfield",
            "Central Bank",
            "Defense Ministry",
            "National Operations Center"
        ]
    }
    
    # Target Criticality Levels
    CRITICALITY_LEVELS = {
        "Alpha": {
            "description": "Highest priority national command assets",
            "examples": ["National Command Center", "Presidential Bunker", "Strategic Missile Command"],
            "recommended_defense": "Multiple overlapping defensive layers"
        },
        "Bravo": {
            "description": "Critical military command & control",
            "examples": ["Military Headquarters", "Early Warning Radar", "Major Air Base"],
            "recommended_defense": "Dedicated missile defense system with backup"
        },
        "Charlie": {
            "description": "Essential military infrastructure",
            "examples": ["Naval Base", "Ammunition Depot", "Communications Hub"],
            "recommended_defense": "Standard missile defense coverage"
        },
        "Delta": {
            "description": "Critical civilian infrastructure",
            "examples": ["Power Plant", "Dam", "Civilian Airport"],
            "recommended_defense": "Regional defensive umbrella"
        },
        "Echo": {
            "description": "Important industrial facilities",
            "examples": ["Oil Refinery", "Manufacturing Plant", "Research Center"],
            "recommended_defense": "Mobile or temporary defense as needed"
        }
    }
    
    # Target Vulnerability Assessment
    @staticmethod
    def assess_target_vulnerability(target_type, defenses=None):
        """Calculate vulnerability score for a target based on its type and defenses"""
        # Base vulnerability scores by target type (higher is more vulnerable)
        base_scores = {
            "Air Base": 0.7,
            "Naval Base": 0.6,
            "Command & Control Center": 0.9,
            "Power Plant": 0.8,
            "Dam": 0.7,
            "Bridge": 0.6,
            "Government Building": 0.8,
            "Oil Refinery": 0.9,
            "Airport": 0.7,
            "Military Headquarters": 0.8
        }
        
        # Default score if type not in database
        base_score = base_scores.get(target_type, 0.5)
        
        # Adjust for defenses if provided
        if defenses:
            defense_factor = min(len(defenses) * 0.15, 0.9)  # Cap at 90% reduction
            return base_score * (1 - defense_factor)
        
        return base_score
    
    @staticmethod
    def get_target_priority(target_type, conflict_stage="initial"):
        """Determine target priority based on type and conflict stage"""
        # Priority matrices (target_type -> conflict_stage -> priority)
        priority_matrix = {
            "Air Defense Battery": {"initial": "high", "ongoing": "medium", "final": "low"},
            "Command & Control Center": {"initial": "high", "ongoing": "high", "final": "high"},
            "Power Plant": {"initial": "medium", "ongoing": "high", "final": "medium"},
            "Bridge": {"initial": "low", "ongoing": "medium", "final": "high"},
            "Military Headquarters": {"initial": "high", "ongoing": "high", "final": "medium"},
            "Communications Hub": {"initial": "high", "ongoing": "medium", "final": "low"},
            "Radar Installation": {"initial": "high", "ongoing": "medium", "final": "low"},
            "Ammunition Depot": {"initial": "medium", "ongoing": "high", "final": "medium"},
            "Airport": {"initial": "medium", "ongoing": "high", "final": "high"}
        }
        
        # Get priority for this target and conflict stage
        target_priorities = priority_matrix.get(target_type, 
                                              {"initial": "medium", "ongoing": "medium", "final": "medium"})
        
        return target_priorities.get(conflict_stage, "medium")
