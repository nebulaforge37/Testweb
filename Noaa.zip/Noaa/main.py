
import requests
import json
from datetime import datetime, timedelta
import os
from flask import Flask, render_template_string, request

app = Flask(__name__)

# NOAA API endpoint
BASE_URL = "https://www.ncei.noaa.gov/cdo-web/api/v2/{endpoint}/"

# You would need to get an API key from NOAA
# https://www.ncdc.noaa.gov/cdo-web/token
API_KEY = os.environ.get("NOAA_API_KEY", "SwNhvrDPrMbdWIxbKiZrWkFaazDAXDNf")

headers = {
    "token": API_KEY
}

def get_datasets():
    """Get available datasets from NOAA"""
    response = requests.get(f"{BASE_URL}datasets", headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"Failed to fetch datasets: {response.status_code}"}

def get_data_categories():
    """Get available data categories from NOAA"""
    response = requests.get(f"{BASE_URL}datacategories", headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"Failed to fetch data categories: {response.status_code}"}

def get_stations(dataset_id="GHCND", location_id=None, start_date=None, end_date=None):
    """Get weather stations based on criteria"""
    params = {"datasetid": dataset_id, "limit": 100}
    
    if location_id:
        params["locationid"] = location_id
    
    if start_date:
        params["startdate"] = start_date
    
    if end_date:
        params["enddate"] = end_date
    
    response = requests.get(f"{BASE_URL}stations", headers=headers, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"Failed to fetch stations: {response.status_code}"}

def get_data(dataset_id="GHCND", station_id=None, start_date=None, end_date=None):
    """Get actual weather data"""
    # Format dates if provided
    if start_date is None:
        start_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    if end_date is None:
        end_date = datetime.now().strftime("%Y-%m-%d")
    
    params = {
        "datasetid": dataset_id,
        "startdate": start_date,
        "enddate": end_date,
        "limit": 1000
    }
    
    if station_id:
        params["stationid"] = station_id
    
    response = requests.get(f"{BASE_URL}data", headers=headers, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"Failed to fetch data: {response.status_code}, {response.text}"}

@app.route('/')
def home():
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>NOAA Data Explorer</title>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" 
              integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" 
              crossorigin=""/>
        <style>
            :root {
                --bg-color: #ffffff;
                --text-color: #333333;
                --card-bg: #f8f9fa;
                --primary-color: #00374d;
                --secondary-color: #005b7f;
                --border-color: #ddd;
                --warning-bg: #fff3cd;
                --success-color: #5cb85c;
                --danger-color: #d9534f;
                --warning-color: #f0ad4e;
                --info-color: #5bc0de;
            }
            
            body { 
                font-family: Arial, sans-serif; 
                margin: 0; 
                padding: 20px; 
                line-height: 1.6; 
                background-color: var(--bg-color);
                color: var(--text-color);
            }
            h1 { color: var(--primary-color); }
            .container { max-width: 1200px; margin: 0 auto; position: relative; }
            .card { 
                border: 1px solid var(--border-color); 
                border-radius: 4px; 
                padding: 15px; 
                margin-bottom: 20px;
                background-color: var(--card-bg);
            }
            .warning { background-color: var(--warning-bg); padding: 10px; border-radius: 4px; }
            button { 
                background-color: var(--primary-color); 
                color: white; 
                border: none; 
                padding: 10px 15px; 
                border-radius: 4px; 
                cursor: pointer; 
            }
            button:hover { background-color: var(--secondary-color); }
            pre { background-color: #f4f4f4; padding: 10px; border-radius: 4px; overflow-x: auto; }
            #map-container { border: 1px solid #ddd; border-radius: 4px; }
            .station-popup { font-size: 14px; }
            .station-popup h3 { margin: 0 0 5px 0; }
            #coordinates-box { 
                position: absolute; 
                top: 10px; 
                right: 10px; 
                z-index: 1000; 
                background: white; 
                padding: 10px; 
                border-radius: 4px; 
                box-shadow: 0 0 10px rgba(0,0,0,0.2);
                font-size: 14px;
            }
            .coordinate-value {
                font-weight: bold;
                color: #00374d;
            }
            .result-box {
                margin-top: 15px;
                padding: 15px;
                background-color: #f8f9fa;
                border-radius: 4px;
                border: 1px solid #ddd;
            }
            
            /* Settings Panel and Menu Styles */
            .settings-panel {
                position: fixed;
                top: 0;
                right: -300px;
                width: 300px;
                height: 100%;
                background-color: white;
                box-shadow: -2px 0 5px rgba(0,0,0,0.2);
                z-index: 2000;
                transition: right 0.3s ease;
                overflow-y: auto;
                padding: 15px;
            }
            
            .settings-panel.active {
                right: 0;
            }
            
            .settings-close {
                position: absolute;
                top: 10px;
                right: 10px;
                font-size: 20px;
                cursor: pointer;
                color: #00374d;
            }
            
            .settings-header {
                border-bottom: 1px solid #ddd;
                padding-bottom: 10px;
                margin-bottom: 15px;
            }
            
            .settings-section {
                margin-bottom: 20px;
            }
            
            .submenu {
                margin-left: 20px;
                display: none;
            }
            
            .submenu.active {
                display: block;
            }
            
            .menu-toggle {
                cursor: pointer;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 8px 0;
                color: #00374d;
                font-weight: bold;
            }
            
            .menu-toggle:hover {
                color: #005b7f;
            }
            
            .toggle-icon {
                transition: transform 0.3s;
            }
            
            .menu-toggle.active .toggle-icon {
                transform: rotate(90deg);
            }
            
            .settings-item {
                margin-bottom: 10px;
            }
            
            .settings-item label {
                display: block;
                margin-bottom: 5px;
            }
            
            .option-group {
                border: 1px solid #eee;
                border-radius: 4px;
                padding: 10px;
                margin-bottom: 10px;
            }
            
            .header-menu {
                position: absolute;
                top: 20px;
                right: 20px;
                z-index: 1000;
            }
            
            .menu-button {
                background-color: #00374d;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 4px;
                cursor: pointer;
                margin-left: 10px;
            }
            
            .menu-button:hover {
                background-color: #005b7f;
            }
            
            .overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
                z-index: 1999;
                display: none;
            }
            
            .overlay.active {
                display: block;
            }
            .weather-icon {
                width: 50px;
                height: 50px;
                vertical-align: middle;
            }
            .weather-main {
                display: flex;
                align-items: center;
                margin-bottom: 10px;
            }
            .weather-temp {
                font-size: 24px;
                font-weight: bold;
                margin-left: 10px;
            }
            .weather-description {
                text-transform: capitalize;
                color: #555;
                margin-left: 10px;
            }
            .weather-details {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
                margin-top: 10px;
            }
            .weather-detail {
                padding: 5px;
                background-color: #f0f0f0;
                border-radius: 3px;
            }
            .letter-grid-label {
                font-size: 12px;
                font-weight: bold;
                text-align: center;
                color: #00374d;
            }
            .grid-label {
                font-size: 12px;
                font-weight: bold;
                text-align: center;
                background-color: rgba(255,255,255,0.7);
                border-radius: 3px;
                padding: 2px;
                color: #00374d;
            }
            .satellite-path {
                stroke: red;
                stroke-width: 2;
                fill: none;
            }
            .satellite-marker {
                color: red;
            }
            #use-current-location {
                margin-right: 10px;
            }
        </style>
    </head>
    <body>
        <!-- Settings Panel -->
        <div class="settings-panel" id="settings-panel">
            <span class="settings-close" id="settings-close">&times;</span>
            <div class="settings-header">
                <h2>Settings</h2>
            </div>
            
            <!-- Display Settings -->
            <div class="settings-section">
                <div class="menu-toggle" data-target="display-settings">
                    <span>Display Settings</span>
                    <span class="toggle-icon">▶</span>
                </div>
                <div class="submenu" id="display-settings">
                    <div class="settings-item">
                        <label for="theme-select">Theme:</label>
                        <select id="theme-select" class="setting-control">
                            <option value="light">Light</option>
                            <option value="dark">Dark</option>
                            <option value="blue">Blue</option>
                        </select>
                    </div>
                    <div class="settings-item">
                        <label for="font-size">Font Size:</label>
                        <input type="range" id="font-size" min="12" max="20" value="14" class="setting-control">
                        <span id="font-size-value">14px</span>
                    </div>
                    <div class="settings-item">
                        <label>
                            <input type="checkbox" id="high-contrast" class="setting-control"> High Contrast Mode
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Map Settings -->
            <div class="settings-section">
                <div class="menu-toggle" data-target="map-settings">
                    <span>Map Settings</span>
                    <span class="toggle-icon">▶</span>
                </div>
                <div class="submenu" id="map-settings">
                    <div class="settings-item">
                        <label for="map-style">Map Style:</label>
                        <select id="map-style" class="setting-control">
                            <option value="standard">Standard</option>
                            <option value="satellite">Satellite</option>
                            <option value="terrain">Terrain</option>
                        </select>
                    </div>
                    <div class="settings-item">
                        <label>
                            <input type="checkbox" id="show-grid" checked class="setting-control"> Show Coordinate Grid
                        </label>
                    </div>
                    <div class="settings-item">
                        <label>
                            <input type="checkbox" id="show-letter-grid" checked class="setting-control"> Show Letter Grid
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Data Settings -->
            <div class="settings-section">
                <div class="menu-toggle" data-target="data-settings">
                    <span>Data Settings</span>
                    <span class="toggle-icon">▶</span>
                </div>
                <div class="submenu" id="data-settings">
                    <div class="settings-item">
                        <label for="units">Units:</label>
                        <select id="units" class="setting-control">
                            <option value="metric">Metric (°C, m/s)</option>
                            <option value="imperial">Imperial (°F, mph)</option>
                        </select>
                    </div>
                    <div class="settings-item">
                        <label for="refresh-interval">Data Refresh Interval:</label>
                        <select id="refresh-interval" class="setting-control">
                            <option value="30">30 seconds</option>
                            <option value="60">1 minute</option>
                            <option value="300">5 minutes</option>
                            <option value="600">10 minutes</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <!-- API Keys -->
            <div class="settings-section">
                <div class="menu-toggle" data-target="api-settings">
                    <span>API Keys</span>
                    <span class="toggle-icon">▶</span>
                </div>
                <div class="submenu" id="api-settings">
                    <div class="settings-item">
                        <label for="noaa-api-key">NOAA API Key:</label>
                        <input type="password" id="noaa-api-key" placeholder="Enter NOAA API Key" class="setting-control">
                    </div>
                    <div class="settings-item">
                        <label for="weather-api-key">OpenWeather API Key:</label>
                        <input type="password" id="weather-api-key" placeholder="Enter OpenWeather API Key" class="setting-control">
                    </div>
                    <div class="settings-item">
                        <label for="satellite-api-key">N2YO API Key:</label>
                        <input type="password" id="satellite-api-key" placeholder="Enter N2YO API Key" class="setting-control">
                    </div>
                    <div class="settings-item">
                        <button id="save-api-keys" class="menu-button">Save Keys</button>
                    </div>
                </div>
            </div>
            
            <!-- About -->
            <div class="settings-section">
                <div class="menu-toggle" data-target="about-section">
                    <span>About</span>
                    <span class="toggle-icon">▶</span>
                </div>
                <div class="submenu" id="about-section">
                    <div class="settings-item">
                        <p><strong>NOAA Data Explorer</strong></p>
                        <p>Version: 1.0.0</p>
                        <p>A tool for exploring NOAA weather data, satellite tracking, and water anomaly analysis.</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Overlay for settings panel -->
        <div class="overlay" id="overlay"></div>
        
        <!-- Main Container -->
        <div class="container">
            <div class="header-menu">
                <button id="settings-button" class="menu-button">Settings</button>
                <button id="help-button" class="menu-button">Help</button>
            </div>
            
            <h1>NOAA Data Explorer</h1>
            
            {% if not api_key %}
            <div class="warning">
                <p>No API key found. You need to set the NOAA_API_KEY environment variable.</p>
                <p>Get an API key from <a href="https://www.ncdc.noaa.gov/cdo-web/token" target="_blank">NOAA's website</a>.</p>
            </div>
            {% endif %}
            
            <div class="card">
                <h2>Available Datasets</h2>
                <button onclick="fetchData('datasets')">Load Datasets</button>
                <div id="datasets-result"></div>
            </div>
            
            <div class="card">
                <h2>Data Categories</h2>
                <button onclick="fetchData('categories')">Load Categories</button>
                <div id="categories-result"></div>
            </div>
            
            <div class="card">
                <h2>Weather Stations</h2>
                <form id="stations-form">
                    <div>
                        <label for="dataset">Dataset ID:</label>
                        <input type="text" id="dataset" value="GHCND" required>
                    </div>
                    <div>
                        <label for="location">Location ID (optional):</label>
                        <input type="text" id="location">
                    </div>
                    <button type="submit">Find Stations</button>
                </form>
                <div id="map-container" style="height: 400px; margin-top: 20px; position: relative;">
                    <div id="coordinates-box">
                        <div>Your Location:</div>
                        <div>Latitude: <span id="user-lat" class="coordinate-value">-</span></div>
                        <div>Longitude: <span id="user-lng" class="coordinate-value">-</span></div>
                        <div>Grid Coordinates: <span id="user-grid" class="coordinate-value">-</span></div>
                        <div>Distance: <span id="distance-si" class="coordinate-value">0 m</span></div>
                        <button id="locate-me" style="margin-top: 5px;">Find My Location</button>
                    </div>
                </div>
                <div id="stations-result"></div>
            </div>
            
            <div class="card">
                <h2>Current Weather</h2>
                <p>Get current weather conditions for any location</p>
                <form id="weather-form">
                    <div>
                        <label for="weather-lat">Latitude:</label>
                        <input type="text" id="weather-lat" placeholder="Enter latitude" required>
                    </div>
                    <div>
                        <label for="weather-lon">Longitude:</label>
                        <input type="text" id="weather-lon" placeholder="Enter longitude" required>
                    </div>
                    <button type="button" id="use-current-location">Use My Location</button>
                    <button type="submit">Get Weather</button>
                </form>
                <div id="weather-result" class="result-box"></div>
            </div>
            
            <div class="card">
                <h2>Satellite Tracker</h2>
                <p>Track satellites in real-time</p>
                <form id="satellite-form">
                    <div>
                        <label for="satellite-select">Select Satellite:</label>
                        <select id="satellite-select">
                            <option value="25544">ISS (International Space Station)</option>
                            <option value="20580">Hubble Space Telescope</option>
                            <option value="33591">NOAA-19</option>
                            <option value="43013">NOAA-20</option>
                            <option value="25338">NOAA-15</option>
                            <option value="28654">NOAA-18</option>
                        </select>
                    </div>
                    <button type="submit">Track Satellite</button>
                </form>
                <div id="satellite-map-container" style="height: 400px; margin-top: 20px; position: relative;"></div>
                <div id="satellite-info" class="result-box"></div>
            </div>
            
            <div class="card">
                <h2>Water Anomaly Monitoring</h2>
                <p>Monitor water levels, temperature anomalies, and potential tornado formations</p>
                <form id="water-anomaly-form">
                    <div>
                        <label for="anomaly-lat">Latitude:</label>
                        <input type="text" id="anomaly-lat" placeholder="Enter latitude" required>
                    </div>
                    <div>
                        <label for="anomaly-lon">Longitude:</label>
                        <input type="text" id="anomaly-lon" placeholder="Enter longitude" required>
                    </div>
                    <div>
                        <label for="anomaly-type">Anomaly Type:</label>
                        <select id="anomaly-type">
                            <option value="water_level">Water Level</option>
                            <option value="sea_temp">Sea Temperature</option>
                            <option value="tornadic_activity">Tornadic Activity</option>
                        </select>
                    </div>
                    <button type="button" id="use-current-location-anomaly">Use My Location</button>
                    <button type="submit">Analyze</button>
                </form>
                <div id="water-anomaly-result" class="result-box"></div>
            </div>
            
            <div class="card">
                <h2>Water Data Inference</h2>
                <p>Predict water conditions based on historical data and current measurements</p>
                <form id="water-inference-form">
                    <div>
                        <label for="inference-lat">Latitude:</label>
                        <input type="text" id="inference-lat" placeholder="Enter latitude" required>
                    </div>
                    <div>
                        <label for="inference-lon">Longitude:</label>
                        <input type="text" id="inference-lon" placeholder="Enter longitude" required>
                    </div>
                    <div>
                        <label for="inference-date">Prediction Date:</label>
                        <input type="date" id="inference-date" required>
                    </div>
                    <button type="submit">Generate Prediction</button>
                </form>
                <div id="water-inference-result" class="result-box"></div>
            </div>
            
            <div class="card">
                <h2>Weather Data</h2>
                <form id="data-form">
                    <div>
                        <label for="data-dataset">Dataset ID:</label>
                        <input type="text" id="data-dataset" value="GHCND" required>
                    </div>
                    <div>
                        <label for="station">Station ID:</label>
                        <input type="text" id="station" required>
                    </div>
                    <div>
                        <label for="start-date">Start Date:</label>
                        <input type="date" id="start-date">
                    </div>
                    <div>
                        <label for="end-date">End Date:</label>
                        <input type="date" id="end-date">
                    </div>
                    <button type="submit">Get Data</button>
                </form>
                <div id="data-result"></div>
            </div>
        </div>
        
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" 
                integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" 
                crossorigin=""></script>
        <!-- Using built-in Leaflet features instead of graticule plugin -->
        <script>
            // Letter grid and coordinate utility functions
            function latLngToLetterGrid(lat, lng) {
                // Convert lat/lng to letter grid coordinates (A-Z for latitude, A-Z for longitude)
                const latRange = 180; // -90 to 90
                const lngRange = 360; // -180 to 180
                
                // Normalize to 0-1 range
                const normalizedLat = (lat + 90) / latRange;
                const normalizedLng = (lng + 180) / lngRange;
                
                // Convert to 0-25 range (for 26 letters)
                const latIndex = Math.floor(normalizedLat * 26);
                const lngIndex = Math.floor(normalizedLng * 26);
                
                // Convert to letters (A-Z)
                const latLetter = String.fromCharCode(65 + Math.min(25, Math.max(0, latIndex)));
                const lngLetter = String.fromCharCode(65 + Math.min(25, Math.max(0, lngIndex)));
                
                return latLetter + lngLetter;
            }
            
            function letterGridToLatLng(gridCode) {
                if (gridCode.length !== 2) return null;
                
                const latLetter = gridCode.charAt(0).toUpperCase();
                const lngLetter = gridCode.charAt(1).toUpperCase();
                
                // Convert letters to 0-25 range
                const latIndex = latLetter.charCodeAt(0) - 65;
                const lngIndex = lngLetter.charCodeAt(0) - 65;
                
                // Convert to normalized 0-1 range
                const normalizedLat = (latIndex + 0.5) / 26;
                const normalizedLng = (lngIndex + 0.5) / 26;
                
                // Convert to actual lat/lng
                const lat = normalizedLat * 180 - 90;
                const lng = normalizedLng * 360 - 180;
                
                return [lat, lng];
            }
            
            function addLetterGrid(map) {
                // Add a 26x26 letter grid overlay
                const gridLayer = L.layerGroup().addTo(map);
                
                // Create grid lines and labels for every letter cell
                for (let i = 0; i <= 26; i++) {
                    // Horizontal lines
                    const latLine = -90 + (i * (180 / 26));
                    const horizontalLine = L.polyline([
                        [latLine, -180],
                        [latLine, 180]
                    ], {
                        color: 'rgba(70, 130, 180, 0.5)',
                        weight: i % 26 === 0 ? 2 : 1,
                        dashArray: '5,5'
                    }).addTo(gridLayer);
                    
                    // Vertical lines
                    const lngLine = -180 + (i * (360 / 26));
                    const verticalLine = L.polyline([
                        [-90, lngLine],
                        [90, lngLine]
                    ], {
                        color: 'rgba(70, 130, 180, 0.5)',
                        weight: i % 26 === 0 ? 2 : 1,
                        dashArray: '5,5'
                    }).addTo(gridLayer);
                    
                    // Add labels at the edges
                    if (i < 26) {
                        const letter = String.fromCharCode(65 + i);
                        
                        // Latitude labels (at right edge)
                        const latMid = -90 + ((i + 0.5) * (180 / 26));
                        L.marker([latMid, 175], {
                            icon: L.divIcon({
                                className: 'letter-grid-label',
                                html: `<div style="background-color: rgba(255,255,255,0.7); padding: 2px; border-radius: 3px;">${letter}</div>`,
                                iconSize: [20, 20],
                                iconAnchor: [10, 10]
                            })
                        }).addTo(gridLayer);
                        
                        // Longitude labels (at bottom edge)
                        const lngMid = -180 + ((i + 0.5) * (360 / 26));
                        L.marker([-85, lngMid], {
                            icon: L.divIcon({
                                className: 'letter-grid-label',
                                html: `<div style="background-color: rgba(255,255,255,0.7); padding: 2px; border-radius: 3px;">${letter}</div>`,
                                iconSize: [20, 20],
                                iconAnchor: [10, 10]
                            })
                        }).addTo(gridLayer);
                    }
                }
                
                return gridLayer;
            }
            
            // Initialize map
            let map = null;
            
            function initMap() {
                if (map) {
                    map.remove();
                }
                
                map = L.map('map-container').setView([20, 0], 2);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                    maxZoom: 18
                }).addTo(map);
                
                // Add basic coordinate grid system with standard Leaflet
                // Create latitude lines
                for (let lat = -80; lat <= 80; lat += 20) {
                    L.polyline([[lat, -180], [lat, 180]], {
                        color: 'rgba(70, 130, 180, 0.5)',
                        weight: 1,
                        dashArray: '5,5'
                    }).addTo(map);
                    
                    // Add latitude labels
                    L.marker([lat, 0], {
                        icon: L.divIcon({
                            className: 'grid-label',
                            html: lat + '°',
                            iconSize: [40, 20],
                            iconAnchor: [20, 10]
                        })
                    }).addTo(map);
                }
                
                // Create longitude lines
                for (let lng = -160; lng <= 160; lng += 40) {
                    L.polyline([[-85, lng], [85, lng]], {
                        color: 'rgba(70, 130, 180, 0.5)',
                        weight: 1,
                        dashArray: '5,5'
                    }).addTo(map);
                    
                    // Add longitude labels
                    L.marker([0, lng], {
                        icon: L.divIcon({
                            className: 'grid-label',
                            html: lng + '°',
                            iconSize: [40, 20],
                            iconAnchor: [20, 10]
                        })
                    }).addTo(map);
                }
                
                // Add letter grid overlay (26x26)
                addLetterGrid(map);
                
                // Add SI units scale
                L.control.scale({
                    imperial: false,
                    metric: true,
                    position: 'bottomleft'
                }).addTo(map);
                
                return map;
            }
            
            function addStationsToMap(stations) {
                if (!map) {
                    map = initMap();
                }
                
                // Clear existing markers
                map.eachLayer(function(layer) {
                    if (layer instanceof L.Marker) {
                        map.removeLayer(layer);
                    }
                });
                
                // Add new markers
                if (stations && stations.results) {
                    const bounds = L.latLngBounds();
                    
                    stations.results.forEach(station => {
                        if (station.latitude && station.longitude) {
                            const marker = L.marker([station.latitude, station.longitude]).addTo(map);
                            
                            const popupContent = `
                                <div class="station-popup">
                                    <h3>${station.name}</h3>
                                    <p><strong>ID:</strong> ${station.id}</p>
                                    <p><strong>Elevation:</strong> ${station.elevation || 'N/A'} m</p>
                                    <button onclick="selectStation('${station.id}')">Select Station</button>
                                </div>
                            `;
                            
                            marker.bindPopup(popupContent);
                            bounds.extend([station.latitude, station.longitude]);
                        }
                    });
                    
                    if (bounds.isValid()) {
                        map.fitBounds(bounds);
                    }
                }
            }
            
            function selectStation(stationId) {
                document.getElementById('station').value = stationId;
                document.getElementById('data-form').scrollIntoView({ behavior: 'smooth' });
            }
            
            // Initialize map on page load
            document.addEventListener('DOMContentLoaded', function() {
                initMap();
                setupGeolocation();
            });
            
            function calculateDistanceInMeters(coord1, coord2) {
                // Haversine formula to calculate distance between two points on Earth
                const [lat1, lon1] = coord1;
                const [lat2, lon2] = coord2;
                
                const R = 6371000; // Earth's radius in meters
                const φ1 = lat1 * Math.PI/180;
                const φ2 = lat2 * Math.PI/180;
                const Δφ = (lat2-lat1) * Math.PI/180;
                const Δλ = (lon2-lon1) * Math.PI/180;

                const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                          Math.cos(φ1) * Math.cos(φ2) *
                          Math.sin(Δλ/2) * Math.sin(Δλ/2);
                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                const d = R * c;
                
                return d;
            }
            
            function setupGeolocation() {
                const locateButton = document.getElementById('locate-me');
                
                locateButton.addEventListener('click', function() {
                    if (navigator.geolocation) {
                        locateButton.textContent = 'Locating...';
                        
                        navigator.geolocation.getCurrentPosition(
                            function(position) {
                                const lat = position.coords.latitude;
                                const lng = position.coords.longitude;
                                
                                // Update displayed coordinates
                                document.getElementById('user-lat').textContent = lat.toFixed(6);
                                document.getElementById('user-lng').textContent = lng.toFixed(6);
                                
                                // Calculate and display grid coordinates
                                const gridCode = latLngToLetterGrid(lat, lng);
                                document.getElementById('user-grid').textContent = gridCode;
                                
                                // Update SI distance from origin (0,0)
                                const distanceMeters = calculateDistanceInMeters([0, 0], [lat, lng]);
                                let distanceDisplay = '';
                                
                                if (distanceMeters >= 1000000) {
                                    distanceDisplay = `${(distanceMeters/1000000).toFixed(2)} Mm`;
                                } else if (distanceMeters >= 1000) {
                                    distanceDisplay = `${(distanceMeters/1000).toFixed(2)} km`;
                                } else {
                                    distanceDisplay = `${Math.round(distanceMeters)} m`;
                                }
                                
                                document.getElementById('distance-si').textContent = distanceDisplay;
                                
                                // Center map on user location
                                map.setView([lat, lng], 10);
                                
                                // Add marker for user location
                                const userMarker = L.marker([lat, lng], {
                                    title: 'Your Location',
                                    icon: L.divIcon({
                                        className: 'user-location-marker',
                                        html: '<div style="background-color: #00374d; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white;"></div>',
                                        iconSize: [22, 22],
                                        iconAnchor: [11, 11]
                                    })
                                }).addTo(map);
                                
                                userMarker.bindPopup('Your Current Location').openPopup();
                                
                                locateButton.textContent = 'Find My Location';
                            },
                            function(error) {
                                console.error('Geolocation error:', error);
                                alert('Unable to retrieve your location. Error: ' + error.message);
                                locateButton.textContent = 'Find My Location';
                            },
                            {
                                enableHighAccuracy: true,
                                timeout: 5000,
                                maximumAge: 0
                            }
                        );
                    } else {
                        alert('Geolocation is not supported by your browser');
                    }
                });
            }
            
            function fetchData(type) {
                let url = '';
                if (type === 'datasets') {
                    url = '/api/datasets';
                } else if (type === 'categories') {
                    url = '/api/categories';
                }
                
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById(`${type}-result`).innerHTML = 
                            `<pre>${JSON.stringify(data, null, 2)}</pre>`;
                    })
                    .catch(error => {
                        document.getElementById(`${type}-result`).innerHTML = 
                            `<p>Error: ${error.message}</p>`;
                    });
            }
            
            document.getElementById('stations-form').addEventListener('submit', function(e) {
                e.preventDefault();
                const dataset = document.getElementById('dataset').value;
                const location = document.getElementById('location').value;
                
                fetch(`/api/stations?dataset=${dataset}&location=${location}`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('stations-result').innerHTML = 
                            `<pre>${JSON.stringify(data, null, 2)}</pre>`;
                        
                        // Add stations to map
                        addStationsToMap(data);
                    })
                    .catch(error => {
                        document.getElementById('stations-result').innerHTML = 
                            `<p>Error: ${error.message}</p>`;
                    });
            });
            
            document.getElementById('data-form').addEventListener('submit', function(e) {
                e.preventDefault();
                const dataset = document.getElementById('data-dataset').value;
                const station = document.getElementById('station').value;
                const startDate = document.getElementById('start-date').value;
                const endDate = document.getElementById('end-date').value;
                
                fetch(`/api/data?dataset=${dataset}&station=${station}&start=${startDate}&end=${endDate}`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('data-result').innerHTML = 
                            `<pre>${JSON.stringify(data, null, 2)}</pre>`;
                    })
                    .catch(error => {
                        document.getElementById('data-result').innerHTML = 
                            `<p>Error: ${error.message}</p>`;
                    });
            });
            
            // Initialize satellite map
            let satelliteMap = null;
            let satelliteMarker = null;
            let satellitePath = null;
            
            function initSatelliteMap() {
                if (satelliteMap) {
                    satelliteMap.remove();
                }
                
                satelliteMap = L.map('satellite-map-container').setView([0, 0], 2);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                    maxZoom: 18
                }).addTo(satelliteMap);
                
                // Add basic coordinate grid system with standard Leaflet
                // Create latitude lines
                for (let lat = -80; lat <= 80; lat += 20) {
                    L.polyline([[lat, -180], [lat, 180]], {
                        color: 'rgba(70, 130, 180, 0.5)',
                        weight: 1,
                        dashArray: '5,5'
                    }).addTo(satelliteMap);
                    
                    // Add latitude labels
                    L.marker([lat, 0], {
                        icon: L.divIcon({
                            className: 'grid-label',
                            html: lat + '°',
                            iconSize: [40, 20],
                            iconAnchor: [20, 10]
                        })
                    }).addTo(satelliteMap);
                }
                
                // Create longitude lines
                for (let lng = -160; lng <= 160; lng += 40) {
                    L.polyline([[-85, lng], [85, lng]], {
                        color: 'rgba(70, 130, 180, 0.5)',
                        weight: 1,
                        dashArray: '5,5'
                    }).addTo(satelliteMap);
                    
                    // Add longitude labels
                    L.marker([0, lng], {
                        icon: L.divIcon({
                            className: 'grid-label',
                            html: lng + '°',
                            iconSize: [40, 20],
                            iconAnchor: [20, 10]
                        })
                    }).addTo(satelliteMap);
                }
                
                // Add SI units scale
                L.control.scale({
                    imperial: false,
                    metric: true,
                    position: 'bottomleft'
                }).addTo(satelliteMap);
                
                return satelliteMap;
            }
            
            // Initialize satellite map on page load
            document.addEventListener('DOMContentLoaded', function() {
                initMap();
                setupGeolocation();
                initSatelliteMap();
                
                // Setup "Use My Location" button for weather
                document.getElementById('use-current-location').addEventListener('click', function() {
                    const userLat = document.getElementById('user-lat').textContent;
                    const userLng = document.getElementById('user-lng').textContent;
                    
                    if (userLat !== '-' && userLng !== '-') {
                        document.getElementById('weather-lat').value = userLat;
                        document.getElementById('weather-lon').value = userLng;
                    } else {
                        alert('Please use the "Find My Location" button first to get your coordinates.');
                    }
                });
            });
            
            // Track satellite position
            document.getElementById('satellite-form').addEventListener('submit', function(e) {
                e.preventDefault();
                const satelliteId = document.getElementById('satellite-select').value;
                trackSatellite(satelliteId);
            });
            
            function trackSatellite(satelliteId) {
                const satelliteInfo = document.getElementById('satellite-info');
                satelliteInfo.innerHTML = '<p>Loading satellite position...</p>';
                
                fetch(`/api/satellite?id=${satelliteId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            satelliteInfo.innerHTML = `<p>Error: ${data.error}</p>`;
                            return;
                        }
                        
                        updateSatelliteMap(data);
                        displaySatelliteInfo(data);
                    })
                    .catch(error => {
                        satelliteInfo.innerHTML = `<p>Error: ${error.message}</p>`;
                    });
            }
            
            function updateSatelliteMap(data) {
                if (!satelliteMap) {
                    satelliteMap = initSatelliteMap();
                }
                
                // Clear existing markers and paths
                if (satelliteMarker) {
                    satelliteMap.removeLayer(satelliteMarker);
                }
                if (satellitePath) {
                    satelliteMap.removeLayer(satellitePath);
                }
                
                // Add current position marker
                const position = [data.position.latitude, data.position.longitude];
                satelliteMarker = L.marker(position, {
                    icon: L.divIcon({
                        className: 'satellite-marker',
                        html: '<i class="fa fa-satellite" style="font-size: 24px;"></i>',
                        iconSize: [24, 24],
                        iconAnchor: [12, 12]
                    })
                }).addTo(satelliteMap);
                
                satelliteMarker.bindPopup(`
                    <strong>${data.info.name}</strong><br>
                    Altitude: ${Math.round(data.position.altitude)} km<br>
                    Velocity: ${Math.round(data.position.velocity)} km/h
                `).openPopup();
                
                // Add predicted path
                if (data.path && data.path.length > 0) {
                    const pathPoints = data.path.map(point => [point.latitude, point.longitude]);
                    satellitePath = L.polyline(pathPoints, {className: 'satellite-path'}).addTo(satelliteMap);
                    
                    // Fit map to path
                    satelliteMap.fitBounds(satellitePath.getBounds());
                } else {
                    // If no path, just center on current position
                    satelliteMap.setView(position, 4);
                }
            }
            
            function displaySatelliteInfo(data) {
                const info = data.info;
                const position = data.position;
                
                // Get grid coordinates for satellite position
                const gridCoordinates = latLngToLetterGrid(position.latitude, position.longitude);
                
                document.getElementById('satellite-info').innerHTML = `
                    <h3>${info.name}</h3>
                    <p><strong>NORAD ID:</strong> ${info.norad_id}</p>
                    <p><strong>Current Position:</strong></p>
                    <p>Latitude: ${position.latitude.toFixed(4)}°</p>
                    <p>Longitude: ${position.longitude.toFixed(4)}°</p>
                    <p>Grid Coordinates: ${gridCoordinates}</p>
                    <p>Altitude: ${Math.round(position.altitude)} km</p>
                    <p>Velocity: ${Math.round(position.velocity)} km/h</p>
                    <p><strong>Orbital Details:</strong></p>
                    <p>Inclination: ${info.inclination.toFixed(2)}°</p>
                    <p>Period: ${Math.round(info.period)} minutes</p>
                `;
            }
            
            // Get weather data
            document.getElementById('weather-form').addEventListener('submit', function(e) {
                e.preventDefault();
                const lat = document.getElementById('weather-lat').value;
                const lon = document.getElementById('weather-lon').value;
                
                if (!lat || !lon) {
                    alert('Please enter latitude and longitude');
                    return;
                }
                
                getWeather(lat, lon);
            });
            
            function getWeather(lat, lon) {
                const weatherResult = document.getElementById('weather-result');
                weatherResult.innerHTML = '<p>Loading weather data...</p>';
                
                fetch(`/api/weather?lat=${lat}&lon=${lon}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            weatherResult.innerHTML = `<p>Error: ${data.error}</p>`;
                            return;
                        }
                        
                        displayWeather(data);
                    })
                    .catch(error => {
                        weatherResult.innerHTML = `<p>Error: ${error.message}</p>`;
                    });
            }
            
            function displayWeather(data) {
                const weather = data.weather[0];
                const main = data.main;
                const wind = data.wind;
                const sys = data.sys;
                const name = data.name;
                
                document.getElementById('weather-result').innerHTML = `
                    <h3>${name}, ${sys.country}</h3>
                    <div class="weather-main">
                        <img class="weather-icon" src="https://openweathermap.org/img/wn/${weather.icon}@2x.png" alt="${weather.description}">
                        <div class="weather-temp">${Math.round(main.temp)}°C</div>
                        <div class="weather-description">${weather.description}</div>
                    </div>
                    <div class="weather-details">
                        <div class="weather-detail">Feels like: ${Math.round(main.feels_like)}°C</div>
                        <div class="weather-detail">Humidity: ${main.humidity}%</div>
                        <div class="weather-detail">Pressure: ${main.pressure} hPa</div>
                        <div class="weather-detail">Wind: ${Math.round(wind.speed * 3.6)} km/h</div>
                        <div class="weather-detail">Min: ${Math.round(main.temp_min)}°C</div>
                        <div class="weather-detail">Max: ${Math.round(main.temp_max)}°C</div>
                    </div>
                `;
            }
            
            // Water Anomaly Monitoring
            document.addEventListener('DOMContentLoaded', function() {
                // Setup "Use My Location" button for water anomaly
                document.getElementById('use-current-location-anomaly').addEventListener('click', function() {
                    const userLat = document.getElementById('user-lat').textContent;
                    const userLng = document.getElementById('user-lng').textContent;
                    
                    if (userLat !== '-' && userLng !== '-') {
                        document.getElementById('anomaly-lat').value = userLat;
                        document.getElementById('anomaly-lon').value = userLng;
                    } else {
                        alert('Please use the "Find My Location" button first to get your coordinates.');
                    }
                });
                
                // Setup date default for water inference
                const today = new Date();
                const nextWeek = new Date(today);
                nextWeek.setDate(today.getDate() + 7);
                document.getElementById('inference-date').valueAsDate = nextWeek;
            });
            
            document.getElementById('water-anomaly-form').addEventListener('submit', function(e) {
                e.preventDefault();
                const lat = document.getElementById('anomaly-lat').value;
                const lon = document.getElementById('anomaly-lon').value;
                const type = document.getElementById('anomaly-type').value;
                
                analyzeWaterAnomaly(lat, lon, type);
            });
            
            function analyzeWaterAnomaly(lat, lon, type) {
                const resultElement = document.getElementById('water-anomaly-result');
                resultElement.innerHTML = '<p>Analyzing water conditions...</p>';
                
                // In a real application, this would call an API endpoint
                // For demonstration, we'll simulate the response
                setTimeout(() => {
                    let anomalyData;
                    
                    if (type === 'water_level') {
                        const baseLevel = 100; // baseline water level in cm
                        const randomVariation = Math.random() * 50 - 25; // -25 to +25 cm
                        const level = baseLevel + randomVariation;
                        const isAnomaly = Math.abs(randomVariation) > 15;
                        
                        anomalyData = {
                            current_level: level.toFixed(1),
                            historical_avg: baseLevel.toFixed(1),
                            deviation: randomVariation.toFixed(1),
                            is_anomaly: isAnomaly,
                            trend: randomVariation > 0 ? 'rising' : 'falling',
                            risk_level: isAnomaly ? (randomVariation > 0 ? 'high' : 'moderate') : 'low'
                        };
                    } else if (type === 'sea_temp') {
                        const baseTemp = 15; // baseline temperature in °C
                        const randomVariation = Math.random() * 6 - 3; // -3 to +3 °C
                        const temp = baseTemp + randomVariation;
                        const isAnomaly = Math.abs(randomVariation) > 2;
                        
                        anomalyData = {
                            current_temp: temp.toFixed(1),
                            historical_avg: baseTemp.toFixed(1),
                            deviation: randomVariation.toFixed(1),
                            is_anomaly: isAnomaly,
                            impact: isAnomaly ? 'Potential impact on marine ecosystems' : 'Normal seasonal variation',
                            risk_level: isAnomaly ? 'moderate' : 'low'
                        };
                    } else if (type === 'tornadic_activity') {
                        const randomValue = Math.random();
                        const riskLevel = randomValue < 0.1 ? 'high' : (randomValue < 0.3 ? 'moderate' : 'low');
                        
                        anomalyData = {
                            risk_index: (randomValue * 10).toFixed(1),
                            wind_shear: (Math.random() * 30).toFixed(1),
                            humidity: (40 + Math.random() * 60).toFixed(1),
                            pressure_drop: (Math.random() * 15).toFixed(1),
                            risk_level: riskLevel,
                            warning: riskLevel === 'high' ? 'Potential tornadic conditions detected' : 'No immediate tornadic threat'
                        };
                    }
                    
                    displayWaterAnomalyResults(type, anomalyData);
                }, 1500);
            }
            
            function displayWaterAnomalyResults(type, data) {
                const resultElement = document.getElementById('water-anomaly-result');
                
                let html = `<h3>${type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} Analysis</h3>`;
                html += `<div class="result-content">`;
                
                if (type === 'water_level') {
                    html += `
                        <p><strong>Current Water Level:</strong> ${data.current_level} cm</p>
                        <p><strong>Historical Average:</strong> ${data.historical_avg} cm</p>
                        <p><strong>Deviation:</strong> ${data.deviation} cm (${data.trend})</p>
                        <p><strong>Risk Level:</strong> <span style="color: ${getRiskColor(data.risk_level)}">${data.risk_level.toUpperCase()}</span></p>
                        ${data.is_anomaly ? '<p><strong>Warning:</strong> Abnormal water level detected</p>' : '<p>Water levels within normal range</p>'}
                    `;
                } else if (type === 'sea_temp') {
                    html += `
                        <p><strong>Current Temperature:</strong> ${data.current_temp}°C</p>
                        <p><strong>Historical Average:</strong> ${data.historical_avg}°C</p>
                        <p><strong>Deviation:</strong> ${data.deviation}°C</p>
                        <p><strong>Risk Level:</strong> <span style="color: ${getRiskColor(data.risk_level)}">${data.risk_level.toUpperCase()}</span></p>
                        <p><strong>Impact Assessment:</strong> ${data.impact}</p>
                    `;
                } else if (type === 'tornadic_activity') {
                    html += `
                        <p><strong>Tornadic Risk Index:</strong> ${data.risk_index}/10</p>
                        <p><strong>Wind Shear:</strong> ${data.wind_shear} m/s</p>
                        <p><strong>Relative Humidity:</strong> ${data.humidity}%</p>
                        <p><strong>Pressure Drop:</strong> ${data.pressure_drop} hPa</p>
                        <p><strong>Risk Level:</strong> <span style="color: ${getRiskColor(data.risk_level)}">${data.risk_level.toUpperCase()}</span></p>
                        <p><strong>Warning Status:</strong> ${data.warning}</p>
                    `;
                }
                
                html += `</div>`;
                resultElement.innerHTML = html;
            }
            
            function getRiskColor(risk) {
                switch(risk.toLowerCase()) {
                    case 'high': return '#d9534f';
                    case 'moderate': return '#f0ad4e';
                    case 'low': return '#5cb85c';
                    default: return '#5bc0de';
                }
            }
            
            // Water Data Inference
            document.getElementById('water-inference-form').addEventListener('submit', function(e) {
                e.preventDefault();
                const lat = document.getElementById('inference-lat').value;
                const lon = document.getElementById('inference-lon').value;
                const date = document.getElementById('inference-date').value;
                
                generateWaterPrediction(lat, lon, date);
            });
            
            function generateWaterPrediction(lat, lon, date) {
                const resultElement = document.getElementById('water-inference-result');
                resultElement.innerHTML = '<p>Generating water condition prediction...</p>';
                
                // In a real application, this would call an API endpoint
                // For demonstration, we'll simulate the response with ML-inference-like results
                setTimeout(() => {
                    const targetDate = new Date(date);
                    const today = new Date();
                    const daysDiff = Math.round((targetDate - today) / (1000 * 60 * 60 * 24));
                    
                    // Generate simulated prediction data
                    const predictedData = {
                        date: date,
                        days_from_now: daysDiff,
                        location: {
                            latitude: parseFloat(lat).toFixed(4),
                            longitude: parseFloat(lon).toFixed(4),
                        },
                        water_level: {
                            predicted: (100 + Math.sin(daysDiff/7 * Math.PI) * 20).toFixed(1),
                            confidence: (90 - Math.min(daysDiff, 30) * 2).toFixed(1),
                            trend: Math.sin(daysDiff/7 * Math.PI) > 0 ? 'rising' : 'falling'
                        },
                        water_temperature: {
                            predicted: (15 + Math.sin(daysDiff/14 * Math.PI) * 5).toFixed(1),
                            confidence: (85 - Math.min(daysDiff, 30) * 1.5).toFixed(1),
                        },
                        water_quality: {
                            predicted_index: (Math.random() * 2 + 7).toFixed(1),
                            confidence: (80 - Math.min(daysDiff, 30) * 2).toFixed(1),
                        },
                        precipitation: {
                            chance: (Math.random() * 100).toFixed(0),
                            amount: (Math.random() * 10).toFixed(1),
                        }
                    };
                    
                    displayWaterPrediction(predictedData);
                }, 2000);
            }
            
            function displayWaterPrediction(data) {
                const resultElement = document.getElementById('water-inference-result');
                
                const html = `
                    <h3>Water Condition Prediction</h3>
                    <p><strong>Target Date:</strong> ${formatDate(data.date)} (${data.days_from_now} days from today)</p>
                    <p><strong>Location:</strong> ${data.location.latitude}, ${data.location.longitude}</p>
                    
                    <h4>Predicted Conditions:</h4>
                    <div class="weather-details">
                        <div class="weather-detail">
                            <strong>Water Level:</strong> ${data.water_level.predicted} cm
                            <br><small>(${data.water_level.trend}, ${data.water_level.confidence}% confidence)</small>
                        </div>
                        <div class="weather-detail">
                            <strong>Water Temperature:</strong> ${data.water_temperature.predicted}°C
                            <br><small>(${data.water_temperature.confidence}% confidence)</small>
                        </div>
                        <div class="weather-detail">
                            <strong>Water Quality Index:</strong> ${data.water_quality.predicted_index}/10
                            <br><small>(${data.water_quality.confidence}% confidence)</small>
                        </div>
                        <div class="weather-detail">
                            <strong>Precipitation:</strong> ${data.precipitation.chance}% chance
                            <br><small>(Est. ${data.precipitation.amount} mm if rain occurs)</small>
                        </div>
                    </div>
                    
                    <p style="margin-top: 15px;"><small>Note: Prediction confidence decreases with longer time horizons.</small></p>
                `;
                
                resultElement.innerHTML = html;
            }
            
            function formatDate(dateString) {
                const date = new Date(dateString);
                return date.toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                });
            }
            
            // Settings Panel and Menu functionality
            document.addEventListener('DOMContentLoaded', function() {
                initSettingsPanel();
                loadSettings();
            });
            
            function initSettingsPanel() {
                const settingsButton = document.getElementById('settings-button');
                const settingsPanel = document.getElementById('settings-panel');
                const settingsClose = document.getElementById('settings-close');
                const overlay = document.getElementById('overlay');
                const menuToggles = document.querySelectorAll('.menu-toggle');
                const helpButton = document.getElementById('help-button');
                
                // Font size slider
                const fontSizeSlider = document.getElementById('font-size');
                const fontSizeValue = document.getElementById('font-size-value');
                
                if (fontSizeSlider && fontSizeValue) {
                    fontSizeSlider.addEventListener('input', function() {
                        fontSizeValue.textContent = this.value + 'px';
                        document.documentElement.style.fontSize = this.value + 'px';
                        saveSettings();
                    });
                }
                
                // Open settings panel
                if (settingsButton) {
                    settingsButton.addEventListener('click', function() {
                        settingsPanel.classList.add('active');
                        overlay.classList.add('active');
                    });
                }
                
                // Close settings panel
                if (settingsClose) {
                    settingsClose.addEventListener('click', function() {
                        settingsPanel.classList.remove('active');
                        overlay.classList.remove('active');
                    });
                }
                
                if (overlay) {
                    overlay.addEventListener('click', function() {
                        settingsPanel.classList.remove('active');
                        overlay.classList.remove('active');
                    });
                }
                
                // Toggle submenus
                menuToggles.forEach(toggle => {
                    toggle.addEventListener('click', function() {
                        const targetId = this.getAttribute('data-target');
                        const targetSubmenu = document.getElementById(targetId);
                        
                        if (this.classList.contains('active')) {
                            this.classList.remove('active');
                            targetSubmenu.classList.remove('active');
                        } else {
                            this.classList.add('active');
                            targetSubmenu.classList.add('active');
                        }
                    });
                });
                
                // Help button
                if (helpButton) {
                    helpButton.addEventListener('click', function() {
                        showHelp();
                    });
                }
                
                // Initialize all settings controls
                const settingControls = document.querySelectorAll('.setting-control');
                settingControls.forEach(control => {
                    control.addEventListener('change', saveSettings);
                });
                
                // Save API Keys button
                const saveApiKeysButton = document.getElementById('save-api-keys');
                if (saveApiKeysButton) {
                    saveApiKeysButton.addEventListener('click', function() {
                        saveApiKeys();
                    });
                }
                
                // Theme selector
                const themeSelect = document.getElementById('theme-select');
                if (themeSelect) {
                    themeSelect.addEventListener('change', function() {
                        applyTheme(this.value);
                    });
                }
                
                // Map settings
                const mapStyle = document.getElementById('map-style');
                const showGrid = document.getElementById('show-grid');
                const showLetterGrid = document.getElementById('show-letter-grid');
                
                if (mapStyle && map) {
                    mapStyle.addEventListener('change', function() {
                        changeMapStyle(this.value);
                    });
                }
                
                if (showGrid) {
                    showGrid.addEventListener('change', function() {
                        toggleGridVisibility(this.checked);
                    });
                }
                
                if (showLetterGrid) {
                    showLetterGrid.addEventListener('change', function() {
                        toggleLetterGridVisibility(this.checked);
                    });
                }
            }
            
            function showHelp() {
                // Create and show help modal
                const modal = document.createElement('div');
                modal.style.position = 'fixed';
                modal.style.top = '50%';
                modal.style.left = '50%';
                modal.style.transform = 'translate(-50%, -50%)';
                modal.style.backgroundColor = 'white';
                modal.style.padding = '20px';
                modal.style.borderRadius = '5px';
                modal.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
                modal.style.zIndex = '3000';
                modal.style.maxWidth = '600px';
                modal.style.maxHeight = '80vh';
                modal.style.overflow = 'auto';
                
                modal.innerHTML = `
                    <h2>NOAA Data Explorer Help</h2>
                    <h3>Getting Started</h3>
                    <p>This application allows you to explore NOAA weather data, track satellites, and analyze water anomalies.</p>
                    
                    <h3>Key Features</h3>
                    <ul>
                        <li><strong>Weather Stations:</strong> Find and view data from NOAA weather stations around the world.</li>
                        <li><strong>Current Weather:</strong> Get current weather conditions for any location.</li>
                        <li><strong>Satellite Tracker:</strong> Track satellites in real-time with their paths displayed on a map.</li>
                        <li><strong>Water Anomaly Monitoring:</strong> Check for water level anomalies, sea temperature changes, and tornadic activity.</li>
                        <li><strong>Water Data Inference:</strong> Predict water conditions based on historical data.</li>
                    </ul>
                    
                    <h3>Settings</h3>
                    <p>Click the Settings button to customize your experience:</p>
                    <ul>
                        <li><strong>Display Settings:</strong> Change theme, font size, and contrast.</li>
                        <li><strong>Map Settings:</strong> Change map style and grid visibility.</li>
                        <li><strong>Data Settings:</strong> Set units and refresh intervals.</li>
                        <li><strong>API Keys:</strong> Configure your API keys for extended functionality.</li>
                    </ul>
                    
                    <h3>Coordinate System</h3>
                    <p>The map uses both standard latitude/longitude coordinates and a 26x26 letter grid system for location reference.</p>
                    
                    <button id="close-help" style="background-color: #00374d; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; margin-top: 15px;">Close</button>
                `;
                
                document.body.appendChild(modal);
                
                // Create overlay
                const helpOverlay = document.createElement('div');
                helpOverlay.style.position = 'fixed';
                helpOverlay.style.top = '0';
                helpOverlay.style.left = '0';
                helpOverlay.style.width = '100%';
                helpOverlay.style.height = '100%';
                helpOverlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
                helpOverlay.style.zIndex = '2999';
                
                document.body.appendChild(helpOverlay);
                
                // Close button functionality
                document.getElementById('close-help').addEventListener('click', function() {
                    document.body.removeChild(modal);
                    document.body.removeChild(helpOverlay);
                });
                
                helpOverlay.addEventListener('click', function() {
                    document.body.removeChild(modal);
                    document.body.removeChild(helpOverlay);
                });
            }
            
            function saveSettings() {
                const settings = {
                    theme: document.getElementById('theme-select').value,
                    fontSize: document.getElementById('font-size').value,
                    highContrast: document.getElementById('high-contrast').checked,
                    mapStyle: document.getElementById('map-style').value,
                    showGrid: document.getElementById('show-grid').checked,
                    showLetterGrid: document.getElementById('show-letter-grid').checked,
                    units: document.getElementById('units').value,
                    refreshInterval: document.getElementById('refresh-interval').value
                };
                
                localStorage.setItem('noaaExplorerSettings', JSON.stringify(settings));
                applySettings(settings);
            }
            
            function loadSettings() {
                let settings = localStorage.getItem('noaaExplorerSettings');
                
                if (settings) {
                    settings = JSON.parse(settings);
                    
                    // Set form values
                    document.getElementById('theme-select').value = settings.theme || 'light';
                    document.getElementById('font-size').value = settings.fontSize || '14';
                    document.getElementById('font-size-value').textContent = (settings.fontSize || '14') + 'px';
                    document.getElementById('high-contrast').checked = settings.highContrast || false;
                    document.getElementById('map-style').value = settings.mapStyle || 'standard';
                    document.getElementById('show-grid').checked = settings.showGrid !== undefined ? settings.showGrid : true;
                    document.getElementById('show-letter-grid').checked = settings.showLetterGrid !== undefined ? settings.showLetterGrid : true;
                    document.getElementById('units').value = settings.units || 'metric';
                    document.getElementById('refresh-interval').value = settings.refreshInterval || '60';
                    
                    // Apply settings
                    applySettings(settings);
                }
                
                // Load API keys
                loadApiKeys();
            }
            
            function applySettings(settings) {
                // Apply theme
                applyTheme(settings.theme);
                
                // Apply font size
                document.documentElement.style.fontSize = settings.fontSize + 'px';
                
                // Apply high contrast
                if (settings.highContrast) {
                    document.body.classList.add('high-contrast');
                } else {
                    document.body.classList.remove('high-contrast');
                }
                
                // Apply map settings if map is initialized
                if (map) {
                    changeMapStyle(settings.mapStyle);
                    toggleGridVisibility(settings.showGrid);
                    toggleLetterGridVisibility(settings.showLetterGrid);
                }
                
                // Apply units
                updateDisplayUnits(settings.units);
            }
            
            function applyTheme(theme) {
                let bgColor, textColor, cardBg, primaryColor;
                
                switch(theme) {
                    case 'dark':
                        bgColor = '#121212';
                        textColor = '#e0e0e0';
                        cardBg = '#1e1e1e';
                        primaryColor = '#58a6ff';
                        break;
                    case 'blue':
                        bgColor = '#e6f2f7';
                        textColor = '#003853';
                        cardBg = '#ffffff';
                        primaryColor = '#0078a8';
                        break;
                    default: // light
                        bgColor = '#ffffff';
                        textColor = '#333333';
                        cardBg = '#f8f9fa';
                        primaryColor = '#00374d';
                }
                
                document.documentElement.style.setProperty('--bg-color', bgColor);
                document.documentElement.style.setProperty('--text-color', textColor);
                document.documentElement.style.setProperty('--card-bg', cardBg);
                document.documentElement.style.setProperty('--primary-color', primaryColor);
                
                document.body.style.backgroundColor = bgColor;
                document.body.style.color = textColor;
                
                const cards = document.querySelectorAll('.card');
                cards.forEach(card => {
                    card.style.backgroundColor = cardBg;
                    card.style.borderColor = theme === 'dark' ? '#333' : '#ddd';
                });
                
                const buttons = document.querySelectorAll('button');
                buttons.forEach(button => {
                    if (!button.classList.contains('menu-button')) {
                        button.style.backgroundColor = primaryColor;
                    }
                });
            }
            
            function changeMapStyle(style) {
                if (!map) return;
                
                // Remove current tile layer
                map.eachLayer(layer => {
                    if (layer instanceof L.TileLayer) {
                        map.removeLayer(layer);
                    }
                });
                
                // Add new tile layer based on selected style
                switch(style) {
                    case 'satellite':
                        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                            attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
                        }).addTo(map);
                        break;
                    case 'terrain':
                        L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
                            attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
                        }).addTo(map);
                        break;
                    default: // standard
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                        }).addTo(map);
                }
                
                // Do the same for satelliteMap if it exists
                if (satelliteMap) {
                    satelliteMap.eachLayer(layer => {
                        if (layer instanceof L.TileLayer) {
                            satelliteMap.removeLayer(layer);
                        }
                    });
                    
                    switch(style) {
                        case 'satellite':
                            L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                                attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
                            }).addTo(satelliteMap);
                            break;
                        case 'terrain':
                            L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
                                attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
                            }).addTo(satelliteMap);
                            break;
                        default: // standard
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                            }).addTo(satelliteMap);
                    }
                }
            }
            
            function toggleGridVisibility(visible) {
                const gridLines = document.querySelectorAll('[class^="leaflet-layer"] path[stroke="rgba(70, 130, 180, 0.5)"]');
                const gridLabels = document.querySelectorAll('.grid-label');
                
                gridLines.forEach(line => {
                    line.style.display = visible ? 'block' : 'none';
                });
                
                gridLabels.forEach(label => {
                    label.style.display = visible ? 'block' : 'none';
                });
            }
            
            function toggleLetterGridVisibility(visible) {
                const letterGridLabels = document.querySelectorAll('.letter-grid-label');
                
                letterGridLabels.forEach(label => {
                    label.style.display = visible ? 'block' : 'none';
                });
            }
            
            function updateDisplayUnits(units) {
                // This would update displayed units in the app
                // For a full implementation, you'd need to convert all displayed values
                console.log('Changing units to:', units);
                // Example: Update weather display if it exists
                const weatherResult = document.getElementById('weather-result');
                if (weatherResult && weatherResult.innerHTML.length > 0) {
                    // Reload weather with new units
                    const lat = document.getElementById('weather-lat').value;
                    const lon = document.getElementById('weather-lon').value;
                    if (lat && lon) {
                        getWeather(lat, lon);
                    }
                }
            }
            
            function saveApiKeys() {
                const noaaKey = document.getElementById('noaa-api-key').value;
                const weatherKey = document.getElementById('weather-api-key').value;
                const satelliteKey = document.getElementById('satellite-api-key').value;
                
                const apiKeys = {
                    noaa: noaaKey,
                    openweather: weatherKey,
                    n2yo: satelliteKey
                };
                
                // In a real application, this would be sent to the server
                // For now, we'll just store in localStorage (not secure for API keys!)
                localStorage.setItem('noaaExplorerApiKeys', JSON.stringify(apiKeys));
                
                alert('API keys saved. Please note that storing API keys in the browser is not secure. In a production environment, these should be stored on the server.');
            }
            
            function loadApiKeys() {
                const keys = localStorage.getItem('noaaExplorerApiKeys');
                
                if (keys) {
                    const apiKeys = JSON.parse(keys);
                    
                    if (apiKeys.noaa) document.getElementById('noaa-api-key').value = apiKeys.noaa;
                    if (apiKeys.openweather) document.getElementById('weather-api-key').value = apiKeys.openweather;
                    if (apiKeys.n2yo) document.getElementById('satellite-api-key').value = apiKeys.n2yo;
                }
            }
        </script>
    </body>
    </html>
    """
    return render_template_string(html, api_key=bool(API_KEY))

@app.route('/api/datasets')
def api_datasets():
    return get_datasets()

@app.route('/api/categories')
def api_categories():
    return get_data_categories()

@app.route('/api/stations')
def api_stations():
    dataset = request.args.get('dataset', 'GHCND')
    location = request.args.get('location', None)
    if location == '':
        location = None
    return get_stations(dataset_id=dataset, location_id=location)

@app.route('/api/data')
def api_data():
    dataset = request.args.get('dataset', 'GHCND')
    station = request.args.get('station')
    start_date = request.args.get('start', None)
    end_date = request.args.get('end', None)
    return get_data(dataset_id=dataset, station_id=station, start_date=start_date, end_date=end_date)

@app.route('/api/weather')
def api_weather():
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    
    if not lat or not lon:
        return {"error": "Latitude and longitude are required"}
    
    # OpenWeatherMap API
    api_key = os.environ.get("OPENWEATHER_API_KEY", "")
    if not api_key:
        return {"error": "OpenWeatherMap API key not configured"}
    
    url = f"https://api.openweathermap.org/data/2.5/weather"
    params = {
        "lat": lat,
        "lon": lon,
        "appid": api_key,
        "units": "metric"  # Use Celsius
    }
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": f"Failed to fetch weather data: {str(e)}"}

@app.route('/api/satellite')
def api_satellite():
    satellite_id = request.args.get('id')
    
    if not satellite_id:
        return {"error": "Satellite ID is required"}
    
    # N2YO API for satellite tracking
    api_key = os.environ.get("N2YO_API_KEY", "")
    if not api_key:
        return {"error": "N2YO API key not configured"}
    
    # Get satellite position
    position_url = f"https://api.n2yo.com/rest/v1/satellite/positions/{satellite_id}/0/0/0/1/&apiKey={api_key}"
    
    try:
        position_response = requests.get(position_url)
        position_response.raise_for_status()
        position_data = position_response.json()
        
        # Get satellite info
        info_url = f"https://api.n2yo.com/rest/v1/satellite/tle/{satellite_id}&apiKey={api_key}"
        info_response = requests.get(info_url)
        info_response.raise_for_status()
        info_data = info_response.json()
        
        # Get predicted path for next 30 minutes (10 positions)
        path_url = f"https://api.n2yo.com/rest/v1/satellite/positions/{satellite_id}/0/0/0/30/&apiKey={api_key}"
        path_response = requests.get(path_url)
        path_data = path_response.json()
        
        # Combine all data
        result = {
            "info": {
                "name": info_data["info"]["satname"],
                "norad_id": info_data["info"]["satid"],
                "inclination": float(info_data["tle"].split("\n")[1][8:16]),
                "period": float(position_data["info"]["satname"].split("~")[1].strip()) if "~" in position_data["info"]["satname"] else 90
            },
            "position": {
                "latitude": position_data["positions"][0]["satlatitude"],
                "longitude": position_data["positions"][0]["satlongitude"],
                "altitude": position_data["positions"][0]["sataltitude"],
                "velocity": 28000  # Approximate velocity in km/h for LEO satellites
            },
            "path": [
                {
                    "latitude": pos["satlatitude"],
                    "longitude": pos["satlongitude"],
                    "altitude": pos["sataltitude"]
                }
                for pos in path_data["positions"]
            ]
        }
        
        return result
    except requests.exceptions.RequestException as e:
        return {"error": f"Failed to fetch satellite data: {str(e)}"}
    except (KeyError, IndexError) as e:
        return {"error": f"Failed to parse satellite data: {str(e)}"}

@app.route('/api/water-anomaly')
def api_water_anomaly():
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    anomaly_type = request.args.get('type', 'water_level')
    
    if not lat or not lon:
        return {"error": "Latitude and longitude are required"}
    
    # In a production app, this would call external APIs or databases
    # For demonstration, we'll generate simulated data
    import random
    import math
    
    try:
        lat_float = float(lat)
        lon_float = float(lon)
        
        # Use latitude and longitude to seed the random generator for consistency
        random.seed(int((lat_float + lon_float) * 1000))
        
        if anomaly_type == 'water_level':
            base_level = 100  # baseline water level in cm
            variation = random.uniform(-25, 25)  # -25 to +25 cm
            level = base_level + variation
            is_anomaly = abs(variation) > 15
            
            return {
                "location": {
                    "lat": lat_float,
                    "lon": lon_float
                },
                "timestamp": datetime.now().isoformat(),
                "type": "water_level",
                "current_level": round(level, 1),
                "historical_avg": base_level,
                "deviation": round(variation, 1),
                "is_anomaly": is_anomaly,
                "trend": "rising" if variation > 0 else "falling",
                "risk_level": "high" if (is_anomaly and variation > 0) else ("moderate" if is_anomaly else "low")
            }
        elif anomaly_type == 'sea_temp':
            base_temp = 15  # baseline temperature in °C
            variation = random.uniform(-3, 3)  # -3 to +3 °C
            temp = base_temp + variation
            is_anomaly = abs(variation) > 2
            
            return {
                "location": {
                    "lat": lat_float,
                    "lon": lon_float
                },
                "timestamp": datetime.now().isoformat(),
                "type": "sea_temp",
                "current_temp": round(temp, 1),
                "historical_avg": base_temp,
                "deviation": round(variation, 1),
                "is_anomaly": is_anomaly,
                "impact": "Potential impact on marine ecosystems" if is_anomaly else "Normal seasonal variation",
                "risk_level": "moderate" if is_anomaly else "low"
            }
        elif anomaly_type == 'tornadic_activity':
            risk_value = random.random()
            risk_level = "high" if risk_value < 0.1 else ("moderate" if risk_value < 0.3 else "low")
            
            return {
                "location": {
                    "lat": lat_float,
                    "lon": lon_float
                },
                "timestamp": datetime.now().isoformat(),
                "type": "tornadic_activity",
                "risk_index": round(risk_value * 10, 1),
                "wind_shear": round(random.uniform(0, 30), 1),
                "humidity": round(random.uniform(40, 100), 1),
                "pressure_drop": round(random.uniform(0, 15), 1),
                "risk_level": risk_level,
                "warning": "Potential tornadic conditions detected" if risk_level == "high" else "No immediate tornadic threat"
            }
        else:
            return {"error": "Invalid anomaly type"}
    except ValueError:
        return {"error": "Invalid latitude or longitude format"}

@app.route('/api/water-inference')
def api_water_inference():
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    date = request.args.get('date')
    
    if not lat or not lon:
        return {"error": "Latitude and longitude are required"}
    
    if not date:
        date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
    
    try:
        lat_float = float(lat)
        lon_float = float(lon)
        target_date = datetime.strptime(date, '%Y-%m-%d')
        today = datetime.now()
        days_diff = (target_date - today).days
        
        # Use a combination of location and date to seed random for consistency
        import random
        import math
        seed_value = int((lat_float + lon_float) * 1000) + days_diff
        random.seed(seed_value)
        
        return {
            "date": date,
            "days_from_now": days_diff,
            "location": {
                "latitude": lat_float,
                "longitude": lon_float
            },
            "water_level": {
                "predicted": round(100 + math.sin(days_diff/7 * math.pi) * 20, 1),
                "confidence": round(90 - min(days_diff, 30) * 2, 1),
                "trend": "rising" if math.sin(days_diff/7 * math.pi) > 0 else "falling"
            },
            "water_temperature": {
                "predicted": round(15 + math.sin(days_diff/14 * math.pi) * 5, 1),
                "confidence": round(85 - min(days_diff, 30) * 1.5, 1)
            },
            "water_quality": {
                "predicted_index": round(random.uniform(7, 9), 1),
                "confidence": round(80 - min(days_diff, 30) * 2, 1)
            },
            "precipitation": {
                "chance": round(random.uniform(0, 100)),
                "amount": round(random.uniform(0, 10), 1)
            },
            "model_info": {
                "name": "WaterPredictNet v1.0",
                "last_trained": "2023-09-15",
                "data_sources": ["NOAA Historical Data", "Satellite Imagery", "Ocean Buoy Network"]
            }
        }
    except ValueError:
        return {"error": "Invalid parameters format"}

if __name__ == '__main__':
    # For development
    # app.run(host='0.0.0.0', port=8080, debug=True)
    
    # For production
    from gunicorn.app.base import BaseApplication
    
    class StandaloneApplication(BaseApplication):
        def __init__(self, app, options=None):
            self.options = options or {}
            self.application = app
            super().__init__()
        
        def load_config(self):
            for key, value in self.options.items():
                if key in self.cfg.settings and value is not None:
                    self.cfg.set(key.lower(), value)
        
        def load(self):
            return self.application
    
    options = {
        'bind': '0.0.0.0:8080',
        'workers': 3,
        'worker_class': 'sync'
    }
    
    if os.environ.get('FLASK_ENV') == 'development':
        # Use Flask's development server
        app.run(host='0.0.0.0', port=8080, debug=True)
    else:
        # Use Gunicorn in production
        StandaloneApplication(app, options).run()
