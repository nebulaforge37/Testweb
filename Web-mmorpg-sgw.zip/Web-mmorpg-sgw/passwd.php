<?
$STR = "zyxwvutsrqponmlkjihgfedcba0123456789987654321abcdefghijklmnopqstuvwxyz";
echo $STR." = ".md5($STR);
?>