<?
include_once("config.php");
$s = new Game();
echo $s->autoLoad();
?>

