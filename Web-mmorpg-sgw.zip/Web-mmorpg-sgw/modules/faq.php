<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
Frequently Asked Question<br />
<br />
What Does &quot;Lantea&quot; mean or stand for?<br /> 
	<font>-Lantea is the last planet is which the atlantians occupied in the series. It's where Atlantis is Located.</font>
<br />
What Does TBC Stand For?<br />
  <font>-It Means that &quot;To Be Coded&quot; and ussually is there but i have yet to fully code it in so it isnt active.</font>
  
</p>
</body>
</html>
