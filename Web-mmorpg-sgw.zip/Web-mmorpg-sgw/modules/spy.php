<?
include_once("../config.php");
$s = new Game();
$array = $s->spy(21,1);
echo $array;
//$weapQ = $s->spyWeapons(21);
/*$x";
*/
?>