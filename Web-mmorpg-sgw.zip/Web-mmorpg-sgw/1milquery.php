<?
include_once("config.php");
$s = new Game();
$s->turnUpdate();
?>