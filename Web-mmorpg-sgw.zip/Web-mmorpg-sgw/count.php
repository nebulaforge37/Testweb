<BODY onload='parent.bb_done_loading();'>
<div id="divFrameCount"><?= $_GET['count']; ?></div>