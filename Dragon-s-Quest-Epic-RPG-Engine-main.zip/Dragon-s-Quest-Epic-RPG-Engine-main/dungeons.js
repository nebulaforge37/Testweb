
export class DungeonPage {
    constructor() {
        this.availableDungeons = [];
    }

    render() {
        const section = document.getElementById('dungeons');
        if (section) {
            section.innerHTML = `
                <h2>Dungeons</h2>
                <div class="dungeon-list"></div>
            `;
        }
    }
}
