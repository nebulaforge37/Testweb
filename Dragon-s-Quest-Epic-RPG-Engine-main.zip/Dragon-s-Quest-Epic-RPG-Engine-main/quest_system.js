class Quest {
  constructor(id, title, description, type, level, rewards) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.type = type;
    this.level = level;
    this.rewards = rewards;
    this.progress = 0;
    this.completed = false;
    this.requirements = [];
    this.nextQuests = [];
  }
}

class QuestSystem {
  constructor() {
    this.activeQuests = new Map();
    this.completedQuests = new Map();
    this.questChains = new Map();
  }

  addQuest(quest) {
    if (!this.activeQuests.has(quest.id) && !this.completedQuests.has(quest.id)) {
      if (this.checkRequirements(quest)) {
        this.activeQuests.set(quest.id, quest);
        return true;
      }
    }
    return false;
  }

  checkRequirements(quest) {
    return quest.requirements.every(reqQuestId => 
      this.completedQuests.has(reqQuestId)
    );
  }

  updateProgress(questId, progress) {
    const quest = this.activeQuests.get(questId);
    if (quest) {
      quest.progress = Math.min(100, progress);
      if (quest.progress >= 100) {
        this.completeQuest(questId);
      }
    }
  }

  completeQuest(questId) {
    const quest = this.activeQuests.get(questId);
    if (quest) {
      quest.completed = true;
      this.completedQuests.set(questId, quest);
      this.activeQuests.delete(questId);
      this.unlockNextQuests(quest);
      return quest.rewards;
    }
    return null;
  }

  unlockNextQuests(quest) {
    quest.nextQuests.forEach(nextQuestId => {
      const nextQuest = this.questChains.get(nextQuestId);
      if (nextQuest && this.checkRequirements(nextQuest)) {
        this.addQuest(nextQuest);
      }
    });
  }
}

// Make QuestSystem available globally
window.questSystem = new QuestSystem();