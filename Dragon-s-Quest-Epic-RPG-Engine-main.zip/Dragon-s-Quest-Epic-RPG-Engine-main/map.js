
class MapPage {
  constructor() {
    this.currentZone = null;
  }

  render() {
    const worldMap = document.querySelector('.world-map');
    if (worldMap) {
      worldMap.innerHTML = `
        <div class="map-container">
          <h2>World Map</h2>
          <div class="map-zones"></div>
        </div>
      `;
    }
  }
}

// Make MapPage available globally
window.MapPage = MapPage;
