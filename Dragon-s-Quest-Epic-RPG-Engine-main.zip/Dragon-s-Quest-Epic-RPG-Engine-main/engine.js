class GameEngine {
  constructor() {
    this.lastTime = 0;
    this.deltaTime = 0;
    this.fps = 60;
    this.timeStep = 1000 / this.fps;
    this.accumulator = 0;
    this.config = new ConfigEngine();
    this.config.loadConfig();
    this.saveSystem = new SaveSystem(this);
    
    this.systems = new Map();
    this.gameState = {
      running: false,
      paused: false,
      currentScene: null,
      debug: false
    };
    
    this.initializeSystems();
  }

  initializeSystems() {
    this.systems.set('combat', new Combat());
    this.systems.set('dungeon', new DungeonSystem());
    this.systems.set('raid', new RaidSystem());
    this.systems.set('trial', new TrialSystem());
    this.systems.set('quest', new QuestSystem());
    this.systems.set('guild', new GuildSystem());
    this.systems.set('nemesis', new NemesisSystem());
    this.systems.set('crafting', new CraftingSystem());
  }

  start() {
    this.gameState.running = true;
    this.lastTime = performance.now();
    requestAnimationFrame((timestamp) => this.gameLoop(timestamp));
  }

  stop() {
    this.gameState.running = false;
  }

  pause() {
    this.gameState.paused = true;
  }

  resume() {
    this.gameState.paused = false;
    this.lastTime = performance.now();
  }

  gameLoop(currentTime) {
    if (!this.gameState.running) return;

    this.deltaTime = currentTime - this.lastTime;
    this.lastTime = currentTime;
    
    if (!this.gameState.paused) {
      this.accumulator += this.deltaTime;
      
      while (this.accumulator >= this.timeStep) {
        this.update(this.timeStep);
        this.accumulator -= this.timeStep;
      }
      
      this.render();
    }

    requestAnimationFrame((timestamp) => this.gameLoop(timestamp));
  }

  update(deltaTime) {
    // Update all game systems
    for (const system of this.systems.values()) {
      system.update(deltaTime);
    }
    
    // Update combat animations
    if (this.systems.get('combat').isInCombat) {
      this.systems.get('combat').updateAnimations(deltaTime);
    }
    
    // Check for auto-save
    this.saveSystem.autoSave();
  }

  render() {
    if (this.gameState.currentScene) {
      this.gameState.currentScene.render();
    }
  }

  changeScene(newScene) {
    if (this.gameState.currentScene) {
      this.gameState.currentScene.exit();
    }
    this.gameState.currentScene = newScene;
    newScene.enter();
  }

  // State Management
  saveGameState() {
    const saveData = {
      player: this.systems.get('player').getSaveData(),
      inventory: this.systems.get('inventory').getSaveData(),
      quests: this.systems.get('quest').getSaveData(),
      timestamp: Date.now()
    };
    
    localStorage.setItem('gameState', JSON.stringify(saveData));
  }

  loadGameState() {
    const savedData = localStorage.getItem('gameState');
    if (savedData) {
      const gameData = JSON.parse(savedData);
      this.systems.get('player').loadSaveData(gameData.player);
      this.systems.get('inventory').loadSaveData(gameData.inventory);
      this.systems.get('quest').loadSaveData(gameData.quests);
    }
  }

  // Event System
  addEventListener(eventName, callback) {
    document.addEventListener(eventName, callback);
  }

  removeEventListener(eventName, callback) {
    document.removeEventListener(eventName, callback);
  }

  dispatchEvent(eventName, detail = {}) {
    const event = new CustomEvent(eventName, { detail });
    document.dispatchEvent(event);
  }
}

class Scene {
  constructor(engine) {
    this.engine = engine;
  }

  enter() {
    // Initialize scene
  }

  exit() {
    // Cleanup scene
  }

  update(deltaTime) {
    // Update scene logic
  }

  render() {
    // Render scene
  }
}

// Make Scene globally available
window.Scene = Scene;