
export class NemesisSystem {
  constructor() {
    this.nemeses = new Map();
    this.traits = [
      'Vengeful', 'Ambitious', 'Cunning', 'Brutal', 'Strategic',
      'Defensive', 'Aggressive', 'Tactical', 'Adaptive', 'Relentless'
    ];
    this.powers = [
      'Regeneration', 'Power Steal', 'Minion Control', 'Elemental Mastery',
      'Shadow Strike', 'Berserker Rage', 'Life Drain', 'Time Manipulation'
    ];
  }

  generateNemesis(playerLevel, defeatedBy = null) {
    const nemesis = {
      id: crypto.randomUUID(),
      level: playerLevel + Math.floor(Math.random() * 5),
      power: Math.floor(Math.random() * 100) + 50,
      traits: this.getRandomTraits(2),
      abilities: this.getRandomPowers(2),
      victories: 0,
      defeats: 0,
      nemesisLevel: 1,
      adaptations: [],
      defeatedBy: defeatedBy,
      revenge: defeatedBy ? true : false
    };

    this.nemeses.set(nemesis.id, nemesis);
    return nemesis;
  }

  getRandomTraits(count) {
    return this.shuffleArray([...this.traits]).slice(0, count);
  }

  getRandomPowers(count) {
    return this.shuffleArray([...this.powers]).slice(0, count);
  }

  evolveNemesis(nemesisId, playerActions) {
    const nemesis = this.nemeses.get(nemesisId);
    if (!nemesis) return null;

    if (playerActions.includes('magic')) {
      nemesis.adaptations.push('Magic Resistance');
    }
    if (playerActions.includes('physical')) {
      nemesis.adaptations.push('Physical Defense');
    }

    nemesis.nemesisLevel++;
    nemesis.power += 25;

    if (nemesis.defeats > 0) {
      nemesis.abilities.push(this.getRandomPowers(1)[0]);
    }
    return nemesis;
  }

  shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
}

export class NPCController {
  constructor() {
    this.personalities = ['Aggressive', 'Defensive', 'Balanced', 'Opportunist'];
  }
}
