
export class SkillsPage {
  constructor() {
    this.skills = [];
  }

  render() {
    const skillsSection = document.getElementById('skills');
    if (skillsSection) {
      skillsSection.innerHTML = `
        <h2>Skills</h2>
        <div class="skills-grid">
          ${this.skills.map(skill => `
            <div class="skill-item">
              <h3>${skill.name}</h3>
              <div class="skill-level">Level ${skill.level}</div>
            </div>
          `).join('')}
        </div>
      `;
    }
  }
}
