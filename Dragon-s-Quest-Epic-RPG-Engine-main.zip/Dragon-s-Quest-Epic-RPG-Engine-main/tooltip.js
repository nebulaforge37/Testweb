
export class TooltipSystem {
  constructor() {
    this.tooltip = document.createElement('div');
    this.tooltip.className = 'tooltip';
    document.body.appendChild(this.tooltip);
    this.initializeEventListeners();
  }

  initializeEventListeners() {
    document.addEventListener('mouseover', (e) => {
      const tooltipData = e.target.dataset.tooltip;
      if (tooltipData) {
        this.show(tooltipData, e);
      }
    });

    document.addEventListener('mouseout', (e) => {
      if (e.target.dataset.tooltip) {
        this.hide();
      }
    });

    document.addEventListener('mousemove', (e) => {
      if (this.tooltip.style.display === 'block') {
        this.position(e);
      }
    });
  }

  show(content, event) {
    this.tooltip.innerHTML = content;
    this.tooltip.style.display = 'block';
    this.position(event);
  }

  hide() {
    this.tooltip.style.display = 'none';
  }

  position(event) {
    const margin = 15;
    let x = event.pageX + margin;
    let y = event.pageY + margin;
    
    const tooltipRect = this.tooltip.getBoundingClientRect();
    const rightEdge = window.innerWidth - tooltipRect.width - margin;
    const bottomEdge = window.innerHeight - tooltipRect.height - margin;
    
    if (x > rightEdge) x = rightEdge;
    if (y > bottomEdge) y = bottomEdge;
    
    this.tooltip.style.left = x + 'px';
    this.tooltip.style.top = y + 'px';
  }
}

// Export a default instance
export const tooltipSystem = new TooltipSystem();
