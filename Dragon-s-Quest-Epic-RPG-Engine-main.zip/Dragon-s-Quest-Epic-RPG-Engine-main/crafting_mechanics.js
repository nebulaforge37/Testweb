
class BlacksmithingSystem {
  constructor() {
    this.masterworkLevels = ['Basic', 'Superior', 'Exquisite', 'Masterwork', 'Legendary'];
    this.temperingLevels = ['Tempered', 'Improved', 'Refined', 'Perfect'];
  }

  getMasterworkBonus(level) {
    const bonuses = {
      'Basic': 0,
      'Superior': 15,
      'Exquisite': 30,
      'Masterwork': 50,
      'Legendary': 75
    };
    return bonuses[level] || 0;
  }

  getTemperingBonus(level) {
    const bonuses = {
      'Tempered': 10,
      'Improved': 25,
      'Refined': 45,
      'Perfect': 70
    };
    return bonuses[level] || 0;
  }

  craftMasterwork(item, level, craftingMaterials) {
    if (!this.masterworkLevels.includes(level)) return null;
    
    const bonus = this.getMasterworkBonus(level);
    return {
      ...item,
      name: `${level} ${item.name}`,
      quality: level,
      damageBonus: bonus,
      armorBonus: bonus,
      requiredMaterials: this.calculateMaterials(level)
    };
  }

  temperItem(item, level, temperingMaterials) {
    if (!this.temperingLevels.includes(level)) return null;
    
    const bonus = this.getTemperingBonus(level);
    return {
      ...item,
      name: `${item.name} (${level})`,
      temperLevel: level,
      damageBonus: (item.damageBonus || 0) + bonus,
      armorBonus: (item.armorBonus || 0) + bonus,
      requiredMaterials: this.calculateTemperingMaterials(level)
    };
  }

  calculateMaterials(level) {
    const baseRequirements = {
      'Basic': { metal: 5, coal: 2 },
      'Superior': { metal: 10, coal: 4, gem: 1 },
      'Exquisite': { metal: 20, coal: 8, gem: 2, crystals: 1 },
      'Masterwork': { metal: 35, coal: 15, gem: 4, crystals: 2 },
      'Legendary': { metal: 50, coal: 25, gem: 8, crystals: 4, legendaryCore: 1 }
    };
    return baseRequirements[level];
  }

  calculateTemperingMaterials(level) {
    const baseRequirements = {
      'Tempered': { metal: 3, coal: 1 },
      'Improved': { metal: 8, coal: 3, crystal: 1 },
      'Refined': { metal: 15, coal: 6, crystal: 2 },
      'Perfect': { metal: 25, coal: 10, crystal: 4, perfectCore: 1 }
    };
    return baseRequirements[level];
  }
}

export default BlacksmithingSystem;
