
const Database = {
  // Initialize database with default values if empty
  init() {
    if (!db.get("users")) {
      db.set("users", {});
    }
    if (!db.get("items")) {
      db.set("items", {});
    }
  },

  // User methods
  createUser(username, password) {
    const users = db.get("users");
    if (users[username]) {
      return false;
    }
    users[username] = {
      password: password,
      inventory: [],
      gold: 0,
      level: 1,
      exp: 0
    };
    db.set("users", users);
    return true;
  },

  getUser(username) {
    const users = db.get("users");
    return users[username];
  },

  updateUser(username, data) {
    const users = db.get("users");
    users[username] = {...users[username], ...data};
    db.set("users", users);
  },

  // Item methods
  addItem(itemId, itemData) {
    const items = db.get("items");
    items[itemId] = itemData;
    db.set("items", items);
  },

  getItem(itemId) {
    const items = db.get("items");
    return items[itemId];
  },

  giveItemToUser(username, itemId) {
    const users = db.get("users");
    if (!users[username]) return false;
    users[username].inventory.push(itemId);
    db.set("users", users);
    return true;
  }
};

const database = Database;
