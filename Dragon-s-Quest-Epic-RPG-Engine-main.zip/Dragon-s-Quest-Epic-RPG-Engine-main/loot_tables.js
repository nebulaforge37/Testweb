
const LootTables = {
  // Monster Loot Tables
  monsters: {
    common: {
      items: [
        { id: 'copper_coin', chance: 0.8, quantity: { min: 1, max: 10 } },
        { id: 'leather_scrap', chance: 0.6, quantity: { min: 1, max: 3 } },
        { id: 'broken_sword', chance: 0.3, quantity: { min: 1, max: 1 } }
      ]
    },
    elite: {
      items: [
        { id: 'silver_coin', chance: 0.9, quantity: { min: 5, max: 15 } },
        { id: 'magic_essence', chance: 0.5, quantity: { min: 1, max: 3 } },
        { id: 'rare_gem', chance: 0.2, quantity: { min: 1, max: 2 } }
      ]
    },
    boss: {
      items: [
        { id: 'gold_coin', chance: 1.0, quantity: { min: 20, max: 50 } },
        { id: 'epic_weapon', chance: 0.4, quantity: { min: 1, max: 1 } },
        { id: 'legendary_material', chance: 0.15, quantity: { min: 1, max: 1 } }
      ]
    }
  },

  // Chest Loot Tables
  chests: {
    wooden: {
      items: [
        { id: 'silver_coin', chance: 0.9, quantity: { min: 10, max: 20 } },
        { id: 'health_potion', chance: 0.7, quantity: { min: 1, max: 3 } },
        { id: 'crafting_material', chance: 0.5, quantity: { min: 2, max: 5 } }
      ]
    },
    golden: {
      items: [
        { id: 'gold_coin', chance: 1.0, quantity: { min: 50, max: 100 } },
        { id: 'rare_equipment', chance: 0.6, quantity: { min: 1, max: 1 } },
        { id: 'epic_gem', chance: 0.3, quantity: { min: 1, max: 2 } }
      ]
    }
  },

  // Dungeon End Rewards
  dungeonRewards: {
    normal: {
      items: [
        { id: 'dungeon_token', chance: 1.0, quantity: { min: 5, max: 10 } },
        { id: 'rare_equipment', chance: 0.8, quantity: { min: 1, max: 2 } },
        { id: 'enchantment_scroll', chance: 0.4, quantity: { min: 1, max: 1 } }
      ]
    },
    mythic: {
      items: [
        { id: 'mythic_token', chance: 1.0, quantity: { min: 10, max: 20 } },
        { id: 'legendary_equipment', chance: 0.5, quantity: { min: 1, max: 1 } },
        { id: 'ancient_relic', chance: 0.2, quantity: { min: 1, max: 1 } }
      ]
    }
  }
};

class LootSystem {
  static rollLoot(table) {
    const loot = [];
    table.items.forEach(item => {
      if (Math.random() <= item.chance) {
        const quantity = Math.floor(
          Math.random() * (item.quantity.max - item.quantity.min + 1) + 
          item.quantity.min
        );
        loot.push({
          id: item.id,
          quantity: quantity
        });
      }
    });
    return loot;
  }

  static getMonsterLoot(type) {
    return this.rollLoot(LootTables.monsters[type]);
  }

  static getChestLoot(type) {
    return this.rollLoot(LootTables.chests[type]);
  }

  static getDungeonReward(type) {
    return this.rollLoot(LootTables.dungeonRewards[type]);
  }
}

export { LootSystem, LootTables };
