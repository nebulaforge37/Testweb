
# Dragon's Quest UML Design Documentation

## Class Diagram

```plantuml
@startuml DragonQuest

class Game {
  - worldSeed: number
  - settings: object
  - player: Player
  - gameData: GameData
  + constructor()
  + initializeData()
  + newGame()
  + loadGame()
  + saveGame()
  + updateStats()
  + showScreen()
}

class Player {
  - hp: number
  - maxHp: number
  - level: number
  - position: Position
  - exp: number
  - inventory: Item[][]
  - equipment: Equipment
  - attributes: Attributes
  + gainExp()
  + levelUp()
  + attack()
  + equip()
  + unequip()
}

class GameData {
  - currentZone: string
  - difficulty: number
  - enemies: Enemy[]
  - currentEnemy: Enemy
  - activeQuests: Quest[]
  - completedQuests: Quest[]
}

class Combat {
  - player: Player
  - enemy: Enemy
  + calculateDamage()
  + applyDamage()
  + checkCritical()
  + calculateDodge()
}

class DungeonSystem {
  - floors: number
  - difficulty: number
  - currentFloor: number
  + generateLayout()
  + spawnEnemies()
  + generateLoot()
}

class QuestSystem {
  - types: string[]
  - classes: string[]
  - quests: Quest[]
  + acceptQuest()
  + completeQuest()
  + updateProgress()
}

class GuildSystem {
  - name: string
  - members: Player[]
  - ranks: string[]
  - missions: Mission[]
  + joinGuild()
  + leaveGuild()
  + promoteMember()
}

class NemesisSystem {
  - active: Nemesis[]
  - defeated: Nemesis[]
  - maxActive: number
  + generateNemesis()
  + evolveNemesis()
  + defeatNemesis()
}

class CraftingSystem {
  - recipes: Recipe[]
  - professions: Profession[]
  + craft()
  + learnRecipe()
  + gainProfessionExp()
}

Game *-- Player
Game *-- GameData
Game *-- Combat
Game *-- DungeonSystem
Game *-- QuestSystem
Game *-- GuildSystem
Game *-- NemesisSystem
Game *-- CraftingSystem

@enduml
```

## Component Diagram

```plantuml
@startuml DragonQuestComponents

package "Core Systems" {
  [Game Engine]
  [Save System]
  [Event Handler]
}

package "Player Systems" {
  [Character Management]
  [Inventory System]
  [Equipment System]
  [Skill System]
}

package "World Systems" {
  [Zone Manager]
  [Weather System]
  [NPC System]
  [Resource System]
}

package "Combat Systems" {
  [Combat Engine]
  [Damage Calculator]
  [AI System]
  [Spell System]
}

package "Content Systems" {
  [Quest Manager]
  [Dungeon Generator]
  [Nemesis Manager]
  [World Boss System]
}

[Game Engine] --> [Character Management]
[Game Engine] --> [Combat Engine]
[Game Engine] --> [Zone Manager]
[Game Engine] --> [Quest Manager]

[Character Management] --> [Inventory System]
[Character Management] --> [Equipment System]
[Character Management] --> [Skill System]

[Combat Engine] --> [Damage Calculator]
[Combat Engine] --> [AI System]
[Combat Engine] --> [Spell System]

[Zone Manager] --> [Weather System]
[Zone Manager] --> [NPC System]
[Zone Manager] --> [Resource System]

[Quest Manager] --> [Dungeon Generator]
[Quest Manager] --> [Nemesis Manager]
[Quest Manager] --> [World Boss System]

@enduml
```

## Sequence Diagram (Combat)

```plantuml
@startuml DragonQuestCombat

actor Player
participant "Game Engine" as Game
participant "Combat System" as Combat
participant "Enemy AI" as AI
participant "Damage Calculator" as Damage

Player -> Game: Initiate Combat
Game -> Combat: Start Combat
activate Combat

loop Combat Round
    Player -> Combat: Select Action
    Combat -> AI: Get Enemy Response
    AI --> Combat: Enemy Action
    Combat -> Damage: Calculate Damage
    Damage --> Combat: Damage Result
    Combat -> Game: Update Game State
    Game --> Player: Display Results
end

Combat -> Game: End Combat
deactivate Combat
Game --> Player: Show Results

@enduml
```
