// Dungeons, Raids, and Trials Data
const GameInstances = {
  dungeons: {
    'Endless Labyrinth': {
      level: 20,
      type: 'Labyrinth',
      generator: (seed) => new LabyrinthDungeon(seed).generate(),
      boss: 'Minotaur King',
      loot: ['Maze Map', 'Thread of Ariadne'],
      minPlayers: 3,
      maxPlayers: 5,
      roles: {
        tank: 1,
        healer: 1,
        dps: 3
      }
    }
  }
};

// Make it globally available
window.GameInstances = GameInstances;