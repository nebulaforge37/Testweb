
const VERSION_INFO = {
  version: '1.0.0',
  buildNumber: '001',
  lastUpdated: '2024-01-20',
  features: {
    combat: '1.0.0',
    inventory: '1.0.0',
    quests: '1.0.0',
    dungeons: '1.0.0',
    guilds: '1.0.0',
    crafting: '1.0.0',
    codex: '1.0.0',
    paragon: '1.0.0'
  },
  changelog: [
    {
      version: '1.0.0',
      date: '2024-01-20',
      changes: [
        'Initial release',
        'Combat system implementation',
        'Inventory system',
        'Basic questing',
        'Dungeon system',
        'Guild system',
        'Crafting mechanics',
        'Codex implementation',
        'Paragon levels'
      ]
    }
  ]
};

export { VERSION_INFO };
