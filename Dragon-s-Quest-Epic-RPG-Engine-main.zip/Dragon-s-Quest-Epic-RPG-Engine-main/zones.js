
// Zone Definitions for all continents
const Buildings = {
  temples: {
    'Temple of Light': { 
      level: 20, 
      type: 'Holy',
      rewards: ['Light Blessing', 'Holy Relic'],
      guardians: ['Light Priest', 'Solar Knight'],
      puzzles: ['Light Beam Puzzle', 'Star Alignment']
    },
    'Dark Sanctuary': { 
      level: 35, 
      type: 'Shadow',
      rewards: ['Shadow Mark', 'Void Stone'],
      guardians: ['Shadow Priest', 'Void Walker'],
      puzzles: ['Shadow Path', 'Dark Ritual']
    },
    'Nature\'s Shrine': { 
      level: 25, 
      type: 'Nature',
      rewards: ['Nature\'s Blessing', 'Druid Staff'],
      guardians: ['Elder Druid', 'Beast Master'],
      puzzles: ['Growth Pattern', 'Animal Tribute']
    }
  },
  
  structures: {
    'Ancient Library': {
      level: 15,
      type: 'Knowledge',
      loot: ['Ancient Scrolls', 'Forgotten Tomes'],
      requires: ['Reading Glasses', 'Translation Stone']
    },
    'Blacksmith\'s Forge': {
      level: 10,
      type: 'Crafting',
      services: ['Weapon Repair', 'Armor Crafting'],
      requires: ['Smithing Hammer', 'Coal']
    },
    'Mage Tower': {
      level: 30,
      type: 'Arcane',
      services: ['Spell Learning', 'Enchanting'],
      requires: ['Magic Staff', 'Mana Crystal']
    }
  }
};

const GameZones = {
  // Aethoria (Natural/Peaceful)
  'Crystal Gardens': { level: 1, type: 'Peaceful', resources: ['Crystal Shards', 'Luminous Flowers'] },
  'Whispering Woods': { level: 3, type: 'Forest', resources: ['Ancient Wood', 'Magic Herbs'] },
  'Rainbow Valley': { level: 5, type: 'Valley', resources: ['Prismatic Ore', 'Rainbow Flowers'] },
  'Cloud Haven': { level: 8, type: 'Sky', resources: ['Cloud Essence', 'Sky Crystals'] },
  
  // Shadowrealm (Dark/Dangerous)
  'Nightmare Peaks': { level: 20, type: 'Mountain', resources: ['Shadow Ore', 'Dark Crystals'] },
  'Haunted Hollows': { level: 23, type: 'Undead', resources: ['Ghost Essence', 'Cursed Bones'] },
  'Dark Abyss': { level: 25, type: 'Void', resources: ['Void Matter', 'Abyss Crystals'] },
  
  // Celestia (Divine/Holy)
  'Heavenly Fields': { level: 40, type: 'Holy', resources: ['Sacred Ore', 'Divine Crystals'] },
  'Angel\'s Rest': { level: 43, type: 'Sacred', resources: ['Holy Essence', 'Blessed Metal'] },
  'Star Plains': { level: 45, type: 'Astral', resources: ['Star Dust', 'Cosmic Ore'] },
  
  // Kingdom Strongholds
  'Royal Castle': { level: 35, type: 'Castle', resources: ['Royal Steel', 'Noble Gems'] },
  'Northern Fort': { level: 25, type: 'Fort', resources: ['Military Steel', 'Stone Blocks'] },
  'Eastern Citadel': { level: 40, type: 'Castle', resources: ['Castle Iron', 'Ancient Artifacts'] },
  'Western Fortress': { level: 30, type: 'Fort', resources: ['Fortified Steel', 'Garrison Supplies'] },
  
  // Underworld Realm (Dark/Infernal)
  'Stygian Depths': { level: 60, type: 'Infernal', resources: ['Soul Essence', 'Hellfire Gems'] },
  'Bone Catacombs': { level: 63, type: 'Necropolis', resources: ['Ancient Bones', 'Death Crystals'] },
  'Infernal Forge': { level: 65, type: 'Forge', resources: ['Hellsteel', 'Demon Crystal'] },
  'Soul Sanctum': { level: 68, type: 'Ethereal', resources: ['Lost Souls', 'Spirit Shards'] },
  'Demon\'s Market': { level: 70, type: 'Settlement', resources: ['Demon Gold', 'Chaos Stones'] },
  'Void Pits': { level: 73, type: 'Void', resources: ['Void Matter', 'Null Crystals'] }
};

// Crafting Blueprints
const CraftingBlueprints = {
  weapons: {
    'Novice Sword': {
      materials: { 'Iron Ingot': 2, 'Wood': 1 },
      level: 1,
      type: 'Sword',
      damage: 10
    },
    'Crystal Staff': {
      materials: { 'Magic Wood': 1, 'Crystal Shard': 3 },
      level: 5,
      type: 'Staff',
      damage: 15
    },
    // More weapons...
  },
  armor: {
    'Leather Vest': {
      materials: { 'Leather': 3, 'Thread': 2 },
      level: 1,
      type: 'Light Armor',
      defense: 5
    },
    'Iron Platemail': {
      materials: { 'Iron Ingot': 5, 'Leather': 2 },
      level: 5,
      type: 'Heavy Armor',
      defense: 15
    }
    // More armor...
  }
};

// Vendor Definitions
const Vendors = {
  'Blacksmith': {
    location: 'Crystal Gardens',
    inventory: ['Iron Sword', 'Steel Dagger', 'Bronze Shield'],
    crafting: ['Basic Weapons', 'Simple Armor'],
    prices: {
      'Iron Sword': 100,
      'Steel Dagger': 150,
      'Bronze Shield': 200
    }
  },
  'Alchemist': {
    location: 'Whispering Woods',
    inventory: ['Health Potion', 'Mana Potion', 'Strength Elixir'],
    crafting: ['Basic Potions', 'Elixirs'],
    prices: {
      'Health Potion': 50,
      'Mana Potion': 75,
      'Strength Elixir': 100
    }
  },
  'Enchanter': {
    location: 'Rainbow Valley',
    inventory: ['Magic Scroll', 'Enchanted Gem', 'Mystic Dust'],
    crafting: ['Basic Enchantments', 'Magical Items'],
    prices: {
      'Magic Scroll': 200,
      'Enchanted Gem': 300,
      'Mystic Dust': 150
    }
  }
};

export { GameZones, CraftingBlueprints, Vendors, Buildings };
