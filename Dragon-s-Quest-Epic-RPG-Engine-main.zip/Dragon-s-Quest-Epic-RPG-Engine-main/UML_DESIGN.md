
# Dragon's Quest UML Game Design Document

## Core Systems Architecture

```plantuml
@startuml DragonQuestCore

package "Core Engine" {
  class GameEngine {
    - worldTier: number
    - season: Season
    - calendar: Calendar
    + initializeSystems()
    + update()
    + render()
  }
}

package "Character System" {
  class Character {
    - level: number
    - class: CharacterClass
    - stats: Stats
    - talents: Talent[]
    - loadout: Loadout
    - wardrobe: Wardrobe
  }

  class CharacterClass {
    - type: string
    - spells: Spell[]
    - abilities: Ability[]
  }

  class Inventory {
    - size: number
    - grid: Item[][]
    + addItem()
    + removeItem()
  }
}

package "Combat System" {
  class CombatManager {
    + processTurn()
    + calculateDamage()
  }

  class Enemy {
    - type: string
    - level: number
    - abilities: Ability[]
  }

  class Boss extends Enemy {
    - phases: Phase[]
    - specialAbilities: Ability[]
  }

  class Champion extends Enemy {
    - bonuses: Bonus[]
    - uniqueTraits: Trait[]
  }
}

package "World System" {
  class WorldManager {
    - currentTier: number
    - zones: Zone[]
    - season: Season
    - calendar: Calendar
  }

  class Zone {
    - level: number
    - type: string
    - monsters: Monster[]
    - shops: Shop[]
  }

  class UnderWorldZone extends Zone {
    - corruption: number
    - specialEncounters: Encounter[]
  }
}

package "Crafting System" {
  class CraftingSystem {
    - blueprints: Blueprint[]
    - materials: Material[]
    + craft()
    + temper()
  }

  class Blacksmith {
    - masterworkLevels: string[]
    - temperingLevels: string[]
    + craftMasterwork()
    + temperItem()
  }

  class Enchanting {
    - gems: Gem[]
    - runes: Rune[]
    - relics: Relic[]
    + enchantItem()
    + socketGem()
  }
}

package "Time System" {
  class Calendar {
    - year: number
    - month: number
    - day: number
    + advanceTime()
  }

  class Season {
    - type: SeasonType
    - effects: Effect[]
    + applySeasonalEffects()
  }
}

GameEngine *-- WorldManager
GameEngine *-- CombatManager
GameEngine *-- CraftingSystem
Character --> CharacterClass
Character *-- Inventory
WorldManager *-- Zone
WorldManager *-- Calendar
CraftingSystem *-- Blacksmith
CraftingSystem *-- Enchanting

@enduml
```

## State Machine Diagrams

```plantuml
@startuml GameStateMachine

[*] --> MainMenu
MainMenu --> WorldExploration: Start Game
WorldExploration --> Combat: Enemy Encounter
WorldExploration --> Shop: Enter Shop
WorldExploration --> Crafting: Open Crafting
WorldExploration --> Inventory: Open Inventory
Combat --> WorldExploration: Combat End
Shop --> WorldExploration: Exit Shop
Crafting --> WorldExploration: Exit Crafting
Inventory --> WorldExploration: Close Inventory

@enduml
```

## Data Flow Diagram

```plantuml
@startuml DataFlow

database "GameState" {
  [PlayerData]
  [WorldData]
  [InventoryData]
  [QuestData]
}

[Player Input] --> [Game Engine]
[Game Engine] --> [Systems]
[Systems] --> [GameState]

package "Core Systems" {
  [Combat System]
  [Crafting System]
  [World System]
  [Time System]
}

[Game Engine] --> [Combat System]
[Game Engine] --> [Crafting System]
[Game Engine] --> [World System]
[Game Engine] --> [Time System]

[GameState] --> [Save System]

@enduml
```
