
export class WildlifeAI {
  constructor() {
    this.behaviors = {
      'peaceful': {
        fleeDistance: 5,
        wanderRadius: 10,
        aggressionLevel: 0
      },
      'neutral': {
        fleeDistance: 3,
        wanderRadius: 15,
        aggressionLevel: 0.3
      },
      'aggressive': {
        fleeDistance: 2,
        wanderRadius: 20,
        aggressionLevel: 0.8
      }
    };
  }

  updateAnimal(animal, playerPosition, deltaTime) {
    const behavior = this.behaviors[animal.behavior];
    const distanceToPlayer = this.calculateDistance(animal.position, playerPosition);

    if (distanceToPlayer < behavior.fleeDistance && behavior.aggressionLevel < 0.5) {
      return this.flee(animal, playerPosition);
    } else if (distanceToPlayer < behavior.fleeDistance && behavior.aggressionLevel >= 0.5) {
      return this.attack(animal, playerPosition);
    } else {
      return this.wander(animal, behavior.wanderRadius, deltaTime);
    }
  }

  calculateDistance(pos1, pos2) {
    return Math.sqrt(Math.pow(pos2.x - pos1.x, 2) + Math.pow(pos2.y - pos1.y, 2));
  }

  flee(animal, playerPosition) {
    const angle = Math.atan2(animal.position.y - playerPosition.y, animal.position.x - playerPosition.x);
    return {
      x: Math.cos(angle) * animal.speed,
      y: Math.sin(angle) * animal.speed
    };
  }

  attack(animal, playerPosition) {
    const angle = Math.atan2(playerPosition.y - animal.position.y, playerPosition.x - animal.position.x);
    return {
      x: Math.cos(angle) * animal.speed,
      y: Math.sin(angle) * animal.speed
    };
  }

  wander(animal, radius, deltaTime) {
    animal.wanderAngle = (animal.wanderAngle || 0) + (Math.random() - 0.5) * 0.5 * deltaTime;
    return {
      x: Math.cos(animal.wanderAngle) * animal.speed,
      y: Math.sin(animal.wanderAngle) * animal.speed
    };
  }
}
