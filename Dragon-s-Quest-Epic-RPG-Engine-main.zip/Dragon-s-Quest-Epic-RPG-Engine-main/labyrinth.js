
class LabyrinthDungeon {
  constructor(seed, size = 32) {
    this.seed = seed;
    this.size = size;
    this.grid = Array(size).fill().map(() => Array(size).fill(1));
    this.rooms = [];
  }

  // Seeded random number generator
  random() {
    this.seed = (this.seed * 9301 + 49297) % 233280;
    return this.seed / 233280;
  }

  generate() {
    // Start from center
    const start = Math.floor(this.size / 2);
    this.carve(start, start);
    this.addRooms();
    return {
      layout: this.grid,
      rooms: this.rooms,
      start: { x: start, y: start }
    };
  }

  carve(x, y) {
    this.grid[y][x] = 0;
    const directions = [[0, -2], [2, 0], [0, 2], [-2, 0]];
    
    // Shuffle directions randomly using seed
    for(let i = directions.length - 1; i > 0; i--) {
      const j = Math.floor(this.random() * (i + 1));
      [directions[i], directions[j]] = [directions[j], directions[i]];
    }

    // Try each direction
    directions.forEach(([dx, dy]) => {
      const newX = x + dx;
      const newY = y + dy;
      
      if(newX > 0 && newX < this.size - 1 && 
         newY > 0 && newY < this.size - 1 && 
         this.grid[newY][newX] === 1) {
        // Carve passage
        this.grid[y + dy/2][x + dx/2] = 0;
        this.carve(newX, newY);
      }
    });
  }

  addRooms() {
    const roomCount = Math.floor(this.size / 4);
    for(let i = 0; i < roomCount; i++) {
      const roomSize = Math.floor(this.random() * 3) + 3;
      const x = Math.floor(this.random() * (this.size - roomSize - 2)) + 1;
      const y = Math.floor(this.random() * (this.size - roomSize - 2)) + 1;
      
      if(this.canPlaceRoom(x, y, roomSize)) {
        this.placeRoom(x, y, roomSize);
        this.rooms.push({x, y, size: roomSize});
      }
    }
  }

  canPlaceRoom(x, y, size) {
    for(let dy = -1; dy <= size + 1; dy++) {
      for(let dx = -1; dx <= size + 1; dx++) {
        if(this.grid[y + dy] && this.grid[y + dy][x + dx] === 0) {
          return false;
        }
      }
    }
    return true;
  }

  placeRoom(x, y, size) {
    for(let dy = 0; dy < size; dy++) {
      for(let dx = 0; dx < size; dx++) {
        this.grid[y + dy][x + dx] = 0;
      }
    }
    // Connect room to maze
    const doorX = x + Math.floor(this.random() * size);
    const doorY = y + Math.floor(this.random() * size);
    this.connectRoomToMaze(doorX, doorY);
  }

  connectRoomToMaze(x, y) {
    const directions = [[0, -1], [1, 0], [0, 1], [-1, 0]];
    for(const [dx, dy] of directions) {
      let currX = x + dx;
      let currY = y + dy;
      while(this.grid[currY] && this.grid[currY][currX] === 1) {
        this.grid[currY][currX] = 0;
        currX += dx;
        currY += dy;
        if(this.grid[currY] && this.grid[currY][currX] === 0) break;
      }
    }
  }
}

export { LabyrinthDungeon };
