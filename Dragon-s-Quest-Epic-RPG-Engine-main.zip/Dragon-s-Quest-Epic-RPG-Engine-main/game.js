
import { Elements } from './elements.js';
import { DebugOverlay } from './debug.js';
import { WildlifeAI } from './wildlife.js';
import { TooltipSystem } from './tooltip.js';
import { ConfigEngine } from './config.js';
import { NemesisSystem } from './nemesis.js';
import { Party } from './party.js';

export class Game {
    constructor() {
        this.currentScreen = 'titleScreen';
        this.initialized = false;
        this.elements = Elements;
        this.debug = new DebugOverlay(this);
        this.wildlifeAI = new WildlifeAI();
        this.tooltipSystem = new TooltipSystem();
        this.config = new ConfigEngine();
        this.nemesisSystem = new NemesisSystem();
        this.partySystem = new Party();
        this.currentSection = 'mainMenu';
        this.pages = new Map();
    }

    initialize() {
        if (this.initialized) return;
        this.initialized = true;
        this.initializePages();
        this.initializeEventListeners();
        console.log('Game initialized');
    }

    showLoadingScreen() {
        document.getElementById('loadingScreen')?.classList.remove('hidden');
    }

    startGame() {
        document.getElementById('loadingScreen')?.classList.add('hidden');
        document.getElementById('gameScreen')?.classList.remove('hidden');
    }

    showAbout() {
        document.getElementById('aboutScreen')?.classList.remove('hidden');
    }

    hideAbout() {
        document.getElementById('aboutScreen')?.classList.add('hidden');
    }

    initializeEventListeners() {
        document.querySelectorAll('[data-section]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.getAttribute('data-section');
                if (section) {
                    this.showPage(section);
                }
            });
        });
    }

    showPage(section) {
        console.log(`Showing page: ${section}`);
    }

    initializePages() {
        console.log("Initializing Pages");
    }
}

// Initialize game instance globally
window.game = new Game();
