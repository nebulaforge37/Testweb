
class Codex {
  constructor() {
    this.categories = {
      enemies: new Map(),
      items: new Map(),
      lore: new Map(),
      locations: new Map(),
      dungeons: new Map()
    };
    this.initializeCodex();
  }

  initializeCodex() {
    // Enemies
    this.addEnemy('demon_imp', {
      name: 'Demon Imp',
      type: 'Demon',
      difficulty: 'Normal',
      rewards: ['Demon Blood', 'Soul Shard'],
      description: 'Small winged demons that attack in swarms.',
      abilities: ['Fireball', 'Quick Flight'],
      weaknesses: ['Holy', 'Ice']
    });

    // Items
    this.addItem('excalibur', {
      name: 'Excalibur',
      type: 'Legendary Sword',
      properties: ['Holy', 'Legendary'],
      lore: 'The legendary sword of king Arthur.',
      acquisition: 'Drops from Dragon Lords'
    });

    // Locations
    this.addLocation('demons_market', {
      name: "Demon's Market",
      type: 'Settlement',
      level: 70,
      resources: ['Demon Gold', 'Chaos Stones'],
      description: 'A dark marketplace where demons trade cursed artifacts.'
    });
  }

  addEnemy(id, data) {
    this.categories.enemies.set(id, {
      discovered: false,
      killCount: 0,
      ...data
    });
  }

  addItem(id, data) {
    this.categories.items.set(id, {
      discovered: false,
      ...data
    });
  }

  addLocation(id, data) {
    this.categories.locations.set(id, {
      discovered: false,
      ...data
    });
  }

  discoverEnemy(id) {
    const enemy = this.categories.enemies.get(id);
    if (enemy) {
      enemy.discovered = true;
    }
  }

  discoverItem(id) {
    const item = this.categories.items.get(id);
    if (item) {
      item.discovered = true;
    }
  }

  discoverLocation(id) {
    const location = this.categories.locations.get(id);
    if (location) {
      location.discovered = true;
    }
  }

  incrementKillCount(id) {
    const enemy = this.categories.enemies.get(id);
    if (enemy) {
      enemy.killCount++;
    }
  }

  getDiscoveredItems() {
    return Array.from(this.categories.items.entries())
      .filter(([_, item]) => item.discovered);
  }

  getDiscoveredEnemies() {
    return Array.from(this.categories.enemies.entries())
      .filter(([_, enemy]) => enemy.discovered);
  }

  getDiscoveredLocations() {
    return Array.from(this.categories.locations.entries())
      .filter(([_, location]) => location.discovered);
  }
}

export default Codex;
