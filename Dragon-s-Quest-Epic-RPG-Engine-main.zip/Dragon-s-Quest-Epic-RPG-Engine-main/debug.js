
export class DebugOverlay {
    constructor(game) {
        this.game = game;
        this.visible = false;
        this.fpsArray = [];
        this.lastTime = performance.now();
        this.initializeOverlay();
    }

    initializeOverlay() {
        this.overlay = document.createElement('div');
        this.overlay.className = 'debug-overlay hidden';
        this.overlay.innerHTML = `
            <div class="debug-section">
                <h3>Performance</h3>
                <p>FPS: <span id="debug-fps">0</span></p>
                <p>Memory: <span id="debug-memory">0</span> MB</p>
            </div>
            <div class="debug-section">
                <h3>Game State</h3>
                <p>Current Scene: <span id="debug-scene">-</span></p>
                <p>Active Entities: <span id="debug-entities">0</span></p>
            </div>
        `;
        document.body.appendChild(this.overlay);
    }

    toggle() {
        this.visible = !this.visible;
        this.overlay.classList.toggle('hidden');
    }

    update() {
        if (!this.visible) return;

        const currentTime = performance.now();
        const deltaTime = currentTime - this.lastTime;
        this.lastTime = currentTime;

        const fps = 1000 / deltaTime;
        this.fpsArray.push(fps);
        if (this.fpsArray.length > 60) this.fpsArray.shift();
        const averageFps = Math.round(this.fpsArray.reduce((a, b) => a + b) / this.fpsArray.length);
        
        document.getElementById('debug-fps').textContent = averageFps;
        document.getElementById('debug-memory').textContent = Math.round(performance.memory?.usedJSHeapSize / 1024 / 1024 || 0);
        document.getElementById('debug-scene').textContent = this.game.currentScreen;
        document.getElementById('debug-entities').textContent = '0';
    }
}
