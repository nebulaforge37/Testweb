
class Pet {
  constructor(name, type, level = 1) {
    this.name = name;
    this.type = type;
    this.level = level;
    this.experience = 0;
    this.abilities = new Map();
    this.stats = {
      health: 50,
      attack: 10,
      defense: 5
    };
  }

  gainExperience(amount) {
    this.experience += amount;
    if (this.experience >= this.level * 100) {
      this.levelUp();
    }
  }

  levelUp() {
    this.level++;
    this.experience = 0;
    this.stats.health += 10;
    this.stats.attack += 2;
    this.stats.defense += 1;
  }

  assist(target) {
    return Math.floor(this.stats.attack * 0.5);
  }
}

class PetSystem {
  constructor() {
    this.activePet = null;
    this.collectedPets = new Map();
    this.availablePets = new Map([
      ['Wolf', { baseStats: { health: 60, attack: 12, defense: 6 }, abilities: ['Pack Hunt', 'Howl'] }],
      ['Dragon', { baseStats: { health: 80, attack: 15, defense: 8 }, abilities: ['Fire Breath', 'Wing Shield'] }],
      ['Phoenix', { baseStats: { health: 70, attack: 13, defense: 7 }, abilities: ['Rebirth', 'Flame Strike'] }]
    ]);
  }

  collectPet(type, name) {
    if (this.availablePets.has(type)) {
      const newPet = new Pet(name, type);
      this.collectedPets.set(name, newPet);
      return newPet;
    }
    return null;
  }

  setActivePet(name) {
    if (this.collectedPets.has(name)) {
      this.activePet = this.collectedPets.get(name);
      return true;
    }
    return false;
  }
}

export const petSystem = new PetSystem();
