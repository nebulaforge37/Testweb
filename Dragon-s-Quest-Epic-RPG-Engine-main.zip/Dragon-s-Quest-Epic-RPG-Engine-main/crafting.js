
export class CraftingPage {
    constructor() {
        this.recipes = [];
    }

    render() {
        const section = document.getElementById('crafting');
        if (section) {
            section.innerHTML = `
                <h2>Crafting</h2>
                <div class="crafting-interface">
                    <div class="crafting-recipes"></div>
                    <div class="crafting-materials"></div>
                    <div class="crafting-result"></div>
                </div>
            `;
        }
    }
}
