
export class ConfigEngine {
  constructor() {
    this.settings = {
      sound: true,
      music: true,
      graphics: 'high',
      difficulty: 'normal'
    };
  }

  getSetting(key) {
    return this.settings[key];
  }

  setSetting(key, value) {
    this.settings[key] = value;
  }
}
