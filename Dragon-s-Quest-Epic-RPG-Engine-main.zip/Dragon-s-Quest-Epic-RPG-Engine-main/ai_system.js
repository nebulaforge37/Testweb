
class AISystem {
  constructor() {
    this.difficultyLevels = {
      easy: 0.8,
      normal: 1.0,
      hard: 1.2,
      expert: 1.5
    };
    
    this.behaviorPatterns = {
      aggressive: { attack: 0.7, defend: 0.1, special: 0.2 },
      defensive: { attack: 0.2, defend: 0.6, special: 0.2 },
      balanced: { attack: 0.4, defend: 0.3, special: 0.3 },
      strategic: { attack: 0.3, defend: 0.3, special: 0.4 }
    };
  }

  calculateThreat(player, enemy) {
    return {
      playerHealth: player.currentHealth / player.maxHealth,
      enemyHealth: enemy.currentHealth / enemy.maxHealth,
      playerLevel: player.level,
      enemyLevel: enemy.level,
      playerDamage: player.damage,
      playerDefense: player.defense
    };
  }

  makeDecision(enemy, player, battleState) {
    const threat = this.calculateThreat(player, enemy);
    const pattern = this.behaviorPatterns[enemy.behavior || 'balanced'];
    const difficulty = this.difficultyLevels[enemy.difficulty || 'normal'];

    if (threat.enemyHealth < 0.2) {
      return this.getDefensiveAction(enemy, difficulty);
    }
    if (threat.playerHealth < 0.3) {
      return this.getAggressiveAction(enemy, difficulty);
    }

    const roll = Math.random();
    if (roll < pattern.attack) {
      return this.getAggressiveAction(enemy, difficulty);
    } else if (roll < pattern.attack + pattern.defend) {
      return this.getDefensiveAction(enemy, difficulty);
    } else {
      return this.getSpecialAction(enemy, difficulty);
    }
  }

  getAggressiveAction(enemy, difficulty) {
    const actions = enemy.abilities.filter(a => a.type === 'attack');
    return this.selectBestAction(actions, difficulty);
  }

  getDefensiveAction(enemy, difficulty) {
    const actions = enemy.abilities.filter(a => a.type === 'defense');
    return this.selectBestAction(actions, difficulty);
  }

  getSpecialAction(enemy, difficulty) {
    const actions = enemy.abilities.filter(a => a.type === 'special');
    return this.selectBestAction(actions, difficulty);
  }

  selectBestAction(actions, difficulty) {
    if (!actions.length) return null;
    actions.sort((a, b) => (b.power * difficulty) - (a.power * difficulty));
    return actions[0];
  }
}

export { AISystem };
