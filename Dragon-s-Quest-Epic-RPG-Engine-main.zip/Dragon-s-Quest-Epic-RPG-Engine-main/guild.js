
export class GuildPage {
    constructor() {
        this.guildInfo = null;
    }

    render() {
        const section = document.getElementById('guild');
        if (section) {
            section.innerHTML = `
                <h2>Guild Hall</h2>
                <div class="guild-interface">
                    <div class="guild-missions"></div>
                    <div class="guild-ranks"></div>
                    <div class="guild-members"></div>
                </div>
            `;
        }
    }
}
