import { Game } from './game.js';
import { ConfigEngine } from './config.js';
import { CharacterPage } from './pages/character.js';
import { InventoryPage } from './pages/inventory.js';
import { SkillsPage } from './pages/skills.js';
import { LoadoutPage } from './pages/loadout.js';
import { MapPage } from './pages/map.js';
import { QuestPage } from './pages/quests.js';
import { CraftingPage } from './pages/crafting.js';
import { DungeonPage } from './pages/dungeons.js';
import { GuildPage } from './pages/guild.js';

class UI {
  static showScreen(screenId) {
    const screens = ['titleScreen', 'loadingScreen', 'gameScreen', 'aboutScreen', 'settingsScreen', 'creditsScreen'];
    screens.forEach(screen => {
      const element = document.getElementById(screen);
      if (element) {
        element.classList.add('hidden');
      }
    });
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
      targetScreen.classList.remove('hidden');
    }
  }
}

// Initialize game instance
const game = new Game();
const configEngine = new ConfigEngine();

// Initialize combat log
const combatLog = {
  add: function(message) {
    const log = document.getElementById('combatLog');
    if (log) {
      const messageElement = document.createElement('div');
      messageElement.textContent = message;
      messageElement.className = 'combat-message';
      log.querySelector('.combat-messages').appendChild(messageElement);
      log.scrollTop = log.scrollHeight;
    }
  }
};

function initializeMenus() {
  document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
      const targetId = item.getAttribute('data-target');
      document.querySelectorAll('.sub-menu').forEach(menu => {
        menu.classList.remove('active');
      });
      if (targetId) {
        document.getElementById(targetId)?.classList.add('active');
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initializeMenus();

  // Initialize all game pages
  const pages = {
    character: new CharacterPage(),
    inventory: new InventoryPage(),
    skills: new SkillsPage(),
    loadout: new LoadoutPage(),
    map: new MapPage(),
    quests: new QuestPage(),
    crafting: new CraftingPage(),
    dungeons: new DungeonPage(),
    guild: new GuildPage()
  };

  // Button handlers
  document.getElementById('startGameBtn')?.addEventListener('click', () => {
    UI.showScreen('loadingScreen');
    setTimeout(() => {
      UI.showScreen('gameScreen');
    }, 2000);
  });

  document.getElementById('aboutBtn')?.addEventListener('click', () => UI.showScreen('aboutScreen'));
  document.getElementById('hideAboutBtn')?.addEventListener('click', () => UI.showScreen('titleScreen'));
  document.getElementById('settingsBtn')?.addEventListener('click', () => UI.showScreen('settingsScreen'));
  document.getElementById('hideSettingsBtn')?.addEventListener('click', () => UI.showScreen('titleScreen'));
  document.getElementById('creditsBtn')?.addEventListener('click', () => UI.showScreen('creditsScreen'));
  document.getElementById('hideCreditsBtn')?.addEventListener('click', () => UI.showScreen('titleScreen'));

  // Settings change handlers
  document.getElementById('soundToggle')?.addEventListener('change', (e) => {
    configEngine.setSetting('sound', e.target.checked);
  });

  document.getElementById('musicToggle')?.addEventListener('change', (e) => {
    configEngine.setSetting('music', e.target.checked);
  });

  document.getElementById('graphicsQuality')?.addEventListener('change', (e) => {
    configEngine.setSetting('graphics', e.target.value);
  });

  // Navigation handlers
  document.querySelectorAll('[data-section]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const section = e.currentTarget.getAttribute('data-section');

      document.querySelectorAll('[data-section]').forEach(el => {
        el.classList.remove('active');
      });

      e.currentTarget.classList.add('active');

      document.querySelectorAll('.game-section').forEach(s => {
        s.classList.add('hidden');
      });

      const targetSection = document.getElementById(section);
      if (targetSection) {
        targetSection.classList.remove('hidden');
        const page = pages[section];
        if (page && typeof page.render === 'function') {
          page.render();
        }
      }
    });
  });

  // Initialize game
  game.initialize();
});

// Export necessary globals
window.UI = UI;
window.game = game;
window.combatLog = combatLog;


class Codex {
  constructor() {
      this.entries = [];
  }

  addEntry(entry) {
      this.entries.push(entry);
  }
}

class BlacksmithingSystem {
  constructor() {
      this.blueprints = {};
  }

  addBlueprint(blueprint) {
      this.blueprints[blueprint.name] = blueprint;
  }
}

class Enemy {
    constructor(health, damage) {
        this.health = health;
        this.damage = damage;
    }

    update() {
        console.log("Enemy is attacking!");
    }
}

class Nemesis extends Enemy {
    constructor(health, damage, specialAbility) {
        super(health, damage);
        this.specialAbility = specialAbility;
    }

    update() {
        super.update();
        console.log(`Nemesis used ${this.specialAbility}!`);
    }
}

// Initialize instances
window.codex = new Codex();
window.blacksmithingSystem = new BlacksmithingSystem();

const GameZones = ["Zone1", "Zone2"];
const CraftingBlueprints = { "Sword": { "materials": ["Iron", "Wood"] } };
const Vendors = ["Vendor A", "Vendor B"];