
class DragDropManager {
  constructor() {
    this.draggedItem = null;
    this.sourceSlot = null;
    this.initializeEventListeners();
  }

  initializeEventListeners() {
    const slots = document.querySelectorAll('.inventory-slot, .equip-slot');
    
    slots.forEach(slot => {
      slot.setAttribute('draggable', 'true');
      
      slot.addEventListener('dragstart', (e) => this.handleDragStart(e));
      slot.addEventListener('dragend', (e) => this.handleDragEnd(e));
      slot.addEventListener('dragover', (e) => this.handleDragOver(e));
      slot.addEventListener('drop', (e) => this.handleDrop(e));
      slot.addEventListener('dragenter', (e) => this.handleDragEnter(e));
      slot.addEventListener('dragleave', (e) => this.handleDragLeave(e));
    });
  }

  handleDragStart(e) {
    this.draggedItem = e.target;
    this.sourceSlot = e.target;
    e.target.classList.add('dragging');
    e.dataTransfer.setData('text/plain', '');
  }

  handleDragEnd(e) {
    e.target.classList.remove('dragging');
    const slots = document.querySelectorAll('.inventory-slot, .equip-slot');
    slots.forEach(slot => slot.classList.remove('dragover'));
  }

  handleDragOver(e) {
    e.preventDefault();
  }

  handleDragEnter(e) {
    e.preventDefault();
    if (e.target.classList.contains('inventory-slot') || 
        e.target.classList.contains('equip-slot')) {
      e.target.classList.add('dragover');
    }
  }

  handleDragLeave(e) {
    e.target.classList.remove('dragover');
  }

  handleDrop(e) {
    e.preventDefault();
    const targetSlot = e.target;
    
    if (!targetSlot.classList.contains('inventory-slot') && 
        !targetSlot.classList.contains('equip-slot')) return;

    targetSlot.classList.remove('dragover');

    if (targetSlot === this.sourceSlot) return;

    // Handle equipment slot restrictions
    if (targetSlot.classList.contains('equip-slot')) {
      const slotType = targetSlot.dataset.slot;
      const itemType = this.draggedItem.dataset.itemType;
      if (slotType !== itemType) return;
    }

    // Swap items
    const targetItem = targetSlot.innerHTML;
    targetSlot.innerHTML = this.sourceSlot.innerHTML;
    this.sourceSlot.innerHTML = targetItem;

    // Update inventory data
    game.inventory.swapItems(
      this.sourceSlot.dataset.index, 
      targetSlot.dataset.index
    );
  }
}

// Initialize drag and drop
document.addEventListener('DOMContentLoaded', () => {
  window.dragDropManager = new DragDropManager();
});
