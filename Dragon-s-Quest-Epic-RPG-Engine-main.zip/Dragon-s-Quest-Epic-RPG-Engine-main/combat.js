
export class CombatPage {
  constructor() {
    this.currentEnemy = null;
    this.playerHealth = 100;
    this.enemyHealth = 100;
  }

  attack() {
    const damage = Math.floor(Math.random() * 20) + 10;
    this.enemyHealth -= damage;
    this.updateCombatLog(`You deal ${damage} damage!`);
    this.updateHealthBars();
  }

  updateCombatLog(message) {
    const log = document.getElementById('combatLog');
    if (log) {
      const messages = log.querySelector('.combat-messages');
      if (messages) {
        const entry = document.createElement('div');
        entry.className = 'combat-message';
        entry.textContent = message;
        messages.appendChild(entry);
        messages.scrollTop = messages.scrollHeight;
      }
    }
  }

  updateHealthBars() {
    const playerHealth = document.querySelector('.player-side .health-fill');
    const enemyHealth = document.querySelector('.enemy-side .health-fill');
    
    if (playerHealth) {
      playerHealth.style.width = `${this.playerHealth}%`;
    }
    if (enemyHealth) {
      enemyHealth.style.width = `${this.enemyHealth}%`;
    }
  }
}
