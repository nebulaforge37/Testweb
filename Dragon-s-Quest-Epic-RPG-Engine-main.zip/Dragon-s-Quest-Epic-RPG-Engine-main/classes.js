// Character Classes
const CharacterClasses = {
  // Martial Classes
  Warrior: {
    type: 'Martial',
    baseStats: { hp: 120, strength: 15, defense: 12, agility: 8 },
    abilities: ['Slash', 'Shield Block', 'Battle Cry', 'Heavy Strike'],
    weaponProficiency: ['Sword', 'Axe', 'Mace', 'Shield'],
    armorProficiency: ['Plate', 'Mail'],
    specialization: ['Berserker', 'Guardian', 'Weapon Master']
  },

  Knight: {
    type: 'Martial',
    baseStats: { hp: 110, strength: 12, defense: 15, agility: 7 },
    abilities: ['Shield Wall', 'Charge', 'Defensive Stance', 'Taunt'],
    weaponProficiency: ['Sword', 'Lance', 'Shield'],
    armorProficiency: ['Plate', 'Mail'],
    specialization: ['Paladin', 'Dark Knight', 'Royal Guard']
  },

  // Magic Classes
  Mage: {
    type: 'Magic',
    baseStats: { hp: 80, mana: 150, intelligence: 15, wisdom: 12 },
    abilities: ['Fireball', 'Ice Bolt', 'Lightning Strike', 'Arcane Missile'],
    weaponProficiency: ['Staff', 'Wand', 'Dagger'],
    armorProficiency: ['Cloth'],
    specialization: ['Elementalist', 'Archmage', 'Battle Mage']
  },

  Warlock: {
    type: 'Magic',
    baseStats: { hp: 90, mana: 130, intelligence: 13, wisdom: 10, darkness: 15 },
    abilities: ['Shadow Bolt', 'Life Drain', 'Curse', 'Summon Demon'],
    weaponProficiency: ['Staff', 'Wand', 'Dagger'],
    armorProficiency: ['Cloth'],
    specialization: ['Demonologist', 'Curse Weaver', 'Soul Reaper']
  },

  // Elemental Classes
  Pyromancer: {
    type: 'Caster',
    element: 'Fire',
    baseStats: { hp: 80, mana: 120, intelligence: 15, wisdom: 12 },
    abilities: ['Fireball', 'Flame Shield', 'Meteor Strike', 'Heat Wave'],
    weaponProficiency: ['Staff', 'Wand'],
    armorProficiency: ['Cloth'],
    specialization: ['Flame Lord', 'Ash Mage', 'Inferno Master']
  },

  Cryomancer: {
    type: 'Caster',
    element: 'Ice',
    baseStats: { hp: 85, mana: 115, intelligence: 14, wisdom: 13 },
    abilities: ['Ice Spike', 'Frost Nova', 'Blizzard', 'Glacial Shield'],
    weaponProficiency: ['Staff', 'Wand'],
    armorProficiency: ['Cloth'],
    specialization: ['Frost Lord', 'Snow Sage', 'Glacier Master']
  },

  // Ranged Classes
  Ranger: {
    type: 'Ranged',
    element: 'Wind',
    baseStats: { hp: 95, strength: 10, agility: 15, accuracy: 12 },
    abilities: ['Precise Shot', 'Multi Arrow', 'Trap', 'Eagle Eye'],
    weaponProficiency: ['Bow', 'Crossbow', 'Dagger'],
    armorProficiency: ['Leather', 'Mail'],
    specialization: ['Hunter', 'Marksman', 'Beast Master']
  },

  // Hybrid Classes
  Spellblade: {
    type: 'Hybrid',
    baseStats: { hp: 100, mana: 100, strength: 12, intelligence: 12 },
    abilities: ['Spell Strike', 'Enchant Weapon', 'Magical Barrier', 'Elemental Slash'],
    weaponProficiency: ['Sword', 'Staff', 'Glaive'],
    armorProficiency: ['Mail', 'Cloth'],
    specialization: ['Rune Knight', 'Mystic Warrior', 'Spell Knight']
  }
};

const MonsterTypes = {
  // Basic Types
  Beast: {
    traits: ['Natural Armor', 'Feral Instincts'],
    weaknesses: ['Fire', 'Magic'],
    resistances: ['Physical'],
    varieties: ['Wolf', 'Bear', 'Lion', 'Tiger']
  },

  Undead: {
    traits: ['Undying', 'Fear Aura'],
    weaknesses: ['Holy', 'Fire'],
    resistances: ['Cold', 'Poison'],
    varieties: ['Skeleton', 'Zombie', 'Ghost', 'Wraith']
  },

  Dragon: {
    traits: ['Flight', 'Breath Weapon', 'Magic Resistance'],
    weaknesses: ['Dragon Slayer Weapons'],
    resistances: ['Elements', 'Physical'],
    varieties: ['Red Dragon', 'Blue Dragon', 'Black Dragon', 'Gold Dragon']
  },

  Demon: {
    traits: ['Fire Immunity', 'Dark Magic'],
    weaknesses: ['Holy', 'Light'],
    resistances: ['Fire', 'Shadow'],
    varieties: ['Imp', 'Hellhound', 'Demon Lord', 'Arch Demon']
  },

  // Elite Types
  EliteBoss: {
    traits: ['Enhanced Abilities', 'Aura Effects'],
    modifiers: {
      hp: 2.0,
      damage: 1.5,
      defense: 1.3
    },
    mechanics: ['Elite Powers', 'Special Abilities'],
    varieties: ['Elite Dragon', 'Elite Demon', 'Elite Undead']
  },

  ChampionBoss: {
    traits: ['Champion Aura', 'Devastating Attacks'],
    modifiers: {
      hp: 2.5,
      damage: 1.8,
      defense: 1.4
    },
    mechanics: ['Champion Powers', 'Ultimate Move'],
    varieties: ['Champion Warrior', 'Champion Mage', 'Champion Beast']
  },

  Boss: {
    traits: ['Unique Abilities', 'Phase Transitions'],
    modifiers: {
      hp: 3.0,
      damage: 2.0,
      defense: 1.5
    },
    mechanics: ['Special Attacks', 'Minion Summoning', 'Rage Phase']
  },

  WorldBoss: {
    traits: ['Epic Abilities', 'Multiple Phases', 'Area Effects'],
    modifiers: {
      hp: 10.0,
      damage: 3.0,
      defense: 2.0
    },
    mechanics: ['Phase Transitions', 'Arena Wide Effects', 'Ultimate Abilities']
  }
};

class MonsterGenerator {
  static generate(type, level, rank = 'normal') {
    const baseStats = {
      normal: { statMod: 1.0, dropMod: 1.0 },
      elite: { statMod: 1.5, dropMod: 2.0 },
      champion: { statMod: 2.0, dropMod: 3.0 },
      legendary: { statMod: 3.0, dropMod: 5.0 }
    };

    const monsterType = MonsterTypes[type];
    const rankMod = baseStats[rank];

    return {
      type: type,
      rank: rank,
      level: level,
      traits: monsterType.traits,
      weaknesses: monsterType.weaknesses,
      resistances: monsterType.resistances,
      stats: {
        hp: Math.floor(100 * level * rankMod.statMod),
        damage: Math.floor(10 * level * rankMod.statMod),
        defense: Math.floor(5 * level * rankMod.statMod)
      },
      dropRate: rankMod.dropMod
    };
  }
}

// Make them globally available
window.CharacterClasses = CharacterClasses;
window.MonsterTypes = MonsterTypes;
window.MonsterGenerator = MonsterGenerator;