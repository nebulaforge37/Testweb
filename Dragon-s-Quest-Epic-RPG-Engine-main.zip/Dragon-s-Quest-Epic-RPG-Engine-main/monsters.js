
const DND5E_Monsters = {
  // Aberrations
  Aboleth: {
    cr: 10,
    type: 'Aberration',
    hp: 135,
    ac: 17,
    attacks: [{
      name: 'Tentacle',
      damage: '2d6+5',
      type: 'bludgeoning'
    }],
    abilities: {
      str: 21, dex: 9, con: 15,
      int: 18, wis: 15, cha: 18
    }
  },
  
  // Dragons
  AdultBlackDragon: {
    cr: 14,
    type: 'Dragon',
    hp: 195,
    ac: 19,
    attacks: [{
      name: 'Bite',
      damage: '2d10+6',
      type: 'piercing'
    }],
    abilities: {
      str: 23, dex: 14, con: 21,
      int: 14, wis: 13, cha: 17
    }
  },
  
  // Humanoids
  Bandit: {
    cr: 1/8,
    type: 'Humanoid',
    hp: 11,
    ac: 12,
    attacks: [{
      name: 'Scimitar',
      damage: '1d6+1',
      type: 'slashing'
    }],
    abilities: {
      str: 11, dex: 12, con: 12,
      int: 10, wis: 10, cha: 10
    }
  }
  // Full monster list removed for brevity - would include all 800+ monsters
};

// Character Classes from PHB and expansions
const DND5E_Classes = {
  Barbarian: {
    hitDie: 12,
    primaryAbility: 'Strength',
    savingThrows: ['Strength', 'Constitution'],
    subclasses: ['Path of the Berserker', 'Path of the Totem Warrior']
  },
  
  Bard: {
    hitDie: 8,
    primaryAbility: 'Charisma',
    savingThrows: ['Dexterity', 'Charisma'],
    subclasses: ['College of Lore', 'College of Valor']
  }
  // Full class list removed for brevity - would include all base classes and subclasses
};

export { DND5E_Monsters, DND5E_Classes };
