
export class CharacterPage {
    constructor() {
        this.stats = {
            strength: 10,
            dexterity: 10,
            intelligence: 10,
            vitality: 10,
            wisdom: 8,
            charisma: 8
        };
        this.level = 1;
        this.experience = 0;
    }

    render() {
        const section = document.getElementById('character');
        if (section) {
            section.innerHTML = `
                <div class="char-header">
                    <div class="char-avatar"></div>
                    <div class="char-info">
                        <h2>Character Overview</h2>
                        <div class="char-class">Level ${this.level} Warrior</div>
                        <div class="char-status">Active</div>
                    </div>
                </div>
                <div class="stats-grid">
                    <div class="stat-block">
                        <span class="stat-label">Strength</span>
                        <span id="stat-str">${this.stats.strength}</span>
                    </div>
                    <div class="stat-block">
                        <span class="stat-label">Dexterity</span>
                        <span id="stat-dex">${this.stats.dexterity}</span>
                    </div>
                    <div class="stat-block">
                        <span class="stat-label">Intelligence</span>
                        <span id="stat-int">${this.stats.intelligence}</span>
                    </div>
                    <div class="stat-block">
                        <span class="stat-label">Vitality</span>
                        <span id="stat-vit">${this.stats.vitality}</span>
                    </div>
                    <div class="stat-block">
                        <span class="stat-label">Wisdom</span>
                        <span id="stat-wis">${this.stats.wisdom}</span>
                    </div>
                    <div class="stat-block">
                        <span class="stat-label">Charisma</span>
                        <span id="stat-cha">${this.stats.charisma}</span>
                    </div>
                </div>
                <div class="char-progression">
                    <h3>Experience Progress</h3>
                    <div class="exp-bar">
                        <div class="exp-fill" style="width: ${(this.experience % 1000) / 10}%"></div>
                    </div>
                    <span class="exp-text">${this.experience} / 1000</span>
                </div>
            `;
        }
    }

    updateStats(stats) {
        Object.assign(this.stats, stats);
        this.render();
    }
}
