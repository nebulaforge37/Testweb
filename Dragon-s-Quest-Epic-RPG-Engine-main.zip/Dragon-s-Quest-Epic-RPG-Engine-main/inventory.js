
export class InventoryPage {
    constructor() {
        this.items = [];
    }

    render() {
        const inventoryGrid = document.querySelector('.inventory-grid');
        if (inventoryGrid) {
            inventoryGrid.innerHTML = this.items.map(item => `
                <div class="inventory-item">
                    <img src="${item.icon}" alt="${item.name}">
                    <span>${item.name}</span>
                </div>
            `).join('');
        }
    }
}
