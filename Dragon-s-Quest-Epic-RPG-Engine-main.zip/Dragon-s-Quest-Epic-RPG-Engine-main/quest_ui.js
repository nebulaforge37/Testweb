
class QuestUI {
  static renderQuestLog() {
    const questLog = document.getElementById('questLog');
    if (!questLog) return;
    
    questLog.innerHTML = '';

    // Active Quests
    const activeSection = document.createElement('div');
    activeSection.className = 'quest-section';
    activeSection.innerHTML = '<h3>Active Quests</h3>';
    
    questSystem.activeQuests.forEach(quest => {
      activeSection.appendChild(this.createQuestCard(quest));
    });
    
    // Completed Quests
    const completedSection = document.createElement('div');
    completedSection.className = 'quest-section';
    completedSection.innerHTML = '<h3>Completed Quests</h3>';
    
    questSystem.completedQuests.forEach(quest => {
      completedSection.appendChild(this.createQuestCard(quest));
    });

    questLog.appendChild(activeSection);
    questLog.appendChild(completedSection);
  }

  static createQuestCard(quest) {
    const card = document.createElement('div');
    card.className = `quest-card ${quest.completed ? 'completed' : ''}`;
    
    card.innerHTML = `
      <h4>${quest.title}</h4>
      <p>${quest.description}</p>
      <div class="quest-info">
        <span>Type: ${quest.type}</span>
        <span>Level: ${quest.level}</span>
      </div>
      ${!quest.completed ? `
        <div class="quest-progress">
          <div class="progress-bar" style="width: ${quest.progress}%"></div>
          <span>${quest.progress}%</span>
        </div>
      ` : ''}
    `;
    
    return card;
  }
}

// Make QuestUI available globally
window.QuestUI = QuestUI;
