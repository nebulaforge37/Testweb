
const CREDITS = {
  developers: [
    {
      role: 'Lead Developer',
      name: 'Apocalypsecoder0'
    }
  ],
  artists: [
    {
      role: 'Art Direction',
      name: 'Art Team'
    }
  ],
  soundDesign: [
    {
      role: 'Music Composition',
      name: 'Audio Team'
    }
  ],
  specialThanks: [
    'Replit Community',
    'Open Source Contributors'
  ],
  version: '0.1.5'
};

export class Credits {
  static show() {
    const creditsDiv = document.getElementById('credits');
    if (creditsDiv) {
      creditsDiv.innerHTML = this.generateCreditsHTML();
      creditsDiv.classList.remove('hidden');
    }
  }

  static hide() {
    const creditsDiv = document.getElementById('credits');
    if (creditsDiv) {
      creditsDiv.classList.add('hidden');
    }
  }

  static generateCreditsHTML() {
    return `
      <div class="credits-content">
        <h2>Dragon's Quest</h2>
        <h3>Development Team</h3>
        ${this.generateSection(CREDITS.developers)}
        
        <h3>Art</h3>
        ${this.generateSection(CREDITS.artists)}
        
        <h3>Sound Design</h3>
        ${this.generateSection(CREDITS.soundDesign)}
        
        <h3>Special Thanks</h3>
        <div class="credits-section">
          ${CREDITS.specialThanks.join('<br>')}
        </div>
        
        <div class="version-info">
          Version ${CREDITS.version}
        </div>
        
        <button onclick="Credits.hide()">Close</button>
      </div>
    `;
  }

  static generateSection(items) {
    return `
      <div class="credits-section">
        ${items.map(item => `
          <div class="credit-item">
            <span class="role">${item.role}</span>
            <span class="name">${item.name}</span>
          </div>
        `).join('')}
      </div>
    `;
  }
}
