
export const Elements = {
  Fire: {
    name: 'Fire',
    effects: ['Burn', 'Melt'],
    weakness: 'Water',
    strength: 'Nature'
  },
  Ice: {
    name: 'Ice',
    effects: ['Freeze', 'Chill'],
    weakness: 'Fire',
    strength: 'Water'
  },
  Lightning: {
    name: 'Lightning',
    effects: ['Shock', 'Stun'],
    weakness: 'Earth',
    strength: 'Water'
  },
  Earth: {
    name: 'Earth',
    effects: ['Petrify', 'Poison'],
    weakness: 'Wind',
    strength: 'Lightning'
  },
  Wind: {
    name: 'Wind',
    effects: ['Float', 'Knockback'],
    weakness: 'Ice',
    strength: 'Earth'
  },
  Holy: {
    name: 'Holy',
    effects: ['Purify', 'Bless'],
    weakness: 'Dark',
    strength: 'Undead'
  },
  Dark: {
    name: 'Dark',
    effects: ['Curse', 'Drain'],
    weakness: 'Holy',
    strength: 'Living'
  }
};
