
// Party System
export class Party {
  constructor(leader) {
    this.leader = leader;
    this.members = [leader];
    this.maxSize = {
      dungeon: 4,
      raid: 20,
      trial: 8,
      quest: 4
    };
    this.status = 'open'; // open, closed, in-progress
  }

  addMember(player) {
    const currentActivity = this.getCurrentActivity();
    if (this.members.length < this.maxSize[currentActivity]) {
      this.members.push(player);
      return true;
    }
    return false;
  }

  removeMember(playerId) {
    this.members = this.members.filter(member => member.id !== playerId);
    if (this.leader.id === playerId && this.members.length > 0) {
      this.leader = this.members[0];
    }
    return this.members.length > 0;
  }

  getCurrentActivity() {
    return this.currentInstance?.type || 'quest';
  }

  startActivity(instance) {
    if (this.members.length >= instance.minPlayers && 
        this.members.length <= this.maxSize[instance.type]) {
      this.currentInstance = instance;
      this.status = 'in-progress';
      return true;
    }
    return false;
  }

  disbandParty() {
    this.members.forEach(member => member.leaveParty());
    this.members = [];
    this.leader = null;
  }
}
