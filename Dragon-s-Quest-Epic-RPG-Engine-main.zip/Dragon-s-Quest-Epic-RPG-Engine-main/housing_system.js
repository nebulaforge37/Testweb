
class House {
  constructor(type) {
    this.type = type;
    this.furniture = new Map();
    this.bonuses = new Map();
    this.maxFurniture = type === 'small' ? 10 : type === 'medium' ? 20 : 30;
  }

  addFurniture(item) {
    if (this.furniture.size < this.maxFurniture) {
      this.furniture.set(item.id, item);
      this.calculateBonuses();
      return true;
    }
    return false;
  }

  removeFurniture(itemId) {
    if (this.furniture.has(itemId)) {
      this.furniture.delete(itemId);
      this.calculateBonuses();
      return true;
    }
    return false;
  }

  calculateBonuses() {
    this.bonuses.clear();
    this.furniture.forEach(item => {
      item.bonuses.forEach((value, stat) => {
        const currentBonus = this.bonuses.get(stat) || 0;
        this.bonuses.set(stat, currentBonus + value);
      });
    });
  }
}

class HousingSystem {
  constructor() {
    this.playerHouses = new Map();
    this.furnitureBlueprints = new Map([
      ['Bed', { cost: 100, bonuses: new Map([['restingBonus', 10]]) }],
      ['Bookshelf', { cost: 150, bonuses: new Map([['skillExp', 5]]) }],
      ['Trophy Stand', { cost: 200, bonuses: new Map([['reputation', 15]]) }]
    ]);
  }

  purchaseHouse(playerId, type) {
    const house = new House(type);
    this.playerHouses.set(playerId, house);
    return house;
  }

  craftFurniture(blueprint) {
    if (this.furnitureBlueprints.has(blueprint)) {
      const item = {
        id: Date.now(),
        type: blueprint,
        bonuses: this.furnitureBlueprints.get(blueprint).bonuses
      };
      return item;
    }
    return null;
  }
}

export const housingSystem = new HousingSystem();
