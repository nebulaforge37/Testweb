
class SaveSystem {
  constructor(gameEngine) {
    this.gameEngine = gameEngine;
    this.maxSaveSlots = 3;
    this.autoSaveInterval = 300000; // 5 minutes
    this.lastAutoSave = Date.now();
  }

  createSaveData() {
    const systems = {};
    this.gameEngine.systems.forEach((system, key) => {
      if (system.getSaveData) {
        systems[key] = system.getSaveData();
      }
    });

    return {
      timestamp: Date.now(),
      gameState: this.gameEngine.gameState,
      systems: systems
    };
  }

  save(slot) {
    const saveData = this.createSaveData();
    localStorage.setItem(`save_slot_${slot}`, JSON.stringify(saveData));
    return true;
  }

  load(slot) {
    const saveData = localStorage.getItem(`save_slot_${slot}`);
    if (!saveData) return false;

    const data = JSON.parse(saveData);
    this.gameEngine.gameState = data.gameState;
    
    Object.entries(data.systems).forEach(([key, systemData]) => {
      const system = this.gameEngine.systems.get(key);
      if (system && system.loadSaveData) {
        system.loadSaveData(systemData);
      }
    });

    return true;
  }

  autoSave() {
    if (Date.now() - this.lastAutoSave >= this.autoSaveInterval) {
      this.save(0); // Use slot 0 for auto-save
      this.lastAutoSave = Date.now();
    }
  }

  getSaveInfo(slot) {
    const saveData = localStorage.getItem(`save_slot_${slot}`);
    if (!saveData) return null;

    const data = JSON.parse(saveData);
    return {
      timestamp: data.timestamp,
      gameState: data.gameState
    };
  }

  deleteSave(slot) {
    localStorage.removeItem(`save_slot_${slot}`);
  }
}

export { SaveSystem };
