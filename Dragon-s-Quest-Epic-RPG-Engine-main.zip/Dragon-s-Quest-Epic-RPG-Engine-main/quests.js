import { QuestPage } from './pages/quests.js';
class QuestPage {
  constructor() {
    this.quests = [];
    this.initialize();
  }

  initialize() {
    if (window.questSystem) {
      this.quests = Array.from(questSystem.activeQuests.values());
    }
  }

  render() {
    const questList = document.querySelector('.quest-list');
    if (questList) {
      questList.innerHTML = this.quests.map(quest => `
        <div class="quest-item">
          <h3>${quest.title}</h3>
          <p>${quest.description}</p>
          <div class="quest-progress">Progress: ${quest.progress}%</div>
          <div class="quest-rewards">
            <h4>Rewards:</h4>
            <ul>
              ${quest.rewards ? Object.entries(quest.rewards).map(([key, value]) => 
                `<li>${key}: ${value}</li>`).join('') : ''}
            </ul>
          </div>
        </div>
      `).join('');
    }
  }

  addQuest(quest) {
    this.quests.push(quest);
    this.render();
  }

  updateProgress(questId, progress) {
    const quest = this.quests.find(q => q.id === questId);
    if (quest) {
      quest.progress = progress;
      this.render();
    }
  }
}

// Initialize global instance
window.questPage = new QuestPage();
