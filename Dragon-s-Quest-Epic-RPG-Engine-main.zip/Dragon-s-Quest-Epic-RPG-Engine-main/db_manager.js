
const pool = require('./db_config');

class DatabaseManager {
  static async createPlayer(username, playerClass) {
    const query = 'INSERT INTO players (username, class) VALUES ($1, $2) RETURNING *';
    const result = await pool.query(query, [username, playerClass]);
    return result.rows[0];
  }

  static async getPlayer(username) {
    const query = 'SELECT * FROM players WHERE username = $1';
    const result = await pool.query(query, [username]);
    return result.rows[0];
  }

  static async updatePlayerExperience(playerId, experience) {
    const query = 'UPDATE players SET experience = experience + $2 WHERE id = $1 RETURNING *';
    const result = await pool.query(query, [playerId, experience]);
    return result.rows[0];
  }

  static async addInventoryItem(playerId, itemId, quantity) {
    const query = `
      INSERT INTO inventory (player_id, item_id, quantity) 
      VALUES ($1, $2, $3) 
      ON CONFLICT (player_id, item_id) 
      DO UPDATE SET quantity = inventory.quantity + $3
      RETURNING *`;
    const result = await pool.query(query, [playerId, itemId, quantity]);
    return result.rows[0];
  }

  static async getPlayerInventory(playerId) {
    const query = 'SELECT * FROM inventory WHERE player_id = $1';
    const result = await pool.query(query, [playerId]);
    return result.rows;
  }

  static async savePlayerStats(playerId, stats) {
    const query = `
      INSERT INTO character_stats (player_id, strength, dexterity, intelligence, vitality, wisdom, charisma)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (player_id)
      DO UPDATE SET 
        strength = $2, dexterity = $3, intelligence = $4, 
        vitality = $5, wisdom = $6, charisma = $7
      RETURNING *`;
    const result = await pool.query(query, [
      playerId, 
      stats.strength, 
      stats.dexterity, 
      stats.intelligence, 
      stats.vitality,
      stats.wisdom,
      stats.charisma
    ]);
    return result.rows[0];
  }
}

module.exports = DatabaseManager;
