
class CombatAnimationSystem {
  constructor() {
    this.particles = [];
    this.damageNumbers = [];
    this.activeEffects = new Map();
  }

  spawnDamageNumber(value, x, y, isCritical = false) {
    const element = document.createElement('div');
    element.className = `damage-number ${isCritical ? 'critical' : ''}`;
    element.textContent = value;
    element.style.left = `${x}px`;
    element.style.top = `${y}px`;
    document.getElementById('combat').appendChild(element);

    setTimeout(() => element.remove(), 1000);
  }

  createParticle(type, x, y) {
    const element = document.createElement('div');
    element.className = `particle ${type}`;
    element.style.left = `${x}px`;
    element.style.top = `${y}px`;
    document.getElementById('combat').appendChild(element);

    setTimeout(() => element.remove(), 1000);
  }

  playAttackAnimation(attacker, target, type = 'normal') {
    const attackerEl = document.getElementById(attacker);
    attackerEl.classList.add('attacking');
    
    setTimeout(() => {
      attackerEl.classList.remove('attacking');
      const targetEl = document.getElementById(target);
      targetEl.classList.add('hit');
      
      if (type === 'fire') {
        this.createParticle('fire', targetEl.offsetLeft, targetEl.offsetTop);
      } else if (type === 'ice') {
        this.createParticle('ice', targetEl.offsetLeft, targetEl.offsetTop);
      }
      
      setTimeout(() => targetEl.classList.remove('hit'), 200);
    }, 300);
  }

  addStatusEffect(targetId, effect) {
    const target = document.getElementById(targetId);
    const effectEl = document.createElement('div');
    effectEl.className = `status-effect ${effect}`;
    target.appendChild(effectEl);
    this.activeEffects.set(targetId + effect, effectEl);
  }

  removeStatusEffect(targetId, effect) {
    const effectEl = this.activeEffects.get(targetId + effect);
    if (effectEl) {
      effectEl.remove();
      this.activeEffects.delete(targetId + effect);
    }
  }
}

export const combatAnimation = new CombatAnimationSystem();
