
const DND5E_Items = {
  weapons: {
    Longsword: {
      type: 'Martial Melee',
      damage: '1d8',
      damageType: 'slashing',
      properties: ['Versatile (1d10)'],
      weight: 3,
      cost: 15
    },
    Shortbow: {
      type: 'Simple Ranged',
      damage: '1d6',
      damageType: 'piercing',
      properties: ['Ammunition', 'Range (80/320)'],
      weight: 2,
      cost: 25
    }
  },
  
  armor: {
    ChainMail: {
      type: 'Heavy Armor',
      ac: 16,
      weight: 55,
      cost: 75,
      requirements: {
        strength: 13
      }
    },
    LeatherArmor: {
      type: 'Light Armor',
      ac: 11,
      weight: 10,
      cost: 10
    }
  },
  
  magicItems: {
    RingOfProtection: {
      type: 'Ring',
      rarity: 'Rare',
      attunement: true,
      effects: {
        ac: 1,
        savingThrows: 1
      }
    },
    FlameTongue: {
      type: 'Weapon',
      rarity: 'Rare',
      attunement: true,
      effects: {
        damage: '2d6',
        damageType: 'fire'
      }
    }
  }
  // Additional items removed for brevity - full list would include all DMG items
};

export { DND5E_Items };
