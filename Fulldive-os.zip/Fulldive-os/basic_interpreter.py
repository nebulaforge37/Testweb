
class BasicInterpreter:
    def __init__(self):
        self.program = {}
        self.variables = {}
        self.current_line = 0
        self.running = False
        self.output = []
    
    def parse_line(self, line):
        """Parse a line of BASIC code"""
        # Check if line starts with a line number
        parts = line.strip().split(" ", 1)
        try:
            line_num = int(parts[0])
            if len(parts) > 1:
                content = parts[1].strip()
                self.program[line_num] = content
                return f"Added line {line_num}"
            else:
                if line_num in self.program:
                    del self.program[line_num]
                    return f"Deleted line {line_num}"
                return "Empty line"
        except ValueError:
            # Direct command without line number
            return self.execute_line(line)
    
    def execute_line(self, line):
        """Execute a single line of BASIC code"""
        line = line.strip().upper()
        
        # Handle simple commands
        if line == "LIST":
            return self.cmd_list()
        elif line == "NEW":
            return self.cmd_new()
        elif line == "RUN":
            return self.cmd_run()
        elif line == "CLEAR":
            return self.cmd_clear()
        
        # Parse and execute statement
        if line.startswith("PRINT "):
            return self.stmt_print(line[6:])
        elif line.startswith("LET "):
            return self.stmt_let(line[4:])
        elif line.startswith("INPUT "):
            return self.stmt_input(line[6:])
        elif line.startswith("GOTO "):
            return self.stmt_goto(line[5:])
        elif line.startswith("IF "):
            return self.stmt_if(line[3:])
        elif line.startswith("REM "):
            return None  # Comments do nothing
        elif line == "END":
            self.running = False
            return "Program ended"
        else:
            return f"Syntax error: {line}"
    
    def cmd_list(self):
        """List the current program"""
        if not self.program:
            return "No program in memory"
        
        result = []
        for line_num in sorted(self.program.keys()):
            result.append(f"{line_num} {self.program[line_num]}")
        return "\n".join(result)
    
    def cmd_new(self):
        """Clear the current program"""
        self.program = {}
        self.variables = {}
        self.current_line = 0
        self.running = False
        return "Program cleared"
    
    def cmd_clear(self):
        """Clear variables but keep program"""
        self.variables = {}
        return "Variables cleared"
    
    def cmd_run(self):
        """Run the current program"""
        if not self.program:
            return "No program to run"
        
        self.variables = {}
        self.running = True
        self.output = []
        
        # Get the first line number
        line_nums = sorted(self.program.keys())
        if not line_nums:
            return "Program is empty"
        
        self.current_line = 0
        next_line = 0
        
        # Execute the program
        while self.running:
            # Find the next line to execute
            for ln in line_nums:
                if ln > next_line:
                    next_line = ln
                    break
            else:
                # No more lines
                self.running = False
                break
            
            self.current_line = next_line
            next_line = self.current_line
            
            # Execute the line
            result = self.execute_line(self.program[self.current_line])
            if result:
                self.output.append(result)
            
            # Advance to the next line
            next_line = self.current_line + 1
        
        return "\n".join(self.output) if self.output else "Program executed"
    
    def stmt_print(self, args):
        """Execute PRINT statement"""
        # Handle string literals
        if args.startswith('"') and args.endswith('"'):
            return args[1:-1]
        
        # Handle variable printing
        if args in self.variables:
            return str(self.variables[args])
        
        # Try to evaluate expressions
        try:
            # Replace variables with their values
            for var in self.variables:
                args = args.replace(var, str(self.variables[var]))
            
            # Evaluate the expression
            result = eval(args)
            return str(result)
        except:
            return f"Error in PRINT: {args}"
    
    def stmt_let(self, args):
        """Execute LET statement"""
        parts = args.split("=", 1)
        if len(parts) != 2:
            return "Syntax error in LET"
        
        var_name = parts[0].strip()
        expression = parts[1].strip()
        
        # Handle string literals
        if expression.startswith('"') and expression.endswith('"'):
            self.variables[var_name] = expression[1:-1]
            return None
        
        # Handle numeric expressions
        try:
            # Replace variables with their values
            for var in self.variables:
                if var != var_name:  # Avoid self-reference
                    expression = expression.replace(var, str(self.variables[var]))
            
            # Evaluate the expression
            result = eval(expression)
            self.variables[var_name] = result
            return None
        except:
            return f"Error in LET: {args}"
    
    def stmt_input(self, args):
        """Execute INPUT statement - for interactive mode only"""
        var_name = args.strip()
        return f"INPUT {var_name}"  # Return a marker for the caller to handle
    
    def stmt_goto(self, args):
        """Execute GOTO statement"""
        try:
            line_num = int(args.strip())
            if line_num in self.program:
                self.current_line = line_num - 1  # Will be incremented in the run loop
                return None
            else:
                return f"Line number {line_num} not found"
        except:
            return f"Error in GOTO: {args}"
    
    def stmt_if(self, args):
        """Execute IF statement"""
        parts = args.split("THEN", 1)
        if len(parts) != 2:
            return "Syntax error in IF: missing THEN"
        
        condition = parts[0].strip()
        action = parts[1].strip()
        
        # Replace variables in condition
        for var in self.variables:
            condition = condition.replace(var, str(self.variables[var]))
        
        # Evaluate condition
        try:
            result = eval(condition)
            if result:
                return self.execute_line(action)
            return None
        except:
            return f"Error in IF condition: {condition}"

    def handle_input(self, var_name, value):
        """Handle INPUT response"""
        try:
            # Try to convert to number if possible
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass  # Keep as string
            
            self.variables[var_name] = value
            return f"Assigned {value} to {var_name}"
        except:
            return f"Error assigning input to {var_name}"
    
    def load_program(self, code):
        """Load a program from string"""
        self.cmd_new()
        lines = code.strip().split('\n')
        for line in lines:
            self.parse_line(line)
        return f"Loaded program with {len(self.program)} lines"
    
    def save_program(self):
        """Save the current program as a string"""
        if not self.program:
            return ""
        
        lines = []
        for line_num in sorted(self.program.keys()):
            lines.append(f"{line_num} {self.program[line_num]}")
        return "\n".join(lines)
