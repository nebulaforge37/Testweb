
import os
import time
import random
import sys
import curses

from game_database import GameDatabase

class RetroGames:
    def __init__(self):
        self.games = {
            "pong": self.play_pong,
            "breakout": self.play_breakout,
            "asteroids": self.play_asteroids
        }
        self.game_db = GameDatabase()
    
    def list_games(self):
        """Return a list of available games"""
        return list(self.games.keys())
        
    def list_classic_games(self, era=None):
        """Return a list of classic games from the database"""
        if era:
            return self.game_db.get_games_by_era(era)
        return self.game_db.get_all_games()
    
    def show_game_info(self, game_id):
        """Display information about a specific classic game"""
        game = self.game_db.get_game_details(game_id)
        if game:
            return f"Title: {game['name']}\nYear: {game['year']}\nPlatform: {game['platform']}\nType: {game['type']}"
        return "Game not found in database."
    
    def play_game(self, game_name):
        """Launch the specified game"""
        game_name = game_name.lower()
        if game_name in self.games:
            return self.games[game_name]()
        else:
            print(f"Game '{game_name}' not found!")
            return False
    
    def play_pong(self):
        """Simple text-based Pong game"""
        try:
            # Initialize curses
            stdscr = curses.initscr()
            curses.curs_set(0)  # Hide cursor
            curses.noecho()     # Don't echo key presses
            curses.cbreak()     # React to keys instantly
            stdscr.keypad(True) # Enable special keys
            stdscr.timeout(100) # Set getch() timeout to 100ms
            
            # Get screen dimensions
            height, width = stdscr.getmaxyx()
            
            # Initialize game state
            paddle_height = 4
            left_paddle_y = height // 2 - paddle_height // 2
            right_paddle_y = height // 2 - paddle_height // 2
            ball_x, ball_y = width // 2, height // 2
            dx, dy = -1, 1
            score_left = 0
            score_right = 0
            
            # Game loop
            while True:
                # Clear screen
                stdscr.clear()
                
                # Draw paddles
                for i in range(paddle_height):
                    stdscr.addch(left_paddle_y + i, 2, '|')
                    stdscr.addch(right_paddle_y + i, width - 3, '|')
                
                # Draw ball
                stdscr.addch(ball_y, ball_x, 'O')
                
                # Draw scores
                stdscr.addstr(0, width // 4, f"Player 1: {score_left}")
                stdscr.addstr(0, width // 4 * 3, f"Player 2: {score_right}")
                
                # Draw instructions
                stdscr.addstr(height - 1, 2, "W/S: Left paddle  Up/Down: Right paddle  Q: Quit")
                
                # Update screen
                stdscr.refresh()
                
                # Get user input
                key = stdscr.getch()
                
                # Process input
                if key == ord('q'):
                    break
                elif key == ord('w') and left_paddle_y > 1:
                    left_paddle_y -= 1
                elif key == ord('s') and left_paddle_y < height - paddle_height - 1:
                    left_paddle_y += 1
                elif key == curses.KEY_UP and right_paddle_y > 1:
                    right_paddle_y -= 1
                elif key == curses.KEY_DOWN and right_paddle_y < height - paddle_height - 1:
                    right_paddle_y += 1
                
                # Move ball
                ball_x += dx
                ball_y += dy
                
                # Ball collision with top/bottom walls
                if ball_y <= 1 or ball_y >= height - 2:
                    dy = -dy
                
                # Ball collision with paddles
                if ball_x == 3 and left_paddle_y <= ball_y <= left_paddle_y + paddle_height:
                    dx = -dx
                elif ball_x == width - 4 and right_paddle_y <= ball_y <= right_paddle_y + paddle_height:
                    dx = -dx
                
                # Ball out of bounds - scoring
                if ball_x <= 1:
                    score_right += 1
                    ball_x, ball_y = width // 2, height // 2
                    dx, dy = random.choice([1, -1]), random.choice([1, -1])
                    time.sleep(1)
                elif ball_x >= width - 2:
                    score_left += 1
                    ball_x, ball_y = width // 2, height // 2
                    dx, dy = random.choice([1, -1]), random.choice([1, -1])
                    time.sleep(1)
                
                # Check for winner
                if score_left >= 5 or score_right >= 5:
                    stdscr.clear()
                    winner = "Player 1" if score_left >= 5 else "Player 2"
                    stdscr.addstr(height // 2, width // 2 - 10, f"{winner} wins! Final score: {score_left}-{score_right}")
                    stdscr.refresh()
                    time.sleep(3)
                    break
            
            return True
            
        except Exception as e:
            return False
        finally:
            # Clean up curses
            if 'stdscr' in locals():
                stdscr.keypad(False)
                curses.nocbreak()
                curses.echo()
                curses.endwin()
    
    def play_breakout(self):
        """Simple text-based Breakout game"""
        try:
            # Initialize curses
            stdscr = curses.initscr()
            curses.curs_set(0)  # Hide cursor
            curses.noecho()     # Don't echo key presses
            curses.cbreak()     # React to keys instantly
            stdscr.keypad(True) # Enable special keys
            stdscr.timeout(100) # Set getch() timeout to 100ms
            
            # Get screen dimensions
            height, width = stdscr.getmaxyx()
            
            # Initialize game state
            paddle_width = 6
            paddle_x = width // 2 - paddle_width // 2
            paddle_y = height - 2
            ball_x, ball_y = width // 2, height - 3
            dx, dy = random.choice([1, -1]), -1
            score = 0
            lives = 3
            
            # Create bricks
            bricks = []
            for y in range(3, 8):
                for x in range(5, width - 5, 2):
                    bricks.append([y, x, 1])  # y, x, visible
            
            # Game loop
            while lives > 0:
                # Clear screen
                stdscr.clear()
                
                # Draw paddle
                for i in range(paddle_width):
                    stdscr.addch(paddle_y, paddle_x + i, '=')
                
                # Draw ball
                stdscr.addch(ball_y, ball_x, 'O')
                
                # Draw bricks
                for brick in bricks:
                    if brick[2]:  # If brick is visible
                        stdscr.addch(brick[0], brick[1], '#')
                
                # Draw score and lives
                stdscr.addstr(0, 2, f"Score: {score}")
                stdscr.addstr(0, width - 15, f"Lives: {lives}")
                
                # Draw instructions
                stdscr.addstr(height - 1, 2, "Left/Right: Move paddle  Q: Quit")
                
                # Update screen
                stdscr.refresh()
                
                # Get user input
                key = stdscr.getch()
                
                # Process input
                if key == ord('q'):
                    break
                elif key == curses.KEY_LEFT and paddle_x > 0:
                    paddle_x -= 1
                elif key == curses.KEY_RIGHT and paddle_x < width - paddle_width:
                    paddle_x += 1
                
                # Move ball
                ball_x += dx
                ball_y += dy
                
                # Ball collision with walls
                if ball_x <= 0 or ball_x >= width - 1:
                    dx = -dx
                if ball_y <= 0:
                    dy = -dy
                
                # Ball collision with paddle
                if ball_y == paddle_y and paddle_x <= ball_x < paddle_x + paddle_width:
                    dy = -dy
                    # Adjust horizontal direction based on where ball hits paddle
                    paddle_middle = paddle_x + paddle_width // 2
                    if ball_x < paddle_middle:
                        dx = -1
                    else:
                        dx = 1
                
                # Ball collision with bricks
                for brick in bricks:
                    if brick[2] and brick[0] == ball_y and brick[1] == ball_x:
                        brick[2] = 0  # Make brick invisible
                        dy = -dy
                        score += 10
                
                # Ball out of bounds
                if ball_y >= height - 1:
                    lives -= 1
                    ball_x, ball_y = width // 2, height - 3
                    dx, dy = random.choice([1, -1]), -1
                    time.sleep(1)
                
                # Check for win
                if all(not brick[2] for brick in bricks):
                    stdscr.clear()
                    stdscr.addstr(height // 2, width // 2 - 15, f"You win! Final score: {score}")
                    stdscr.refresh()
                    time.sleep(3)
                    break
            
            # Game over
            if lives <= 0:
                stdscr.clear()
                stdscr.addstr(height // 2, width // 2 - 15, f"Game over! Final score: {score}")
                stdscr.refresh()
                time.sleep(3)
            
            return True
            
        except Exception as e:
            return False
        finally:
            # Clean up curses
            if 'stdscr' in locals():
                stdscr.keypad(False)
                curses.nocbreak()
                curses.echo()
                curses.endwin()
    
    def play_asteroids(self):
        """Simple text-based Asteroids game"""
        try:
            # Initialize curses
            stdscr = curses.initscr()
            curses.curs_set(0)  # Hide cursor
            curses.noecho()     # Don't echo key presses
            curses.cbreak()     # React to keys instantly
            stdscr.keypad(True) # Enable special keys
            stdscr.timeout(100) # Set getch() timeout to 100ms
            
            # Get screen dimensions
            height, width = stdscr.getmaxyx()
            
            # Initialize game state
            ship_y, ship_x = height // 2, width // 2
            asteroids = []
            bullets = []
            score = 0
            lives = 3
            level = 1
            
            # Create initial asteroids
            for _ in range(5):
                # Random position at the edge of the screen
                if random.choice([True, False]):
                    # Horizontal edge
                    y = random.choice([1, height - 2])
                    x = random.randint(1, width - 2)
                else:
                    # Vertical edge
                    y = random.randint(1, height - 2)
                    x = random.choice([1, width - 2])
                
                # Random direction towards center
                dy = 1 if y == 1 else -1 if y == height - 2 else 0
                dx = 1 if x == 1 else -1 if x == width - 2 else 0
                
                asteroids.append([y, x, dy, dx])
            
            # Game loop
            while lives > 0:
                # Clear screen
                stdscr.clear()
                
                # Draw ship
                stdscr.addch(ship_y, ship_x, '^')
                
                # Draw asteroids
                for ast in asteroids:
                    stdscr.addch(ast[0], ast[1], '*')
                
                # Draw bullets
                for bullet in bullets:
                    stdscr.addch(bullet[0], bullet[1], '.')
                
                # Draw score and lives
                stdscr.addstr(0, 2, f"Score: {score}")
                stdscr.addstr(0, width - 15, f"Lives: {lives}")
                stdscr.addstr(0, width // 2 - 5, f"Level: {level}")
                
                # Draw instructions
                stdscr.addstr(height - 1, 2, "Arrows: Move  Space: Shoot  Q: Quit")
                
                # Update screen
                stdscr.refresh()
                
                # Get user input
                key = stdscr.getch()
                
                # Process input
                if key == ord('q'):
                    break
                elif key == curses.KEY_UP and ship_y > 1:
                    ship_y -= 1
                elif key == curses.KEY_DOWN and ship_y < height - 2:
                    ship_y += 1
                elif key == curses.KEY_LEFT and ship_x > 0:
                    ship_x -= 1
                elif key == curses.KEY_RIGHT and ship_x < width - 1:
                    ship_x += 1
                elif key == ord(' '):
                    # Fire bullet
                    bullets.append([ship_y - 1, ship_x, -1, 0])  # y, x, dy, dx
                
                # Move bullets
                for bullet in bullets[:]:
                    bullet[0] += bullet[2]
                    bullet[1] += bullet[3]
                    
                    # Remove bullets that are out of bounds
                    if bullet[0] < 0 or bullet[0] >= height or bullet[1] < 0 or bullet[1] >= width:
                        bullets.remove(bullet)
                
                # Move asteroids
                for ast in asteroids[:]:
                    ast[0] += ast[2]
                    ast[1] += ast[3]
                    
                    # Wrap asteroids around screen
                    if ast[0] < 1:
                        ast[0] = height - 2
                    elif ast[0] >= height - 1:
                        ast[0] = 1
                    if ast[1] < 1:
                        ast[1] = width - 2
                    elif ast[1] >= width - 1:
                        ast[1] = 1
                
                # Check for bullet-asteroid collisions
                for bullet in bullets[:]:
                    for ast in asteroids[:]:
                        if bullet[0] == ast[0] and bullet[1] == ast[1]:
                            if bullet in bullets:
                                bullets.remove(bullet)
                            if ast in asteroids:
                                asteroids.remove(ast)
                            score += 20
                
                # Check for ship-asteroid collisions
                for ast in asteroids[:]:
                    if ship_y == ast[0] and ship_x == ast[1]:
                        lives -= 1
                        if lives > 0:
                            time.sleep(1)
                            ship_y, ship_x = height // 2, width // 2
                
                # Level progression
                if not asteroids:
                    level += 1
                    # Add more asteroids for next level
                    for _ in range(level * 3):
                        # Random position at the edge of the screen
                        if random.choice([True, False]):
                            # Horizontal edge
                            y = random.choice([1, height - 2])
                            x = random.randint(1, width - 2)
                        else:
                            # Vertical edge
                            y = random.randint(1, height - 2)
                            x = random.choice([1, width - 2])
                        
                        # Random direction towards center
                        dy = random.choice([-1, 0, 1])
                        dx = random.choice([-1, 0, 1])
                        if dy == 0 and dx == 0:  # Ensure movement
                            dy = random.choice([-1, 1])
                        
                        asteroids.append([y, x, dy, dx])
                    
                    # Show level message
                    stdscr.clear()
                    stdscr.addstr(height // 2, width // 2 - 10, f"Level {level} - Get ready!")
                    stdscr.refresh()
                    time.sleep(2)
            
            # Game over
            if lives <= 0:
                stdscr.clear()
                stdscr.addstr(height // 2, width // 2 - 15, f"Game over! Final score: {score}")
                stdscr.refresh()
                time.sleep(3)
            
            return True
            
        except Exception as e:
            return False
        finally:
            # Clean up curses
            if 'stdscr' in locals():
                stdscr.keypad(False)
                curses.nocbreak()
                curses.echo()
                curses.endwin()
