
class GameDatabase:
    def __init__(self):
        self.classic_games = {
            # 8-bit era games
            "pacman": {"name": "Pac-Man", "year": 1980, "platform": "Arcade/Atari", "type": "Maze"},
            "space_invaders": {"name": "Space Invaders", "year": 1978, "platform": "Arcade/Atari", "type": "Shooter"},
            "donkey_kong": {"name": "Donkey Kong", "year": 1981, "platform": "Arcade/NES", "type": "Platform"},
            "galaga": {"name": "Galaga", "year": 1981, "platform": "Arcade", "type": "Shooter"},
            "frogger": {"name": "Frogger", "year": 1981, "platform": "Arcade", "type": "Action"},
            "tetris": {"name": "Tetris", "year": 1984, "platform": "Various", "type": "Puzzle"},
            "bubble_bobble": {"name": "Bubble Bobble", "year": 1986, "platform": "Arcade/NES", "type": "Platform"},
            "bomberman": {"name": "Bomberman", "year": 1983, "platform": "NES/MSX", "type": "Action"},
            "dig_dug": {"name": "Dig Dug", "year": 1982, "platform": "Arcade", "type": "Action"},
            "defender": {"name": "Defender", "year": 1981, "platform": "Arcade", "type": "Shooter"},
            
            # 16-bit era games
            "sonic": {"name": "Sonic the Hedgehog", "year": 1991, "platform": "Genesis/Mega Drive", "type": "Platform"},
            "street_fighter_2": {"name": "Street Fighter II", "year": 1991, "platform": "Arcade/SNES", "type": "Fighting"},
            "mortal_kombat": {"name": "Mortal Kombat", "year": 1992, "platform": "Arcade/Genesis", "type": "Fighting"},
            "zelda_alttp": {"name": "The Legend of Zelda: A Link to the Past", "year": 1991, "platform": "SNES", "type": "Action-Adventure"},
            "super_metroid": {"name": "Super Metroid", "year": 1994, "platform": "SNES", "type": "Action-Adventure"},
            "final_fantasy_6": {"name": "Final Fantasy VI", "year": 1994, "platform": "SNES", "type": "RPG"},
            "chrono_trigger": {"name": "Chrono Trigger", "year": 1995, "platform": "SNES", "type": "RPG"},
            "castlevania_sotn": {"name": "Castlevania: Symphony of the Night", "year": 1997, "platform": "PlayStation", "type": "Action-RPG"},
            "mega_man_x": {"name": "Mega Man X", "year": 1993, "platform": "SNES", "type": "Action-Platform"},
            "earthworm_jim": {"name": "Earthworm Jim", "year": 1994, "platform": "Genesis/SNES", "type": "Platform"}
        }
    
    def get_game_details(self, game_id):
        """Return details for a specific game"""
        return self.classic_games.get(game_id, None)
    
    def get_all_games(self):
        """Return all games in the database"""
        return self.classic_games
    
    def get_games_by_era(self, era):
        """Return games filtered by 8-bit or 16-bit era"""
        if era == "8bit":
            return {k: v for k, v in self.classic_games.items() if v.get("year", 0) < 1990}
        elif era == "16bit":
            return {k: v for k, v in self.classic_games.items() if v.get("year", 0) >= 1990}
        return {}
    
    def get_games_by_type(self, game_type):
        """Return games filtered by type"""
        return {k: v for k, v in self.classic_games.items() if v.get("type", "") == game_type}
