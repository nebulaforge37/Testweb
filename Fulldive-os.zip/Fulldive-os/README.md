
# FullDive Machine Simulator

A retro computing system simulator with modern PS5-like features, implementing a nostalgic yet futuristic virtual machine experience.

## Features

- **BIOS System**: Complete with POST (Power-On Self Test) sequence
- **FullDive OS**: Custom operating system with both retro and modern interfaces
- **File Management**: Directory listings, file viewing, and editing
- **Memory Card System**: Insert, remove, format and view memory cards
- **Hardware Monitoring**: View detailed hardware specifications
- **Settings Menu**: Configure display, sound, network, and other system settings
- **Retro Games**: Play simple text-based games like Pong, Breakout, and Asteroids
- **BASIC Programming**: Create and run simple BASIC programs

## Usage

1. Run the simulator with `python main.py`
2. Experience the BIOS boot sequence
3. Navigate the OS using the commands listed in the help system
4. Type `HELP` at any time to see available commands

## Commands

- `DIR` - List files
- `TYPE <filename>` - Display file content
- `CLS` - Clear screen
- `GAME <number>` - Run a game (1: Pong, 2: Breakout, 3: Asteroids)
- `EDIT [filename]` - Launch code editor
- `DISPLAY` - Show display settings
- `SET_DISPLAY` - Change display settings
- `HARDWARE` - Show hardware information
- `MEMORY_CARDS` - Manage memory cards
- `SETTINGS` - Open PS5-style settings menu
- `DOS` - Enter DOS menu
- `GALLERY` - View and create ASCII art
- `EXIT` - Quit FullDive OS

## Project Structure

The system consists of two main classes:
- `FullDiveBIOS`: Handles system initialization and hardware checks
- `FullDiveOS`: Provides the operating system interface and all functionality

## Future Enhancements

- Audio and sound effects
- Video playback capabilities
- Graphical user interface with boot loader animation
