
import os
import time
import curses
import sys

class XboxDashboard:
    def __init__(self):
        self.tiles = [
            {"name": "Home", "icon": "🏠", "color": 1},
            {"name": "Games", "icon": "🎮", "color": 2},
            {"name": "Media", "icon": "🎬", "color": 3},
            {"name": "Settings", "icon": "⚙️", "color": 4},
            {"name": "Store", "icon": "🛒", "color": 5},
            {"name": "Terminal", "icon": "💻", "color": 6}
        ]
        
        self.game_items = ["Pong", "Breakout", "Asteroids", "Game Database"]
        self.media_items = ["ASCII Gallery", "Sound Test", "Visualizer"]
        self.settings_items = ["Display", "Sound", "System", "Storage"]
        self.terminal_items = ["BASIC", "DOS", "Command Line"]
        
        self.selected_tile = 0
        self.menu_open = False
        self.selected_item = 0
        self.current_items = []
        
    def setup_colors(self):
        """Initialize color pairs for the dashboard"""
        curses.start_color()
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)  # Home
        curses.init_pair(2, curses.COLOR_CYAN, curses.COLOR_BLACK)   # Games
        curses.init_pair(3, curses.COLOR_MAGENTA, curses.COLOR_BLACK)  # Media
        curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLACK)  # Settings
        curses.init_pair(5, curses.COLOR_RED, curses.COLOR_BLACK)    # Store
        curses.init_pair(6, curses.COLOR_BLUE, curses.COLOR_BLACK)   # Terminal
        curses.init_pair(7, curses.COLOR_WHITE, curses.COLOR_BLACK)  # Default
    
    def draw_dashboard(self, stdscr):
        """Draw the Xbox Series X style dashboard"""
        # Clear screen
        stdscr.clear()
        
        # Get screen dimensions
        height, width = stdscr.getmaxyx()
        
        # Draw title
        title = "FullDive Xbox Dashboard"
        stdscr.addstr(1, (width - len(title)) // 2, title, curses.A_BOLD | curses.color_pair(7))
        
        # Draw horizontal tiles
        tile_y = 4
        for i, tile in enumerate(self.tiles):
            x_pos = (width // 2) - 21 + (i * 7)
            
            # Skip if out of screen bounds
            if x_pos < 0 or x_pos > width - 7:
                continue
                
            # Draw tile with appropriate color
            attrs = curses.A_BOLD if i == self.selected_tile else 0
            color = curses.color_pair(tile["color"])
            
            # Draw tile box
            for y in range(5):
                for x in range(6):
                    if y == 0 or y == 4 or x == 0 or x == 5:
                        stdscr.addch(tile_y + y, x_pos + x, '█', attrs | color)
            
            # Draw tile icon
            stdscr.addstr(tile_y + 2, x_pos + 2, tile["icon"], attrs | color)
            
            # Draw tile name
            name_pos = x_pos + (6 - len(tile["name"])) // 2
            stdscr.addstr(tile_y + 6, name_pos, tile["name"], attrs | color)
        
        # Draw submenu if open
        if self.menu_open:
            menu_y = tile_y + 8
            menu_width = 30
            menu_x = (width - menu_width) // 2
            
            # Draw menu box
            for y in range(len(self.current_items) + 2):
                for x in range(menu_width):
                    if y == 0 or y == len(self.current_items) + 1 or x == 0 or x == menu_width - 1:
                        stdscr.addch(menu_y + y, menu_x + x, '█', curses.color_pair(self.tiles[self.selected_tile]["color"]))
            
            # Draw menu title
            menu_title = self.tiles[self.selected_tile]["name"]
            title_pos = menu_x + (menu_width - len(menu_title)) // 2
            stdscr.addstr(menu_y, title_pos, menu_title, curses.color_pair(self.tiles[self.selected_tile]["color"]) | curses.A_BOLD)
            
            # Draw menu items
            for i, item in enumerate(self.current_items):
                if i == self.selected_item:
                    stdscr.addstr(menu_y + i + 1, menu_x + 2, f"> {item}", curses.A_BOLD | curses.color_pair(self.tiles[self.selected_tile]["color"]))
                else:
                    stdscr.addstr(menu_y + i + 1, menu_x + 2, f"  {item}", curses.color_pair(7))
        
        # Draw navigation help
        help_text = "← → to switch tiles | ↑ ↓ to navigate menu | Enter to select | Q to quit"
        # Only display help text if it fits within the screen width
        if len(help_text) < width:
            try:
                stdscr.addstr(height - 1, max(0, (width - len(help_text)) // 2), help_text, curses.color_pair(7))
            except curses.error:
                # Silently handle any remaining curses errors related to screen boundaries
                pass
        
        # Refresh screen
        stdscr.refresh()
    
    def run(self, fulldiveis=None):
        """Run the Xbox dashboard interface"""
        def _curses_main(stdscr):
            # Set up curses
            curses.curs_set(0)  # Hide cursor
            stdscr.timeout(100)  # Non-blocking input
            
            # Setup colors
            self.setup_colors()
            
            # Main loop
            while True:
                # Draw the dashboard
                self.draw_dashboard(stdscr)
                
                # Get user input
                key = stdscr.getch()
                
                # Process input
                if key == ord('q'):
                    break
                elif key == curses.KEY_LEFT:
                    if self.menu_open:
                        self.menu_open = False
                    else:
                        self.selected_tile = max(0, self.selected_tile - 1)
                elif key == curses.KEY_RIGHT:
                    if self.menu_open:
                        self.menu_open = False
                    else:
                        self.selected_tile = min(len(self.tiles) - 1, self.selected_tile + 1)
                elif key == curses.KEY_UP and self.menu_open:
                    self.selected_item = max(0, self.selected_item - 1)
                elif key == curses.KEY_DOWN and self.menu_open:
                    self.selected_item = min(len(self.current_items) - 1, self.selected_item + 1)
                elif key == 10:  # Enter key
                    if not self.menu_open:
                        # Open submenu
                        self.menu_open = True
                        self.selected_item = 0
                        
                        # Set current items based on selected tile
                        tile_name = self.tiles[self.selected_tile]["name"]
                        if tile_name == "Games":
                            self.current_items = self.game_items
                        elif tile_name == "Media":
                            self.current_items = self.media_items
                        elif tile_name == "Settings":
                            self.current_items = self.settings_items
                        elif tile_name == "Terminal":
                            self.current_items = self.terminal_items
                        elif tile_name == "Home":
                            self.current_items = ["Profile", "Dashboard", "Recent"]
                        elif tile_name == "Store":
                            self.current_items = ["Games", "Apps", "Demos"]
                    else:
                        # Selected an item from the menu
                        # Exit curses temporarily to execute action
                        stdscr.clear()
                        stdscr.refresh()
                        curses.endwin()
                        
                        # Execute selected item
                        self.execute_item(fulldiveis)
                        
                        # Wait for a keypress before returning to dashboard
                        print("\nPress Enter to return to Xbox Dashboard...")
                        input()
                        
                        # Reinitialize curses
                        stdscr.clear()
                        curses.curs_set(0)
        
        # Start curses application
        curses.wrapper(_curses_main)
    
    def execute_item(self, os_instance):
        """Execute the selected menu item"""
        tile_name = self.tiles[self.selected_tile]["name"]
        item = self.current_items[self.selected_item]
        
        print(f"\nExecuting: {tile_name} > {item}")
        
        # If no OS instance is provided, just show a message
        if not os_instance:
            print("OS instance not provided. This is just a demonstration.")
            time.sleep(1)
            return
        
        # Handle different menu selections
        if tile_name == "Games":
            if item in ["Pong", "Breakout", "Asteroids"]:
                os_instance.cmd_game([item.lower()])
            elif item == "Game Database":
                os_instance.cmd_game(["LIST"])
        
        elif tile_name == "Media":
            if item == "ASCII Gallery":
                os_instance.cmd_gallery([])
            elif item == "Sound Test":
                os_instance.cmd_sound([])
        
        elif tile_name == "Settings":
            if item == "Display":
                os_instance.cmd_set_display([])
            elif item == "Sound":
                os_instance.cmd_sound([])
            elif item == "System":
                os_instance.cmd_hardware([])
            elif item == "Storage":
                os_instance.cmd_memory_cards([])
        
        elif tile_name == "Terminal":
            if item == "BASIC":
                os_instance.cmd_basic([])
            elif item == "DOS":
                os_instance.cmd_dos([])
            elif item == "Command Line":
                print("Returning to command line interface...")
        
        # Add more handlers as needed
        else:
            print(f"Action for {item} not implemented yet")
            time.sleep(1)
