
import os
import time
import curses
import sys

class XMBGui:
    def __init__(self):
        self.categories = [
            "Games", "Media", "Settings", "Network", "Users", "Terminal"
        ]
        
        self.items = {
            "Games": ["Pong", "Breakout", "Asteroids", "Game Database"],
            "Media": ["ASCII Gallery", "Sound Test", "Visualizer"],
            "Settings": ["Display", "Sound", "System", "Storage"],
            "Network": ["Status", "Setup", "Browser"],
            "Users": ["Profile", "Login", "Create User"],
            "Terminal": ["BASIC", "DOS", "Command Line"]
        }
        
        self.descriptions = {
            "Pong": "Classic two-player paddle game",
            "Breakout": "Break blocks with a bouncing ball",
            "Asteroids": "Destroy asteroids in space",
            "Game Database": "Browse classic retro games",
            "ASCII Gallery": "View ASCII art collection",
            "Sound Test": "Test system sound effects",
            "Visualizer": "Audio visualization effects",
            "Display": "Change resolution and colors",
            "Sound": "Adjust volume and sound effects",
            "System": "System information and updates",
            "Storage": "Manage memory cards and storage",
            "Status": "Check network connection status",
            "Setup": "Configure network settings",
            "Browser": "Simple text-based web browser",
            "Profile": "View and edit user profile",
            "Login": "Switch between user accounts",
            "Create User": "Create a new user account",
            "BASIC": "BASIC programming language",
            "DOS": "DOS command interface",
            "Command Line": "Advanced terminal commands"
        }
        
        self.icons = {
            "Games": "🎮",
            "Media": "🎬",
            "Settings": "⚙️",
            "Network": "🌐",
            "Users": "👤",
            "Terminal": "💻",
        }
        
        self.selected_category = 0
        self.selected_item = 0
        
    def draw_xmb(self, stdscr):
        """Draw the XMB interface"""
        # Clear screen
        stdscr.clear()
        
        # Get screen dimensions
        height, width = stdscr.getmaxyx()
        
        # Draw title
        title = "FullDive XMB GUI"
        stdscr.addstr(1, (width - len(title)) // 2, title, curses.A_BOLD)
        
        # Draw horizontal categories
        category_y = height // 3
        for i, category in enumerate(self.categories):
            x_pos = (width // 2) + (i - self.selected_category) * 15
            
            # Skip if out of screen bounds
            if x_pos < 0 or x_pos > width - len(category):
                continue
                
            # Draw category
            if i == self.selected_category:
                stdscr.addstr(category_y, x_pos, f"{self.icons.get(category, '*')} {category}", curses.A_BOLD)
            else:
                stdscr.addstr(category_y, x_pos, f"{self.icons.get(category, '*')} {category}")
        
        # Draw vertical items for selected category
        if self.selected_category < len(self.categories):
            category = self.categories[self.selected_category]
            items = self.items.get(category, [])
            
            for i, item in enumerate(items):
                y_pos = (height // 2) + (i - self.selected_item) * 2
                
                # Skip if out of screen bounds
                if y_pos < 0 or y_pos >= height:
                    continue
                    
                # Draw item
                if i == self.selected_item:
                    stdscr.addstr(y_pos, width // 4, f"> {item}", curses.A_BOLD)
                else:
                    stdscr.addstr(y_pos, width // 4, f"  {item}")
            
            # Draw description for selected item
            if items and 0 <= self.selected_item < len(items):
                item = items[self.selected_item]
                description = self.descriptions.get(item, "No description available")
                
                # Draw in a box at the bottom
                desc_y = height - 4
                stdscr.addstr(desc_y, 4, "Description:", curses.A_BOLD)
                stdscr.addstr(desc_y + 1, 4, description[:width-8])
        
        # Draw navigation help
        help_text = "Arrow keys to navigate | Enter to select | Q to quit"
        # Only display help text if it fits within the screen width
        if len(help_text) < width:
            try:
                stdscr.addstr(height - 1, max(0, (width - len(help_text)) // 2), help_text)
            except curses.error:
                # Silently handle any remaining curses errors related to screen boundaries
                pass
        
        # Refresh screen
        stdscr.refresh()
    
    def run(self, fulldiveis=None):
        """Run the XMB interface"""
        def _curses_main(stdscr):
            # Set up curses
            curses.curs_set(0)  # Hide cursor
            stdscr.timeout(100)  # Non-blocking input
            
            # Enable colors if available
            if curses.has_colors():
                curses.start_color()
                curses.init_pair(1, curses.COLOR_CYAN, curses.COLOR_BLACK)
                curses.init_pair(2, curses.COLOR_GREEN, curses.COLOR_BLACK)
                stdscr.bkgd(' ', curses.color_pair(1))
            
            # Main loop
            while True:
                # Draw the XMB
                self.draw_xmb(stdscr)
                
                # Get user input
                key = stdscr.getch()
                
                # Process input
                if key == ord('q'):
                    break
                elif key == curses.KEY_LEFT:
                    self.selected_category = max(0, self.selected_category - 1)
                    self.selected_item = 0
                elif key == curses.KEY_RIGHT:
                    self.selected_category = min(len(self.categories) - 1, self.selected_category + 1)
                    self.selected_item = 0
                elif key == curses.KEY_UP:
                    self.selected_item = max(0, self.selected_item - 1)
                elif key == curses.KEY_DOWN:
                    category = self.categories[self.selected_category]
                    items = self.items.get(category, [])
                    self.selected_item = min(len(items) - 1, self.selected_item + 1)
                elif key == 10:  # Enter key
                    # Handle selection
                    category = self.categories[self.selected_category]
                    if self.selected_item < len(self.items.get(category, [])):
                        item = self.items[category][self.selected_item]
                        
                        # Clear screen before returning to main program
                        stdscr.clear()
                        stdscr.refresh()
                        
                        # Exit curses mode temporarily
                        curses.endwin()
                        
                        # Execute the selected action
                        self.execute_item(category, item, fulldiveis)
                        
                        # Wait for a keypress before returning to XMB
                        print("\nPress Enter to return to XMB...")
                        input()
                        
                        # Reinitialize curses
                        stdscr.clear()
                        curses.curs_set(0)
        
        # Start curses application
        curses.wrapper(_curses_main)
    
    def execute_item(self, category, item, os_instance):
        """Execute the selected item's action"""
        print(f"\nExecuting: {category} > {item}")
        
        # If no OS instance is provided, just show a message
        if not os_instance:
            print("OS instance not provided. This is just a demonstration.")
            time.sleep(1)
            return
        
        # Handle different categories
        if category == "Games":
            if item in ["Pong", "Breakout", "Asteroids"]:
                os_instance.cmd_game([item.lower()])
            elif item == "Game Database":
                os_instance.cmd_game(["LIST"])
                
        elif category == "Media":
            if item == "ASCII Gallery":
                os_instance.cmd_gallery([])
            elif item == "Sound Test":
                os_instance.cmd_sound([])
            
        elif category == "Settings":
            if item == "Display":
                os_instance.cmd_set_display([])
            elif item == "Sound":
                os_instance.cmd_sound([])
            elif item == "System":
                os_instance.cmd_hardware([])
            elif item == "Storage":
                os_instance.cmd_memory_cards([])
            
        elif category == "Terminal":
            if item == "BASIC":
                os_instance.cmd_basic([])
            elif item == "DOS":
                os_instance.cmd_dos([])
            elif item == "Command Line":
                print("Returning to command line interface...")
                
        # Add more category handlers as needed
        else:
            print(f"Action for {item} not implemented yet")
            time.sleep(1)
