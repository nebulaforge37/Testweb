
class ASCIIArtGallery:
    def __init__(self):
        self.gallery = {
            "computer": """
              .----.
              |    |
              |    |
         _____|    |_____
        |                |
        |                |
        |                |
        |                |
        |                |
        |                |
        |                |
        |________________|
        |                |
        |                |
        |                |
        |                |
        |                |
        |                |
        |________________|
            """,
            "house": """
                  /\\
                 /  \\
                /    \\
               /      \\
              /        \\
             /__________\\
             |  ___     |
             | |___|    |
             |__________|
            """,
            "cat": """
       /\\     /\\
      {  `---'  }
      {  O   O  }
      ~~>  V  <~~
       \\  \\|/  /
        `-----'__
        /     \\__)
       (    /    |
        \\__/    /
         \\_____/
            """,
            "spaceship": """
             /\\
            /  \\
           |    |
           |    |
           |    |
          /|    |\\
         / |    | \\
        /__|____|__\\
           |  |
           |__|
           """,
            "heart": """
     .:::.   .:::.
    :::::::.:::::::
    :::::::::::::::
    ':::::::::::::'
      ':::::::::'
        ':::::'
          ':'
            """
        }
        self.user_gallery = {}
        
    def display_menu(self):
        """Display the ASCII Art Gallery menu"""
        print("\nASCII Art Gallery")
        print("=" * 40)
        print("1. Browse Gallery")
        print("2. View Art")
        print("3. Create New Art")
        print("4. Edit Existing Art")
        print("5. Delete Art")
        print("0. Exit Gallery")
        
    def browse_gallery(self):
        """Show available ASCII art"""
        print("\nBuilt-in Gallery:")
        for i, name in enumerate(sorted(self.gallery.keys())):
            print(f"  {i+1}. {name}")
        
        if self.user_gallery:
            print("\nYour Gallery:")
            for i, name in enumerate(sorted(self.user_gallery.keys())):
                print(f"  {i+1}. {name}")
        else:
            print("\nYour Gallery is empty. Create some art!")
    
    def view_art(self, name):
        """Display selected ASCII art"""
        if name in self.gallery:
            print(f"\n{name.upper()}:")
            print(self.gallery[name])
            return True
        elif name in self.user_gallery:
            print(f"\n{name.upper()} (Your Creation):")
            print(self.user_gallery[name])
            return True
        else:
            print(f"Art '{name}' not found.")
            return False
    
    def create_art(self, name, content=None):
        """Create new ASCII art"""
        if name in self.gallery or name in self.user_gallery:
            print(f"Art with name '{name}' already exists!")
            return False
        
        if content is None:
            print("\nCreate your ASCII art below:")
            print("Enter your art line by line. Type 'DONE' on a new line when finished.")
            lines = []
            while True:
                line = input()
                if line.strip().upper() == 'DONE':
                    break
                lines.append(line)
            content = "\n".join(lines)
        
        self.user_gallery[name] = content
        print(f"Art '{name}' saved to your gallery!")
        return True
    
    def edit_art(self, name):
        """Edit existing ASCII art"""
        if name in self.user_gallery:
            print(f"\nCurrently editing: {name}")
            print(self.user_gallery[name])
            print("\nEnter your new art line by line. Type 'DONE' on a new line when finished.")
            
            lines = []
            while True:
                line = input()
                if line.strip().upper() == 'DONE':
                    break
                lines.append(line)
            
            self.user_gallery[name] = "\n".join(lines)
            print(f"Art '{name}' updated!")
            return True
        else:
            print(f"You can only edit art in your gallery. '{name}' not found.")
            return False
    
    def delete_art(self, name):
        """Delete user-created ASCII art"""
        if name in self.user_gallery:
            confirm = input(f"Are you sure you want to delete '{name}'? (y/n): ").lower()
            if confirm == 'y':
                del self.user_gallery[name]
                print(f"Art '{name}' deleted.")
                return True
            else:
                print("Deletion canceled.")
                return False
        else:
            print(f"You can only delete art in your gallery. '{name}' not found.")
            return False
    
    def run(self):
        """Run the ASCII Art Gallery interface"""
        while True:
            self.display_menu()
            choice = input("Select option: ")
            
            if choice == "0":
                print("Exiting ASCII Art Gallery...")
                break
            elif choice == "1":
                self.browse_gallery()
            elif choice == "2":
                name = input("Enter art name to view: ").lower()
                self.view_art(name)
            elif choice == "3":
                name = input("Enter name for new art: ").lower()
                self.create_art(name)
            elif choice == "4":
                name = input("Enter art name to edit: ").lower()
                self.edit_art(name)
            elif choice == "5":
                name = input("Enter art name to delete: ").lower()
                self.delete_art(name)
            else:
                print("Invalid choice.")
