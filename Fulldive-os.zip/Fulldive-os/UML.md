
# FullDive Machine Simulator UML

## Class Diagram

```
+------------------+        
| FullDiveBIOS     |        
+------------------+        
| - memory_size    |        
| - cpu_type       |        
| - rom_version    |        
| - modern_hardware|        
+------------------+        
| + run()          |        
+------------------+        
         |
         | initializes
         v
+------------------+        
| FullDiveOS       |        
+------------------+        
| - running        |        
| - current_drive  |        
| - bit_mode       |        
| - resolution     |        
| - memory_cards   |        
| - hardware       |        
| - settings       |        
| - drives         |        
| - dos_mode       |        
+------------------+        
| + boot_sequence()|        
| + list_files()   |        
| + show_file()    |        
| + run_game()     |        
| + clear_screen() |        
| + dos_menu()     |        
| + change_drive() |        
| + run_ide()      |        
| + format_disk()  |        
| + delete_file()  |        
| + rename_file()  |        
| + manage_memory_cards() |
| + show_hardware_info() |
| + ps5_settings_menu() |
| + set_display_settings() |
| + run()          |        
+------------------+        
```

## Sequence Diagram (Boot Process)

```
User     FullDiveBIOS     FullDiveOS
 |           |                |
 |--run()-->|                |
 |           |--POST Tests-->|
 |           |<--Success-----|
 |           |                |
 |           |--------------->|
 |           |   initialize   |
 |           |                |
 |           |                |--boot_sequence()-->|
 |           |                |                    |
 |           |                |<--OS Ready---------|
 |           |                |
 |--command->|                |
 |           |                |--process_command()-->|
 |           |                |<--command_result-----|
 |           |                |
```

## Component Diagram

```
+---------------------+     +------------------------+
|                     |     |                        |
|  BIOS Subsystem     |---->|  Operating System      |
|                     |     |                        |
+---------------------+     +------------------------+
                                       |
                                       |
                            +----------v-----------+
                            |                      |
                            |  File System Manager |
                            |                      |
                            +----------------------+
                                       |
                   +---------+---------+---------+
                   |         |         |         |
         +---------v--+ +----v-----+ +-v--------+ +-------v------+
         |            | |          | |          | |              |
         | Text Editor| | DOS Menu | | Settings | | Memory Cards |
         |            | |          | |          | |              |
         +------------+ +----------+ +----------+ +--------------+
```

## State Diagram (OS States)

```
    +-------------+
    | System Boot |
    +-------------+
           |
           v
    +-------------+
    | BIOS POST   |
    +-------------+
           |
           v
    +-------------+                    +------------+
    | OS Running  |<------------------>| DOS Mode   |
    +-------------+                    +------------+
      ^   |    ^                          |
      |   |    |                          |
      |   v    |                          v
+-----+---+ +--+--------+            +------------+
| Settings | | Game Mode |           | File Ops   |
+---------+ +-----------+           +------------+
```
