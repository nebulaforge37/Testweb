
import random
import time
import os

class BotLogoGenerator:
    def __init__(self):
        self.logos = {
            "classic": [
                r"""
  ______      _ _ _____  _            ____   ____ _____
 |  ____|    | | |  __ \(_)          |  _ \ / __ \_   _|
 | |__ _   _ | | | |  | |_  __   __  | |_) | |  | || |
 |  __| | | || | | |  | | | \ \ / /  |  _ <| |  | || |
 | |  | |_| || | | |__| | |  \ V /   | |_) | |__| || |_
 |_|   \__,_||_|_|_____/|_|   \_/    |____/ \____/_____|
                """,
                r"""
  _____     _ _ ____  _            ____   ___ _____
 |  ___|   | | |  _ \(_)_   _____ | __ ) / _ \_   _|
 | |_ _   _| | | | | | \ \ / / _ \|  _ \| | | || |
 |  _| | | | | | |_| | |\ V /  __/| |_) | |_| || |
 |_|  |_|_|_|_|____/|_| \_/ \___|____/ \___/ |_|
                """
            ],
            "minimalist": [
                r"""
 _______     ___ _    ___ _____   _____ 
|_   _| |   | _ ) |  / _ \_   _| |_   _|
  | | | |__ | _ \ |_| (_) || |     | |  
  |_| |____|___/___|\___/ |_|     |_|  
                """,
                r"""
 +-+-+-+-+-+-+-+ +-+-+-+
 |F|u|l|l|D|i|v|e| |B|o|t|
 +-+-+-+-+-+-+-+ +-+-+-+
                """
            ],
            "cyberpunk": [
                r"""
 ╔═══╗╔╗──╔╗╔═══╗╔═══╗╔╗──╔╗╔═══╗  ╔═══╗╔═══╗╔════╗
 ║╔══╝║║──║║║╔═╗║║╔═╗║║╚╗╔╝║║╔══╝  ║╔══╝║╔═╗║║╔╗╔╗║
 ║╚══╗║║──║║║║─║║║║─║║╚╗║║╔╝║╚══╗  ║╚══╗║║─║║╚╝║║╚╝
 ║╔══╝║║──║║║╚═╝║║║─║║─║╚╝║─║╔══╝  ║╔══╝║║─║║──║║──
 ║║───║╚═╗║║║╔═╗║║╚═╝║─╚╗╔╝─║╚══╗  ║║───║╚═╝║──║║──
 ╚╝───╚══╝╚╝╚╝─╚╝╚═══╝──╚╝──╚═══╝  ╚╝───╚═══╝──╚╝──
                """,
                r"""
 ┏━━━┓╋╋┏┓╋╋┏┓┏━━━┓┏━━━┓╋╋┏┓╋╋┏┓┏━━━┓  ┏━━┓┏━━━┓┏━━━┓
 ┃┏━━┛╋╋┃┃╋╋┃┃┃┏━┓┃┃┏━┓┃╋╋┃┃╋╋┃┃┃┏━┓┃  ┃┏┓┃┃┏━┓┃┃┏━┓┃
 ┃┗━━┓╋╋┃┃╋╋┃┃┃┃╋┃┃┃┃╋┃┃╋╋┃┃╋╋┃┃┃┗━┛┃  ┃┗┛┃┃┃╋┃┃┃┗━━┓
 ┃┏━━┛╋╋┃┃╋╋┃┃┃┗━┛┃┃┃╋┃┃╋╋┃┗━━┛┃┃┏━━┛  ┃┏━┛┃┃╋┃┃┗━━┓┃
 ┃┃╋╋╋╋╋┃┗━━┛┃┃┏━┓┃┃┗━┛┃╋╋┗━━━━┛┃┃╋╋╋  ┃┃╋╋┃┗━┛┃┃┗━┛┃
 ┗┛╋╋╋╋╋┗━━━━┛┗┛╋┗┛┗━━━┛╋╋╋╋╋╋╋╋┗┛╋╋╋  ┗┛╋╋┗━━━┛┗━━━┛
                """
            ],
            "retro": [
                r"""
 oooooooooooo             oooo oooo       oooooooooo.   o8o                         oooooooooo.                     .
 `888'     `8             `888 `888       `888'   `Y8b  `"'                         `888'   `Y8b                  .o8
  888          oooo  oooo   888  888        888      888 oooo  oooo    ooo  .ooooo.  888     888  .ooooo.  .oooo888
  888oooo8     `888  `888   888  888        888      888 `888   `88b..8P'  d88' `88b 888oooo888' d88' `88bd88' `888
  888    "      888   888   888  888        888      888  888     Y888P    888   888 888    `88b 888   888888   888
  888           888   888   888  888        888     d88'  888   .o8"'88b   888   888 888    .88P 888   888888   888
 o888o          `V88V"V8P' o888o o888o     o888bood8P'   o888o o88'   888o`Y8bod8P' o888bood8P'  `Y8bod8P'`Y8bod88P"
                """,
                r"""
 8888888888        888 888 8888888b. d8b                 888888b.            888    
 888               888 888 888  "Y88b88                  888  "88b           888    
 888               888 888 888    888Y8P                 888  .88P           888    
 8888888  888  888 888 888 888    888    888  888 .d88b. 8888888K.   .d88b. 888888 
 888      888  888 888 888 888    888    888  888d8P  Y8b888  "Y88b d88""88b888    
 888      888  888 888 888 888    888    Y88  88P88888888888    888 888  888888    
 888      Y88b 888 888 888 888  .d88P     Y8bd8P Y8b.    888   d88P Y88..88PY88b.  
 888       "Y88888 888 888 8888888P"       Y88P   "Y8888 8888888P"   "Y88P"  "Y888
                """
            ]
        }
        
        self.colors = {
            "default": "\033[0m",
            "blue": "\033[94m",
            "green": "\033[92m",
            "yellow": "\033[93m",
            "red": "\033[91m",
            "magenta": "\033[95m",
            "cyan": "\033[96m"
        }
        
    def get_random_logo(self, style=None):
        """Get a random logo, optionally of a specific style"""
        if style and style in self.logos:
            return random.choice(self.logos[style])
        
        # Get a random style if none specified
        random_style = random.choice(list(self.logos.keys()))
        return random.choice(self.logos[random_style])
    
    def display_logo(self, style=None, color=None, animate=False):
        """Display a logo with optional animation"""
        logo = self.get_random_logo(style)
        
        # Get color
        color_code = self.colors.get(color, self.colors["default"])
        if not color:
            # Random color if none specified
            color_code = random.choice(list(self.colors.values()))
        
        if animate:
            self._animate_logo(logo, color_code)
        else:
            print(f"{color_code}{logo}\033[0m")
    
    def _animate_logo(self, logo, color):
        """Animate the logo appearance"""
        os.system('cls' if os.name == 'nt' else 'clear')
        
        # Split into lines for animation
        lines = logo.strip('\n').split('\n')
        for i in range(len(lines)):
            os.system('cls' if os.name == 'nt' else 'clear')
            for j in range(i + 1):
                print(f"{color}{lines[j]}\033[0m")
            time.sleep(0.1)
        
        # Hold for a moment
        time.sleep(0.5)
    
    def list_styles(self):
        """List all available logo styles"""
        return list(self.logos.keys())
    
    def list_colors(self):
        """List all available colors"""
        return list(self.colors.keys())

if __name__ == "__main__":
    # Test the logo generator
    logo_gen = BotLogoGenerator()
    
    print("Available styles:")
    for style in logo_gen.list_styles():
        print(f"- {style}")
    
    print("\nAvailable colors:")
    for color in logo_gen.list_colors():
        print(f"- {color}")
    
    print("\nDisplaying random logo:")
    logo_gen.display_logo(animate=True)
    
    input("\nPress Enter to see more logos...")
    
    for style in logo_gen.list_styles():
        print(f"\nStyle: {style}")
        logo_gen.display_logo(style=style, color="cyan")
        time.sleep(1)
