import os
import time
import random
import sys
import curses
from datetime import datetime
from terminal import AdvancedTerminal
from games import RetroGames
from basic_interpreter import BasicInterpreter
from ascii_gallery import ASCIIArtGallery
from sound_system import SoundSystem
from xmb_gui import XMBGui
from xbox_dashboard import XboxDashboard
from firmware_updater import FirmwareUpdater

class FullDiveBIOS:
    def __init__(self):
        self.version = "1.0.0"
        self.hardware = {
            "CPU": "RetroCore 8086X",
            "RAM": "16 GB",
            "Storage": "1 TB SSD",
            "Display": "1080p HD",
            "Audio": "64-bit PCM"
        }

    def run_bootloader(self):
        """Display bootloader animation"""
        os.system('cls' if os.name == 'nt' else 'clear')
        frames = [
            "▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒░░░░░░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░░░░░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░░░░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░░░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒░",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒",
        ]

        # Sound simulation
        print("\a")  # Bell character for a beep

        for i in range(len(frames)):
            os.system('cls' if os.name == 'nt' else 'clear')
            print("\n\n")
            print("\033[36m" + "FullDive BIOS Loading..." + "\033[0m")
            print("\n")
            print("\033[32m" + frames[i] + "\033[0m")
            print("\n")
            print(f"Loading... {i*10}%")
            time.sleep(0.3)

            # Add some beeps at key points
            if i == 3 or i == 7:
                print("\a")  # Bell character for a beep

        time.sleep(0.5)
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\033[32m" + """
  _____     _ _ ____  _            ____  _____ ___  ____  
 |  ___|   | | |  _ \(_)_   _____ | __ )|_   _/ _ \/ ___| 
 | |_ _   _| | | | | | \ \ / / _ \|  _ \  | || | | \___ \ 
 |  _| | | | | | |_| | |\ V /  __/| |_) | | || |_| |___) |
 |_|  |_|_|_|_|____/|_| \_/ \___|____/  |_| \___/|____/ 
        """ + "\033[0m")
        time.sleep(1)

    def run_post(self):
        """Power-On Self Test sequence"""
        # Run bootloader animation first
        self.run_bootloader()

        os.system('cls' if os.name == 'nt' else 'clear')
        print("\033[32m" + "FullDive BIOS v" + self.version + "\033[0m")
        print("=" * 50)
        print("Initializing system...")
        time.sleep(0.5)

        components = ["CPU", "Memory", "Storage", "Display", "Audio"]
        for component in components:
            print(f"Testing {component}... ", end="", flush=True)
            time.sleep(random.uniform(0.2, 0.7))
            print("\033[32mOK\033[0m")

        print("\nHardware detected:")
        for key, value in self.hardware.items():
            print(f"  - {key}: {value}")

        print("\nPOST completed successfully.")
        print("Press any key to boot FullDive OS...")
        input()
        return True


class FullDiveOS:
    def __init__(self):
        self.version = "2.0"
        self.username = "User"
        self.current_dir = "C:\\"
        self.files = {
            "C:\\README.TXT": "Welcome to FullDive OS!\nType HELP for commands.",
            "C:\\HELLO.BAS": "10 PRINT \"HELLO WORLD\"\n20 END",
            "C:\\GAMES\\PONG.BAS": "# Pong game would be here",
            "C:\\GAMES\\BREAKOUT.BAS": "# Breakout game would be here",
            "C:\\GAMES\\ASTEROIDS.BAS": "# Asteroids game would be here"
        }
        self.memory_cards = {
            "SLOT1": {"inserted": False, "name": None, "capacity": "8MB", "used": "0MB"},
            "SLOT2": {"inserted": False, "name": None, "capacity": "8MB", "used": "0MB"}
        }
        self.display_settings = {"mode": "text", "color": "green", "resolution": "80x25"}
        self.command_history = []

        # Initialize advanced components
        self.terminal = AdvancedTerminal()
        self.games = RetroGames()
        self.basic = BasicInterpreter()
        self.ascii_gallery = ASCIIArtGallery()
        self.sound_system = SoundSystem()
        self.xmb_gui = XMBGui()
        self.xbox_dashboard = XboxDashboard()
        self.firmware_updater = FirmwareUpdater()

        # Initialize console manager
        from console_manager import ConsoleManager
        self.console_manager = ConsoleManager()

        # Initialize logo generator
        from bot_logo import BotLogoGenerator
        self.logo_generator = BotLogoGenerator()

    def boot(self):
        # Play startup sound
        self.sound_system.play_startup()

        os.system('cls' if os.name == 'nt' else 'clear')
        print("\033[32m" + """
 ______      _ _ _____  _            ____   _____ 
|  ____|    | | |  __ \(_)          / __ \ / ____|
| |__ _   _ | | | |  | |___   _____| |  | | (___  
|  __| | | || | | |  | | \ \ / / _ \ |  | |\___ \ 
| |  | |_| || | | |__| | |\ V /  __/ |__| |____) |
|_|   \__,_||_|_|_____/|_| \_/ \___|\____/|_____/ 
        """ + "\033[0m")
        print(f"Version {self.version} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 60)
        print(f"Welcome, {self.username}!")
        print("Type HELP for available commands.")
        print()

        self.main_loop()

    def main_loop(self):
        while True:
            command = input(f"\033[32m{self.current_dir}>\033[0m ").strip().upper()
            if command:
                self.command_history.append(command)
                self.process_command(command)

    def process_command(self, command):
        parts = command.split()
        cmd = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        commands = {
            "HELP": self.cmd_help,
            "DIR": self.cmd_dir,
            "TYPE": self.cmd_type,
            "CLS": self.cmd_cls,
            "EXIT": self.cmd_exit,
            "GAME": self.cmd_game,
            "EDIT": self.cmd_edit,
            "DISPLAY": self.cmd_display,
            "SET_DISPLAY": self.cmd_set_display,
            "HARDWARE": self.cmd_hardware,
            "MEMORY_CARDS": self.cmd_memory_cards,
            "SETTINGS": self.cmd_settings,
            "SOUND": self.cmd_sound,
            "DOS": self.cmd_dos,
            "BASIC": self.cmd_basic,
            "HISTORY": self.cmd_history,
            "TERMINAL": self.cmd_terminal,
            "GALLERY": self.cmd_gallery,
            "XMB": self.cmd_xmb,
            "XBOX": self.cmd_xbox,
            "CONSOLE": self.cmd_console,
            "FIRMWARE": self.cmd_firmware,
            "LOGO": self.cmd_logo
        }

        if cmd in commands:
            commands[cmd](args)
        else:
            print(f"Unknown command: {cmd}")
            print("Type HELP for a list of commands.")

    def cmd_help(self, args):
        print("\nAvailable commands:")
        print("  HELP        - Show this help")
        print("  DIR         - List files")
        print("  TYPE <file> - Display file content")
        print("  CLS         - Clear screen")
        print("  GAME <name> - Run a game (PONG, BREAKOUT, ASTEROIDS)")
        print("  GAME LIST  - Show list of classic 8-bit and 16-bit games")
        print("  GAME INFO  - Show details about a specific classic game")
        print("  EDIT [file] - Launch code editor")
        print("  DISPLAY     - Show display settings")
        print("  SET_DISPLAY - Change display settings")
        print("  HARDWARE    - Show hardware information")
        print("  MEMORY_CARDS- Manage memory cards")
        print("  SOUND       - Configure sound settings")
        print("  SETTINGS    - Open settings menu")
        print("  TERMINAL    - Terminal color and behavior settings")
        print("  DOS         - Enter DOS menu")
        print("  BASIC [file]- Launch BASIC interpreter")
        print("  GALLERY     - ASCII Art Gallery")
        print("  HISTORY     - Show command history")
        print("  XMB         - Launch XMB graphical interface")
        print("  XBOX        - Launch Xbox dashboard interface")
        print("  CONSOLE     - Console pane settings and toolbar")
        print("  FIRMWARE    - Check and update system firmware")
        print("  LOGO        - Display FullDive Bot logo")
        print("  EXIT        - Quit FullDive OS")
        print()

    def cmd_dir(self, args):
        print("\nDirectory of", self.current_dir)
        print("=" * 40)

        dir_files = {path.split('\\')[-1]: size 
                    for path, size in [
                        (path, len(content)) 
                        for path, content in self.files.items() 
                        if path.startswith(self.current_dir)
                    ]}

        if dir_files:
            for name, size in dir_files.items():
                print(f"{name.ljust(20)} {size} bytes")
        else:
            print("No files found.")
        print()

    def cmd_type(self, args):
        if not args:
            print("Usage: TYPE <filename>")
            return

        filename = args[0]
        full_path = self.current_dir + filename if self.current_dir.endswith('\\') else self.current_dir + '\\' + filename

        if full_path in self.files:
            print("\n" + self.files[full_path] + "\n")
        else:
            print(f"File not found: {filename}")

    def cmd_cls(self, args):
        os.system('cls' if os.name == 'nt' else 'clear')

    def cmd_exit(self, args):
        print("Shutting down FullDive OS...")
        self.sound_system.play_shutdown()
        time.sleep(1)
        sys.exit(0)

    def cmd_game(self, args):
        if not args:
            print("Usage: GAME <name>")
            print("Available playable games:")
            print("  PONG - Classic Pong")
            print("  BREAKOUT - Brick breaker game")
            print("  ASTEROIDS - Avoid or shoot asteroids")
            print("\nAdditional commands:")
            print("  GAME LIST - Show list of classic 8-bit and 16-bit games")
            print("  GAME INFO <game_id> - Show info about a specific classic game")
            return

        if args[0].upper() == "LIST":
            era = args[1].lower() if len(args) > 1 else None
            games = self.games.list_classic_games(era)

            print("\nClassic Video Game Database:")
            print("=" * 50)

            if era:
                print(f"Showing {era} era games:\n")

            for game_id, details in games.items():
                print(f"{details['name']} ({details['year']}) - {details['type']}")

            print("\nUse 'GAME INFO <game_id>' to see more details about a specific game")
            return

        elif args[0].upper() == "INFO" and len(args) > 1:
            game_id = args[1].lower()
            info = self.games.show_game_info(game_id)
            print("\n" + info)
            return

        game_name = args[0].lower()
        game_map = {"1": "pong", "2": "breakout", "3": "asteroids", 
                   "pong": "pong", "breakout": "breakout", "asteroids": "asteroids"}

        if game_name in game_map:
            print(f"\nLaunching {game_map[game_name].title()}...")
            print("Use arrow keys to move, space to shoot (in Asteroids)")
            print("Press Q to quit the game")
            time.sleep(2)

            # Run the game
            self.games.play_game(game_map[game_name])

            # Clear screen after game ends
            os.system('cls' if os.name == 'nt' else 'clear')
        else:
            print(f"Game '{game_name}' not found. Try PONG, BREAKOUT, or ASTEROIDS.")

    def cmd_edit(self, args):
        filename = args[0] if args else None

        if filename:
            full_path = self.current_dir + filename if self.current_dir.endswith('\\') else self.current_dir + '\\' + filename
            content = self.files.get(full_path, "")
        else:
            full_path = None
            content = ""

        print("\nSimple Text Editor")
        print("=" * 40)
        print("Enter text (type END on a new line to save and exit):")

        if content:
            print(content)

        lines = []
        while True:
            line = input()
            if line == "END":
                break
            lines.append(line)

        if full_path:
            self.files[full_path] = "\n".join(lines)
            print(f"File saved: {filename}")
        else:
            print("No filename specified. File not saved.")

    def cmd_display(self, args):
        print("\nCurrent Display Settings:")
        print("=" * 40)
        for key, value in self.display_settings.items():
            print(f"{key.capitalize()}: {value}")
        print()

    def cmd_set_display(self, args):
        print("\nDisplay Settings:")
        print("1. Mode (text/graphics)")
        print("2. Color (green/amber/white/blue)")
        print("3. Resolution (80x25/132x43)")
        print("0. Back")

        choice = input("Select option: ")

        if choice == "1":
            mode = input("Enter mode (text/graphics): ").lower()
            if mode in ["text", "graphics"]:
                self.display_settings["mode"] = mode
                print("Mode updated.")
            else:
                print("Invalid mode.")
        elif choice == "2":
            color = input("Enter color (green/amber/white/blue): ").lower()
            if color in ["green", "amber", "white", "blue"]:
                self.display_settings["color"] = color
                print("Color updated.")
            else:
                print("Invalid color.")
        elif choice == "3":
            res = input("Enter resolution (80x25/132x43/1080p): ").lower()
            if res in ["80x25", "132x43", "1080p"]:
                self.display_settings["resolution"] = res
                print("Resolution updated.")
            else:
                print("Invalid resolution.")

    def cmd_hardware(self, args):
        print("\nHardware Information:")
        print("=" * 40)
        hardware = {
            "CPU": "RetroCore 8086X",
            "Speed": "4.77 MHz",
            "RAM": "16 GB",
            "Storage": "1 TB SSD",
            "Display": "1080p HD",
            "Audio": "64-bit PCM",
            "IO Ports": "Serial, Parallel",
            "Firmware": f"v{self.firmware_updater.current_version}"
        }

        for key, value in hardware.items():
            print(f"{key.ljust(15)}: {value}")
        print()

    def cmd_memory_cards(self, args):
        print("\nMemory Card Management:")
        print("=" * 40)
        print("1. View memory cards")
        print("2. Insert memory card")
        print("3. Remove memory card")
        print("4. Format memory card")
        print("0. Back")

        choice = input("Select option: ")

        if choice == "1":
            print("\nMemory Card Status:")
            for slot, info in self.memory_cards.items():
                status = f"{info['name']} ({info['used']}/{info['capacity']})" if info["inserted"] else "Empty"
                print(f"{slot}: {status}")

        elif choice == "2":
            slot = input("Enter slot (SLOT1/SLOT2): ").upper()
            if slot in self.memory_cards:
                if not self.memory_cards[slot]["inserted"]:
                    name = input("Enter memory card name: ")
                    self.memory_cards[slot]["inserted"] = True
                    self.memory_cards[slot]["name"] = name
                    print(f"Memory card {name} inserted into {slot}.")
                else:
                    print(f"{slot} already has a memory card inserted.")
            else:
                print("Invalid slot.")

        elif choice == "3":
            slot = input("Enter slot (SLOT1/SLOT2): ").upper()
            if slot in self.memory_cards and self.memory_cards[slot]["inserted"]:
                name = self.memory_cards[slot]["name"]
                self.memory_cards[slot]["inserted"] = False
                self.memory_cards[slot]["name"] = None
                print(f"Memory card {name} removed from {slot}.")
            else:
                print("No memory card in that slot or invalid slot.")

        elif choice == "4":
            slot = input("Enter slot (SLOT1/SLOT2): ").upper()
            if slot in self.memory_cards and self.memory_cards[slot]["inserted"]:
                confirm = input(f"Format memory card in {slot}? (y/n): ").lower()
                if confirm == 'y':
                    self.memory_cards[slot]["used"] = "0MB"
                    print(f"Memory card in {slot} formatted.")
                else:
                    print("Formatting cancelled.")
            else:
                print("No memory card in that slot.")

    def cmd_sound(self, args):
        """Sound system management"""
        print("\nSound System Settings:")
        print("=" * 40)
        print("1. Toggle sound (On/Off)")
        print("2. Set volume (0-10)")
        print("3. Change sound theme")
        print("4. Play test sound")
        print("5. Show current settings")
        print("0. Back")

        choice = input("Select option: ")

        if choice == "1":
            enabled = self.sound_system.toggle_sound()
            status = "enabled" if enabled else "disabled"
            print(f"Sound is now {status}")
            if enabled:
                self.sound_system.play_startup()

        elif choice == "2":
            try:
                level = int(input("Enter volume level (0-10): "))
                if self.sound_system.set_volume(level):
                    print(f"Volume set to {level}")
                    if level > 0:
                        self.sound_system.play_beep()
                else:
                    print("Invalid volume level. Use 0-10.")
            except ValueError:
                print("Please enter a number between 0 and 10.")

        elif choice == "3":
            print("\nAvailable sound themes:")
            themes = self.sound_system.get_themes()
            for i, (name, desc) in enumerate(themes.items(), 1):
                print(f"{i}. {name} - {desc}")

            theme_choice = input("\nSelect theme: ").lower()
            if theme_choice in themes:
                self.sound_system.set_theme(theme_choice)
                print(f"Theme set to '{theme_choice}'")
                self.sound_system.play_startup()
            else:
                try:
                    idx = int(theme_choice) - 1
                    if 0 <= idx < len(themes):
                        theme_name = list(themes.keys())[idx]
                        self.sound_system.set_theme(theme_name)
                        print(f"Theme set to '{theme_name}'")
                        self.sound_system.play_startup()
                    else:
                        print("Invalid selection.")
                except ValueError:
                    print("Invalid selection.")

        elif choice == "4":
            print("Playing test sounds...")
            print("Beep:")
            self.sound_system.play_beep()
            time.sleep(0.5)

            print("Startup:")
            self.sound_system.play_startup()
            time.sleep(0.5)

            print("Error:")
            self.sound_system.play_error()
            time.sleep(0.5)

            print("Shutdown:")
            self.sound_system.play_shutdown()

        elif choice == "5":
            status = self.sound_system.get_sound_status()
            print("\nCurrent Sound Settings:")
            for key, value in status.items():
                print(f"{key.capitalize()}: {value}")
        else:
            print("Invalid option.")

    def cmd_xmb(self, args):
        """Launch the XMB GUI interface"""
        print("\nLaunching XMB Graphical Interface...")
        time.sleep(1)
        self.xmb_gui.run(self)
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Returned to command line interface.")

    def cmd_logo(self, args):
        """Display the FullDive Bot logo"""
        if not args:
            print("\nDisplaying random FullDive Bot logo:")
            self.logo_generator.display_logo(animate=True)
            return

        if args[0].upper() == "LIST":
            print("\nAvailable logo styles:")
            for style in self.logo_generator.list_styles():
                print(f"- {style}")
            print("\nAvailable colors:")
            for color in self.logo_generator.list_colors():
                print(f"- {color}")
            return

        style = args[0].lower() if args and args[0].lower() in self.logo_generator.list_styles() else None
        color = args[1].lower() if len(args) > 1 and args[1].lower() in self.logo_generator.list_colors() else None

        animate = True
        if len(args) > 2 and args[2].lower() == "static":
            animate = False

        self.logo_generator.display_logo(style=style, color=color, animate=animate)


    def cmd_settings(self, args):
        while True:
            print("\nSettings:")
            print("=" * 40)
            print("1. Display")
            print("2. Sound")
            print("3. Network")
            print("4. User Preferences")
            print("5. System Information")
            print("6. Firmware Update")
            print("0. Back")

            choice = input("Select option: ")

            if choice == "0":
                break
            elif choice == "1":
                self.cmd_set_display([])
            elif choice == "2":
                self.cmd_sound([])
            elif choice == "6":
                self.cmd_firmware([])
            elif choice in ["3", "4", "5"]:
                print("\nThis settings section is under development.")
                input("Press Enter to continue...")
            else:
                print("Invalid option.")

    def cmd_console(self, args):
        """Manage console settings and toolbar"""
        if not args:
            print("\nConsole Manager")
            print("=" * 40)
            print("1. Console Settings")
            print("2. Toggle Toolbar")
            print("3. Run in Visual Mode")
            print("0. Back")

            choice = input("Select option: ")

            if choice == "1":
                print("\nLaunching console settings...")
                os.system('cls' if os.name == 'nt' else 'clear')
                curses.wrapper(self._console_settings)
            elif choice == "2":
                is_visible = self.console_manager.toggle_toolbar()
                print(f"Toolbar is now {'visible' if is_visible else 'hidden'}")
            elif choice == "3":
                print("\nLaunching visual console mode...")
                time.sleep(1)
                os.system('cls' if os.name == 'nt' else 'clear')
                curses.wrapper(self._run_visual_console)
        else:
            subcmd = args[0].upper()
            if subcmd == "SETTINGS":
                os.system('cls' if os.name == 'nt' else 'clear')
                curses.wrapper(self._console_settings)
            elif subcmd == "TOOLBAR":
                is_visible = self.console_manager.toggle_toolbar()
                print(f"Toolbar is now {'visible' if is_visible else 'hidden'}")
            elif subcmd == "VISUAL":
                os.system('cls' if os.name == 'nt' else 'clear')
                curses.wrapper(self._run_visual_console)
            else:
                print(f"Unknown console subcommand: {subcmd}")

    def _console_settings(self, stdscr):
        """Show console settings dialog"""
        self.console_manager.show_settings_dialog(stdscr)

    def _run_visual_console(self, stdscr):
        """Run the console in visual mode with toolbar"""
        curses.curs_set(1)  # Show cursor
        stdscr.clear()

        height, width = stdscr.getmaxyx()
        current_line = 0
        command_history = []
        current_command = ""
        cursor_pos = 0

        # Main visual console loop
        while True:
            # Clear screen
            stdscr.clear()

            # Draw toolbar if enabled
            if self.console_manager.toolbar_visible:
                self.console_manager.draw_toolbar(stdscr, width)
                prompt_start = 1  # Start prompt below toolbar
            else:
                prompt_start = 0  # Start prompt at top

            # Draw command history
            for i, cmd in enumerate(command_history[-height+3:]):
                if isinstance(cmd, tuple):  # This is a response
                    y_pos = prompt_start + i
                    stdscr.addstr(y_pos, 2, cmd[1])
                else:  # This is a command
                    y_pos = prompt_start + i
                    stdscr.addstr(y_pos, 0, f"{self.current_dir}> {cmd}")

            # Draw current command line
            prompt = f"{self.current_dir}> "
            stdscr.addstr(prompt_start + len(command_history[-height+3:]), 0, prompt)

            # Draw current command with cursor
            if cursor_pos == len(current_command):
                stdscr.addstr(current_command)
                # Place cursor at end of line
                stdscr.move(prompt_start + len(command_history[-height+3:]), len(prompt) + cursor_pos)
            else:
                stdscr.addstr(current_command[:cursor_pos])
                stdscr.addstr(current_command[cursor_pos:])
                # Place cursor at the right position
                stdscr.move(prompt_start + len(command_history[-height+3:]), len(prompt) + cursor_pos)

            # Refresh screen
            stdscr.refresh()

            # Get input
            key = stdscr.getch()

            # Process input
            if key == 27:  # Escape
                break
            elif key == 10:  # Enter
                if current_command:
                    # Add command to history
                    command_history.append(current_command)

                    # Process command and add response to history
                    response = self._process_visual_command(current_command)
                    if response:
                        command_history.append(("response", response))

                    # Clear current command
                    current_command = ""
                    cursor_pos = 0
            elif key == curses.KEY_BACKSPACE or key == 127:  # Backspace
                if cursor_pos > 0:
                    current_command = current_command[:cursor_pos-1] + current_command[cursor_pos:]
                    cursor_pos -= 1
            elif key == curses.KEY_DC:  # Delete
                if cursor_pos < len(current_command):
                    current_command = current_command[:cursor_pos] + current_command[cursor_pos+1:]
            elif key == curses.KEY_LEFT:
                cursor_pos = max(0, cursor_pos - 1)
            elif key == curses.KEY_RIGHT:
                cursor_pos = min(len(current_command), cursor_pos + 1)
            elif key == curses.KEY_UP:
                # TODO: Navigate command history
                pass
            elif key == curses.KEY_DOWN:
                # TODO: Navigate command history
                pass
            elif key == curses.KEY_F1:
                self.console_manager.toggle_toolbar()
            elif key == curses.KEY_F4:
                self.console_manager.show_settings_dialog(stdscr)
            elif 32 <= key <= 126:  # Printable ASCII
                current_command = current_command[:cursor_pos] + chr(key) + current_command[cursor_pos:]
                cursor_pos += 1

    def _process_visual_command(self, command):
        """Process a command in visual mode and return the response"""
        # This is a simplified version - in a real implementation, 
        # you would need to capture the output of self.process_command
        if command.upper() == "EXIT":
            return "Exiting visual console mode..."
        elif command.upper() == "HELP":
            return "Available commands: DIR, HELP, EXIT"
        elif command.upper() == "DIR":
            return "Directory listing would appear here"
        else:
            return f"Command not recognized: {command}"

    def cmd_terminal(self, args):
        print("\nTerminal Settings:")
        print("=" * 40)
        print("1. Color Scheme")
        print("2. Command History")
        print("0. Back")

        choice = input("Select option: ")

        if choice == "1":
            print("\nAvailable Color Schemes:")
            for i, scheme in enumerate(self.terminal.list_color_schemes()):
                print(f"{i+1}. {scheme}")

            scheme_choice = input("\nSelect color scheme: ")
            try:
                scheme_index = int(scheme_choice) - 1
                schemes = self.terminal.list_color_schemes()
                if 0 <= scheme_index < len(schemes):
                    scheme_name = schemes[scheme_index]
                    if self.terminal.set_color_scheme(scheme_name):
                        print(f"Color scheme changed to {scheme_name}.")
                    else:
                        print("Failed to change color scheme.")
                else:
                    print("Invalid selection.")
            except ValueError:
                print("Please enter a number.")

        elif choice == "2":
            limit = input("How many history entries to show? (Enter for all): ")
            try:
                if limit:
                    limit = int(limit)
                else:
                    limit = None
                self.terminal.show_command_history(limit)
            except ValueError:
                print("Please enter a number.")
                print("\nThis settings section is under development.")
                input("Press Enter to continue...")
            else:
                print("Invalid option.")

    def cmd_dos(self, args):
        print("\nFullDive DOS Interface")
        print("=" * 40)
        print("Type EXIT to return to FullDive OS")

        while True:
            cmd = input("DOS> ").strip().upper()
            if cmd == "EXIT":
                break
            elif cmd == "DIR":
                self.cmd_dir([])
            elif cmd.startswith("TYPE "):
                self.cmd_type([cmd.split()[1]])
            elif cmd == "CLS":
                self.cmd_cls([])
            elif cmd == "HELP":
                print("\nDOS Commands:")
                print("  DIR      - List files")
                print("  TYPE     - Display file content")
                print("  CLS      - Clear screen")
                print("  EXIT     - Return to FullDive OS")
            else:
                print(f"Unknown DOS command: {cmd}")

    def cmd_basic(self, args):
        print("\nBASIC Interpreter v1.0")
        print("=" * 40)
        print("Enter your BASIC program or commands:")
        print("- Line numbers (e.g., 10 PRINT \"HELLO\") add lines to the program")
        print("- RUN, LIST, NEW are immediate commands")
        print("- Type EXIT to return to FullDive OS")
        print()

        # Load a program file if specified
        if args:
            filename = args[0]
            full_path = self.current_dir + filename if self.current_dir.endswith('\\') else self.current_dir + '\\' + filename

            if full_path in self.files and full_path.upper().endswith(".BAS"):
                print(f"Loading program from {filename}...")
                self.basic.load_program(self.files[full_path])
                print("Program loaded. Type RUN to execute.")

        # BASIC interpreter loop
        while True:
            line = input("BASIC> ").strip()
            if line.upper() == "EXIT":
                break

            result = self.basic.parse_line(line)

            # Handle special case for INPUT
            if result and result.startswith("INPUT "):
                var_name = result[6:]
                value = input(f"? ")
                self.basic.handle_input(var_name, value)
            elif result:
                print(result)

    def cmd_history(self, args):
        print("\nCommand History:")
        for i, cmd in enumerate(self.command_history):
            print(f"{i+1}. {cmd}")
        print()

    def cmd_gallery(self, args):
        """Launch the ASCII Art Gallery"""
        print("\nLaunching ASCII Art Gallery...")
        self.ascii_gallery.run()

    def cmd_xbox(self, args):
        """Launch the Xbox dashboard interface"""
        print("\nLaunching Xbox Series X Dashboard Interface...")
        time.sleep(1)
        self.xbox_dashboard.run(self)
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Returned to command line interface.")

    def cmd_firmware(self, args):
        """Firmware update management"""
        if not args:
            print("\nFirmware Management")
            print("=" * 40)
            print("1. Check for updates")
            print("2. View update history")
            print("3. View current firmware information")
            print("4. Rollback to previous version")
            print("0. Back")

            choice = input("Select option: ")

            if choice == "1":
                self._firmware_check_and_update()
            elif choice == "2":
                self.firmware_updater.view_update_history()
            elif choice == "3":
                self._firmware_show_version_info()
            elif choice == "4":
                self.firmware_updater.rollback_update()
        else:
            subcmd = args[0].upper()
            if subcmd == "CHECK":
                self._firmware_check_and_update()
            elif subcmd == "HISTORY":
                self.firmware_updater.view_update_history()
            elif subcmd == "INFO":
                self._firmware_show_version_info()
            elif subcmd == "ROLLBACK":
                self.firmware_updater.rollback_update()
            else:
                print(f"Unknown firmware subcommand: {subcmd}")

    def _firmware_check_and_update(self):
        """Check for updates and potentially install them"""
        update_available = self.firmware_updater.check_for_updates()

        if not update_available:
            print(f"Your firmware is up to date (version {self.firmware_updater.current_version}).")
            return

        details = self.firmware_updater.get_update_details()

        print(f"\nFirmware update available: v{details['available_version']}")
        print(f"Current version: v{details['current_version']}")
        print(f"Update size: {details['size']}")
        print(f"Estimated installation time: {details['estimated_time']}")
        print("\nChangelog:")
        for change in details['changes']:
            print(f"- {change}")

        download = input("\nDo you want to download this update? (y/n): ").lower()
        if download != 'y':
            print("Update cancelled.")
            return

        if self.firmware_updater.download_update():
            install = input("\nDo you want to install this update now? (y/n): ").lower()
            if install != 'y':
                print("Update downloaded but not installed.")
                print("You can install it later using the FIRMWARE command.")
                return

            self.firmware_updater.install_update()
            restart = input("\nRestart system now to complete the update? (y/n): ").lower()
            if restart == 'y':
                print("Restarting system...")
                time.sleep(2)
                # Simulate a restart by clearing the screen and re-displaying the boot sequence
                os.system('cls' if os.name == 'nt' else 'clear')
                self.sound_system.play_shutdown()
                time.sleep(1)
                self.boot()

    def _firmware_show_version_info(self):
        """Display detailed information about the current firmware version"""
        info = self.firmware_updater.get_version_info()

        print("\nFirmware Information:")
        print("=" * 40)
        print(f"Version: v{info['version']}")
        print(f"Status: {info['status']}")
        print(f"Build date: {info['build_date']}")
        print(f"Installed date: {info['installed_date']}")
        print("\nFeatures and changes:")
        for change in info['changes']:
            print(f"- {change}")


def main():
    bios = FullDiveBIOS()
    if bios.run_post():
        os_system = FullDiveOS()
        os_system.boot()


if __name__ == "__main__":
    main()


class LogoGenerator:
    def __init__(self):
        self.logos = {
            "style1": ["  _.--""--._  ",
                       " /         \\",
                       "|  O     O  |",
                       "\\         /",
                       "  '-._.--'",
                       ],
            "style2": ["    _.--""--._    ",
                       "   /         \\   ",
                       "  |    .    |  ",
                       "  \\         /  ",
                       "   '-._.--'   ",
                       ],
            "style3": ["   .--""--.   ",
                       "  /        \\  ",
                       " |  ^ ^  | ",
                       " \\        / ",
                       "  '--'--'   ",
                       ]
        }
        self.colors = ["red", "green", "blue", "yellow", "cyan", "magenta"]

    def list_styles(self):
        return list(self.logos.keys())

    def list_colors(self):
        return self.colors

    def display_logo(self, style=None, color=None, animate=True):
        if style and style not in self.logos:
            print(f"Error: Logo style '{style}' not found.")
            return
        
        if color and color not in self.colors:
            print(f"Error: Color '{color}' not found.")
            return

        if style:
            logo = self.logos[style]
        else:
            logo = random.choice(list(self.logos.values()))

        if color:
            color_code = self.get_color_code(color)
        else:
            color_code = ""

        if animate:
            for line in logo:
                print(f"\033[{color_code}m{line}\033[0m")
                time.sleep(0.2)
        else:
            for line in logo:
                print(f"\033[{color_code}m{line}\033[0m")

    def get_color_code(self, color):
        color_map = {
            "red": "31",
            "green": "32",
            "blue": "34",
            "yellow": "33",
            "cyan": "36",
            "magenta": "35"
        }
        return color_map.get(color, "") #Default to no color if not found