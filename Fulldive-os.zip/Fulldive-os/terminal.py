
import os
import sys
import re
import readline

class AdvancedTerminal:
    def __init__(self):
        self.command_history = []
        self.max_history = 100
        self.color_schemes = {
            "default": {
                "prompt": "\033[32m",
                "text": "\033[0m",
                "error": "\033[31m",
                "success": "\033[32m",
                "highlight": "\033[36m"
            },
            "monochrome": {
                "prompt": "",
                "text": "",
                "error": "",
                "success": "",
                "highlight": ""
            },
            "amber": {
                "prompt": "\033[33m",
                "text": "\033[33m",
                "error": "\033[31m",
                "success": "\033[32m",
                "highlight": "\033[33;1m"
            },
            "matrix": {
                "prompt": "\033[32m",
                "text": "\033[32m",
                "error": "\033[31m",
                "success": "\033[32;1m",
                "highlight": "\033[32;1m"
            }
        }
        self.current_scheme = "default"
        self.initiate_readline()
        
    def initiate_readline(self):
        """Set up readline for command history and tab completion"""
        # Enable tab completion
        readline.parse_and_bind("tab: complete")
        
        # Set up custom completer
        readline.set_completer(self.completer)
        
    def completer(self, text, state):
        """Custom tab completer function"""
        commands = [
            "HELP", "DIR", "TYPE", "CLS", "EXIT", "GAME", "EDIT",
            "DISPLAY", "SET_DISPLAY", "HARDWARE", "MEMORY_CARDS",
            "SETTINGS", "DOS", "BASIC", "HISTORY"
        ]
        
        # Filter commands that start with the text
        matches = [cmd for cmd in commands if cmd.startswith(text.upper())]
        
        if state < len(matches):
            return matches[state]
        return None
        
    def input(self, prompt=""):
        """Enhanced input with colored prompt and history"""
        colored_prompt = f"{self.color_schemes[self.current_scheme]['prompt']}{prompt}{self.color_schemes[self.current_scheme]['text']}"
        user_input = input(colored_prompt)
        
        if user_input and len(self.command_history) < self.max_history:
            self.command_history.append(user_input)
        
        return user_input
    
    def print(self, text, style="text"):
        """Print with the specified style from the current color scheme"""
        if style in self.color_schemes[self.current_scheme]:
            color_code = self.color_schemes[self.current_scheme][style]
            print(f"{color_code}{text}{self.color_schemes[self.current_scheme]['text']}")
        else:
            print(text)
    
    def clear_screen(self):
        """Clear the terminal screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def set_color_scheme(self, scheme_name):
        """Change the current color scheme"""
        if scheme_name in self.color_schemes:
            self.current_scheme = scheme_name
            return True
        return False
    
    def list_color_schemes(self):
        """List all available color schemes"""
        return list(self.color_schemes.keys())
    
    def show_command_history(self, limit=None):
        """Display command history with optional limit"""
        limit = limit or len(self.command_history)
        for i, cmd in enumerate(self.command_history[-limit:]):
            self.print(f"{i+1}. {cmd}", "highlight")
