
import os
import time
import sys
import random

class SoundSystem:
    def __init__(self):
        self.sound_enabled = True
        self.volume = 5  # Scale of 0-10
        self.current_theme = "retro"
        self.themes = {
            "retro": "8-bit classic computing sounds",
            "modern": "High-fidelity digital sounds",
            "silent": "No sounds"
        }
    
    def toggle_sound(self):
        """Toggle sound on/off"""
        self.sound_enabled = not self.sound_enabled
        return self.sound_enabled
    
    def set_volume(self, level):
        """Set volume level (0-10)"""
        if 0 <= level <= 10:
            self.volume = level
            return True
        return False
    
    def set_theme(self, theme):
        """Set sound theme"""
        if theme in self.themes:
            self.current_theme = theme
            return True
        return False
    
    def get_themes(self):
        """Get list of available sound themes"""
        return self.themes
    
    def play_beep(self):
        """Play a simple beep if sound is enabled"""
        if self.sound_enabled and self.current_theme != "silent":
            repeats = max(1, self.volume // 3)  # Scale volume to number of beeps
            for _ in range(repeats):
                sys.stdout.write('\a')  # ASCII bell character
                sys.stdout.flush()
                time.sleep(0.1)
    
    def play_error(self):
        """Play error sound"""
        if self.sound_enabled and self.current_theme != "silent":
            for _ in range(2):
                sys.stdout.write('\a')
                sys.stdout.flush()
                time.sleep(0.2)
    
    def play_startup(self):
        """Play startup sound sequence"""
        if self.sound_enabled and self.current_theme != "silent":
            for i in range(3):
                sys.stdout.write('\a')
                sys.stdout.flush()
                time.sleep(0.15)
    
    def play_shutdown(self):
        """Play shutdown sound sequence"""
        if self.sound_enabled and self.current_theme != "silent":
            for i in range(3, 0, -1):
                sys.stdout.write('\a')
                sys.stdout.flush()
                time.sleep(0.2)
    
    def play_keypress(self):
        """Soft sound for keypresses"""
        # Terminal bell is too loud for keypresses
        # This is a placeholder - not actually making sound
        pass
    
    def play_command_success(self):
        """Play sound when command executes successfully"""
        if self.sound_enabled and self.current_theme != "silent":
            sys.stdout.write('\a')
            sys.stdout.flush()
    
    def get_sound_status(self):
        """Return current sound settings"""
        return {
            "enabled": self.sound_enabled,
            "volume": self.volume,
            "theme": self.current_theme
        }
