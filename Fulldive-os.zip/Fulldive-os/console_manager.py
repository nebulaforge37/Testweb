
import os
import curses
import time

class ConsoleManager:
    def __init__(self):
        self.toolbar_visible = True
        self.settings = {
            "font_size": "normal",   # small, normal, large
            "color_scheme": "default", # default, dark, light, retro
            "show_line_numbers": True,
            "word_wrap": True,
            "auto_indent": True,
            "scroll_speed": 1,       # 1-5
            "cursor_style": "block", # block, line, underscore
            "highlight_current_line": True
        }
        
    def toggle_toolbar(self):
        """Toggle the visibility of the toolbar"""
        self.toolbar_visible = not self.toolbar_visible
        return self.toolbar_visible
        
    def draw_toolbar(self, stdscr, width):
        """Draw the console toolbar at the top of the screen"""
        if not self.toolbar_visible:
            return
            
        # Create toolbar at top of screen
        toolbar_y = 0
        stdscr.attron(curses.A_REVERSE)
        toolbar = " F1:Help | F2:Save | F3:Load | F4:Settings | F5:Run | F10:Exit "
        padding = " " * (width - len(toolbar))
        stdscr.addstr(toolbar_y, 0, toolbar + padding)
        stdscr.attroff(curses.A_REVERSE)
        
    def show_settings_dialog(self, stdscr):
        """Display and handle the settings dialog"""
        # Save current terminal state
        curses.def_prog_mode()
        
        # Create new window for settings
        height, width = stdscr.getmaxyx()
        win_height = 16
        win_width = 50
        win_y = (height - win_height) // 2
        win_x = (width - win_width) // 2
        
        settings_win = curses.newwin(win_height, win_width, win_y, win_x)
        settings_win.keypad(1)
        settings_win.box()
        
        # Title
        settings_win.addstr(0, (win_width - 18) // 2, " Console Settings ", curses.A_BOLD)
        
        # Settings options
        options = [
            ("Font Size", ["Small", "Normal", "Large"]),
            ("Color Scheme", ["Default", "Dark", "Light", "Retro"]),
            ("Line Numbers", ["On", "Off"]),
            ("Word Wrap", ["On", "Off"]),
            ("Auto Indent", ["On", "Off"]),
            ("Scroll Speed", ["1", "2", "3", "4", "5"]),
            ("Cursor Style", ["Block", "Line", "Underscore"]),
            ("Highlight Current Line", ["On", "Off"]),
            ("Save and Exit", [])
        ]
        
        # Convert current settings to option indices
        current_selections = [
            0 if self.settings["font_size"] == "small" else 1 if self.settings["font_size"] == "normal" else 2,
            0 if self.settings["color_scheme"] == "default" else 1 if self.settings["color_scheme"] == "dark" else 2 if self.settings["color_scheme"] == "light" else 3,
            0 if self.settings["show_line_numbers"] else 1,
            0 if self.settings["word_wrap"] else 1,
            0 if self.settings["auto_indent"] else 1,
            self.settings["scroll_speed"] - 1,
            0 if self.settings["cursor_style"] == "block" else 1 if self.settings["cursor_style"] == "line" else 2,
            0 if self.settings["highlight_current_line"] else 1,
            0
        ]
        
        current_option = 0
        editing = False
        
        # Main settings loop
        while True:
            settings_win.clear()
            settings_win.box()
            settings_win.addstr(0, (win_width - 18) // 2, " Console Settings ", curses.A_BOLD)
            
            # Draw options
            for i, (option, values) in enumerate(options):
                y_pos = i + 2
                if i == len(options) - 1:
                    # Special case for Save and Exit
                    settings_win.addstr(y_pos, 2, option, curses.A_BOLD if i == current_option else 0)
                else:
                    # Regular option with value
                    if i == current_option and editing:
                        settings_win.addstr(y_pos, 2, option + ": ", curses.A_BOLD)
                        for j, value in enumerate(values):
                            if j == current_selections[i]:
                                settings_win.addstr("[" + value + "]", curses.A_REVERSE)
                            else:
                                settings_win.addstr(" " + value + " ")
                    else:
                        settings_win.addstr(y_pos, 2, option + ": " + values[current_selections[i]], 
                                           curses.A_BOLD if i == current_option else 0)
            
            # Draw help
            if editing:
                help_text = "← → to change value | Enter to confirm"
            else:
                help_text = "↑↓ to navigate | Enter to edit | Esc to exit"
            settings_win.addstr(win_height - 2, (win_width - len(help_text)) // 2, help_text)
            
            # Refresh and get input
            settings_win.refresh()
            key = settings_win.getch()
            
            # Process input
            if key == 27:  # Escape
                break
            elif key == curses.KEY_UP and not editing:
                current_option = max(0, current_option - 1)
            elif key == curses.KEY_DOWN and not editing:
                current_option = min(len(options) - 1, current_option + 1)
            elif key == 10:  # Enter
                if current_option == len(options) - 1:  # Save and Exit
                    self._apply_settings(current_selections)
                    break
                else:
                    editing = not editing
            elif key == curses.KEY_LEFT and editing:
                if options[current_option][1]:  # If there are values
                    current_selections[current_option] = max(0, current_selections[current_option] - 1)
            elif key == curses.KEY_RIGHT and editing:
                if options[current_option][1]:  # If there are values
                    current_selections[current_option] = min(len(options[current_option][1]) - 1, 
                                                            current_selections[current_option] + 1)
        
        # Restore terminal state
        curses.reset_prog_mode()
        stdscr.refresh()
        
    def _apply_settings(self, selections):
        """Apply the settings from the dialog"""
        # Font size
        font_sizes = ["small", "normal", "large"]
        self.settings["font_size"] = font_sizes[selections[0]]
        
        # Color scheme
        color_schemes = ["default", "dark", "light", "retro"]
        self.settings["color_scheme"] = color_schemes[selections[1]]
        
        # Boolean settings
        self.settings["show_line_numbers"] = selections[2] == 0
        self.settings["word_wrap"] = selections[3] == 0
        self.settings["auto_indent"] = selections[4] == 0
        
        # Scroll speed
        self.settings["scroll_speed"] = selections[5] + 1
        
        # Cursor style
        cursor_styles = ["block", "line", "underscore"]
        self.settings["cursor_style"] = cursor_styles[selections[6]]
        
        # Highlight current line
        self.settings["highlight_current_line"] = selections[7] == 0
        
    def run_demo(self):
        """Run a standalone demo of the console manager"""
        def _curses_main(stdscr):
            curses.curs_set(0)  # Hide cursor
            stdscr.clear()
            
            # Setup colors
            if curses.has_colors():
                curses.start_color()
                curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
                curses.init_pair(2, curses.COLOR_WHITE, curses.COLOR_BLUE)
            
            # Main demo loop
            while True:
                # Get screen dimensions
                height, width = stdscr.getmaxyx()
                
                # Clear screen
                stdscr.clear()
                
                # Draw toolbar
                self.draw_toolbar(stdscr, width)
                
                # Draw main content
                content_start = 1 if self.toolbar_visible else 0
                stdscr.addstr(content_start + 2, 2, "Console Manager Demo", curses.A_BOLD)
                stdscr.addstr(content_start + 4, 2, f"Current settings:", curses.color_pair(1))
                
                # Display current settings
                y_pos = content_start + 6
                for key, value in self.settings.items():
                    stdscr.addstr(y_pos, 4, f"{key}: {value}")
                    y_pos += 1
                
                # Draw help text
                help_text = "F1: Toggle Toolbar | F4: Settings | Q: Quit"
                stdscr.addstr(height - 1, 0, help_text)
                
                # Refresh screen
                stdscr.refresh()
                
                # Get input
                key = stdscr.getch()
                
                # Process input
                if key == ord('q') or key == ord('Q'):
                    break
                elif key == curses.KEY_F1:
                    self.toggle_toolbar()
                elif key == curses.KEY_F4:
                    self.show_settings_dialog(stdscr)
        
        # Start curses application
        curses.wrapper(_curses_main)

# For standalone testing
if __name__ == "__main__":
    console = ConsoleManager()
    console.run_demo()
