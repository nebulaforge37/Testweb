
"""
Telemetry Anomaly Tracker
Combines multiverse telemetry with time anomaly detection to track and identify
temporal anomalies through telemetry data analysis.
"""

import random
import math
import time
from typing import List, Dict, Tuple, Optional, Any
from multiverse_telemetry import MultiverseTelemetry, TelemetrySignal
from temporal_physics import TimeDilation, ParadoxRegistry

class TemporalAnomaly:
    """Represents a temporal anomaly detected through telemetry data"""
    
    def __init__(self, anomaly_id: int, description: str, timeline_name: str,
                 year: int, coordinates=None, magnitude: float = 0.5):
        """
        Initialize a temporal anomaly
        
        Args:
            anomaly_id: Unique identifier for this anomaly
            description: Description of the anomaly
            timeline_name: Timeline where the anomaly was detected
            year: Year when the anomaly occurred
            coordinates: Spatial coordinates (if available)
            magnitude: Severity/magnitude of the anomaly (0.0-1.0)
        """
        self.anomaly_id = anomaly_id
        self.description = description
        self.timeline_name = timeline_name
        self.year = year
        self.coordinates = coordinates
        self.magnitude = magnitude
        self.detected_at = time.time()
        self.type = self._determine_anomaly_type()
        self.decay_rate = random.uniform(0.001, 0.02)  # How quickly anomaly naturally decays
        self.stability = random.uniform(0.3, 0.8)  # How stable the anomaly is
        self.affected_entities = []  # Entities affected by this anomaly
        self.containment_level = 0.0  # Level of containment (0.0 = uncontained, 1.0 = fully contained)
        self.telemetry_signals = []  # Telemetry signals associated with this anomaly
        self.status = "Active"  # Active, Decaying, Contained, Resolved
        
    def _determine_anomaly_type(self) -> str:
        """Determine the type of anomaly based on characteristics"""
        types = [
            "Temporal Echo", "Causal Fracture", "Timeline Bleed",
            "Quantum Distortion", "Paradox Singularity", "Time Loop",
            "Phase Shift", "Reality Tear", "Worldline Rupture"
        ]
        return random.choice(types)
        
    def get_current_magnitude(self) -> float:
        """Calculate current magnitude accounting for decay and containment"""
        elapsed_time = time.time() - self.detected_at
        decay_factor = math.exp(-self.decay_rate * elapsed_time)
        contained_factor = 1.0 - self.containment_level
        
        return self.magnitude * decay_factor * contained_factor
        
    def is_active(self) -> bool:
        """Check if this anomaly is still active"""
        return self.get_current_magnitude() > 0.05 and self.status != "Resolved"
        
    def add_affected_entity(self, entity_id: str, effect_description: str = None):
        """Add an entity affected by this anomaly"""
        if not effect_description:
            effects = [
                "temporal displacement",
                "causal disconnection",
                "quantum duplication",
                "timeline desynchronization",
                "temporal aura corruption"
            ]
            effect_description = random.choice(effects)
            
        self.affected_entities.append({
            "entity_id": entity_id,
            "effect": effect_description,
            "detected_at": time.time()
        })
        
    def add_telemetry_signal(self, signal: TelemetrySignal):
        """Add a telemetry signal associated with this anomaly"""
        self.telemetry_signals.append(signal)
        
    def update_containment(self, containment_delta: float):
        """Update the containment level of this anomaly"""
        old_level = self.containment_level
        self.containment_level = max(0.0, min(1.0, self.containment_level + containment_delta))
        
        # Update status based on containment level
        if self.containment_level >= 0.9:
            self.status = "Contained"
        elif self.containment_level > old_level:
            self.status = "Containment in Progress"
            
        return self.containment_level
        
    def get_effect_radius(self) -> float:
        """Calculate the effect radius of this anomaly"""
        base_radius = self.magnitude * 100  # Base radius in arbitrary units
        current_magnitude = self.get_current_magnitude()
        
        return base_radius * (current_magnitude / self.magnitude)
        
    def get_stability_impact(self, distance: float = 0.0) -> float:
        """
        Calculate stability impact on timelines or entities
        
        Args:
            distance: Distance from anomaly center (0 = direct impact)
            
        Returns:
            Stability impact (negative value = destabilizing)
        """
        current_magnitude = self.get_current_magnitude()
        if distance == 0:
            return -current_magnitude * 0.2  # Direct impact
            
        # Impact decreases with distance
        effect_radius = self.get_effect_radius()
        if distance > effect_radius:
            return 0.0  # Outside effect radius
            
        # Calculate impact based on distance
        distance_factor = 1.0 - (distance / effect_radius)
        return -current_magnitude * 0.2 * distance_factor
        
    def __str__(self) -> str:
        current_magnitude = self.get_current_magnitude()
        return f"{self.type} Anomaly #{self.anomaly_id} in {self.timeline_name} ({self.year}): {current_magnitude:.2f} magnitude, {self.status}"


class TelemetryAnomalyTracker:
    """Tracks temporal anomalies using telemetry data"""
    
    def __init__(self, telemetry_system: MultiverseTelemetry = None):
        """Initialize the anomaly tracker with a telemetry system"""
        self.telemetry = telemetry_system
        self.anomalies = {}  # Dict of anomaly_id: TemporalAnomaly
        self.next_anomaly_id = 1
        self.detection_threshold = 0.3  # Threshold for detecting new anomalies
        self.last_scan = time.time()
        self.scan_interval = if not telemetry_system:
                         5.0  # 5 seconds if no telemetry data 
                     else:
                         2.0  # 2 seconds if telemetry data available
        self.paradox_registry = ParadoxRegistry()
        self.containment_methods = self._initialize_containment_methods()
        self.timeline_risk_levels = {}  # Cached risk levels for timelines
        
    def _initialize_containment_methods(self) -> Dict[str, Dict[str, Any]]:
        """Initialize available containment methods for anomalies"""
        return {
            "temporal_shielding": {
                "name": "Temporal Shielding",
                "description": "Creates a shield around the anomaly to prevent it from spreading",
                "effectiveness": 0.4,
                "stability_impact": 0.2,
                "energy_cost": 0.3
            },
            "phase_cancellation": {
                "name": "Phase Cancellation",
                "description": "Generates counter-phase temporal waves to cancel the anomaly",
                "effectiveness": 0.6,
                "stability_impact": 0.4,
                "energy_cost": 0.5
            },
            "causal_reinforcement": {
                "name": "Causal Reinforcement",
                "description": "Strengthens causal links to prevent anomaly from disrupting timeline",
                "effectiveness": 0.3,
                "stability_impact": 0.1,
                "energy_cost": 0.2
            },
            "quantum_isolation": {
                "name": "Quantum Isolation",
                "description": "Isolates the anomaly in its own quantum bubble",
                "effectiveness": 0.7,
                "stability_impact": 0.5,
                "energy_cost": 0.6
            },
            "timeline_anchoring": {
                "name": "Timeline Anchoring",
                "description": "Anchors the affected timeline to prevent drift",
                "effectiveness": 0.5,
                "stability_impact": 0.3,
                "energy_cost": 0.4
            }
        }
        
    def create_anomaly(self, timeline_name: str, year: int, magnitude: float = None,
                     description: str = None, coordinates = None) -> TemporalAnomaly:
        """Create a new temporal anomaly"""
        if magnitude is None:
            magnitude = random.uniform(0.3, 0.8)
            
        if description is None:
            descriptions = [
                "Unexpected temporal flux detected",
                "Causality violation in progress",
                "Timeline integrity compromised",
                "Quantum wave function collapse detected",
                "Temporal energy spike detected",
                "Worldline discontinuity observed",
                "Causal chain disruption detected"
            ]
            description = random.choice(descriptions)
            
        # Create the anomaly
        anomaly = TemporalAnomaly(
            self.next_anomaly_id, description, timeline_name, year, coordinates, magnitude
        )
        
        # Add to tracked anomalies
        self.anomalies[self.next_anomaly_id] = anomaly
        self.next_anomaly_id += 1
        
        return anomaly
        
    def scan_for_anomalies(self) -> List[TemporalAnomaly]:
        """
        Scan telemetry data for potential anomalies
        
        Returns:
            List of newly detected anomalies
        """
        # Don't scan too frequently
        current_time = time.time()
        if current_time - self.last_scan < self.scan_interval:
            return []
            
        self.last_scan = current_time
        new_anomalies = []
        
        # Skip if no telemetry system available
        if not self.telemetry:
            return []
            
        # Get the telemetry report
        report = self.telemetry.generate_telemetry_report()
        
        # Check for potential anomalies in recent timeline crossings
        for crossing in report.get("recent_crossings", []):
            # Unusual crossings might indicate anomalies
            if random.random() < 0.2:  # 20% chance to detect anomaly from crossing
                entity_id = crossing["entity_id"]
                from_timeline = crossing["from_timeline"]
                to_timeline = crossing["to_timeline"]
                
                # Get entity position
                position = self.telemetry.get_entity_position(entity_id)
                if position:
                    # Create an anomaly at this location
                    year = position.temporal.year
                    anomaly = self.create_anomaly(
                        from_timeline, year, 
                        magnitude=random.uniform(0.3, 0.7),
                        description=f"Timeline crossing anomaly: {from_timeline} → {to_timeline}",
                        coordinates=position.spatial
                    )
                    
                    # Add the entity as affected
                    anomaly.add_affected_entity(entity_id, "timeline crossing instability")
                    
                    new_anomalies.append(anomaly)
        
        # Check for entities with unusual velocity or quantum signatures
        for entity_id, summary in report.get("entity_summaries", {}).items():
            track = self.telemetry.tracks.get(entity_id)
            if not track or len(track.signals) < 2:
                continue
                
            # Check velocity
            velocity = track.get_velocity_vector()
            if velocity:
                dx, dy, dz, dt = velocity
                if dt != 0:
                    spatial_velocity = math.sqrt(dx*dx + dy*dy + dz*dz) / abs(dt)
                    
                    # Very high velocity might indicate anomaly
                    if spatial_velocity > 5000 and random.random() < 0.4:
                        position = track.get_current_position()
                        if position:
                            anomaly = self.create_anomaly(
                                position.timeline_name, position.temporal.year,
                                magnitude=random.uniform(0.4, 0.8),
                                description=f"Extreme velocity anomaly: {spatial_velocity:.0f} km/day",
                                coordinates=position.spatial
                            )
                            
                            anomaly.add_affected_entity(entity_id, "extreme velocity distortion")
                            new_anomalies.append(anomaly)
                            
            # Check quantum signature changes
            if len(track.signals) >= 3:
                sig1 = track.signals[-3].coordinate.quantum_signature
                sig2 = track.signals[-2].coordinate.quantum_signature
                sig3 = track.signals[-1].coordinate.quantum_signature
                
                # Look for rapid, significant changes in quantum signature
                if abs(sig3 - sig2) > 0.3 and abs(sig2 - sig1) > 0.3:
                    position = track.get_current_position()
                    if position:
                        anomaly = self.create_anomaly(
                            position.timeline_name, position.temporal.year,
                            magnitude=random.uniform(0.5, 0.9),
                            description="Quantum signature fluctuation anomaly",
                            coordinates=position.spatial
                        )
                        
                        anomaly.add_affected_entity(entity_id, "quantum signature destabilization")
                        new_anomalies.append(anomaly)
        
        return new_anomalies
        
    def get_active_anomalies(self, timeline_name: str = None) -> List[TemporalAnomaly]:
        """
        Get all active anomalies, optionally filtered by timeline
        
        Args:
            timeline_name: Optional timeline to filter by
            
        Returns:
            List of active anomalies
        """
        active = [a for a in self.anomalies.values() if a.is_active()]
        
        if timeline_name:
            active = [a for a in active if a.timeline_name == timeline_name]
            
        return active
        
    def get_anomaly(self, anomaly_id: int) -> Optional[TemporalAnomaly]:
        """Get a specific anomaly by ID"""
        return self.anomalies.get(anomaly_id)
        
    def update_all_anomalies(self):
        """Update all anomalies (decay, check status, etc.)"""
        for anomaly in list(self.anomalies.values()):
            if not anomaly.is_active():
                anomaly.status = "Resolved"
        
    def calculate_timeline_stability_impact(self, timeline_name: str) -> float:
        """
        Calculate the combined stability impact of all anomalies on a timeline
        
        Args:
            timeline_name: The timeline to calculate impact for
            
        Returns:
            Combined stability impact (negative value = destabilizing)
        """
        anomalies = self.get_active_anomalies(timeline_name)
        
        if not anomalies:
            return 0.0
            
        # Sum up the direct impacts
        total_impact = sum(anomaly.get_stability_impact() for anomaly in anomalies)
        
        # Adjust for multiple anomalies (they compound each other)
        if len(anomalies) > 1:
            # More anomalies have compounding effects
            total_impact *= (1 + (len(anomalies) - 1) * 0.2)
            
        return total_impact
        
    def contain_anomaly(self, anomaly_id: int, method_key: str = None) -> Dict[str, Any]:
        """
        Attempt to contain an anomaly
        
        Args:
            anomaly_id: ID of the anomaly to contain
            method_key: Specific containment method to use, or None for automatic selection
            
        Returns:
            Results of the containment attempt
        """
        anomaly = self.get_anomaly(anomaly_id)
        
        if not anomaly:
            return {
                "success": False,
                "message": f"Anomaly {anomaly_id} not found"
            }
            
        if not anomaly.is_active():
            return {
                "success": False,
                "message": f"Anomaly {anomaly_id} is already resolved or contained"
            }
            
        # If no method specified, choose the best one
        if not method_key:
            # Different anomaly types work better with different containment methods
            if anomaly.type == "Temporal Echo" or anomaly.type == "Time Loop":
                method_key = "phase_cancellation"
            elif anomaly.type == "Quantum Distortion" or anomaly.type == "Reality Tear":
                method_key = "quantum_isolation"
            elif anomaly.type == "Causal Fracture" or anomaly.type == "Worldline Rupture":
                method_key = "causal_reinforcement"
            elif anomaly.type == "Timeline Bleed":
                method_key = "timeline_anchoring"
            else:
                method_key = "temporal_shielding"
                
        # Get the method details
        method = self.containment_methods.get(method_key)
        
        if not method:
            return {
                "success": False,
                "message": f"Containment method '{method_key}' not found"
            }
            
        # Calculate success chance and effectiveness
        base_effectiveness = method["effectiveness"]
        
        # Adjust for anomaly magnitude and stability
        magnitude_factor = 1.0 - (anomaly.get_current_magnitude() * 0.5)
        stability_factor = anomaly.stability
        
        adjusted_effectiveness = base_effectiveness * magnitude_factor * stability_factor
        
        # Attempt containment
        containment_amount = adjusted_effectiveness * random.uniform(0.8, 1.2)
        new_containment = anomaly.update_containment(containment_amount)
        
        # Prepare result
        result = {
            "success": True,
            "anomaly_id": anomaly_id,
            "method": method["name"],
            "effectiveness": adjusted_effectiveness,
            "stability_impact": method["stability_impact"],
            "energy_cost": method["energy_cost"],
            "previous_containment": new_containment - containment_amount,
            "current_containment": new_containment,
            "current_magnitude": anomaly.get_current_magnitude(),
            "status": anomaly.status
        }
        
        return result
        
    def get_timeline_risk_assessment(self, timeline_name: str) -> Dict[str, Any]:
        """
        Generate a risk assessment for a timeline based on anomalies
        
        Args:
            timeline_name: The timeline to assess
            
        Returns:
            Risk assessment data
        """
        # Get active anomalies for this timeline
        anomalies = self.get_active_anomalies(timeline_name)
        
        # Calculate risk score based on anomalies
        risk_score = 0.0
        
        for anomaly in anomalies:
            # Higher magnitude, higher risk
            risk_score += anomaly.get_current_magnitude() * 4
            
            # Certain types are more dangerous
            if anomaly.type in ["Paradox Singularity", "Reality Tear", "Worldline Rupture"]:
                risk_score *= 1.5
        
        # Determine risk level
        risk_level = "Low"
        if risk_score > 5.0:
            risk_level = "Extreme"
        elif risk_score > 3.0:
            risk_level = "High"
        elif risk_score > 1.0:
            risk_level = "Medium"
            
        # Find nearest critical event
        nearest_critical = None
        if anomalies:
            # Sort by magnitude (highest first)
            critical_anomalies = sorted(anomalies, key=lambda a: a.get_current_magnitude(), reverse=True)
            if critical_anomalies:
                top_anomaly = critical_anomalies[0]
                # Estimate time until critical based on decay rate vs current magnitude
                current_mag = top_anomaly.get_current_magnitude()
                if current_mag > 0.7:  # Only truly dangerous anomalies
                    # Estimate time remaining until critical event
                    time_remaining = (-math.log(0.2 / current_mag)) / top_anomaly.decay_rate
                    
                    nearest_critical = {
                        "type": top_anomaly.type,
                        "year": top_anomaly.year,
                        "magnitude": current_mag,
                        "time_remaining": f"{time_remaining:.1f} seconds",
                        "anomaly_id": top_anomaly.anomaly_id
                    }
        
        # Store the assessment
        assessment = {
            "timeline": timeline_name,
            "risk_level": risk_level,
            "risk_score": risk_score,
            "active_anomalies": len(anomalies),
            "cumulative_magnitude": sum(a.get_current_magnitude() for a in anomalies),
            "stability_impact": self.calculate_timeline_stability_impact(timeline_name),
            "nearest_critical_event": nearest_critical,
            "active_predictions": [],  # For future prediction functionality
            "recommended_actions": []
        }
        
        # Add recommended actions based on risk level
        if risk_level == "High" or risk_level == "Extreme":
            assessment["recommended_actions"].append("Immediate containment of all high-magnitude anomalies")
            assessment["recommended_actions"].append("Timeline stabilization protocol recommended")
        elif risk_level == "Medium":
            assessment["recommended_actions"].append("Monitor and contain anomalies above 0.5 magnitude")
        else:
            assessment["recommended_actions"].append("Routine monitoring recommended")
            
        # Cache the assessment
        self.timeline_risk_levels[timeline_name] = {
            "level": risk_level,
            "score": risk_score,
            "timestamp": time.time()
        }
        
        return assessment
        
    def get_multiverse_anomaly_report(self) -> str:
        """Generate a comprehensive report of anomalies across the multiverse"""
        all_anomalies = list(self.anomalies.values())
        active_anomalies = [a for a in all_anomalies if a.is_active()]
        
        report = ["=== MULTIVERSE ANOMALY REPORT ==="]
        report.append(f"Total Anomalies: {len(all_anomalies)}")
        report.append(f"Active Anomalies: {len(active_anomalies)}")
        
        if active_anomalies:
            # Group by timeline
            timeline_anomalies = {}
            for anomaly in active_anomalies:
                if anomaly.timeline_name not in timeline_anomalies:
                    timeline_anomalies[anomaly.timeline_name] = []
                timeline_anomalies[anomaly.timeline_name].append(anomaly)
            
            report.append("\nActive Anomalies by Timeline:")
            for timeline, anomalies in timeline_anomalies.items():
                risk_info = self.timeline_risk_levels.get(timeline, {"level": "Unknown"})
                report.append(f"\n{timeline} Timeline (Risk: {risk_info.get('level', 'Unknown')})")
                
                for anomaly in sorted(anomalies, key=lambda a: a.get_current_magnitude(), reverse=True):
                    mag = anomaly.get_current_magnitude()
                    cont = anomaly.containment_level
                    report.append(f"- {anomaly.type} #{anomaly.anomaly_id} ({anomaly.year}): Mag {mag:.2f}, Containment {cont:.0%}")
                    
                    # Add details for significant anomalies
                    if mag > 0.6:
                        report.append(f"  * {anomaly.description}")
                        if anomaly.affected_entities:
                            entity_count = len(anomaly.affected_entities)
                            report.append(f"  * Affecting {entity_count} entities")
        
        # Add risk assessment summary
        report.append("\nTimeline Risk Summary:")
        risk_levels = {k: v for k, v in self.timeline_risk_levels.items() 
                     if time.time() - v.get("timestamp", 0) < 300}  # Only show recent assessments
                     
        for timeline, risk in sorted(risk_levels.items(), key=lambda x: x[1].get("score", 0), reverse=True):
            report.append(f"- {timeline}: {risk.get('level', 'Unknown')} (Score: {risk.get('score', 0):.1f})")
        
        return "\n".join(report)


def run_telemetry_anomaly_demo():
    """Run a demonstration of the telemetry anomaly tracker"""
    from multiverse_telemetry import MultiverseTelemetry
    import time
    
    print("=== Telemetry Anomaly Tracker Demonstration ===")
    
    # Create telemetry system
    telemetry = MultiverseTelemetry()
    
    # Register some entities
    telemetry.register_entity("Explorer-1", {
        "type": "time_traveler",
        "name": "Dr. Elena Kowalski"
    })
    
    telemetry.register_entity("Observer-7", {
        "type": "quantum_observer",
        "name": "Quantum AI Sentinel"
    })
    
    telemetry.register_entity("Anomaly-X", {
        "type": "unknown",
        "threat_level": "unknown"
    })
    
    # Create the anomaly tracker
    tracker = TelemetryAnomalyTracker(telemetry)
    
    # Create some test anomalies
    print("\nCreating test anomalies...")
    
    anomaly1 = tracker.create_anomaly(
        "Alpha Prime", 2030, 0.7,
        "Temporal echo from future experiment"
    )
    print(f"Created: {anomaly1}")
    
    anomaly2 = tracker.create_anomaly(
        "Beta Variant", 1985, 0.4,
        "Timeline bleed from neighboring reality"
    )
    print(f"Created: {anomaly2}")
    
    anomaly3 = tracker.create_anomaly(
        "Gamma Nexus", 2077, 0.9,
        "Paradox singularity forming near critical nexus point"
    )
    print(f"Created: {anomaly3}")
    
    # Add some affected entities
    anomaly1.add_affected_entity("Explorer-1", "temporal disorientation")
    anomaly3.add_affected_entity("Observer-7", "quantum state corruption")
    anomaly3.add_affected_entity("Anomaly-X", "accelerated probability collapse")
    
    # Attempt containment
    print("\nAttempting anomaly containment...")
    
    result1 = tracker.contain_anomaly(anomaly1.anomaly_id, "phase_cancellation")
    print(f"Containment of Anomaly #{anomaly1.anomaly_id}")
    print(f"Method: {result1['method']}")
    print(f"Effectiveness: {result1['effectiveness']:.2f}")
    print(f"New containment level: {result1['current_containment']:.2f}")
    
    result3 = tracker.contain_anomaly(anomaly3.anomaly_id, "quantum_isolation")
    print(f"\nContainment of Anomaly #{anomaly3.anomaly_id}")
    print(f"Method: {result3['method']}")
    print(f"Effectiveness: {result3['effectiveness']:.2f}")
    print(f"New containment level: {result3['current_containment']:.2f}")
    
    # Generate risk assessments
    print("\nGenerating timeline risk assessments...")
    
    alpha_risk = tracker.get_timeline_risk_assessment("Alpha Prime")
    print(f"Alpha Prime Timeline - Risk Level: {alpha_risk['risk_level']}")
    print(f"Risk Score: {alpha_risk['risk_score']:.2f}")
    print(f"Active Anomalies: {alpha_risk['active_anomalies']}")
    if alpha_risk.get('recommended_actions'):
        print("Recommended Actions:")
        for action in alpha_risk['recommended_actions']:
            print(f"- {action}")
            
    gamma_risk = tracker.get_timeline_risk_assessment("Gamma Nexus")
    print(f"\nGamma Nexus Timeline - Risk Level: {gamma_risk['risk_level']}")
    print(f"Risk Score: {gamma_risk['risk_score']:.2f}")
    print(f"Active Anomalies: {gamma_risk['active_anomalies']}")
    if gamma_risk.get('nearest_critical_event'):
        event = gamma_risk['nearest_critical_event']
        print(f"Critical Event: {event['type']} (Magnitude: {event['magnitude']:.2f})")
        print(f"Time Remaining: {event['time_remaining']}")
    
    # Update anomalies to simulate time passing
    print("\nSimulating anomaly evolution...")
    for i in range(3):
        time.sleep(1)
        print(f"Update cycle {i+1}...")
        tracker.update_all_anomalies()
        
        # Show current magnitudes
        for anomaly in tracker.get_active_anomalies():
            mag = anomaly.get_current_magnitude()
            cont = anomaly.containment_level
            print(f"Anomaly #{anomaly.anomaly_id}: Magnitude {mag:.2f}, Containment {cont:.2f}")
    
    # Generate final report
    print("\n" + tracker.get_multiverse_anomaly_report())
    
    return tracker


if __name__ == "__main__":
    run_telemetry_anomaly_demo()
