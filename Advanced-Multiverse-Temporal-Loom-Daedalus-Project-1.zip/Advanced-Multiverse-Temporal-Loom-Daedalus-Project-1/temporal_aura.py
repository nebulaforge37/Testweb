
"""
Temporal Aura System
This module simulates the ethereal temporal energy fields that surround objects and beings
across the multiverse, visualizing their temporal history and potential futures.
"""

import random
import math
import time
from typing import List, Dict, Optional, Tuple, Any, Union
from temporal_physics import TimeDilation, ParadoxRegistry

class TemporalAura:
    """Represents the temporal energy field surrounding an entity"""
    
    def __init__(self, entity_name: str, timeline_name: str, strength: float = None,
                complexity: float = None, stability: float = None):
        """
        Initialize a temporal aura
        
        Args:
            entity_name: Name of the entity this aura surrounds
            timeline_name: Timeline where this entity exists
            strength: Overall strength of the aura (0.0-1.0)
            complexity: Complexity of the aura pattern (0.0-1.0)
            stability: How stable the aura is (0.0-1.0)
        """
        self.entity_name = entity_name
        self.timeline_name = timeline_name
        self.strength = strength or random.uniform(0.3, 0.9)
        self.complexity = complexity or random.uniform(0.2, 0.8)
        self.stability = stability or random.uniform(0.4, 1.0)
        
        # Aura properties
        self.color_spectrum = self._generate_color_spectrum()
        self.resonance_frequency = random.uniform(5.0, 12.0)  # Hz
        self.harmonic_pattern = self._generate_harmonic_pattern()
        self.temporal_echo_strength = random.uniform(0.0, 0.4)
        self.quantum_signature = random.random()
        
        # Temporal history reflected in the aura
        self.past_shadows = random.randint(1, 5)
        self.future_echoes = round(random.uniform(0, 3))
        self.time_dilation_factor = random.uniform(0.9, 1.1)
        
        # Tracks changes to the aura over time
        self.fluctuation_history = []
        self.last_reading = time.time()
        self.last_updated = time.time()
        
    def _generate_color_spectrum(self) -> Dict[str, float]:
        """Generate a color spectrum for the aura"""
        colors = {
            "red": random.uniform(0, 1),
            "orange": random.uniform(0, 1),
            "yellow": random.uniform(0, 1),
            "green": random.uniform(0, 1),
            "blue": random.uniform(0, 1),
            "indigo": random.uniform(0, 1),
            "violet": random.uniform(0, 1),
            "ultraviolet": random.uniform(0, 0.5),  # Less visible spectrum
            "infrared": random.uniform(0, 0.5)      # Less visible spectrum
        }
        
        # Normalize to create a proper distribution
        total = sum(colors.values())
        if total > 0:
            for color in colors:
                colors[color] /= total
                
        # Dominant color influenced by timeline stability
        stability_colors = {
            "high": ["blue", "indigo", "violet"],
            "medium": ["green", "yellow"],
            "low": ["red", "orange", "infrared"]
        }
        
        stability_level = "high" if self.stability > 0.7 else "medium" if self.stability > 0.4 else "low"
        dominant_color = random.choice(stability_colors[stability_level])
        colors[dominant_color] *= 1.5
        
        return colors
    
    def _generate_harmonic_pattern(self) -> List[float]:
        """Generate a harmonic pattern for the aura"""
        # More complex auras have more harmonics
        harmonic_count = 3 + round(self.complexity * 5)
        base_frequency = self.resonance_frequency
        
        harmonics = [base_frequency]
        for i in range(1, harmonic_count):
            if random.random() < 0.7:  # 70% chance of regular harmonic
                harmonics.append(base_frequency * (i + 1))
            else:  # 30% chance of unusual harmonic
                harmonics.append(base_frequency * random.uniform(0.5, 3.5))
                
        return harmonics
    
    def read_aura(self) -> Dict[str, Any]:
        """Take a current reading of the aura's state"""
        # Calculate time since last reading
        now = time.time()
        time_since_reading = now - self.last_reading
        self.last_reading = now
        
        # Introduce small random fluctuations based on time passed
        drift_factor = min(0.2, time_since_reading / 3600)  # Max 20% change per hour
        
        # Apply fluctuations
        strength_change = random.uniform(-drift_factor, drift_factor) * self.strength
        self.strength = max(0.1, min(1.0, self.strength + strength_change))
        
        stability_change = random.uniform(-drift_factor, drift_factor) * self.stability
        self.stability = max(0.1, min(1.0, self.stability + stability_change))
        
        # Record the fluctuation
        self.fluctuation_history.append({
            "timestamp": now,
            "strength": self.strength,
            "stability": self.stability,
            "dominant_color": self.get_dominant_color()
        })
        
        # Limit history to 100 entries
        if len(self.fluctuation_history) > 100:
            self.fluctuation_history = self.fluctuation_history[-100:]
            
        # Compile the reading
        reading = {
            "entity_name": self.entity_name,
            "timeline": self.timeline_name,
            "timestamp": now,
            "strength": self.strength,
            "stability": self.stability,
            "dominant_color": self.get_dominant_color(),
            "harmonic_resonance": self.resonance_frequency,
            "past_shadows": self.past_shadows,
            "future_echoes": self.future_echoes,
            "temporal_state": self.interpret_aura_state()
        }
        
        return reading
    
    def get_dominant_color(self) -> str:
        """Get the dominant color in the aura"""
        return max(self.color_spectrum.items(), key=lambda x: x[1])[0]
    
    def interpret_aura_state(self) -> str:
        """Interpret the current state of the aura"""
        if self.stability < 0.3:
            if self.strength > 0.7:
                return "Chaotic: Strong but unstable temporal energy"
            else:
                return "Fading: Unstable and weakening temporal connection"
        elif self.stability < 0.6:
            if self.strength > 0.7:
                return "Fluctuating: Strong with moderate stability"
            else:
                return "Subdued: Moderate stability with below-average strength"
        else:  # stability >= 0.6
            if self.strength > 0.7:
                return "Radiant: Strong and stable temporal presence"
            else:
                return "Steady: Stable but with moderate energy levels"
    
    def influence_from_paradox(self, paradox_type: str, intensity: float = 0.5):
        """
        Update the aura based on exposure to a temporal paradox
        
        Args:
            paradox_type: Type of paradox encountered
            intensity: Intensity of the paradox effect (0.0-1.0)
        """
        intensity = max(0.1, min(1.0, intensity))  # Constrain to valid range
        
        # Different paradoxes affect auras differently
        if paradox_type == "bootstrap":
            # Bootstrap paradoxes create stable time loops
            self.stability = min(1.0, self.stability + (0.2 * intensity))
            self.past_shadows += 1
            self.color_spectrum["blue"] = min(1.0, self.color_spectrum.get("blue", 0) + 0.2)
            
        elif paradox_type == "grandfather":
            # Causality violations destabilize auras significantly
            self.stability = max(0.1, self.stability - (0.3 * intensity))
            self.strength = max(0.1, self.strength - (0.2 * intensity))
            self.color_spectrum["red"] = min(1.0, self.color_spectrum.get("red", 0) + 0.3)
            
        elif paradox_type == "predestination":
            # Predestination paradoxes increase resonance
            self.resonance_frequency += random.uniform(0.5, 1.5) * intensity
            self.future_echoes += 1
            self.color_spectrum["violet"] = min(1.0, self.color_spectrum.get("violet", 0) + 0.2)
            
        elif paradox_type == "consistency":
            # Consistency paradoxes create harmonic disruptions
            self.harmonic_pattern = self._generate_harmonic_pattern()
            self.complexity = min(1.0, self.complexity + (0.1 * intensity))
            self.color_spectrum["orange"] = min(1.0, self.color_spectrum.get("orange", 0) + 0.2)
            
        else:  # Generic paradox effect
            # General paradox exposure
            self.stability = max(0.1, self.stability - (0.1 * intensity))
            self.complexity = min(1.0, self.complexity + (0.1 * intensity))
        
        # Record that we updated the aura
        self.last_updated = time.time()
    
    def exposure_to_timeline(self, foreign_timeline_name: str, duration_hours: float = 1.0):
        """
        Update the aura based on exposure to a different timeline
        
        Args:
            foreign_timeline_name: Name of the other timeline
            duration_hours: How many hours of exposure
        """
        # Simulate changes from timeline exposure
        if foreign_timeline_name != self.timeline_name:
            # Different timeline exposure leaves imprints
            self.complexity = min(1.0, self.complexity + (0.05 * min(duration_hours, 10) / 10))
            
            # Long exposures can actually create stability as the entity adapts
            if duration_hours > 5:
                self.stability = min(1.0, self.stability + 0.02)
            else:
                # Short exposures are disruptive
                self.stability = max(0.1, self.stability - 0.03)
            
            # Create new time echoes
            if random.random() < 0.3:
                self.past_shadows += 1
            if random.random() < 0.2:
                self.future_echoes += 1
            
            # Adjust color spectrum based on exposure
            new_color = random.choice(list(self.color_spectrum.keys()))
            self.color_spectrum[new_color] = min(1.0, self.color_spectrum.get(new_color, 0) + 0.1)
        
        self.last_updated = time.time()
    
    def merge_with_aura(self, other_aura: 'TemporalAura') -> 'TemporalAura':
        """
        Merge this aura with another, returning a new combined aura
        
        Args:
            other_aura: Another temporal aura to merge with
            
        Returns:
            A new merged aura
        """
        # Create a merged aura name
        merged_name = f"{self.entity_name}/{other_aura.entity_name} Merged Entity"
        
        # Base timeline is the one with higher stability
        base_timeline = self.timeline_name if self.stability >= other_aura.stability else other_aura.timeline_name
        
        # Average the core properties
        merged_strength = (self.strength + other_aura.strength) / 2
        merged_complexity = (self.complexity + other_aura.complexity) / 2
        
        # Merging reduces stability slightly
        merged_stability = ((self.stability + other_aura.stability) / 2) * 0.9
        
        # Create the new merged aura
        merged_aura = TemporalAura(
            merged_name,
            base_timeline,
            merged_strength,
            merged_complexity,
            merged_stability
        )
        
        # Merge color spectrums
        for color in set(list(self.color_spectrum.keys()) + list(other_aura.color_spectrum.keys())):
            merged_aura.color_spectrum[color] = (
                self.color_spectrum.get(color, 0) + other_aura.color_spectrum.get(color, 0)
            ) / 2
        
        # Combine temporal features - take the max of each
        merged_aura.past_shadows = max(self.past_shadows, other_aura.past_shadows)
        merged_aura.future_echoes = max(self.future_echoes, other_aura.future_echoes)
        
        # Fluctuation history contains both histories
        merged_aura.fluctuation_history = sorted(
            self.fluctuation_history + other_aura.fluctuation_history,
            key=lambda x: x["timestamp"]
        )[-100:]  # Keep last 100 entries
        
        return merged_aura
    
    def get_visual_description(self) -> str:
        """Generate a text description of how the aura would appear visually"""
        dominant = self.get_dominant_color()
        
        # Base description
        description = [f"A {self.get_intensity_adjective()} {dominant} aura"]
        
        # Add details based on properties
        if self.stability < 0.3:
            description.append("with erratic, flickering edges")
        elif self.stability < 0.6:
            description.append("with gently pulsing boundaries")
        else:
            description.append("with smooth, stable boundaries")
            
        # Color mixing details
        secondary_colors = sorted(
            [(color, value) for color, value in self.color_spectrum.items() if color != dominant],
            key=lambda x: x[1],
            reverse=True
        )
        
        if secondary_colors:
            description.append(f"containing wisps of {secondary_colors[0][0]}")
            
            if len(secondary_colors) > 1 and secondary_colors[1][1] > 0.25:
                description.append(f"and {secondary_colors[1][0]}")
                
        # Echo details
        if self.past_shadows > 3:
            description.append("with multiple shadowy past-echoes trailing behind")
        elif self.past_shadows > 1:
            description.append("with faint past-shadows")
            
        if self.future_echoes > 2:
            description.append("surrounded by ghostly future-potential echoes")
        elif self.future_echoes > 0:
            description.append("with occasional glimpses of future states")
            
        # Time dilation effect
        if abs(self.time_dilation_factor - 1.0) > 0.05:
            if self.time_dilation_factor > 1.0:
                description.append("where time appears to flow slightly faster within")
            else:
                description.append("where time appears to flow slightly slower within")
        
        return ", ".join(description)
    
    def get_intensity_adjective(self) -> str:
        """Get an adjective describing the aura's intensity"""
        if self.strength < 0.3:
            return "dim"
        elif self.strength < 0.5:
            return "soft"
        elif self.strength < 0.7:
            return "bright"
        elif self.strength < 0.9:
            return "intense"
        else:
            return "brilliant"
    
    def __str__(self) -> str:
        return (f"Temporal Aura [{self.entity_name}]: {self.get_intensity_adjective()} "
                f"{self.get_dominant_color()} aura with {self.past_shadows} past shadow(s) "
                f"and {self.future_echoes} future echo(es)")


class AuraDetector:
    """Detects and analyzes temporal auras around entities"""
    
    def __init__(self, sensitivity: float = 0.7, calibration: float = 0.8):
        """
        Initialize an aura detector
        
        Args:
            sensitivity: How sensitive the detector is (0.0-1.0)
            calibration: How well calibrated the detector is (0.0-1.0)
        """
        self.sensitivity = max(0.1, min(1.0, sensitivity))
        self.calibration = max(0.1, min(1.0, calibration))
        self.detection_range = 10 + (20 * self.sensitivity)  # in meters
        self.last_calibration = time.time()
        self.detection_history = []
        self.known_auras = {}  # entity_name -> TemporalAura
        
    def detect_aura(self, aura: TemporalAura) -> Dict[str, Any]:
        """
        Attempt to detect and analyze a temporal aura
        
        Returns a detection result with potentially imperfect readings
        based on detector properties
        """
        # Basic detection chance based on aura strength and detector sensitivity
        detection_chance = aura.strength * self.sensitivity
        
        if random.random() > detection_chance:
            return {"detected": False, "message": "No aura detected"}
            
        # Calculate error factor based on calibration
        error_factor = (1.0 - self.calibration) * 0.3
        
        # Get a true reading from the aura
        true_reading = aura.read_aura()
        
        # Apply error to readings based on calibration
        detection = {
            "detected": True,
            "entity_name": true_reading["entity_name"],
            "timestamp": time.time(),
            "strength": max(0.0, min(1.0, true_reading["strength"] + random.uniform(-error_factor, error_factor))),
            "stability": max(0.0, min(1.0, true_reading["stability"] + random.uniform(-error_factor, error_factor))),
            "dominant_color": true_reading["dominant_color"],  # Colors are categorical, so we leave as-is
            "resonance": true_reading["harmonic_resonance"] * random.uniform(1-error_factor, 1+error_factor),
            "past_shadows": max(0, round(true_reading["past_shadows"] * random.uniform(1-error_factor, 1+error_factor))),
            "future_echoes": max(0, round(true_reading["future_echoes"] * random.uniform(1-error_factor, 1+error_factor))),
            "temporal_state": true_reading["temporal_state"],
            "visual_description": aura.get_visual_description()
        }
        
        # Less sensitive detectors can't detect future echoes well
        if self.sensitivity < 0.6:
            detection["future_echoes"] = max(0, detection["future_echoes"] - 1)
            
        # Store this aura for future reference
        self.known_auras[aura.entity_name] = aura
        
        # Store in history
        self.detection_history.append({
            "timestamp": time.time(),
            "entity_name": aura.entity_name,
            "strength": detection["strength"],
            "stability": detection["stability"]
        })
        
        return detection
    
    def calibrate(self, known_aura: TemporalAura = None) -> float:
        """
        Calibrate the detector using a known aura reference
        Returns new calibration level
        """
        # Calibration improves detector accuracy
        if known_aura:
            # Using a known reference aura gives better calibration
            self.calibration = min(1.0, self.calibration + 0.1)
        else:
            # Self-calibration is less effective
            self.calibration = min(1.0, self.calibration + 0.05)
            
        self.last_calibration = time.time()
        return self.calibration
    
    def upgrade_sensitivity(self, amount: float = 0.1) -> float:
        """Upgrade the detector sensitivity"""
        self.sensitivity = min(1.0, self.sensitivity + amount)
        self.detection_range = 10 + (20 * self.sensitivity)  # Update range
        return self.sensitivity
    
    def compare_auras(self, entity1_name: str, entity2_name: str) -> Dict[str, Any]:
        """
        Compare two known auras and provide analysis on their similarities and differences
        """
        aura1 = self.known_auras.get(entity1_name)
        aura2 = self.known_auras.get(entity2_name)
        
        if not aura1 or not aura2:
            return {"success": False, "message": "One or both entities not found in known auras"}
            
        # Calculate similarity metrics
        strength_diff = abs(aura1.strength - aura2.strength)
        stability_diff = abs(aura1.stability - aura2.stability)
        complexity_diff = abs(aura1.complexity - aura2.complexity)
        
        # Compare color spectrums
        color_similarity = 0
        total_colors = set(aura1.color_spectrum.keys()) | set(aura2.color_spectrum.keys())
        
        if total_colors:
            for color in total_colors:
                color_similarity += 1.0 - abs(
                    aura1.color_spectrum.get(color, 0) - 
                    aura2.color_spectrum.get(color, 0)
                )
            color_similarity /= len(total_colors)
        
        # Calculate overall similarity (0-1)
        similarity = (
            (1.0 - strength_diff) * 0.2 +
            (1.0 - stability_diff) * 0.2 +
            (1.0 - complexity_diff) * 0.2 +
            color_similarity * 0.4
        )
        
        # Determine if they might be from same timeline
        same_timeline_probability = 0.8 if aura1.timeline_name == aura2.timeline_name else 0.2
        
        if similarity > 0.8:
            same_timeline_probability += 0.15
        elif similarity < 0.3:
            same_timeline_probability -= 0.15
            
        same_timeline_probability = max(0.05, min(0.95, same_timeline_probability))
        
        # Generate analysis
        if similarity > 0.8:
            relationship = "Very similar auras, likely connected entities"
        elif similarity > 0.6:
            relationship = "Moderately similar auras with notable connections"
        elif similarity > 0.4:
            relationship = "Some similarities but significant differences"
        else:
            relationship = "Very different auras with minimal connection"
            
        # Prepare detailed analysis
        analysis = {
            "success": True,
            "entity1": entity1_name,
            "entity2": entity2_name,
            "similarity_score": similarity,
            "relationship_assessment": relationship,
            "same_timeline_probability": same_timeline_probability,
            "details": {
                "strength_difference": strength_diff,
                "stability_difference": stability_diff,
                "complexity_difference": complexity_diff,
                "color_similarity": color_similarity,
                "temporal_similarity": 1.0 - abs(aura1.time_dilation_factor - aura2.time_dilation_factor)
            }
        }
        
        return analysis
    
    def __str__(self) -> str:
        detection_count = len(self.detection_history)
        known_aura_count = len(self.known_auras)
        
        return (f"Temporal Aura Detector: {self.sensitivity:.2f} sensitivity, "
                f"{self.calibration:.2f} calibration, {self.detection_range:.1f}m range, "
                f"{known_aura_count} known auras")


class AuraInterferenceField:
    """Generates a field that can mask or interfere with temporal auras"""
    
    def __init__(self, field_strength: float = 0.5, field_radius: float = 5.0,
                masked_timelines: List[str] = None):
        """
        Initialize an aura interference field
        
        Args:
            field_strength: Strength of the interference (0.0-1.0)
            field_radius: Radius of the field in meters
            masked_timelines: List of timeline names this field masks specifically
        """
        self.field_strength = max(0.1, min(1.0, field_strength))
        self.field_radius = max(1.0, field_radius)
        self.masked_timelines = masked_timelines or []
        self.field_mode = "mask"  # Can be "mask" or "disrupt"
        self.energy_consumption = field_strength * field_radius * 0.5  # Per hour
        self.active = True
        self.activation_time = time.time()
        
    def apply_to_aura(self, aura: TemporalAura) -> TemporalAura:
        """
        Apply the field effect to an aura, returning a modified copy
        
        Args:
            aura: The temporal aura to modify
            
        Returns:
            Modified aura (a copy)
        """
        if not self.active:
            return aura
            
        # Create a copy to avoid modifying the original
        modified_aura = TemporalAura(
            aura.entity_name,
            aura.timeline_name,
            aura.strength,
            aura.complexity,
            aura.stability
        )
        
        # Copy other properties
        modified_aura.color_spectrum = aura.color_spectrum.copy()
        modified_aura.resonance_frequency = aura.resonance_frequency
        modified_aura.harmonic_pattern = aura.harmonic_pattern.copy()
        modified_aura.past_shadows = aura.past_shadows
        modified_aura.future_echoes = aura.future_echoes
        modified_aura.time_dilation_factor = aura.time_dilation_factor
        
        # Apply field effects
        # Specific timeline masking is more effective
        timeline_specific = aura.timeline_name in self.masked_timelines
        effect_multiplier = 1.5 if timeline_specific else 1.0
        
        if self.field_mode == "mask":
            # Masking reduces aura strength significantly
            modified_aura.strength = max(0.1, aura.strength - 
                                        (self.field_strength * 0.8 * effect_multiplier))
            
            # Also reduces complexity and makes it harder to analyze
            modified_aura.complexity = max(0.1, aura.complexity - 
                                         (self.field_strength * 0.4 * effect_multiplier))
            
            # Masks future echoes especially well
            modified_aura.future_echoes = max(0, round(aura.future_echoes * 
                                                    (1 - self.field_strength * effect_multiplier)))
                                                    
            # Mask color spectrum by averaging it toward gray
            for color in modified_aura.color_spectrum:
                modified_aura.color_spectrum[color] = aura.color_spectrum[color] * (1 - self.field_strength * 0.7)
                
        elif self.field_mode == "disrupt":
            # Disruption reduces stability but doesn't hide as well
            modified_aura.stability = max(0.1, aura.stability - 
                                        (self.field_strength * 0.7 * effect_multiplier))
            
            # Makes aura reading fluctuate
            modified_aura.strength = max(0.1, min(1.0, aura.strength + 
                                                 random.uniform(-0.3, 0.3) * self.field_strength))
            
            # Increases apparent complexity by adding noise
            modified_aura.complexity = min(1.0, aura.complexity + 
                                         (self.field_strength * 0.5 * effect_multiplier))
                                         
            # Disrupts harmonic pattern
            modified_aura.harmonic_pattern = [h * random.uniform(0.8, 1.2) 
                                            for h in aura.harmonic_pattern]
        
        return modified_aura
    
    def set_mode(self, mode: str) -> bool:
        """
        Set the field mode
        
        Args:
            mode: Either "mask" (hide auras) or "disrupt" (interfere with readings)
            
        Returns:
            Success status
        """
        if mode in ["mask", "disrupt"]:
            self.field_mode = mode
            return True
        return False
    
    def increase_strength(self, amount: float = 0.1) -> float:
        """Increase field strength, returns new strength"""
        old_strength = self.field_strength
        self.field_strength = min(1.0, self.field_strength + amount)
        
        # Update energy consumption
        self.energy_consumption = self.field_strength * self.field_radius * 0.5
        
        return self.field_strength
    
    def calculate_energy_used(self) -> float:
        """Calculate total energy used since activation"""
        if not self.active:
            return 0
            
        hours_active = (time.time() - self.activation_time) / 3600
        return self.energy_consumption * hours_active
    
    def toggle(self) -> bool:
        """Toggle the field on/off, returns new state"""
        self.active = not self.active
        
        if self.active:
            self.activation_time = time.time()
            
        return self.active
    
    def __str__(self) -> str:
        status = "ACTIVE" if self.active else "INACTIVE"
        masked = f", masking {len(self.masked_timelines)} specific timelines" if self.masked_timelines else ""
        return (f"Aura Interference Field: {status}, {self.field_mode} mode, "
                f"{self.field_strength:.2f} strength, {self.field_radius:.1f}m radius{masked}")


def run_temporal_aura_demo():
    """Run a demonstration of the temporal aura system"""
    print("=== Temporal Aura System Demonstration ===")
    
    # Create some sample auras
    print("\nCreating sample temporal auras...")
    
    # A stable entity with strong temporal presence
    traveler_aura = TemporalAura("Time Traveler", "Alpha Prime", 0.85, 0.7, 0.8)
    
    # A paradox-influenced entity
    paradox_aura = TemporalAura("Paradox Subject", "Beta Variant", 0.75, 0.9, 0.4)
    paradox_aura.influence_from_paradox("grandfather", 0.6)
    
    # An entity that frequently crosses timelines
    jumper_aura = TemporalAura("Timeline Jumper", "Theta Nexus", 0.65, 0.8, 0.6)
    for _ in range(5):
        jumper_aura.exposure_to_timeline(f"Random Timeline {random.randint(1, 100)}", 
                                        random.uniform(0.5, 3.0))
    
    # Display the auras
    print(f"\n{traveler_aura}")
    print(f"Visual description: {traveler_aura.get_visual_description()}")
    
    print(f"\n{paradox_aura}")
    print(f"Visual description: {paradox_aura.get_visual_description()}")
    
    print(f"\n{jumper_aura}")
    print(f"Visual description: {jumper_aura.get_visual_description()}")
    
    # Create an aura detector
    print("\nCreating aura detector...")
    detector = AuraDetector(0.7, 0.8)
    print(detector)
    
    # Detect auras
    print("\nDetecting auras...")
    traveler_reading = detector.detect_aura(traveler_aura)
    print(f"\nDetection results for Time Traveler:")
    print(f"Strength: {traveler_reading['strength']:.2f}")
    print(f"Stability: {traveler_reading['stability']:.2f}")
    print(f"Dominant color: {traveler_reading['dominant_color']}")
    print(f"Temporal state: {traveler_reading['temporal_state']}")
    
    # Create an interference field
    print("\nCreating interference field...")
    interference = AuraInterferenceField(0.7, 5.0, ["Beta Variant"])
    print(interference)
    
    # Apply interference to an aura
    print("\nApplying interference field to Paradox Subject...")
    masked_aura = interference.apply_to_aura(paradox_aura)
    
    # Compare original and masked readings
    original_reading = detector.detect_aura(paradox_aura)
    masked_reading = detector.detect_aura(masked_aura)
    
    print("\nOriginal reading:")
    print(f"Strength: {original_reading['strength']:.2f}")
    print(f"Stability: {original_reading['stability']:.2f}")
    print(f"Visual: {original_reading['visual_description']}")
    
    print("\nMasked reading:")
    print(f"Strength: {masked_reading['strength']:.2f}")
    print(f"Stability: {masked_reading['stability']:.2f}")
    print(f"Visual: {masked_reading['visual_description']}")
    
    # Compare two auras
    print("\nComparing Time Traveler and Timeline Jumper auras...")
    comparison = detector.compare_auras("Time Traveler", "Timeline Jumper")
    
    print(f"Similarity score: {comparison['similarity_score']:.2f}")
    print(f"Assessment: {comparison['relationship_assessment']}")
    print(f"Same timeline probability: {comparison['same_timeline_probability']:.2f}")
    
    # Merge two auras
    print("\nMerging Time Traveler and Paradox Subject auras...")
    merged_aura = traveler_aura.merge_with_aura(paradox_aura)
    
    print(merged_aura)
    print(f"Visual description: {merged_aura.get_visual_description()}")
    
    return {
        "auras": {
            "traveler": traveler_aura,
            "paradox": paradox_aura,
            "jumper": jumper_aura,
            "merged": merged_aura
        },
        "detector": detector,
        "interference": interference
    }


if __name__ == "__main__":
    run_temporal_aura_demo()
