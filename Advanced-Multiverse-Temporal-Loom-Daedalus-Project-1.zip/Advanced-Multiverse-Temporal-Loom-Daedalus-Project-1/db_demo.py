
#!/usr/bin/env python3
"""
Multiverse Database Demo
This script demonstrates the database functionality by creating timelines,
connecting them, and querying the database.
"""

import time
import random
from main import Multiverse, Timeline, QuantumWormhole, ParadoxResolver, Timewave

def run_database_demo():
    """Run a demonstration of the database functionality."""
    print("=== Multiverse Database Demo ===")
    print("Initializing multiverse with database...")
    
    # Import the database options manager
    from db_options import DatabaseOptionsManager
    
    # Create the database manager
    db_manager = DatabaseOptionsManager()
    use_db = db_manager.is_database_enabled()
    
    # Create a multiverse with database enabled
    multiverse = Multiverse(use_database=use_db)
    
    # Create several timelines
    print("\nCreating timelines...")
    alpha = multiverse.create_timeline("Database Alpha", 0.9)
    beta = multiverse.create_timeline("Database Beta", 0.75)
    gamma = multiverse.create_timeline("Database Gamma", 0.6)
    delta = multiverse.create_timeline("Database Delta", 0.5)
    omega = multiverse.create_timeline("Database Omega", 0.85)
    
    # Add historical events to each timeline
    print("\nAdding events to timelines...")
    alpha.add_event("Timeline origin point", 2000)
    alpha.add_event("Quantum computing breakthrough", 2025)
    alpha.add_event("First contact with extradimensional beings", 2042)

    beta.add_event("Timeline diverged from Alpha Prime", 2010)
    beta.add_event("Global climate catastrophe", 2028)
    beta.add_event("Underground civilization established", 2035)

    gamma.add_event("Timeline artificially created", 1980)
    gamma.add_event("Robotic revolution", 2015)
    gamma.add_event("Human consciousness uploaded to quantum network", 2038)

    delta.add_event("Timeline formed from quantum fluctuation", 1995)
    delta.add_event("Dimensional barrier discovery", 2022)
    delta.add_event("Time strand manipulation technology invented", 2030)

    omega.add_event("Timeline originated from future recursion", 2090)
    omega.add_event("Temporal mechanics breakthrough", 2065)
    omega.add_event("Quantum field unification theory completed", 2078)
    
    # Connect timelines
    print("\nConnecting timelines...")
    multiverse.connect_timelines("Database Alpha", "Database Beta")
    multiverse.connect_timelines("Database Alpha", "Database Gamma", quantum_entangle=True)
    multiverse.connect_timelines("Database Beta", "Database Delta")
    multiverse.connect_timelines("Database Gamma", "Database Delta")
    multiverse.connect_timelines("Database Omega", "Database Alpha", quantum_entangle=True)
    
    # Create stable quantum wormholes
    print("\nCreating quantum wormholes...")
    multiverse.create_quantum_wormhole("Database Alpha", "Database Omega", year_shift=30)
    multiverse.create_quantum_wormhole("Database Beta", "Database Gamma", year_shift=-10)
    
    # Simulate time travel events with paradoxes
    print("\nSimulating time travel events with potential paradoxes...")
    time_travelers = [
        "Dr. Elena Silva", "Quantum Explorer Jackson", "Professor Paradox", 
        "Traveler X", "Dr. Schrödinger", "Temporal Engineer Novikov"
    ]
    
    # Perform some wormhole travel
    for i in range(2):
        traveler = random.choice(time_travelers)
        wormhole_index = random.randint(0, len(multiverse.wormholes) - 1)
        origin_year = random.randint(2030, 2060)
        print(f"\nWormhole Travel {i+1}: {traveler} traveling via wormhole {wormhole_index} in year {origin_year}")
        multiverse.perform_quantum_wormhole_travel(wormhole_index, traveler, origin_year)
    
    # Perform some regular time travel
    for i in range(3):
        traveler = random.choice(time_travelers)
        timeline_names = list(multiverse.timelines.keys())
        origin_name = random.choice(timeline_names)
        destination_name = random.choice([n for n in timeline_names if n != origin_name])
        year = random.randint(2000, 2070)
        quantum_tunneling = random.random() < 0.4
        
        print(f"\nTime Travel {i+1}: {traveler} traveling from {origin_name} to {destination_name} in year {year}")
        multiverse.time_travel(origin_name, destination_name, traveler, year, quantum_tunneling)
    
    # Create quantum superposition
    print("\nCreating quantum superposition...")
    superposition = multiverse.create_quantum_superposition("Database Delta")
    if superposition:
        superposition.add_event("Quantum state observed creating alternative history", 2035)
    
    # Add some timewaves
    print("\nCreating temporal waves...")
    wave1 = multiverse.create_timewave("Database Alpha", 2040, 1.2, "Quantum singularity experiment")
    wave2 = multiverse.create_timewave("Database Beta", 2030, 0.8, "Temporal resonance cascade")
    
    # Propagate waves
    print("\nPropagating temporal waves...")
    for i in range(2):
        print(f"Propagation cycle {i+1}...")
        multiverse.propagate_timewaves()
    
    # Save and export multiverse state
    print("\nSaving multiverse state to database...")
    multiverse.save_multiverse_state()
    
    print("\nExporting multiverse state to file...")
    export_file = multiverse.export_to_file("db_multiverse_export.json")
    
    # Database queries
    print("\n=== Database Queries ===")
    
    print("\nUnstable timelines:")
    unstable = multiverse.get_unstable_timelines()
    for timeline in unstable:
        print(f"  - {timeline['name']} (Stability: {timeline['stability']:.2f})")
    
    print("\nQuantum anomalies:")
    anomalies = multiverse.get_quantum_anomalies()
    for anomaly in anomalies:
        print(f"  - {anomaly['name']}")
        if anomaly['wave_function_collapse']:
            print("    - Wave function collapse")
        if anomaly['entanglement_level'] > 0.8:
            print(f"    - High entanglement ({anomaly['entanglement_level']:.2f})")
        if anomaly['superposition']:
            print("    - Quantum superposition")
    
    print("\nParadox statistics:")
    paradox_stats = multiverse.get_paradox_statistics()
    for stat in paradox_stats:
        print(f"  - {stat['type']}: {stat['count']} (Resolved: {stat['resolved']})")
    
    print("\nSearching for 'quantum' events:")
    quantum_events = multiverse.search_events_across_timelines("quantum")
    
    print("\n=== Create a new multiverse and import from file ===")
    new_multiverse = Multiverse(use_database=True)
    print(f"New multiverse has {len(new_multiverse.timelines)} timelines")
    
    print("\nImporting from file...")
    new_multiverse.import_from_file("db_multiverse_export.json")
    print(f"After import, new multiverse has {len(new_multiverse.timelines)} timelines")
    
    print("\nDisplaying imported timelines:")
    for name, timeline in new_multiverse.timelines.items():
        print(f"  - {name} (Stability: {timeline.stability:.2f}, Events: {len(timeline.events)})")
    
    print("\nDatabase demo completed!")
    
    # Run the coordinate system demo if enabled
    from db_options import DatabaseOptionsManager
    db_manager = DatabaseOptionsManager()
    
    if db_manager.is_coordinates_enabled():
        print("\n\n")
        print("=" * 50)
        print("Running coordinate system demo...")
        from coordinate_demo import run_coordinate_demo
        run_coordinate_demo()

if __name__ == "__main__":
    run_database_demo()
