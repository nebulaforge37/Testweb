"""
Multiverse App System
A centralized system that connects all modules and provides a unified interface
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox
import importlib.util
import subprocess
import time
import random

class AppSystem:
    """Central app system that ties all modules together"""

    def __init__(self):
        self.modules = {}
        self.discover_modules()

    def discover_modules(self):
        """Discover all available Python modules in the system"""
        # Get all .py files in the current directory
        for file in os.listdir('.'):
            if file.endswith('.py') and file != 'app_system.py':
                module_name = file[:-3]  # Remove .py extension
                self.modules[module_name] = {
                    'file': file,
                    'available': True,
                    'description': self.get_module_description(file)
                }

    def get_module_description(self, file_path):
        """Extract module description from docstring"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()

            # Extract doc comment if it exists
            if '"""' in content:
                start = content.find('"""') + 3
                end = content.find('"""', start)
                if end > start:
                    return content[start:end].strip().split('\n')[0]

            return "No description available"
        except Exception:
            return "Error reading module"

    def run_module(self, module_name):
        """Run a specific module"""
        if module_name in self.modules and self.modules[module_name]['available']:
            try:
                # Try to import and run the module
                module_spec = importlib.util.spec_from_file_location(
                    module_name, 
                    self.modules[module_name]['file']
                )
                if module_spec:
                    module = importlib.util.module_from_spec(module_spec)
                    module_spec.loader.exec_module(module)

                    # Try to run the main function if it exists
                    if hasattr(module, 'main'):
                        module.main()
                    else:
                        # Otherwise use subprocess as fallback
                        subprocess.run([sys.executable, self.modules[module_name]['file']])

                    return True
                else:
                    print(f"Could not load module {module_name}")
            except Exception as e:
                print(f"Error running module {module_name}: {e}")

        return False

    def get_module_categories(self):
        """Group modules into categories based on name prefixes"""
        categories = {
            'core': [],
            'timeline': [],
            'quantum': [],
            'temporal': [],
            'reality': [],
            'db': [],
            'demo': [],
            'visualization': [],
            'other': []
        }

        for module_name, info in self.modules.items():
            if module_name.startswith('timeline_') or module_name == 'timeline_types':
                categories['timeline'].append((module_name, info))
            elif module_name.startswith('quantum_'):
                categories['quantum'].append((module_name, info))
            elif module_name.startswith('temporal_') or module_name == 'temporal_physics':
                categories['temporal'].append((module_name, info))
            elif module_name.startswith('reality_') or module_name == 'alternate_realities':
                categories['reality'].append((module_name, info))
            elif module_name.startswith('db_') or module_name == 'multiverse_db':
                categories['db'].append((module_name, info))
            elif 'demo' in module_name:
                categories['demo'].append((module_name, info))
            elif module_name in ['main', 'app_launcher', 'menu_system']:
                categories['core'].append((module_name, info))
            elif 'visualization' in module_name:
                categories['visualization'].append((module_name, info))
            else:
                categories['other'].append((module_name, info))

        return categories

class AppSystemGUI:
    """GUI for the App System"""

    def __init__(self, root):
        self.root = root
        self.root.title("Multiverse Simulation App System")
        self.root.geometry("1000x700")
        self.root.configure(bg="#1e1e2e")

        self.app_system = AppSystem()
        self.setup_ui()

    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Title
        title_label = ttk.Label(main_frame, 
                               text="Multiverse Simulation System", 
                               font=("Arial", 20, "bold"))
        title_label.pack(pady=10)

        subtitle_label = ttk.Label(main_frame, 
                                  text="Central App System", 
                                  font=("Arial", 14))
        subtitle_label.pack(pady=5)

        # Create notebook for categories
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill=tk.BOTH, expand=True, pady=10)

        # Get module categories
        categories = self.app_system.get_module_categories()

        # Create a tab for each category
        for category_name, modules in categories.items():
            if not modules:
                continue

            # Format category name
            display_name = category_name.replace('_', ' ').title()



            # Create frame for this category
            category_frame = ttk.Frame(notebook)
            notebook.add(category_frame, text=display_name)

            # Configure grid
            for i in range(3):
                category_frame.columnconfigure(i, weight=1)

            # Add module buttons
            for i, (module_name, info) in enumerate(modules):
                row = i // 3
                col = i % 3

                # Create module button
                self.create_module_button(
                    category_frame,
                    module_name,
                    info['description'],
                    lambda m=module_name: self.run_module(m),
                    row, col
                )

        # Bottom controls
        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(fill=tk.X, pady=10)

        refresh_button = ttk.Button(bottom_frame, text="Refresh Modules", 
                                   command=self.refresh_modules)
        refresh_button.pack(side=tk.LEFT, padx=5)

        launch_menu_button = ttk.Button(bottom_frame, text="Launch Menu System", 
                                       command=lambda: self.run_module("menu_system"))
        launch_menu_button.pack(side=tk.LEFT, padx=5)

        links_page_button = ttk.Button(bottom_frame, text="Open Links Page", 
                                      command=lambda: self.run_module("links_page"))
        links_page_button.pack(side=tk.LEFT, padx=5)

        quit_button = ttk.Button(bottom_frame, text="Quit", 
                               command=self.root.destroy)
        quit_button.pack(side=tk.RIGHT, padx=5)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, side=tk.BOTTOM, pady=5)

    def create_module_button(self, parent, name, description, command, row, column):
        """Create a styled module button with description"""
        frame = ttk.Frame(parent)
        frame.grid(row=row, column=column, padx=10, pady=10, sticky="nsew")

        # Format display name
        display_name = name.replace('_', ' ').title()

        button = ttk.Button(frame, text=display_name, command=command)
        button.pack(fill=tk.X, pady=5)

        desc_label = ttk.Label(frame, text=description, wraplength=250)
        desc_label.pack(pady=5)

        return frame

    def run_module(self, module_name):
        """Run the selected module"""
        self.status_var.set(f"Running module: {module_name}...")
        self.root.update_idletasks()

        success = self.app_system.run_module(module_name)

        if success:
            self.status_var.set(f"Successfully ran {module_name}")
        else:
            self.status_var.set(f"Failed to run {module_name}")
            messagebox.showerror("Error", f"Failed to run module {module_name}")

    def refresh_modules(self):
        """Refresh the module list"""
        self.status_var.set("Refreshing modules...")
        self.root.update_idletasks()

        self.app_system.discover_modules()

        # Recreate the UI with updated modules
        for widget in self.root.winfo_children():
            widget.destroy()

        self.setup_ui()
        self.status_var.set("Modules refreshed")

def main():
    """Run the app system"""
    try:
        # Try to use GUI version
        root = tk.Tk()
        app = AppSystemGUI(root)
        root.mainloop()
    except Exception as e:
        # Fall back to CLI version
        print(f"Error launching GUI: {e}")
        print("Falling back to command line interface...")

        app_system = AppSystem()
        categories = app_system.get_module_categories()

        while True:
            print("\n==== Multiverse Simulation App System ====")
            print("Available Categories:")

            category_names = [name for name, modules in categories.items() if modules]
            for i, name in enumerate(category_names, 1):
                print(f"{i}. {name.title()}")

            print("0. Exit")

            try:
                choice = int(input("\nSelect a category (0 to exit): "))
                if choice == 0:
                    break

                if 1 <= choice <= len(category_names):
                    category = category_names[choice - 1]
                    modules = categories[category]

                    print(f"\n==== {category.title()} Modules ====")
                    for i, (module_name, info) in enumerate(modules, 1):
                        print(f"{i}. {module_name}")
                        print(f"   {info['description']}")

                    module_choice = int(input("\nSelect a module (0 to go back): "))
                    if 1 <= module_choice <= len(modules):
                        selected = modules[module_choice - 1][0]
                        app_system.run_module(selected)
                else:
                    print("Invalid category selection.")
            except (ValueError, IndexError):
                print("Invalid selection.")

if __name__ == "__main__":
    main()
"""
Application System for the Multiverse Simulation
Manages application launching and integration for the simulation system.
"""

import os
import sys
import importlib
from typing import List, Dict, Any, Optional
import time

class AppSystem:
    """Central application management system for the multiverse simulation"""

    def __init__(self):
        """Initialize app system"""
        self.apps = {
            "timeline": {
                "name": "Timeline Explorer",
                "module": "timeline_visualization",
                "function": "main",
                "description": "Explore and visualize timelines",
                "category": "Visualization"
            },
            "quantum": {
                "name": "Quantum Dimension Explorer",
                "module": "quantum_demo",
                "function": "main",
                "description": "Explore quantum dimensions and mechanics",
                "category": "Visualization"
            },
            "fusion": {
                "name": "Fusion Reactor Simulator",
                "module": "fusion_demo",
                "function": "main",
                "description": "Simulate quantum fusion reactors",
                "category": "Simulation"
            },
            "coordinates": {
                "name": "Multiverse Coordinates",
                "module": "coordinate_demo",
                "function": "main",
                "description": "Work with multiverse coordinate systems",
                "category": "Navigation"
            },
            "menu": {
                "name": "Main Menu",
                "module": "menu_system",
                "function": "main",
                "description": "Main navigation menu",
                "category": "System"
            },
            "timeloops": {
                "name": "Time Loop Manager",
                "module": "time_loop_integration",
                "function": "main",
                "description": "Manage and analyze time loops",
                "category": "Temporal"
            },
            "paradox": {
                "name": "Paradox Forecaster",
                "module": "paradox_forecasting",
                "function": "display_forecasting_interface",
                "description": "Detect and forecast potential paradoxes",
                "category": "Analysis"
            },
            "algorithm": {
                "name": "Algorithm Demo",
                "module": "algorithm_demo",
                "function": "main",
                "description": "Demonstrate simulation algorithms",
                "category": "Demo"
            },
            "database": {
                "name": "Database Settings",
                "module": "db_settings_menu",
                "function": "main",
                "description": "Configure database settings",
                "category": "System"
            },
            "ml_demo": {
                "name": "Machine Learning Demo",
                "module": "ml_algorithms_demo",
                "function": "main",
                "description": "Demonstrate machine learning algorithms",
                "category": "Demo"
            },
            "dashboard": {
                "name": "Multiverse Dashboard",
                "module": "dashboard",
                "function": "main",
                "description": "Monitoring dashboard for the multiverse",
                "category": "Visualization"
            },
            "complexity": {
                "name": "Time Complexity Analyzer",
                "module": "time_complexity_algorithms",
                "function": "demonstrate_time_complexity",
                "description": "Analyze algorithm time complexities",
                "category": "Analysis"
            },
            "echoes": {
                "name": "Temporal Echo Visualization",
                "module": "temporal_echoes",
                "function": "run_temporal_echoes_demo",
                "description": "Visualize echoes from deleted timelines",
                "category": "Visualization"
            },
            "outside_space_time": {
                "name": "Outside Space-Time Continuum",
                "module": "outside_space_time",
                "function": "main",
                "description": "Explore regions outside of normal space-time",
                "category": "Physics"
            },
            "time_loom_shield": {
                "name": "Time Loom Shield",
                "module": "temporal_echo_integration",
                "function": "run_integration_demo",
                "description": "Manage and control the Time Loom Shield",
                "category": "Temporal"
            }
        }
        self.running_apps = {}
        self.last_app_id = 0

    def get_app_list(self) -> List[Dict[str, Any]]:
        """Get a list of all available applications"""
        result = []
        for app_id, app_info in self.apps.items():
            # Check if the module exists
            module_exists = self._check_module_exists(app_info["module"])

            result.append({
                "id": app_id,
                "name": app_info["name"],
                "description": app_info["description"],
                "category": app_info["category"],
                "available": module_exists
            })

        # Sort by category and then by name
        return sorted(result, key=lambda x: (x["category"], x["name"]))

    def get_apps_by_category(self) -> Dict[str, List[Dict[str, Any]]]:
        """Get applications organized by category"""
        categories = {}

        for app in self.get_app_list():
            category = app["category"]
            if category not in categories:
                categories[category] = []
            categories[category].append(app)

        return categories

    def _check_module_exists(self, module_name: str) -> bool:
        """Check if a module exists"""
        try:
            # Try to find the module spec without importing
            spec = importlib.util.find_spec(module_name)
            return spec is not None
        except (ImportError, ValueError):
            return False

    def launch_app(self, app_id: str) -> bool:
        """Launch an application by its ID"""
        if app_id not in self.apps:
            print(f"Error: Application '{app_id}' not found.")
            return False

        app_info = self.apps[app_id]
        module_name = app_info["module"]
        function_name = app_info["function"]

        try:
            # Import the module
            module = importlib.import_module(module_name)

            # Get the main function
            if hasattr(module, function_name):
                function = getattr(module, function_name)

                # Call the function
                function()
                return True
            else:
                print(f"Error: Function '{function_name}' not found in module '{module_name}'.")
                return False
        except ImportError as e:
            print(f"Error: Could not import module '{module_name}'. {e}")
            return False
        except Exception as e:
            print(f"Error launching application: {e}")
            return False

def display_app_menu():
    """Display the application menu and allow the user to launch an app"""
    app_system = AppSystem()

    # Get apps by category
    categories = app_system.get_apps_by_category()

    print("\n=== Multiverse Simulation Application Menu ===\n")

    # Sort categories alphabetically
    for category in sorted(categories.keys()):
        print(f"{category} Applications:")

        for i, app in enumerate(categories[category], 1):
            status = "✅" if app["available"] else "❌"
            print(f"  {i}. {app['name']} {status}")
            print(f"     {app['description']}")

        print()

    # Flatten app list for selection
    all_apps = app_system.get_app_list()

    try:
        app_index = int(input("Enter application number to launch (0 to exit): ")) - 1

        if 0 <= app_index < len(all_apps):
            app = all_apps[app_index]

            if app["available"]:
                print(f"\nLaunching {app['name']}...\n")
                app_system.launch_app(app["id"])
            else:
                print(f"\nError: {app['name']} is not available.")
        elif app_index == -1:
            return
        else:
            print("\nInvalid selection.")
    except ValueError:
        print("\nInvalid input. Please enter a number.")

def main():
    display_app_menu()

if __name__ == "__main__":
    main()