
"""
Reality Anchors Module
This module introduces anchor points that help maintain reality stability
and provide safe points for reality travelers.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any, Set
from quantum_dimensions import QuantumDimension, QuantumReality, DimensionalRegistry
from alternate_realities import RealityManager, RealityCoordinate

class AnchorType:
    """Type of reality anchor"""
    
    def __init__(self, name: str, description: str, stability_bonus: float, creation_difficulty: float):
        """
        Initialize an anchor type
        
        Args:
            name: Name of this anchor type
            description: Description of how it works
            stability_bonus: Bonus to reality stability (0.0-1.0)
            creation_difficulty: How difficult it is to create (0.0-1.0)
        """
        self.name = name
        self.description = description
        self.stability_bonus = stability_bonus
        self.creation_difficulty = creation_difficulty
        self.special_properties = []
        
    def add_property(self, name: str, description: str):
        """Add a special property to this anchor type"""
        self.special_properties.append({
            "name": name,
            "description": description
        })
        
    def __str__(self) -> str:
        return f"{self.name} (Stability: +{self.stability_bonus:.2f}): {self.description}"


class RealityAnchor:
    """Represents a stable anchor point in the multiverse"""
    
    def __init__(self, anchor_id: int, name: str, anchor_type: AnchorType, creator: str = "Unknown"):
        """
        Initialize a reality anchor
        
        Args:
            anchor_id: Unique identifier for this anchor
            name: Designation for this anchor
            anchor_type: Type of reality anchor
            creator: Entity that created this anchor
        """
        self.anchor_id = anchor_id
        self.name = name
        self.anchor_type = anchor_type
        self.creator = creator
        self.creation_time = random.randint(1000000000, 9999999999)  # Unix timestamp
        
        self.dimension_id = None
        self.reality_id = None
        self.coordinates = None  # RealityCoordinate object when placed
        
        self.stability = random.uniform(0.7, 1.0)  # Internal stability
        self.power_level = random.uniform(0.6, 1.0)  # Power level (affects range)
        self.range = 500 * self.power_level  # Effective range in arbitrary units
        
        self.properties = []  # Additional properties
        self.activation_log = []  # Log of activations
        
    def add_property(self, name: str, description: str, power: float = 0.5):
        """Add a special property to this anchor"""
        self.properties.append({
            "name": name,
            "description": description,
            "power": power
        })
        
    def place(self, dimension_id: int, reality_id: Optional[int], 
             coordinates: RealityCoordinate = None):
        """Place this anchor in a specific location"""
        self.dimension_id = dimension_id
        self.reality_id = reality_id
        self.coordinates = coordinates
        
        self.activation_log.append({
            "action": "placement",
            "dimension_id": dimension_id,
            "reality_id": reality_id,
            "timestamp": self.creation_time
        })
        
    def calculate_stability_bonus(self, distance: float = 0.0) -> float:
        """
        Calculate the stability bonus provided at a given distance
        
        Args:
            distance: Distance from the anchor (0.0 for at the anchor)
            
        Returns:
            Stability bonus (0.0-1.0)
        """
        # Maximum bonus at the anchor itself
        if distance <= 0.1:
            return self.anchor_type.stability_bonus * self.stability
            
        # Bonus decreases with distance
        if distance >= self.range:
            return 0.0
            
        # Linear decay with distance
        decay_factor = 1.0 - (distance / self.range)
        return self.anchor_type.stability_bonus * self.stability * decay_factor
    
    def activate(self, traveler_name: str, action: str = "stabilization") -> Dict[str, Any]:
        """
        Activate the anchor for a specific purpose
        
        Args:
            traveler_name: Name of the traveler activating the anchor
            action: Type of activation
            
        Returns:
            Result of activation
        """
        # Record activation
        activation = {
            "traveler": traveler_name,
            "action": action,
            "timestamp": random.randint(1000000000, 9999999999),
            "success": True,
            "effects": []
        }
        
        # Different activation types
        if action == "stabilization":
            # Basic stabilization
            stability_boost = self.anchor_type.stability_bonus * self.stability * random.uniform(0.8, 1.0)
            activation["effects"].append(f"Reality stabilized by {stability_boost:.2f}")
            
        elif action == "protection":
            # Protection from dimensional instability
            protection_level = self.power_level * random.uniform(0.7, 0.9)
            activation["effects"].append(f"Dimensional protection field activated at {protection_level:.2f} strength")
            
        elif action == "beacon":
            # Act as a beacon for other travelers
            beacon_range = int(self.range * 2 * random.uniform(0.9, 1.1))
            activation["effects"].append(f"Beacon activated with range of {beacon_range} units")
            
        elif action == "repair":
            # Repair reality damage
            repair_effectiveness = self.stability * random.uniform(0.6, 0.8)
            activation["effects"].append(f"Reality repair initiated with {repair_effectiveness:.2f} effectiveness")
            
        else:
            # Unknown action
            activation["success"] = False
            activation["effects"].append(f"Unknown activation type: {action}")
        
        # Apply anchor properties to the activation
        all_properties = self.properties + self.anchor_type.special_properties
        for prop in all_properties:
            if random.random() < 0.3:  # 30% chance for each property to manifest
                activation["effects"].append(f"{prop['name']}: {prop['description']}")
        
        self.activation_log.append(activation)
        return activation
    
    def is_in_range(self, dimension_id: int, reality_id: Optional[int], 
                  coordinates: RealityCoordinate = None) -> Tuple[bool, float]:
        """
        Check if a location is within range of this anchor
        
        Returns:
            (in_range, distance) tuple
        """
        # Must be in the same dimension and reality
        if dimension_id != self.dimension_id:
            return False, float('inf')
            
        if reality_id is not None and self.reality_id is not None and reality_id != self.reality_id:
            return False, float('inf')
            
        # If we have specific coordinates, check distance
        if coordinates and self.coordinates:
            distance = coordinates.calculate_distance(self.coordinates)
            return distance <= self.range, distance
            
        # If we're in the same dimension/reality but don't have coordinates, assume in range
        return True, 0.0
        
    def __str__(self) -> str:
        location = f"D{self.dimension_id}"
        if self.reality_id is not None:
            location += f":R{self.reality_id}"
            
        return f"{self.name} ({self.anchor_type.name}) at {location} - Power: {self.power_level:.2f}, Range: {self.range:.0f}"


class AnchorRegistry:
    """Registry for tracking and managing reality anchors"""
    
    def __init__(self, dimensional_registry: DimensionalRegistry = None, 
               reality_manager: RealityManager = None):
        """Initialize the anchor registry"""
        self.dimensional_registry = dimensional_registry
        self.reality_manager = reality_manager
        self.anchor_types = self._initialize_anchor_types()
        self.anchors: Dict[int, RealityAnchor] = {}
        self.next_anchor_id = 1
        
    def _initialize_anchor_types(self) -> Dict[str, AnchorType]:
        """Initialize standard anchor types"""
        anchor_types = {}
        
        # Quantum Lighthouse - standard stabilization anchor
        lighthouse = AnchorType(
            "Quantum Lighthouse",
            "Standard stabilization anchor that emits quantum coherence fields",
            stability_bonus=0.2,
            creation_difficulty=0.3
        )
        lighthouse.add_property("Reality Beacon", "Can be detected by travelers across dimensions")
        lighthouse.add_property("Safe Harbor", "Provides protection from dimensional instability")
        anchor_types["lighthouse"] = lighthouse
        
        # Dimensional Anchor - stronger but harder to create
        dimensional = AnchorType(
            "Dimensional Anchor",
            "Advanced anchor that directly reinforces dimensional boundaries",
            stability_bonus=0.4,
            creation_difficulty=0.7
        )
        dimensional.add_property("Boundary Reinforcement", "Strengthens the walls between dimensions")
        dimensional.add_property("Reality Lockdown", "Can prevent unauthorized transit near the anchor")
        anchor_types["dimensional"] = dimensional
        
        # Quantum Nexus - specialized for connecting realities
        nexus = AnchorType(
            "Quantum Nexus",
            "Specialized anchor that creates controlled connections between realities",
            stability_bonus=0.3,
            creation_difficulty=0.5
        )
        nexus.add_property("Reality Bridge", "Can establish temporary passages between realities")
        nexus.add_property("Quantum Synchronization", "Harmonizes quantum fields between realities")
        anchor_types["nexus"] = nexus
        
        # Temporal Anchor - specialized for time stabilization
        temporal = AnchorType(
            "Temporal Anchor",
            "Specialized anchor that stabilizes temporal fluctuations and paradoxes",
            stability_bonus=0.25,
            creation_difficulty=0.6
        )
        temporal.add_property("Paradox Dampening", "Reduces the impact of temporal paradoxes")
        temporal.add_property("Timeflow Regulation", "Normalizes temporal flow in the vicinity")
        anchor_types["temporal"] = temporal
        
        # Emergency Beacon - quick to create but less powerful
        emergency = AnchorType(
            "Emergency Beacon",
            "Quickly deployable temporary anchor for emergency stabilization",
            stability_bonus=0.15,
            creation_difficulty=0.2
        )
        emergency.add_property("Rapid Deployment", "Can be created quickly in emergencies")
        emergency.add_property("Distress Signal", "Alerts nearby anchors and travelers")
        anchor_types["emergency"] = emergency
        
        return anchor_types
        
    def get_anchor_type(self, type_name: str) -> Optional[AnchorType]:
        """Get an anchor type by name"""
        return self.anchor_types.get(type_name.lower())
    
    def create_anchor(self, name: str, type_name: str, creator: str,
                    dimension_id: int, reality_id: Optional[int],
                    coordinates: RealityCoordinate = None) -> Optional[RealityAnchor]:
        """
        Create a new reality anchor
        
        Args:
            name: Name for the anchor
            type_name: Type of anchor to create
            creator: Entity creating the anchor
            dimension_id: Dimension ID for placement
            reality_id: Reality ID for placement (optional)
            coordinates: Specific coordinates (optional)
            
        Returns:
            The created anchor or None if failed
        """
        anchor_type = self.get_anchor_type(type_name)
        if not anchor_type:
            print(f"Unknown anchor type: {type_name}")
            return None
            
        # Check if the dimension/reality exists
        if self.dimensional_registry:
            dimension = self.dimensional_registry.get_dimension(dimension_id)
            if not dimension:
                print(f"Dimension {dimension_id} not found")
                return None
                
            if reality_id is not None:
                reality = self.dimensional_registry.get_reality(reality_id)
                if not reality or reality.dimension_id != dimension_id:
                    print(f"Reality {reality_id} not found in dimension {dimension_id}")
                    return None
        
        # Create the anchor
        anchor = RealityAnchor(self.next_anchor_id, name, anchor_type, creator)
        self.next_anchor_id += 1
        
        # Calculate success chance based on creation difficulty
        creation_chance = 1.0 - (anchor_type.creation_difficulty * 0.6)
        
        # Creation more difficult in unstable realities
        if self.dimensional_registry and reality_id is not None:
            reality = self.dimensional_registry.get_reality(reality_id)
            if reality:
                stability_modifier = reality.stability * 0.3
                creation_chance += stability_modifier
        
        # Attempt to create the anchor
        success = random.random() < creation_chance
        
        if not success:
            print(f"Failed to create {anchor_type.name} anchor. The reality was too unstable or the process was flawed.")
            return None
            
        # Place the anchor
        anchor.place(dimension_id, reality_id, coordinates)
        
        # Add to registry
        self.anchors[anchor.anchor_id] = anchor
        
        print(f"Created anchor: {anchor}")
        
        # Apply immediate stability bonus to the reality if applicable
        if self.dimensional_registry and reality_id is not None:
            reality = self.dimensional_registry.get_reality(reality_id)
            if reality:
                stability_bonus = anchor.calculate_stability_bonus()
                old_stability = reality.stability
                reality.stability = min(1.0, reality.stability + stability_bonus)
                print(f"Reality {reality_id} stability increased from {old_stability:.2f} to {reality.stability:.2f}")
                
                # Add an event to the reality
                reality.add_event(f"Reality anchor '{name}' established by {creator}")
            
        return anchor
    
    def get_anchor(self, anchor_id: int) -> Optional[RealityAnchor]:
        """Get an anchor by ID"""
        return self.anchors.get(anchor_id)
    
    def get_anchors_in_range(self, dimension_id: int, reality_id: Optional[int], 
                            coordinates: RealityCoordinate = None) -> List[Tuple[RealityAnchor, float]]:
        """
        Get all anchors in range of a location, with distances
        
        Returns:
            List of (anchor, distance) tuples
        """
        in_range = []
        
        for anchor in self.anchors.values():
            in_range_check, distance = anchor.is_in_range(dimension_id, reality_id, coordinates)
            if in_range_check:
                in_range.append((anchor, distance))
                
        # Sort by distance
        in_range.sort(key=lambda x: x[1])
        
        return in_range
    
    def calculate_stability_bonus(self, dimension_id: int, reality_id: Optional[int],
                                coordinates: RealityCoordinate = None) -> float:
        """
        Calculate combined stability bonus from all anchors in range
        
        Returns:
            Combined stability bonus
        """
        anchors = self.get_anchors_in_range(dimension_id, reality_id, coordinates)
        if not anchors:
            return 0.0
            
        # Calculate combined bonus (diminishing returns for multiple anchors)
        combined_bonus = 0.0
        for anchor, distance in anchors:
            anchor_bonus = anchor.calculate_stability_bonus(distance)
            # Each additional anchor contributes less
            if combined_bonus == 0.0:
                combined_bonus = anchor_bonus  # Full bonus from closest anchor
            else:
                # Diminishing returns formula
                combined_bonus += anchor_bonus * (1.0 - (combined_bonus * 0.5))
                
        return min(0.5, combined_bonus)  # Cap at 50% boost
    
    def find_nearest_anchor(self, dimension_id: int, reality_id: Optional[int],
                          coordinates: RealityCoordinate = None) -> Optional[Tuple[RealityAnchor, float]]:
        """Find the nearest anchor to a location"""
        anchors = self.get_anchors_in_range(dimension_id, reality_id, coordinates)
        if anchors:
            return anchors[0]  # First one is closest
        return None
    
    def activate_nearest_anchor(self, traveler_name: str, dimension_id: int, 
                              reality_id: Optional[int],
                              coordinates: RealityCoordinate = None, 
                              action: str = "stabilization") -> Dict[str, Any]:
        """
        Activate the nearest anchor for a specific purpose
        
        Returns:
            Activation result or failure message
        """
        nearest = self.find_nearest_anchor(dimension_id, reality_id, coordinates)
        if not nearest:
            return {
                "success": False,
                "message": "No anchors in range to activate"
            }
            
        anchor, distance = nearest
        
        # Different activation range than effect range
        activation_range = anchor.range * 0.5  # Can only activate from closer range
        
        if distance > activation_range:
            return {
                "success": False,
                "message": f"Nearest anchor '{anchor.name}' is too far to activate ({distance:.1f} units)"
            }
            
        # Activate the anchor
        activation = anchor.activate(traveler_name, action)
        
        result = {
            "success": activation["success"],
            "anchor": anchor.anchor_id,
            "distance": distance,
            "effects": activation["effects"]
        }
        
        # Apply effects based on action type
        if activation["success"]:
            if action == "stabilization" and self.dimensional_registry and reality_id is not None:
                # Apply stability boost to the reality
                reality = self.dimensional_registry.get_reality(reality_id)
                if reality:
                    # Extract stability boost from effects
                    boost = 0.0
                    for effect in activation["effects"]:
                        if "stabilized by" in effect:
                            try:
                                boost = float(effect.split()[-1])
                            except:
                                pass
                    
                    if boost > 0:
                        old_stability = reality.stability
                        reality.stability = min(1.0, reality.stability + boost)
                        result["applied_stability"] = reality.stability - old_stability
                        
                        # Add an event to the reality
                        reality.add_event(f"Reality anchor '{anchor.name}' activated by {traveler_name}")
            
            # Format a message
            message = f"Activated {anchor.name} ({anchor.anchor_type.name}) at distance of {distance:.1f} units\n"
            message += "Effects:\n- " + "\n- ".join(activation["effects"])
            result["message"] = message
            
        return result
    
    def generate_anchor_report(self, anchor_id: Optional[int] = None) -> str:
        """Generate a report on anchors"""
        if anchor_id is not None:
            # Report on specific anchor
            anchor = self.get_anchor(anchor_id)
            if not anchor:
                return f"Anchor with ID {anchor_id} not found."
                
            report = [f"=== REALITY ANCHOR REPORT: {anchor.name} (ID: {anchor_id}) ==="]
            report.append(f"Type: {anchor.anchor_type.name}")
            report.append(f"Description: {anchor.anchor_type.description}")
            
            location = f"Dimension {anchor.dimension_id}"
            if anchor.reality_id is not None:
                location += f", Reality {anchor.reality_id}"
            report.append(f"Location: {location}")
            
            report.append(f"Creator: {anchor.creator}")
            report.append(f"Stability: {anchor.stability:.2f}")
            report.append(f"Power Level: {anchor.power_level:.2f}")
            report.append(f"Range: {anchor.range:.0f} units")
            report.append(f"Stability Bonus (at center): {anchor.calculate_stability_bonus():.2f}")
            
            report.append("\nProperties:")
            all_properties = anchor.properties + anchor.anchor_type.special_properties
            for prop in all_properties:
                report.append(f"  - {prop['name']}: {prop['description']}")
                
            if anchor.activation_log:
                report.append("\nRecent Activations:")
                for activation in anchor.activation_log[-3:]:  # Show last 3 activations
                    traveler = activation.get("traveler", "Unknown")
                    action = activation.get("action", "unknown action")
                    report.append(f"  - {traveler}: {action}")
                    
            return "\n".join(report)
        else:
            # Summary report of all anchors
            if not self.anchors:
                return "No reality anchors registered."
                
            report = ["=== REALITY ANCHOR REGISTRY SUMMARY ==="]
            report.append(f"Total Anchors: {len(self.anchors)}")
            
            # Count by type
            type_counts = {}
            for anchor in self.anchors.values():
                type_name = anchor.anchor_type.name
                type_counts[type_name] = type_counts.get(type_name, 0) + 1
                
            report.append("\nAnchor Types:")
            for type_name, count in type_counts.items():
                report.append(f"  - {type_name}: {count}")
                
            # Dimension coverage
            dimension_coverage = {}
            for anchor in self.anchors.values():
                dimension_coverage[anchor.dimension_id] = dimension_coverage.get(anchor.dimension_id, 0) + 1
                    
            report.append("\nDimension Coverage:")
            for dim_id, count in sorted(dimension_coverage.items()):
                report.append(f"  - Dimension {dim_id}: {count} anchors")
            
            return "\n".join(report)


def run_anchor_demo(dimensional_registry: DimensionalRegistry = None, 
                 reality_manager: RealityManager = None):
    """Run a demonstration of reality anchors"""
    print("=== Reality Anchors Demonstration ===")
    
    # Create registry if not provided
    if not dimensional_registry:
        dimensional_registry = DimensionalRegistry()
        dimensions = dimensional_registry.initialize_dimensions(count=3)
    
    # Create an anchor registry
    anchor_registry = AnchorRegistry(dimensional_registry, reality_manager)
    
    # Show available anchor types
    print("\nAvailable Reality Anchor Types:")
    for name, anchor_type in anchor_registry.anchor_types.items():
        print(f"- {anchor_type}")
    
    # Create some anchors in different dimensions/realities
    print("\nCreating reality anchors...")
    
    # First find some dimensions/realities to place anchors in
    if dimensional_registry.dimensions:
        anchors = []
        
        # Try to place in first three dimensions
        for i, dimension_id in enumerate(list(dimensional_registry.dimensions.keys())[:3]):
            dimension = dimensional_registry.get_dimension(dimension_id)
            
            # Choose anchor type
            anchor_types = list(anchor_registry.anchor_types.keys())
            anchor_type = anchor_types[i % len(anchor_types)]
            
            # Try to place in a reality first
            reality_id = None
            for reality in dimensional_registry.realities.values():
                if reality.dimension_id == dimension_id:
                    reality_id = reality.reality_id
                    break
            
            # Create the anchor
            anchor_name = f"Anchor-{chr(65+i)}-{dimension_id}"
            creator = random.choice(["Dr. Eliza Chen", "Professor Paradox", "Quantum Agent Smith"])
            
            anchor = anchor_registry.create_anchor(
                anchor_name, anchor_type, creator,
                dimension_id, reality_id
            )
            
            if anchor:
                anchors.append(anchor)
                
        if not anchors:
            print("Failed to create any anchors. Creating default anchor...")
            # Create a default anchor
            anchor = anchor_registry.create_anchor(
                "Default-Anchor", "lighthouse", "System",
                1, None
            )
            if anchor:
                anchors = [anchor]
    
        # Test activation
        if anchors:
            print("\nTesting anchor activation:")
            anchor = random.choice(anchors)
            dimension_id = anchor.dimension_id
            reality_id = anchor.reality_id
            
            activation = anchor_registry.activate_nearest_anchor(
                "Dr. Eliza Chen", dimension_id, reality_id
            )
            
            if activation["success"]:
                print(activation["message"])
                if "applied_stability" in activation:
                    print(f"Applied stability bonus: {activation['applied_stability']:.2f}")
            else:
                print(f"Activation failed: {activation['message']}")
            
        # Test finding anchors in range
        print("\nTesting anchor range detection:")
        for dimension_id in list(dimensional_registry.dimensions.keys())[:2]:
            anchors_in_range = anchor_registry.get_anchors_in_range(dimension_id, None)
            print(f"Dimension {dimension_id}: {len(anchors_in_range)} anchors in range")
            
            for anchor, distance in anchors_in_range:
                bonus = anchor.calculate_stability_bonus(distance)
                print(f"  - {anchor.name}: {distance:.1f} units away, stability bonus: {bonus:.2f}")
    
    # Print detailed report for one anchor
    if anchors:
        anchor = random.choice(anchors)
        print("\n" + anchor_registry.generate_anchor_report(anchor.anchor_id))
    
    # Print summary report
    print("\n" + anchor_registry.generate_anchor_report())
    
    return anchor_registry


def integrate_with_reality_manager(anchor_registry: AnchorRegistry, 
                                 reality_manager: RealityManager):
    """Integrate anchor registry with reality manager"""
    print("=== Integrating Reality Anchors with Reality Manager ===")
    
    if not anchor_registry.anchors:
        print("No anchors registered. Creating some...")
        # Create some default anchors in key realities
        creators = ["System Administrator", "Reality Commission", "Dimensional Authority"]
        
        # Place in first 3 realities
        realities = list(reality_manager.registry.realities.values())[:3]
        
        for i, reality in enumerate(realities):
            anchor_types = list(anchor_registry.anchor_types.keys())
            anchor_type = anchor_types[i % len(anchor_types)]
            
            anchor_name = f"Anchor-{chr(65+i)}-{reality.reality_id}"
            creator = random.choice(creators)
            
            anchor = anchor_registry.create_anchor(
                anchor_name, anchor_type, creator,
                reality.dimension_id, reality.reality_id
            )
    
    # Extend reality travel to apply anchor effects
    original_travel_method = reality_manager.perform_reality_travel
    
    def enhanced_reality_travel(traveler_name, destination_dimension, destination_reality, use_breach=False):
        # Call original method
        result = original_travel_method(traveler_name, destination_dimension, destination_reality, use_breach)
        
        # Apply anchor effects at destination
        bonus = anchor_registry.calculate_stability_bonus(destination_dimension, destination_reality)
        if bonus > 0:
            reality = reality_manager.registry.get_reality(destination_reality)
            if reality:
                old_stability = reality.stability
                reality.stability = min(1.0, reality.stability + bonus)
                
                print(f"\nReality anchor effect: Stability increased from {old_stability:.2f} to {reality.stability:.2f}")
                
                # Find the nearest anchor that contributed
                nearest = anchor_registry.find_nearest_anchor(destination_dimension, destination_reality)
                if nearest:
                    anchor, distance = nearest
                    print(f"Nearest anchor: {anchor.name} ({distance:.1f} units away)")
        
        return result
    
    # Replace the travel method
    reality_manager.perform_reality_travel = enhanced_reality_travel
    print("Reality travel system enhanced with anchor effects")
    
    # Apply anchor effects to all current realities
    for reality_id, reality in reality_manager.registry.realities.items():
        bonus = anchor_registry.calculate_stability_bonus(reality.dimension_id, reality_id)
        if bonus > 0:
            old_stability = reality.stability
            reality.stability = min(1.0, reality.stability + bonus)
            
            print(f"Reality {reality_id} affected by anchors: Stability {old_stability:.2f} -> {reality.stability:.2f}")
    
    return reality_manager


if __name__ == "__main__":
    run_anchor_demo()
"""
Reality Anchor System
This module provides tools for creating and managing reality anchors
that stabilize timelines and dimensions against paradoxical effects.
"""

import random
import math
import time
from typing import Dict, List, Tuple, Optional, Any

class RealityAnchor:
    """
    A reality anchor that stabilizes a specific point in space-time,
    preventing paradoxes and timeline degradation.
    """
    
    def __init__(self, 
                anchor_id: str,
                timeline_name: str,
                year: int,
                strength: float = 1.0,
                radius: float = 100.0):
        """
        Initialize a reality anchor
        
        Args:
            anchor_id: Unique identifier for this anchor
            timeline_name: The timeline this anchor is placed in
            year: The year this anchor is placed at
            strength: The stabilizing strength (0.0-2.0)
            radius: The effective radius in km
        """
        self.anchor_id = anchor_id
        self.timeline_name = timeline_name
        self.year = year
        self.strength = min(2.0, max(0.1, strength))
        self.radius = max(1.0, radius)
        
        # Generate coordinates
        self.x = random.uniform(-1000, 1000)  # Arbitrary coordinate system
        self.y = random.uniform(-1000, 1000)
        self.z = random.uniform(-1000, 1000)
        
        # Anchor properties
        self.stability = 1.0  # Degrades over time
        self.creation_time = time.time()
        self.last_maintenance = time.time()
        self.paradox_absorptions = 0
        self.field_integrity = 1.0
        self.energy_capacity = self.strength * 100.0
        self.current_energy = self.energy_capacity
        
        # Status flags
        self.active = True
        self.overloaded = False
        self.field_collapse = False
    
    def update_status(self, elapsed_time: float) -> None:
        """
        Update the anchor's status based on elapsed time
        
        Args:
            elapsed_time: Time elapsed in days since last update
        """
        # Anchors slowly lose energy and stability
        energy_decay = self.energy_capacity * 0.01 * elapsed_time
        self.current_energy = max(0, self.current_energy - energy_decay)
        
        # Stability degrades faster if energy is low
        energy_ratio = self.current_energy / self.energy_capacity
        stability_decay = 0.005 * elapsed_time * (1.0 + (1.0 - energy_ratio) * 2)
        self.stability = max(0, self.stability - stability_decay)
        
        # Field integrity follows stability but can degrade faster
        if self.paradox_absorptions > 0:
            # Each paradox absorption damages field integrity
            integrity_damage = self.paradox_absorptions * 0.05 * elapsed_time
            self.field_integrity = max(0, self.field_integrity - integrity_damage)
        else:
            # Normal decay
            self.field_integrity = max(0, self.field_integrity - (0.003 * elapsed_time))
        
        # Update flags based on current status
        self.active = self.current_energy > 0 and self.stability > 0.1
        self.overloaded = self.paradox_absorptions > int(self.strength * 5)
        self.field_collapse = self.field_integrity < 0.2
    
    def perform_maintenance(self) -> Tuple[bool, str]:
        """
        Perform maintenance on the anchor to restore energy and stability
        
        Returns:
            Tuple of (success, message)
        """
        if self.field_collapse:
            return False, "Cannot perform maintenance: field collapse detected"
        
        # Reset maintenance timer
        self.last_maintenance = time.time()
        
        # Restore energy
        energy_before = self.current_energy
        self.current_energy = self.energy_capacity
        
        # Improve stability
        stability_before = self.stability
        stability_gain = min(1.0 - self.stability, 0.3)
        self.stability += stability_gain
        
        # Repair field integrity
        integrity_before = self.field_integrity
        integrity_gain = min(1.0 - self.field_integrity, 0.2)
        self.field_integrity += integrity_gain
        
        # Reset overload if not too severe
        if self.paradox_absorptions < int(self.strength * 8):
            self.paradox_absorptions = 0
            self.overloaded = False
        
        return True, f"Maintenance complete: Energy +{self.current_energy - energy_before:.2f}, Stability +{stability_gain:.2f}, Integrity +{integrity_gain:.2f}"
    
    def absorb_paradox(self, paradox_magnitude: float) -> Tuple[bool, float]:
        """
        Attempt to absorb a paradox effect
        
        Args:
            paradox_magnitude: The magnitude of the paradox (0.0-1.0)
            
        Returns:
            Tuple of (success, remaining_magnitude)
        """
        if not self.active or self.overloaded or self.field_collapse:
            return False, paradox_magnitude
        
        # Scale paradox magnitude based on anchor strength
        scaled_magnitude = paradox_magnitude / self.strength
        
        # Energy cost for absorption
        energy_cost = scaled_magnitude * 20.0
        
        # Check if we have enough energy
        if energy_cost > self.current_energy:
            # Partial absorption
            absorption_ratio = self.current_energy / energy_cost
            self.current_energy = 0
            self.paradox_absorptions += 1
            self.field_integrity -= 0.1 * scaled_magnitude
            
            # Return remaining magnitude
            remaining = paradox_magnitude * (1.0 - absorption_ratio)
            return True, remaining
        else:
            # Full absorption
            self.current_energy -= energy_cost
            self.paradox_absorptions += 1
            self.field_integrity -= 0.05 * scaled_magnitude
            
            return True, 0.0
    
    def calculate_protection_at_distance(self, distance: float) -> float:
        """
        Calculate protection factor at a given distance
        
        Args:
            distance: Distance from anchor in km
            
        Returns:
            Protection factor (0.0-1.0)
        """
        if not self.active or distance > self.radius:
            return 0.0
        
        # Protection declines with distance using inverse square law
        base_protection = self.strength * self.stability * (self.field_integrity ** 0.5)
        distance_factor = 1.0 - (distance / self.radius) ** 2
        
        return base_protection * distance_factor
    
    def get_status_report(self) -> Dict[str, Any]:
        """Get a detailed status report"""
        days_since_maintenance = (time.time() - self.last_maintenance) / 86400  # Convert to days
        
        return {
            "anchor_id": self.anchor_id,
            "timeline": self.timeline_name,
            "year": self.year,
            "coordinates": (self.x, self.y, self.z),
            "strength": self.strength,
            "radius": self.radius,
            "stability": self.stability,
            "field_integrity": self.field_integrity,
            "energy": {
                "current": self.current_energy,
                "capacity": self.energy_capacity,
                "percentage": (self.current_energy / self.energy_capacity) * 100
            },
            "status": {
                "active": self.active,
                "overloaded": self.overloaded,
                "field_collapse": self.field_collapse
            },
            "maintenance": {
                "days_since_last": days_since_maintenance,
                "recommended": days_since_maintenance > 30 or self.stability < 0.5
            },
            "paradox_absorptions": self.paradox_absorptions
        }
    
    def __str__(self) -> str:
        status = "ACTIVE" if self.active else "INACTIVE"
        if self.overloaded:
            status = "OVERLOADED"
        if self.field_collapse:
            status = "FIELD COLLAPSE"
        
        return (f"Reality Anchor {self.anchor_id}: {status} - "
                f"Timeline: {self.timeline_name}, Year: {self.year}, "
                f"Strength: {self.strength:.2f}, Stability: {self.stability:.2f}")


class RealityAnchorNetwork:
    """
    A network of connected reality anchors that form a protective grid
    across a timeline or multiple timelines.
    """
    
    def __init__(self, network_id: str, name: str = None):
        """
        Initialize a reality anchor network
        
        Args:
            network_id: Unique identifier for this network
            name: Descriptive name
        """
        self.network_id = network_id
        self.name = name or f"Network {network_id}"
        self.anchors: List[str] = []  # List of anchor IDs in this network
        self.connections: Dict[str, List[str]] = {}  # Anchor ID -> connected anchor IDs
        self.creation_time = time.time()
        self.stability = 1.0
        self.synchronization = 1.0
        self.primary_timeline = None
    
    def add_anchor(self, anchor_id: str) -> bool:
        """
        Add an anchor to this network
        
        Args:
            anchor_id: The ID of the anchor to add
            
        Returns:
            True if added successfully
        """
        if anchor_id not in self.anchors:
            self.anchors.append(anchor_id)
            self.connections[anchor_id] = []
            return True
        return False
    
    def connect_anchors(self, anchor_id1: str, anchor_id2: str) -> bool:
        """
        Create a connection between two anchors in the network
        
        Args:
            anchor_id1: First anchor ID
            anchor_id2: Second anchor ID
            
        Returns:
            True if connected successfully
        """
        if (anchor_id1 in self.anchors and 
            anchor_id2 in self.anchors and 
            anchor_id1 != anchor_id2):
            
            # Add bidirectional connection if it doesn't exist
            if anchor_id2 not in self.connections[anchor_id1]:
                self.connections[anchor_id1].append(anchor_id2)
            
            if anchor_id1 not in self.connections[anchor_id2]:
                self.connections[anchor_id2].append(anchor_id1)
                
            return True
        
        return False
    
    def calculate_network_strength(self, anchors_data: Dict[str, RealityAnchor]) -> float:
        """
        Calculate the overall strength of this network based on connected anchors
        
        Args:
            anchors_data: Dictionary of anchor_id -> RealityAnchor objects
            
        Returns:
            Network strength factor (0.0-2.0)
        """
        if not self.anchors:
            return 0.0
        
        # Base strength from individual anchors
        total_strength = 0.0
        active_anchors = 0
        
        for anchor_id in self.anchors:
            anchor = anchors_data.get(anchor_id)
            if anchor and anchor.active:
                total_strength += anchor.strength * anchor.stability
                active_anchors += 1
        
        if active_anchors == 0:
            return 0.0
            
        # Calculate base average
        base_strength = total_strength / active_anchors
        
        # Network bonus based on connectivity
        connection_count = sum(len(conns) for conns in self.connections.values()) // 2
        ideal_connections = (active_anchors * (active_anchors - 1)) // 2
        
        if ideal_connections == 0:
            connectivity_ratio = 0
        else:
            connectivity_ratio = min(1.0, connection_count / ideal_connections)
        
        # Synchronization factor
        sync_factor = self.synchronization
        
        # Final strength calculation
        network_strength = base_strength * (1.0 + connectivity_ratio * 0.5) * sync_factor
        
        return min(2.0, network_strength)
    
    def update_status(self, anchors_data: Dict[str, RealityAnchor]) -> None:
        """
        Update network status based on its anchors
        
        Args:
            anchors_data: Dictionary of anchor_id -> RealityAnchor objects
        """
        # Remove invalid anchors
        self.anchors = [a_id for a_id in self.anchors if a_id in anchors_data]
        
        # Update connections
        for anchor_id in list(self.connections.keys()):
            if anchor_id not in self.anchors:
                del self.connections[anchor_id]
            else:
                self.connections[anchor_id] = [
                    conn for conn in self.connections[anchor_id] 
                    if conn in self.anchors
                ]
        
        # Calculate how many anchors are in the same timeline
        timeline_counts = {}
        active_anchors = 0
        
        for anchor_id in self.anchors:
            anchor = anchors_data.get(anchor_id)
            if anchor:
                timeline = anchor.timeline_name
                timeline_counts[timeline] = timeline_counts.get(timeline, 0) + 1
                
                if anchor.active:
                    active_anchors += 1
        
        # Find primary timeline
        if timeline_counts:
            self.primary_timeline = max(timeline_counts.items(), key=lambda x: x[1])[0]
        else:
            self.primary_timeline = None
        
        # Update synchronization based on timeline distribution
        if not self.anchors:
            self.synchronization = 0.0
        else:
            # Higher synchronization if anchors are in the same timeline
            max_count = max(timeline_counts.values()) if timeline_counts else 0
            self.synchronization = max_count / len(self.anchors)
        
        # Update stability based on active anchors
        if not self.anchors:
            self.stability = 0.0
        else:
            self.stability = active_anchors / len(self.anchors)
    
    def __str__(self) -> str:
        return (f"Anchor Network {self.name}: "
                f"{len(self.anchors)} anchors, "
                f"Stability: {self.stability:.2f}, "
                f"Synchronization: {self.synchronization:.2f}")


class RealityAnchorSystem:
    """
    System for managing reality anchors across the multiverse.
    """
    
    def __init__(self, multiverse = None):
        """
        Initialize the reality anchor system
        
        Args:
            multiverse: Optional reference to the multiverse object
        """
        self.multiverse = multiverse
        self.anchors: Dict[str, RealityAnchor] = {}
        self.networks: Dict[str, RealityAnchorNetwork] = {}
        self.last_update = time.time()
        self.next_anchor_id = 1
        self.next_network_id = 1
    
    def create_anchor(self, 
                     timeline_name: str,
                     year: int,
                     strength: float = 1.0,
                     radius: float = 100.0,
                     auto_network: bool = True) -> str:
        """
        Create a new reality anchor
        
        Args:
            timeline_name: Timeline to place the anchor in
            year: Year to place the anchor at
            strength: Anchor strength (0.0-2.0)
            radius: Effective radius in km
            auto_network: Automatically add to appropriate network
            
        Returns:
            The ID of the created anchor
        """
        # Generate anchor ID
        anchor_id = f"RA-{self.next_anchor_id:04d}"
        self.next_anchor_id += 1
        
        # Create the anchor
        anchor = RealityAnchor(
            anchor_id, 
            timeline_name, 
            year, 
            strength, 
            radius
        )
        
        self.anchors[anchor_id] = anchor
        
        # Automatically add to appropriate network if requested
        if auto_network:
            # Find a network focusing on this timeline, or create one
            network_id = None
            for net_id, network in self.networks.items():
                if network.primary_timeline == timeline_name:
                    network_id = net_id
                    break
            
            if not network_id:
                # Create a new network for this timeline
                network_id = f"NET-{self.next_network_id:03d}"
                self.next_network_id += 1
                
                network = RealityAnchorNetwork(
                    network_id, 
                    f"{timeline_name} Protection Network"
                )
                self.networks[network_id] = network
            
            # Add anchor to the network
            self.networks[network_id].add_anchor(anchor_id)
            
            # Connect to nearby anchors in the same network
            self._connect_to_nearby_anchors(anchor_id, network_id)
        
        return anchor_id
    
    def _connect_to_nearby_anchors(self, anchor_id: str, network_id: str) -> None:
        """Connect an anchor to nearby anchors in the same network"""
        if network_id not in self.networks or anchor_id not in self.anchors:
            return
        
        network = self.networks[network_id]
        anchor = self.anchors[anchor_id]
        
        # Find anchors in the same timeline that are close by
        for other_id in network.anchors:
            if other_id == anchor_id:
                continue
                
            other = self.anchors.get(other_id)
            if not other:
                continue
                
            # Same timeline and close in time
            if (other.timeline_name == anchor.timeline_name and 
                abs(other.year - anchor.year) < 50):
                
                # Calculate spatial distance
                distance = math.sqrt(
                    (other.x - anchor.x) ** 2 +
                    (other.y - anchor.y) ** 2 +
                    (other.z - anchor.z) ** 2
                )
                
                # Connect if within combined radii
                if distance < (anchor.radius + other.radius):
                    network.connect_anchors(anchor_id, other_id)
    
    def update_all(self) -> None:
        """Update all anchors and networks"""
        current_time = time.time()
        elapsed_days = (current_time - self.last_update) / 86400  # Convert to days
        
        # Update all anchors
        for anchor in self.anchors.values():
            anchor.update_status(elapsed_days)
        
        # Update all networks
        for network in self.networks.values():
            network.update_status(self.anchors)
        
        self.last_update = current_time
    
    def get_anchor(self, anchor_id: str) -> Optional[RealityAnchor]:
        """Get an anchor by ID"""
        return self.anchors.get(anchor_id)
    
    def get_network(self, network_id: str) -> Optional[RealityAnchorNetwork]:
        """Get a network by ID"""
        return self.networks.get(network_id)
    
    def get_timeline_protection_factor(self, timeline_name: str) -> float:
        """
        Calculate the overall protection factor for a timeline
        
        Args:
            timeline_name: The name of the timeline
            
        Returns:
            Protection factor (0.0-1.0)
        """
        # Find anchors in this timeline
        timeline_anchors = [
            a for a in self.anchors.values() 
            if a.timeline_name == timeline_name and a.active
        ]
        
        if not timeline_anchors:
            return 0.0
        
        # Find networks operating in this timeline
        timeline_networks = [
            n for n in self.networks.values()
            if n.primary_timeline == timeline_name
        ]
        
        # Base protection from individual anchors
        anchor_protection = sum(a.strength * a.stability for a in timeline_anchors)
        anchor_protection = min(1.0, anchor_protection / (3.0 + len(timeline_anchors) * 0.3))
        
        # Enhanced protection from networks
        network_protection = 0.0
        if timeline_networks:
            network_strength = max(n.calculate_network_strength(self.anchors) for n in timeline_networks)
            network_protection = min(1.0, network_strength / 2.0)
        
        # Combine factors with network bonus
        combined_protection = anchor_protection + (network_protection * 0.5)
        return min(1.0, combined_protection)
    
    def get_protection_at_coordinates(self, 
                                    timeline_name: str, 
                                    year: int, 
                                    x: float, 
                                    y: float, 
                                    z: float) -> float:
        """
        Calculate protection factor at specific coordinates
        
        Args:
            timeline_name: Timeline name
            year: Year
            x, y, z: Spatial coordinates
            
        Returns:
            Protection factor (0.0-1.0)
        """
        # Find active anchors in this timeline
        timeline_anchors = [
            a for a in self.anchors.values() 
            if a.timeline_name == timeline_name and a.active
        ]
        
        if not timeline_anchors:
            return 0.0
        
        # Calculate protection from each anchor
        protections = []
        for anchor in timeline_anchors:
            # Time distance affects protection
            time_distance = abs(anchor.year - year)
            if time_distance > 50:  # Arbitrary limit
                effective_strength = anchor.strength * max(0, (100 - time_distance) / 50)
            else:
                effective_strength = anchor.strength
            
            # Calculate spatial distance
            distance = math.sqrt(
                (anchor.x - x) ** 2 +
                (anchor.y - y) ** 2 +
                (anchor.z - z) ** 2
            )
            
            # Calculate protection at this distance
            protection = anchor.calculate_protection_at_distance(distance)
            protection *= (effective_strength / anchor.strength)  # Adjust for time distance
            
            protections.append(protection)
        
        # Use the strongest protection as the base
        if not protections:
            return 0.0
            
        strongest = max(protections)
        
        # Additional anchors provide diminishing returns
        additional = sum(sorted(protections, reverse=True)[1:]) * 0.3
        
        return min(1.0, strongest + additional)
    
    def handle_paradox(self, 
                      timeline_name: str, 
                      year: int, 
                      x: float, 
                      y: float, 
                      z: float, 
                      magnitude: float) -> Tuple[float, List[str]]:
        """
        Handle a paradox event by using anchors to absorb it
        
        Args:
            timeline_name: Timeline where paradox occurred
            year: Year of the paradox
            x, y, z: Spatial coordinates
            magnitude: Paradox magnitude (0.0-1.0)
            
        Returns:
            Tuple of (remaining_magnitude, list of affected anchor IDs)
        """
        # Find active anchors in this timeline
        timeline_anchors = [
            a for a in self.anchors.values() 
            if a.timeline_name == timeline_name and a.active
        ]
        
        affected_anchors = []
        remaining = magnitude
        
        # Sort anchors by distance (closest first)
        sorted_anchors = []
        for anchor in timeline_anchors:
            # Calculate spatial distance
            distance = math.sqrt(
                (anchor.x - x) ** 2 +
                (anchor.y - y) ** 2 +
                (anchor.z - z) ** 2
            )
            
            # Only include anchors within their radius
            if distance <= anchor.radius:
                # Calculate effective strength based on time distance
                time_distance = abs(anchor.year - year)
                if time_distance > 50:
                    time_factor = max(0, (100 - time_distance) / 50)
                else:
                    time_factor = 1.0
                
                sorted_anchors.append((anchor, distance, time_factor))
        
        # Sort by distance
        sorted_anchors.sort(key=lambda x: x[1])
        
        # Try to absorb the paradox with anchors
        for anchor, distance, time_factor in sorted_anchors:
            if remaining <= 0:
                break
                
            # Scale the paradox based on distance and time
            local_magnitude = remaining * time_factor
            
            # Try to absorb
            success, new_remaining = anchor.absorb_paradox(local_magnitude)
            
            if success:
                # Calculate how much was absorbed
                absorbed = local_magnitude - new_remaining
                remaining -= absorbed
                
                # Add to affected anchors
                affected_anchors.append(anchor.anchor_id)
        
        # Make sure we don't return a negative value
        remaining = max(0.0, remaining)
        
        return remaining, affected_anchors
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get an overall status report of the anchor system"""
        # Update everything first
        self.update_all()
        
        # Count active/inactive anchors
        total_anchors = len(self.anchors)
        active_anchors = sum(1 for a in self.anchors.values() if a.active)
        overloaded_anchors = sum(1 for a in self.anchors.values() if a.overloaded)
        collapsed_anchors = sum(1 for a in self.anchors.values() if a.field_collapse)
        
        # Count anchors by timeline
        timeline_counts = {}
        for anchor in self.anchors.values():
            timeline = anchor.timeline_name
            timeline_counts[timeline] = timeline_counts.get(timeline, 0) + 1
        
        # Calculate overall system integrity
        if total_anchors > 0:
            system_integrity = (active_anchors - overloaded_anchors * 0.5 - collapsed_anchors) / total_anchors
        else:
            system_integrity = 0.0
        
        return {
            "total_anchors": total_anchors,
            "active_anchors": active_anchors,
            "overloaded_anchors": overloaded_anchors,
            "collapsed_anchors": collapsed_anchors,
            "timeline_distribution": timeline_counts,
            "total_networks": len(self.networks),
            "system_integrity": system_integrity,
            "anchors_needing_maintenance": sum(
                1 for a in self.anchors.values()
                if a.active and (
                    a.stability < 0.5 or 
                    time.time() - a.last_maintenance > 30 * 86400
                )
            )
        }


def run_reality_anchor_demo():
    """Run a demonstration of the reality anchor system"""
    print("\n=== Reality Anchor System Demonstration ===\n")
    
    # Create the anchor system
    system = RealityAnchorSystem()
    
    # Create some anchors in different timelines
    print("Creating reality anchors...")
    
    # Alpha Prime anchors (strong network)
    alpha1 = system.create_anchor("Alpha Prime", 2020, 1.2, 200.0)
    alpha2 = system.create_anchor("Alpha Prime", 2040, 1.1, 180.0)
    alpha3 = system.create_anchor("Alpha Prime", 2060, 1.3, 220.0)
    alpha4 = system.create_anchor("Alpha Prime", 2000, 0.9, 150.0)
    
    # Beta Variant anchors (smaller network)
    beta1 = system.create_anchor("Beta Variant", 2030, 0.8, 120.0)
    beta2 = system.create_anchor("Beta Variant", 2050, 0.9, 130.0)
    
    # Gamma Nexus (single anchor)
    gamma1 = system.create_anchor("Gamma Nexus", 2025, 1.5, 250.0)
    
    # Create a damaged anchor
    damaged = system.create_anchor("Delta Flux", 2010, 0.6, 100.0)
    damaged_anchor = system.get_anchor(damaged)
    damaged_anchor.stability = 0.3
    damaged_anchor.field_integrity = 0.2
    damaged_anchor.current_energy = damaged_anchor.energy_capacity * 0.1
    
    # Update the system to establish connections
    system.update_all()
    
    # Display information about the anchors
    print("\n=== Reality Anchors ===\n")
    for anchor_id, anchor in system.anchors.items():
        print(f"{anchor}")
    
    # Display networks
    print("\n=== Anchor Networks ===\n")
    for network_id, network in system.networks.items():
        print(f"{network}")
        print(f"  Anchors: {', '.join(network.anchors)}")
        
        strength = network.calculate_network_strength(system.anchors)
        print(f"  Network Strength: {strength:.2f}")
    
    # Calculate protection levels
    print("\n=== Timeline Protection Levels ===\n")
    timelines = ["Alpha Prime", "Beta Variant", "Gamma Nexus", "Delta Flux"]
    
    for timeline in timelines:
        protection = system.get_timeline_protection_factor(timeline)
        print(f"{timeline}: {protection:.2f} ({protection*100:.1f}% protection)")
    
    # Simulate a paradox in Alpha Prime
    print("\n=== Paradox Simulation ===\n")
    paradox_timeline = "Alpha Prime"
    paradox_year = 2030
    paradox_coords = (100, 200, 50)
    paradox_magnitude = 0.8
    
    print(f"Simulating paradox in {paradox_timeline}, year {paradox_year}")
    print(f"Initial magnitude: {paradox_magnitude:.2f}")
    
    remaining, affected = system.handle_paradox(
        paradox_timeline, paradox_year, 
        *paradox_coords, paradox_magnitude
    )
    
    print(f"Remaining magnitude after absorption: {remaining:.2f}")
    print(f"Reduction: {(paradox_magnitude - remaining) / paradox_magnitude * 100:.1f}%")
    print(f"Affected anchors: {len(affected)}")
    
    # Update and show anchor statuses
    system.update_all()
    
    print("\n=== Anchor Statuses After Paradox ===\n")
    for anchor_id in affected:
        anchor = system.get_anchor(anchor_id)
        print(f"{anchor}")
        print(f"  Energy: {anchor.current_energy:.2f}/{anchor.energy_capacity:.2f}")
        print(f"  Field Integrity: {anchor.field_integrity:.2f}")
        print(f"  Paradox Absorptions: {anchor.paradox_absorptions}")
    
    # Perform maintenance on one anchor
    if affected:
        print("\n=== Performing Maintenance ===\n")
        anchor_id = affected[0]
        anchor = system.get_anchor(anchor_id)
        
        print(f"Before maintenance: {anchor}")
        success, message = anchor.perform_maintenance()
        print(f"Maintenance result: {message}")
        print(f"After maintenance: {anchor}")
    
    # Show overall system status
    print("\n=== System Status ===\n")
    status = system.get_system_status()
    
    print(f"Total anchors: {status['total_anchors']}")
    print(f"Active anchors: {status['active_anchors']}")
    print(f"System integrity: {status['system_integrity']:.2f}")
    print(f"Anchors needing maintenance: {status['anchors_needing_maintenance']}")
    
    return system


if __name__ == "__main__":
    run_reality_anchor_demo()
