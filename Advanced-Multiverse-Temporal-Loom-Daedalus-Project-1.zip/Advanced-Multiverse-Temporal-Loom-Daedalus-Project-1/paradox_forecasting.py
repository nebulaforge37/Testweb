
"""
Paradox Forecasting System
This module provides tools to predict and prevent paradoxes before they occur
by analyzing causal chains and temporal anomalies.
"""

import random
import math
import time
from typing import List, Dict, Tuple, Optional, Any, Union
from datetime import datetime, timedelta

class ParadoxType:
    """Represents a type of time paradox"""
    
    def __init__(self, 
                type_id: str,
                name: str, 
                description: str, 
                severity: float,
                warning_signs: List[str]):
        """
        Initialize a paradox type
        
        Args:
            type_id: Unique identifier
            name: Name of this paradox type
            description: Description of how this paradox works
            severity: Severity level (0.0-1.0)
            warning_signs: List of warning signs that predict this paradox
        """
        self.type_id = type_id
        self.name = name
        self.description = description
        self.severity = severity
        self.warning_signs = warning_signs
        self.resolution_methods = []
        self.historical_examples = []
        
    def add_resolution(self, method: str, effectiveness: float, difficulty: float):
        """Add a resolution method for this paradox type"""
        self.resolution_methods.append({
            "method": method,
            "effectiveness": effectiveness,
            "difficulty": difficulty
        })
        
    def add_historical_example(self, timeline: str, year: int, description: str, resolution: str = None):
        """Add a historical example of this paradox type"""
        self.historical_examples.append({
            "timeline": timeline,
            "year": year,
            "description": description,
            "resolution": resolution
        })
        
    def get_random_warning_sign(self) -> str:
        """Get a random warning sign for this paradox type"""
        if not self.warning_signs:
            return "Unknown warning signs"
        return random.choice(self.warning_signs)
        
    def get_best_resolution(self) -> Dict[str, Any]:
        """Get the most effective resolution method"""
        if not self.resolution_methods:
            return {
                "method": "No known resolution methods",
                "effectiveness": 0.0,
                "difficulty": 1.0
            }
            
        return max(self.resolution_methods, key=lambda r: r["effectiveness"])
        
    def __str__(self) -> str:
        return f"{self.name} (Severity: {self.severity:.2f}): {self.description}"


class TemporalAnomaly:
    """Represents a detected temporal anomaly that may lead to a paradox"""
    
    def __init__(self, 
                anomaly_id: int,
                timeline_name: str,
                year: int,
                anomaly_type: str = None):
        """
        Initialize a temporal anomaly
        
        Args:
            anomaly_id: Unique identifier
            timeline_name: Timeline where the anomaly was detected
            year: Year in the timeline where the anomaly exists
            anomaly_type: Type of anomaly
        """
        self.anomaly_id = anomaly_id
        self.timeline_name = timeline_name
        self.year = year
        self.anomaly_type = anomaly_type or random.choice([
            "Causal Disruption",
            "Temporal Flux",
            "Quantum Instability",
            "Worldline Fracture",
            "Reality Ripple",
            "Timeline Inconsistency",
            "Chronological Distortion"
        ])
        
        # Anomaly properties
        self.detection_time = time.time()
        self.magnitude = random.uniform(0.3, 0.9)  # How significant the anomaly is
        self.growth_rate = random.uniform(0.01, 0.1)  # How quickly it's growing
        self.stability = random.uniform(0.3, 0.8)  # How stable this anomaly is
        
        # Time until paradox formation (0-14 days)
        self.time_to_paradox = random.uniform(0, 60 * 60 * 24 * 14)  # seconds
        
        # Potential paradox types
        self.potential_paradoxes = []
        
        # Intervention history
        self.interventions = []
        
        # Current status
        self.status = "Detected"  # Detected, Analyzed, Contained, Resolved, Collapsed
        
    def add_potential_paradox(self, paradox_type: ParadoxType, probability: float):
        """Add a potential paradox type that may result from this anomaly"""
        self.potential_paradoxes.append({
            "type": paradox_type,
            "probability": probability
        })
        
    def get_current_magnitude(self) -> float:
        """Calculate current magnitude after growth"""
        time_elapsed = time.time() - self.detection_time
        growth_factor = math.exp(self.growth_rate * (time_elapsed / (60 * 60 * 24)))  # Days
        current_magnitude = self.magnitude * growth_factor
        return min(1.0, current_magnitude)
        
    def get_time_remaining(self) -> float:
        """Get remaining time until paradox formation in seconds"""
        time_elapsed = time.time() - self.detection_time
        remaining = self.time_to_paradox - time_elapsed
        return max(0, remaining)
        
    def get_containment_difficulty(self) -> float:
        """Calculate the difficulty of containing this anomaly"""
        magnitude = self.get_current_magnitude()
        time_factor = min(1.0, self.get_time_remaining() / (60 * 60 * 24 * 2))  # 2 days baseline
        
        # More stability makes containment easier
        return magnitude * (1.0 - self.stability) * (1.0 + (1.0 - time_factor))
        
    def add_intervention(self, method: str, effectiveness: float, agent: str):
        """Record an intervention attempt on this anomaly"""
        intervention = {
            "timestamp": time.time(),
            "method": method,
            "effectiveness": effectiveness,
            "agent": agent,
            "magnitude_before": self.get_current_magnitude()
        }
        
        # Apply effectiveness
        self.magnitude = max(0.05, self.magnitude * (1.0 - effectiveness))
        
        # Reduce growth rate
        self.growth_rate = max(0.001, self.growth_rate * (1.0 - (effectiveness * 0.5)))
        
        # Extend time to paradox
        time_extension = effectiveness * 60 * 60 * 24 * random.uniform(1, 7)  # 1-7 days based on effectiveness
        self.time_to_paradox += time_extension
        
        # Record final magnitude
        intervention["magnitude_after"] = self.get_current_magnitude()
        intervention["time_added"] = time_extension / (60 * 60 * 24)  # days
        
        self.interventions.append(intervention)
        
        # Update status if needed
        if self.get_current_magnitude() < 0.1:
            self.status = "Contained"
        
        return intervention
        
    def get_most_likely_paradox(self) -> Optional[Tuple[ParadoxType, float]]:
        """Get the most likely paradox type"""
        if not self.potential_paradoxes:
            return None
            
        most_likely = max(self.potential_paradoxes, key=lambda p: p["probability"])
        return (most_likely["type"], most_likely["probability"])
        
    def format_time_remaining(self) -> str:
        """Format the time remaining in a human-readable format"""
        seconds = self.get_time_remaining()
        
        if seconds <= 0:
            return "CRITICAL: PARADOX IMMINENT"
            
        days, remainder = divmod(seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        if days > 0:
            return f"{int(days)}d {int(hours)}h {int(minutes)}m"
        elif hours > 0:
            return f"{int(hours)}h {int(minutes)}m {int(seconds)}s"
        else:
            return f"{int(minutes)}m {int(seconds)}s"
        
    def __str__(self) -> str:
        magnitude = self.get_current_magnitude()
        magnitude_str = "Critical" if magnitude > 0.8 else "Major" if magnitude > 0.5 else "Moderate" if magnitude > 0.3 else "Minor"
        
        time_remaining = self.format_time_remaining()
        
        return f"[{self.status}] {magnitude_str} {self.anomaly_type} in {self.timeline_name} ({self.year}) - {time_remaining} remaining"


class ParadoxPrediction:
    """A prediction of a future paradox"""
    
    def __init__(self, 
                prediction_id: int,
                timeline_name: str,
                year: int,
                paradox_type: ParadoxType,
                probability: float,
                anomaly_id: Optional[int] = None):
        """
        Initialize a paradox prediction
        
        Args:
            prediction_id: Unique identifier
            timeline_name: Timeline where paradox is predicted
            year: Year in the timeline where paradox may occur
            paradox_type: Type of paradox predicted
            probability: Probability of occurrence (0.0-1.0)
            anomaly_id: Associated anomaly ID if any
        """
        self.prediction_id = prediction_id
        self.timeline_name = timeline_name
        self.year = year
        self.paradox_type = paradox_type
        self.probability = probability
        self.anomaly_id = anomaly_id
        
        # Prediction details
        self.creation_time = time.time()
        self.expiration_time = time.time() + (60 * 60 * 24 * 30)  # 30 days by default
        self.warning_signs = []
        self.causal_chains = []
        self.recommendation = ""
        self.confidence_level = min(1.0, probability + random.uniform(-0.1, 0.1))
        self.severity = paradox_type.severity * probability
        
        # Status tracking
        self.status = "Active"  # Active, Verified, Prevented, Expired, Occurred
        self.prevention_actions = []
        self.verification_details = None
        
        # Generate warning signs
        self._generate_warning_signs()
        
    def _generate_warning_signs(self):
        """Generate warning signs for this prediction"""
        # Add specific warning signs based on paradox type
        for _ in range(random.randint(2, 5)):
            sign = self.paradox_type.get_random_warning_sign()
            if sign not in self.warning_signs:
                self.warning_signs.append(sign)
                
        # Add a timeline-specific warning sign
        timeline_signs = [
            f"Unusual quantum fluctuations detected in {self.timeline_name}",
            f"Temporal energy buildup near {self.year} in {self.timeline_name}",
            f"Causal inconsistencies observed in historical records of {self.timeline_name}",
            f"Timeline {self.timeline_name} showing abnormal entanglement patterns",
            f"Reality coefficient destabilization in {self.timeline_name}"
        ]
        
        sign = random.choice(timeline_signs)
        if sign not in self.warning_signs:
            self.warning_signs.append(sign)
            
    def add_causal_chain(self, description: str, impact: float):
        """Add a causal chain that could lead to this paradox"""
        self.causal_chains.append({
            "description": description,
            "impact": impact
        })
        
    def set_recommendation(self, recommendation: str):
        """Set a recommendation for preventing this paradox"""
        self.recommendation = recommendation
        
    def add_prevention_action(self, description: str, effectiveness: float, agent: str):
        """Record a prevention action taken to avoid this paradox"""
        action = {
            "timestamp": time.time(),
            "description": description,
            "effectiveness": effectiveness,
            "agent": agent
        }
        
        self.prevention_actions.append(action)
        
        # Update probability based on preventive actions
        total_effectiveness = sum(a["effectiveness"] for a in self.prevention_actions)
        self.probability = max(0.01, self.probability * (1.0 - min(0.99, total_effectiveness)))
        self.severity = self.paradox_type.severity * self.probability
        
        # Update status if effectively prevented
        if self.probability < 0.1:
            self.status = "Prevented"
            
        return action
        
    def verify_prediction(self, occurred: bool, details: str):
        """Verify whether the prediction was accurate"""
        self.verification_details = {
            "timestamp": time.time(),
            "occurred": occurred,
            "details": details
        }
        
        self.status = "Occurred" if occurred else "Prevented"
        return self.verification_details
        
    def check_expiration(self) -> bool:
        """Check if this prediction has expired"""
        if time.time() > self.expiration_time and self.status == "Active":
            self.status = "Expired"
            return True
        return False
        
    def get_priority_level(self) -> str:
        """Get the priority level of this prediction"""
        # Consider probability, severity, and time until predicted event
        if self.probability > 0.8 and self.severity > 0.7:
            return "CRITICAL"
        elif self.probability > 0.6 and self.severity > 0.5:
            return "HIGH"
        elif self.probability > 0.4 and self.severity > 0.3:
            return "MEDIUM"
        else:
            return "LOW"
            
    def __str__(self) -> str:
        priority = self.get_priority_level()
        return f"[{self.status}] {priority} PRIORITY: {self.paradox_type.name} in {self.timeline_name} ({self.year}) - {self.probability:.0%} probability"


class ParadoxForecaster:
    """Main system for detecting, analyzing, and predicting paradoxes"""
    
    def __init__(self, multiverse = None):
        """Initialize the paradox forecaster"""
        self.multiverse = multiverse
        self.paradox_types = self._initialize_paradox_types()
        self.anomalies = {}  # anomaly_id -> TemporalAnomaly
        self.predictions = {}  # prediction_id -> ParadoxPrediction
        self.next_anomaly_id = 1
        self.next_prediction_id = 1
        
        # Analytics storage
        self.detection_history = []
        self.prevention_history = []
        self.resolution_history = []
        
    def _initialize_paradox_types(self) -> Dict[str, ParadoxType]:
        """Initialize standard paradox types"""
        paradox_types = {}
        
        # Grandfather Paradox
        grandfather = ParadoxType(
            "grandfather",
            "Grandfather Paradox",
            "A time traveler prevents their own existence by altering the past",
            0.9,  # Very severe
            [
                "Timeline attempting self-erasure",
                "Historical records showing conflicting ancestry data",
                "Quantum signature decay in biological markers",
                "Causal loop deterioration affecting personal timelines",
                "Time traveler experiencing physiological fading"
            ]
        )
        
        grandfather.add_resolution("Quantum timeline bifurcation", 0.8, 0.7)
        grandfather.add_resolution("Causal loop stabilization", 0.6, 0.8)
        grandfather.add_resolution("Paradox inhibitor field deployment", 0.7, 0.9)
        
        grandfather.add_historical_example(
            "Gamma Nexus", 2056,
            "Dr. Eliza Chen's accidental prevention of her grandparents' meeting",
            "Timeline split creating branch reality"
        )
        
        paradox_types[grandfather.type_id] = grandfather
        
        # Bootstrap Paradox
        bootstrap = ParadoxType(
            "bootstrap",
            "Bootstrap Paradox",
            "Information or objects exist without a discernible origin",
            0.6,  # Moderately severe
            [
                "Objects with quantum temporal displacement",
                "Information with no discernible source",
                "Identical designs appearing across isolated timelines",
                "Historical attribution loops",
                "Embedded knowledge with non-causal patterns"
            ]
        )
        
        bootstrap.add_resolution("Origin point fabrication", 0.7, 0.5)
        bootstrap.add_resolution("Information cycle stabilization", 0.8, 0.6)
        bootstrap.add_resolution("Quantum attribution anchoring", 0.6, 0.7)
        
        bootstrap.add_historical_example(
            "Beta Variant", 2042,
            "The 'Novikov Equations' appearing in historical records before Novikov's birth",
            "Causal attribution established through quantum archaeology"
        )
        
        paradox_types[bootstrap.type_id] = bootstrap
        
        # Predestination Paradox
        predestination = ParadoxType(
            "predestination",
            "Predestination Paradox",
            "Attempts to change the past result in causing the known events",
            0.4,  # Less severe
            [
                "Convergent causal chains despite intervention",
                "Temporal resistance to change",
                "Intervention attempts reinforcing established events",
                "Reality exhibiting deterministic patterns",
                "Multiple unrelated attempts producing identical outcomes"
            ]
        )
        
        predestination.add_resolution("Accept predestined outcome", 0.9, 0.3)
        predestination.add_resolution("Quantum variance introduction", 0.5, 0.7)
        predestination.add_resolution("Tangential timeline creation", 0.7, 0.8)
        
        predestination.add_historical_example(
            "Alpha Prime", 2031,
            "Temporal Security Agency causing the very disaster they were sent to prevent",
            "Acceptance protocol implemented, focus shifted to aftermath management"
        )
        
        paradox_types[predestination.type_id] = predestination
        
        # Consistency Paradox
        consistency = ParadoxType(
            "consistency",
            "Consistency Paradox",
            "Timeline modifications causing internal contradictions in history",
            0.8,  # Severe
            [
                "Historical records showing multiple contradictory versions",
                "Physical laws operating inconsistently in localized areas",
                "Memory/record discrepancies among timeline inhabitants",
                "Quantum superposition of conflicting historical events",
                "Archaeological evidence showing impossible sequences"
            ]
        )
        
        consistency.add_resolution("Reality harmonization field", 0.8, 0.8)
        consistency.add_resolution("Selective memory/record adjustment", 0.7, 0.9)
        consistency.add_resolution("Timeline compartmentalization", 0.6, 0.7)
        
        consistency.add_historical_example(
            "Delta Flux", 2068,
            "Schrodinger's President: records showing two different election outcomes simultaneously",
            "Timeline compartmentalization into discrete quantum states"
        )
        
        paradox_types[consistency.type_id] = consistency
        
        # Cumulative Paradox
        cumulative = ParadoxType(
            "cumulative",
            "Cumulative Paradox",
            "Multiple minor temporal alterations eventually destabilizing a timeline",
            0.7,  # Moderately severe
            [
                "Increasing quantum fluctuations across timeline",
                "Growing number of minor historical inconsistencies",
                "Temporal friction in causally dense areas",
                "Timeline showing progressive entropy increases",
                "Reality coefficient destabilization patterns"
            ]
        )
        
        cumulative.add_resolution("Temporal reset to baseline", 0.9, 0.9)
        cumulative.add_resolution("Incremental stability reinforcement", 0.6, 0.7)
        cumulative.add_resolution("Quantum normalization field", 0.7, 0.8)
        
        cumulative.add_historical_example(
            "Omega Point", 2093,
            "Progressive timeline degradation from excessive corporate time tourism",
            "Temporal moratorium and phased restoration protocol"
        )
        
        paradox_types[cumulative.type_id] = cumulative
        
        return paradox_types
    
    def scan_timeline_for_anomalies(self, timeline_name: str, scan_power: float = 0.5) -> List[TemporalAnomaly]:
        """
        Scan a timeline for temporal anomalies
        
        Args:
            timeline_name: Timeline to scan
            scan_power: Power of the scan (0.0-1.0)
            
        Returns:
            List of newly detected anomalies
        """
        # Record the scan
        scan_record = {
            "timestamp": time.time(),
            "timeline": timeline_name,
            "power": scan_power,
            "anomalies_found": []
        }
        
        # Determine number of potential anomalies
        # More powerful scans can find more anomalies
        timeline = None
        if self.multiverse and hasattr(self.multiverse, 'timelines'):
            timeline = self.multiverse.timelines.get(timeline_name)
            
        base_count = random.randint(0, 2)
        power_bonus = int(scan_power * 3)
        
        # Timeline instability increases chance of anomalies
        instability_bonus = 0
        if timeline and hasattr(timeline, 'stability'):
            instability_bonus = int((1.0 - timeline.stability) * 3)
            
        total_possible = base_count + power_bonus + instability_bonus
        
        # Determine detection success chance
        base_success = 0.3 + (scan_power * 0.5)
        
        # Make detection attempts
        detected_anomalies = []
        
        for _ in range(total_possible):
            if random.random() < base_success:
                # Generate a year relevant to the timeline
                year = 2000 + random.randint(-50, 100)  # 1950-2100
                
                if timeline and timeline.events:
                    # Use a year from existing events if available
                    years = [event[0] for event in timeline.events]
                    # Either use an existing year or one nearby
                    if random.random() < 0.7:
                        year = random.choice(years)
                    else:
                        base_year = random.choice(years)
                        year = base_year + random.randint(-10, 10)
                
                # Create the anomaly
                anomaly = TemporalAnomaly(self.next_anomaly_id, timeline_name, year)
                self.next_anomaly_id += 1
                
                # Adjust properties based on timeline if available
                if timeline and hasattr(timeline, 'stability'):
                    # Less stable timelines have larger anomalies
                    stability_factor = timeline.stability
                    anomaly.magnitude = min(0.95, anomaly.magnitude * (1.5 - stability_factor))
                    anomaly.growth_rate = min(0.2, anomaly.growth_rate * (1.5 - stability_factor))
                    
                # Determine potential paradox types
                self._analyze_anomaly(anomaly)
                
                # Store the anomaly
                self.anomalies[anomaly.anomaly_id] = anomaly
                detected_anomalies.append(anomaly)
                
                # Record in scan
                scan_record["anomalies_found"].append(anomaly.anomaly_id)
        
        self.detection_history.append(scan_record)
        return detected_anomalies
    
    def _analyze_anomaly(self, anomaly: TemporalAnomaly):
        """Analyze an anomaly to determine potential paradox types"""
        # Determine how many potential paradox types
        count = random.randint(1, 3)
        
        # Assign probabilities to different paradox types
        available_types = list(self.paradox_types.values())
        
        for _ in range(count):
            if not available_types:
                break
                
            # Select a random paradox type
            paradox_type = random.choice(available_types)
            available_types.remove(paradox_type)
            
            # Determine probability based on anomaly magnitude and paradox severity
            base_probability = anomaly.magnitude * random.uniform(0.5, 1.0)
            
            # More severe paradox types less likely to manifest
            severity_modifier = 1.0 - (paradox_type.severity * 0.3)
            
            probability = base_probability * severity_modifier
            
            # Add to potential paradoxes
            anomaly.add_potential_paradox(paradox_type, probability)
        
        # Update status
        anomaly.status = "Analyzed"
    
    def generate_prediction(self, anomaly_id: int) -> Optional[ParadoxPrediction]:
        """
        Generate a paradox prediction from an anomaly
        
        Returns:
            Paradox prediction or None if not possible
        """
        anomaly = self.anomalies.get(anomaly_id)
        if not anomaly:
            return None
            
        # Get the most likely paradox type
        most_likely = anomaly.get_most_likely_paradox()
        if not most_likely:
            return None
            
        paradox_type, probability = most_likely
        
        # Create the prediction
        prediction = ParadoxPrediction(
            self.next_prediction_id,
            anomaly.timeline_name,
            anomaly.year,
            paradox_type,
            probability,
            anomaly_id
        )
        self.next_prediction_id += 1
        
        # Generate causal chains
        self._generate_causal_chains(prediction)
        
        # Generate recommendation
        self._generate_recommendation(prediction)
        
        # Store the prediction
        self.predictions[prediction.prediction_id] = prediction
        
        return prediction
    
    def _generate_causal_chains(self, prediction: ParadoxPrediction):
        """Generate causal chains for a prediction"""
        # Number of causal chains
        count = random.randint(2, 4)
        
        # Potential causal triggers
        triggers = [
            "Temporal research experiment",
            "Unauthorized time travel",
            "Quantum field disturbance",
            "Paradox resolution attempt",
            "Timeline repair operation",
            "Reality modification technology",
            "Natural temporal instability",
            "Dimensional boundary weakening",
            "Historical data tampering",
            "Multiverse convergence event"
        ]
        
        # Potential consequences
        consequences = [
            "leading to causal loop formation",
            "causing timeline inconsistency",
            "disrupting established events",
            "creating quantum entanglement across time",
            "affecting reality coefficient stability",
            "inducing temporal resonance cascade",
            "fracturing worldline integrity",
            "generating paradoxical energy signatures",
            "destabilizing fixed points in time"
        ]
        
        # Generate chains
        for i in range(count):
            # More impactful chains for earlier entries
            impact = random.uniform(0.5, 0.9) * (1.0 - (i * 0.1))
            
            trigger = random.choice(triggers)
            triggers.remove(trigger)  # Don't reuse
            if not triggers:
                triggers = ["Unidentified temporal event", "Unknown causal trigger"]
                
            consequence = random.choice(consequences)
            consequences.remove(consequence)  # Don't reuse
            if not consequences:
                consequences = ["with undetermined consequences", "affecting timeline stability"]
                
            # Generate description
            description = f"{trigger} in {prediction.timeline_name} {consequence}"
            
            # Add year modifier sometimes
            if random.random() < 0.7:
                year_modifier = random.randint(-10, 10)
                if year_modifier != 0:
                    year = prediction.year + year_modifier
                    year_text = f"in {year}" if year_modifier > 0 else f"from {year}"
                    description += f" {year_text}"
            
            prediction.add_causal_chain(description, impact)
    
    def _generate_recommendation(self, prediction: ParadoxPrediction):
        """Generate a recommendation for dealing with a prediction"""
        # Get best resolution method from paradox type
        resolution = prediction.paradox_type.get_best_resolution()
        
        # Different approaches based on probability
        if prediction.probability > 0.8:
            approach = "URGENT INTERVENTION REQUIRED"
        elif prediction.probability > 0.5:
            approach = "PREVENTIVE ACTION RECOMMENDED"
        else:
            approach = "MONITORING ADVISED"
            
        # Generate specific recommendations
        specific_actions = []
        
        # Always include best resolution method
        specific_actions.append(f"Implement {resolution['method']}")
        
        # Add recommendation for most significant causal chain
        if prediction.causal_chains:
            most_significant = max(prediction.causal_chains, key=lambda c: c["impact"])
            chain_parts = most_significant["description"].split("causing")
            if len(chain_parts) > 1:
                specific_actions.append(f"Prevent {chain_parts[0].strip()}")
            else:
                specific_actions.append(f"Intervene in {most_significant['description']}")
        
        # Add timeline-specific recommendation
        timeline_actions = [
            f"Establish temporal monitoring in {prediction.timeline_name} near {prediction.year}",
            f"Deploy paradox dampening field at affected coordinates",
            f"Prepare quantum stabilizers for affected location",
            f"Brief all temporal agents on this paradox type",
            f"Setup contingency timeline branch if prevention fails"
        ]
        specific_actions.append(random.choice(timeline_actions))
        
        # Compile recommendation
        recommendation = f"{approach}:\n"
        for i, action in enumerate(specific_actions):
            recommendation += f"{i+1}. {action}\n"
            
        # Add warning
        if prediction.severity > 0.7:
            recommendation += "\nWARNING: Failure to act may result in timeline collapse or severe quantum destabilization."
            
        prediction.set_recommendation(recommendation)
    
    def contain_anomaly(self, anomaly_id: int, method: str = None, agent: str = "Automated System") -> Dict[str, Any]:
        """
        Attempt to contain a temporal anomaly
        
        Args:
            anomaly_id: ID of the anomaly to contain
            method: Containment method to use
            agent: Entity performing containment
            
        Returns:
            Containment results
        """
        anomaly = self.anomalies.get(anomaly_id)
        if not anomaly:
            return {
                "success": False,
                "message": "Anomaly not found"
            }
            
        # Generate a method if not provided
        if not method:
            methods = [
                "Temporal containment field",
                "Quantum stabilizer array",
                "Causality reinforcement wave",
                "Paradox dampening field",
                "Temporal isolation protocol",
                "Reality anchor deployment",
                "Worldline strengthening procedure"
            ]
            method = random.choice(methods)
            
        # Calculate containment effectiveness
        difficulty = anomaly.get_containment_difficulty()
        base_effectiveness = random.uniform(0.3, 0.8)
        
        # Adjust effectiveness based on method
        if "field" in method.lower():
            method_modifier = random.uniform(0.9, 1.1)
        elif "quantum" in method.lower():
            method_modifier = random.uniform(0.8, 1.2)
        else:
            method_modifier = random.uniform(0.7, 1.3)
            
        # More difficult anomalies are harder to contain
        effectiveness = base_effectiveness * method_modifier * (1.0 - (difficulty * 0.5))
        effectiveness = min(0.95, max(0.1, effectiveness))
        
        # Apply the intervention
        intervention = anomaly.add_intervention(method, effectiveness, agent)
        
        # Update related predictions if they exist
        for prediction in self.predictions.values():
            if prediction.anomaly_id == anomaly_id:
                # Update probability based on intervention effectiveness
                old_probability = prediction.probability
                prediction.probability = max(0.01, prediction.probability * (1.0 - (effectiveness * 0.5)))
                
                # Update status if probability is low enough
                if prediction.probability < 0.1 and prediction.status == "Active":
                    prediction.status = "Prevented"
                    
                # Record the action
                prediction.add_prevention_action(
                    f"Anomaly containment: {method}",
                    effectiveness * 0.5,  # Action effectiveness is less than direct prevention
                    agent
                )
        
        # Record in history
        self.prevention_history.append({
            "timestamp": time.time(),
            "anomaly_id": anomaly_id,
            "method": method,
            "effectiveness": effectiveness,
            "agent": agent,
            "result": f"Anomaly magnitude reduced to {anomaly.get_current_magnitude():.2f}"
        })
        
        return {
            "success": True,
            "method": method,
            "effectiveness": effectiveness,
            "message": f"Anomaly contained with {effectiveness:.0%} effectiveness.",
            "current_magnitude": anomaly.get_current_magnitude(),
            "status": anomaly.status
        }
    
    def prevent_paradox(self, prediction_id: int, method: str = None, agent: str = "Temporal Agent") -> Dict[str, Any]:
        """
        Take action to prevent a predicted paradox
        
        Args:
            prediction_id: ID of the prediction to prevent
            method: Prevention method to use
            agent: Entity performing prevention
            
        Returns:
            Prevention results
        """
        prediction = self.predictions.get(prediction_id)
        if not prediction:
            return {
                "success": False,
                "message": "Prediction not found"
            }
            
        if prediction.status != "Active":
            return {
                "success": False,
                "message": f"Prediction has status '{prediction.status}' and cannot be modified"
            }
            
        # Generate a method if not provided
        if not method:
            # Try to use a resolution method from the paradox type
            if prediction.paradox_type.resolution_methods:
                resolution = random.choice(prediction.paradox_type.resolution_methods)
                method = resolution["method"]
            else:
                methods = [
                    "Causal chain intervention",
                    "Temporal event modification",
                    "Paradox preemption protocol",
                    "Timeline reinforcement",
                    "Quantum state solidification",
                    "Historical record correction",
                    "Tangential timeline creation"
                ]
                method = random.choice(methods)
            
        # Calculate prevention effectiveness
        base_effectiveness = random.uniform(0.4, 0.9)
        
        # Harder to prevent higher probability paradoxes
        difficulty_modifier = 1.0 - (prediction.probability * 0.3)
        
        # Harder to prevent more severe paradoxes
        severity_modifier = 1.0 - (prediction.paradox_type.severity * 0.2)
        
        effectiveness = base_effectiveness * difficulty_modifier * severity_modifier
        effectiveness = min(0.95, max(0.1, effectiveness))
        
        # Apply the prevention action
        action = prediction.add_prevention_action(method, effectiveness, agent)
        
        # Update related anomaly if it exists
        if prediction.anomaly_id and prediction.anomaly_id in self.anomalies:
            anomaly = self.anomalies[prediction.anomaly_id]
            
            # Reduce anomaly magnitude
            magnitude_reduction = effectiveness * 0.7
            anomaly.magnitude = max(0.05, anomaly.magnitude * (1.0 - magnitude_reduction))
            
            # Update status if needed
            if anomaly.get_current_magnitude() < 0.1:
                anomaly.status = "Contained"
        
        # Record in history
        self.prevention_history.append({
            "timestamp": time.time(),
            "prediction_id": prediction_id,
            "method": method,
            "effectiveness": effectiveness,
            "agent": agent,
            "result": f"Prediction probability reduced to {prediction.probability:.2f}"
        })
        
        return {
            "success": True,
            "method": method,
            "effectiveness": effectiveness,
            "message": f"Paradox prevention completed with {effectiveness:.0%} effectiveness.",
            "current_probability": prediction.probability,
            "status": prediction.status
        }
    
    def update_all_anomalies(self):
        """Update all anomalies and check for critical situations"""
        critical_anomalies = []
        
        for anomaly_id, anomaly in list(self.anomalies.items()):
            # Check if paradox time has been reached
            if anomaly.get_time_remaining() <= 0 and anomaly.status not in ["Resolved", "Collapsed"]:
                # Check if contained
                if anomaly.get_current_magnitude() < 0.1:
                    anomaly.status = "Resolved"
                else:
                    anomaly.status = "Collapsed"
                    critical_anomalies.append(anomaly)
                    
                    # Update related predictions
                    for prediction in self.predictions.values():
                        if prediction.anomaly_id == anomaly_id and prediction.status == "Active":
                            prediction.verify_prediction(
                                True,
                                f"Anomaly {anomaly_id} collapsed into paradox"
                            )
        
        # Expire old predictions
        for prediction in self.predictions.values():
            prediction.check_expiration()
            
        return critical_anomalies
    
    def get_active_anomalies(self) -> List[TemporalAnomaly]:
        """Get all active anomalies sorted by urgency"""
        active = [a for a in self.anomalies.values() 
                 if a.status not in ["Resolved", "Collapsed"]]
                 
        # Sort by time remaining and magnitude
        return sorted(active, key=lambda a: (a.get_time_remaining(), -a.get_current_magnitude()))
    
    def get_active_predictions(self) -> List[ParadoxPrediction]:
        """Get all active predictions sorted by priority"""
        active = [p for p in self.predictions.values() if p.status == "Active"]
        
        # Sort by probability and severity
        return sorted(active, key=lambda p: (-p.probability, -p.severity))
    
    def get_anomalies_report(self) -> str:
        """Generate a report on temporal anomalies"""
        anomalies = list(self.anomalies.values())
        if not anomalies:
            return "No temporal anomalies detected."
            
        report = ["=== TEMPORAL ANOMALY REPORT ==="]
        
        # Count by status
        status_counts = {}
        for anomaly in anomalies:
            status_counts[anomaly.status] = status_counts.get(anomaly.status, 0) + 1
            
        report.append(f"Total anomalies: {len(anomalies)}")
        for status, count in status_counts.items():
            report.append(f"- {status}: {count}")
            
        # Show active critical anomalies
        critical = [a for a in anomalies 
                   if a.status not in ["Resolved", "Collapsed"]
                   and a.get_current_magnitude() > 0.7]
                   
        if critical:
            report.append("\nCRITICAL ANOMALIES:")
            for anomaly in sorted(critical, key=lambda a: a.get_time_remaining()):
                remaining = anomaly.format_time_remaining()
                report.append(f"- {anomaly.anomaly_type} in {anomaly.timeline_name} ({anomaly.year})")
                report.append(f"  Magnitude: {anomaly.get_current_magnitude():.2f}, Time remaining: {remaining}")
                
                # Show potential paradox
                likely_paradox = anomaly.get_most_likely_paradox()
                if likely_paradox:
                    paradox_type, probability = likely_paradox
                    report.append(f"  Likely outcome: {paradox_type.name} ({probability:.0%} probability)")
                    
        # Recent interventions
        recent_interventions = []
        for anomaly in anomalies:
            for intervention in anomaly.interventions[-2:]:  # Last 2 interventions
                if time.time() - intervention.get("timestamp", 0) < 86400:  # Last 24 hours
                    recent_interventions.append({
                        "anomaly_id": anomaly.anomaly_id,
                        "timeline": anomaly.timeline_name,
                        "year": anomaly.year,
                        "method": intervention["method"],
                        "agent": intervention["agent"],
                        "effectiveness": intervention["effectiveness"],
                        "timestamp": intervention["timestamp"]
                    })
                    
        if recent_interventions:
            report.append("\nRECENT INTERVENTIONS:")
            for intervention in sorted(recent_interventions, 
                                      key=lambda i: i["timestamp"], 
                                      reverse=True)[:5]:  # Last 5
                timeago = time.time() - intervention["timestamp"]
                hours_ago = timeago / 3600
                time_str = f"{hours_ago:.1f} hours ago"
                
                report.append(f"- {intervention['method']} in {intervention['timeline']} ({intervention['year']})")
                report.append(f"  By: {intervention['agent']}, Effectiveness: {intervention['effectiveness']:.0%}, {time_str}")
        
        return "\n".join(report)
    
    def get_predictions_report(self) -> str:
        """Generate a report on paradox predictions"""
        predictions = list(self.predictions.values())
        if not predictions:
            return "No paradox predictions generated."
            
        report = ["=== PARADOX PREDICTION REPORT ==="]
        
        # Count by status
        status_counts = {}
        for prediction in predictions:
            status_counts[prediction.status] = status_counts.get(prediction.status, 0) + 1
            
        report.append(f"Total predictions: {len(predictions)}")
        for status, count in status_counts.items():
            report.append(f"- {status}: {count}")
            
        # Show high priority active predictions
        high_priority = [p for p in predictions 
                        if p.status == "Active" 
                        and p.get_priority_level() in ["CRITICAL", "HIGH"]]
                        
        if high_priority:
            report.append("\nHIGH PRIORITY PREDICTIONS:")
            for prediction in sorted(high_priority, 
                                   key=lambda p: (-p.probability, -p.severity))[:3]:  # Top 3
                report.append(f"- {prediction.paradox_type.name} in {prediction.timeline_name} ({prediction.year})")
                report.append(f"  Probability: {prediction.probability:.0%}, Severity: {prediction.severity:.2f}")
                
                # Show top warning sign
                if prediction.warning_signs:
                    report.append(f"  Warning sign: {prediction.warning_signs[0]}")
                    
                # Show top causal chain
                if prediction.causal_chains:
                    top_chain = max(prediction.causal_chains, key=lambda c: c["impact"])
                    report.append(f"  Causal factor: {top_chain['description']}")
                    
        # Prevention success stats
        if status_counts.get("Prevented", 0) > 0:
            prevented = [p for p in predictions if p.status == "Prevented"]
            total_actions = sum(len(p.prevention_actions) for p in prevented)
            avg_effectiveness = sum(a["effectiveness"] for p in prevented 
                                  for a in p.prevention_actions) / max(1, total_actions)
                                  
            report.append("\nPREVENTION STATISTICS:")
            report.append(f"Successfully prevented paradoxes: {len(prevented)}")
            report.append(f"Total prevention actions: {total_actions}")
            report.append(f"Average action effectiveness: {avg_effectiveness:.0%}")
            
            # Most effective methods
            method_effectiveness = {}
            for p in prevented:
                for action in p.prevention_actions:
                    method = action["method"]
                    method_effectiveness[method] = method_effectiveness.get(method, []) + [action["effectiveness"]]
                    
            if method_effectiveness:
                best_methods = sorted(method_effectiveness.items(), 
                                    key=lambda m: sum(m[1])/len(m[1]), 
                                    reverse=True)[:2]  # Top 2
                                    
                report.append("\nMost effective prevention methods:")
                for method, effectiveness_list in best_methods:
                    avg = sum(effectiveness_list) / len(effectiveness_list)
                    report.append(f"- {method}: {avg:.0%} average effectiveness")
        
        return "\n".join(report)
    
    def get_paradox_type_details(self, type_id: str) -> str:
        """Get detailed information about a paradox type"""
        paradox_type = self.paradox_types.get(type_id)
        if not paradox_type:
            return f"Paradox type '{type_id}' not found."
            
        details = [f"=== {paradox_type.name.upper()} ==="]
        details.append(f"Severity: {paradox_type.severity:.2f}")
        details.append(f"Description: {paradox_type.description}")
        
        details.append("\nWarning signs:")
        for sign in paradox_type.warning_signs:
            details.append(f"- {sign}")
            
        if paradox_type.resolution_methods:
            details.append("\nKnown resolution methods:")
            for resolution in sorted(paradox_type.resolution_methods, 
                                   key=lambda r: r["effectiveness"], 
                                   reverse=True):
                details.append(f"- {resolution['method']}")
                details.append(f"  Effectiveness: {resolution['effectiveness']:.0%}, Difficulty: {resolution['difficulty']:.0%}")
                
        if paradox_type.historical_examples:
            details.append("\nHistorical examples:")
            for example in paradox_type.historical_examples:
                details.append(f"- {example['timeline']} ({example['year']}): {example['description']}")
                if example.get("resolution"):
                    details.append(f"  Resolution: {example['resolution']}")
                    
        return "\n".join(details)
    
    def get_timeline_risk_assessment(self, timeline_name: str) -> Dict[str, Any]:
        """
        Generate a risk assessment for a specific timeline
        
        Returns:
            Risk assessment data dictionary
        """
        # Gather all data related to this timeline
        timeline_anomalies = [a for a in self.anomalies.values() 
                             if a.timeline_name == timeline_name]
                             
        timeline_predictions = [p for p in self.predictions.values() 
                              if p.timeline_name == timeline_name]
                              
        # Calculate overall risk metrics
        active_anomalies = [a for a in timeline_anomalies 
                           if a.status not in ["Resolved", "Collapsed"]]
                           
        active_predictions = [p for p in timeline_predictions 
                            if p.status == "Active"]
                            
        # Calculate average metrics
        avg_anomaly_magnitude = sum(a.get_current_magnitude() for a in active_anomalies) / max(1, len(active_anomalies))
        
        total_prediction_risk = sum(p.probability * p.severity for p in active_predictions)
        avg_prediction_probability = sum(p.probability for p in active_predictions) / max(1, len(active_predictions))
        
        # Most common paradox type
        paradox_types = [p.paradox_type.type_id for p in timeline_predictions]
        most_common_type = max(set(paradox_types), key=paradox_types.count) if paradox_types else None
        
        # Time to nearest critical event
        earliest_time = float('inf')
        earliest_anomaly = None
        
        for anomaly in active_anomalies:
            time_remaining = anomaly.get_time_remaining()
            if time_remaining < earliest_time:
                earliest_time = time_remaining
                earliest_anomaly = anomaly
                
        # Calculate overall risk level
        risk_factors = [
            avg_anomaly_magnitude * 0.4,
            len(active_anomalies) * 0.1,
            avg_prediction_probability * 0.3,
            total_prediction_risk * 0.2
        ]
        
        overall_risk = sum(r for r in risk_factors if r is not None)
        
        # Risk level categorization
        if overall_risk > 0.7:
            risk_level = "SEVERE"
        elif overall_risk > 0.4:
            risk_level = "HIGH"
        elif overall_risk > 0.2:
            risk_level = "MODERATE"
        else:
            risk_level = "LOW"
            
        # Generate assessment
        assessment = {
            "timeline": timeline_name,
            "risk_level": risk_level,
            "risk_score": overall_risk,
            "active_anomalies": len(active_anomalies),
            "avg_anomaly_magnitude": avg_anomaly_magnitude if active_anomalies else 0,
            "active_predictions": len(active_predictions),
            "avg_prediction_probability": avg_prediction_probability if active_predictions else 0,
            "most_common_paradox": most_common_type,
            "nearest_critical_event": None,
            "recommendations": []
        }
        
        # Add nearest critical event info
        if earliest_anomaly and earliest_time < float('inf'):
            assessment["nearest_critical_event"] = {
                "type": earliest_anomaly.anomaly_type,
                "year": earliest_anomaly.year,
                "time_remaining": earliest_anomaly.format_time_remaining(),
                "magnitude": earliest_anomaly.get_current_magnitude()
            }
            
        # Generate recommendations
        if risk_level == "SEVERE":
            assessment["recommendations"].append("URGENT: Immediate temporal intervention required")
            assessment["recommendations"].append("Deploy multiple containment teams to active anomalies")
            assessment["recommendations"].append("Consider timeline quarantine protocols")
            
        elif risk_level == "HIGH":
            assessment["recommendations"].append("Deploy containment teams to highest magnitude anomalies")
            assessment["recommendations"].append("Implement prevention strategies for high-probability predictions")
            assessment["recommendations"].append("Increase temporal monitoring frequency")
            
        elif risk_level == "MODERATE":
            assessment["recommendations"].append("Regular monitoring of active anomalies")
            assessment["recommendations"].append("Prepare containment resources for potential escalation")
            assessment["recommendations"].append("Analyze causal chains for prevention opportunities")
            
        else:  # LOW
            assessment["recommendations"].append("Standard monitoring protocols sufficient")
            assessment["recommendations"].append("Document and track any minor anomalies")
            
        return assessment


def run_paradox_forecasting_demo(multiverse=None):
    """Run a demonstration of the paradox forecasting system"""
    print("=== Paradox Forecasting System Demonstration ===")
    
    # Create forecaster
    forecaster = ParadoxForecaster(multiverse)
    
    # Show paradox types
    print("\nInitialized Paradox Types:")
    for type_id, paradox in forecaster.paradox_types.items():
        print(f"- {paradox.name} (Severity: {paradox.severity:.2f})")
    
    # Select timelines to scan
    timelines_to_scan = []
    if multiverse and hasattr(multiverse, 'timelines'):
        timelines_to_scan = list(multiverse.timelines.keys())[:3]  # Scan first 3 timelines
    
    if not timelines_to_scan:
        timelines_to_scan = ["Alpha Prime", "Beta Variant", "Gamma Nexus"]
    
    # Scan for anomalies
    print("\nScanning timelines for temporal anomalies...")
    all_anomalies = []
    
    for timeline in timelines_to_scan:
        print(f"Scanning timeline: {timeline}")
        anomalies = forecaster.scan_timeline_for_anomalies(timeline, scan_power=0.7)
        all_anomalies.extend(anomalies)
        
        for anomaly in anomalies:
            print(f"  Detected: {anomaly}")
    
    if not all_anomalies:
        print("No anomalies detected in scans.")
        # Create a test anomaly for demonstration
        timeline = timelines_to_scan[0]
        test_anomaly = TemporalAnomaly(forecaster.next_anomaly_id, timeline, 2042)
        forecaster.next_anomaly_id += 1
        forecaster._analyze_anomaly(test_anomaly)
        forecaster.anomalies[test_anomaly.anomaly_id] = test_anomaly
        all_anomalies = [test_anomaly]
        print(f"Created test anomaly for demonstration: {test_anomaly}")
    
    # Generate predictions from anomalies
    print("\nGenerating paradox predictions from anomalies...")
    all_predictions = []
    
    for anomaly in all_anomalies:
        prediction = forecaster.generate_prediction(anomaly.anomaly_id)
        if prediction:
            all_predictions.append(prediction)
            print(f"  Prediction: {prediction}")
            
            # Show some details
            print(f"    Priority: {prediction.get_priority_level()}")
            if prediction.warning_signs:
                print(f"    Warning sign: {prediction.warning_signs[0]}")
    
    if not all_predictions:
        print("No predictions could be generated.")
    
    # Attempt to prevent a paradox
    if all_predictions:
        print("\nAttempting prevention of highest priority prediction...")
        
        # Choose highest priority
        target_prediction = max(all_predictions, key=lambda p: p.probability * p.severity)
        
        # Try prevention
        result = forecaster.prevent_paradox(target_prediction.prediction_id)
        
        if result["success"]:
            print(f"Prevention attempt: {result['method']}")
            print(f"Effectiveness: {result['effectiveness']:.0%}")
            print(f"New probability: {result['current_probability']:.0%}")
            print(f"Status: {result['status']}")
    
    # Contain an anomaly
    if all_anomalies:
        print("\nAttempting to contain a temporal anomaly...")
        
        # Choose highest magnitude
        target_anomaly = max(all_anomalies, key=lambda a: a.get_current_magnitude())
        
        # Try containment
        result = forecaster.contain_anomaly(target_anomaly.anomaly_id)
        
        if result["success"]:
            print(f"Containment method: {result['method']}")
            print(f"Effectiveness: {result['effectiveness']:.0%}")
            print(f"New magnitude: {result['current_magnitude']:.2f}")
            print(f"Status: {result['status']}")
    
    # Risk assessment
    if timelines_to_scan:
        print("\nGenerating timeline risk assessment...")
        assessment = forecaster.get_timeline_risk_assessment(timelines_to_scan[0])
        
        print(f"Timeline: {assessment['timeline']}")
        print(f"Risk Level: {assessment['risk_level']}")
        print(f"Risk Score: {assessment['risk_score']:.2f}")
        print(f"Active Anomalies: {assessment['active_anomalies']}")
        print(f"Active Predictions: {assessment['active_predictions']}")
        
        if assessment['nearest_critical_event']:
            event = assessment['nearest_critical_event']
            print(f"Next Critical Event: {event['type']} in {event['year']}")
            print(f"Time Remaining: {event['time_remaining']}")
        
        print("\nRecommendations:")
        for recommendation in assessment['recommendations']:
            print(f"- {recommendation}")
    
    # Generate reports
    print("\n" + forecaster.get_anomalies_report())
    print("\n" + forecaster.get_predictions_report())
    
    # Show details for a paradox type
    print("\nExample Paradox Type Details:")
    print(forecaster.get_paradox_type_details("grandfather"))
    
    return forecaster


if __name__ == "__main__":
    run_paradox_forecasting_demo()
