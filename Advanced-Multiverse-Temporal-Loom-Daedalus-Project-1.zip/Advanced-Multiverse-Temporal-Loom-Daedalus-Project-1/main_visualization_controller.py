
"""
Main Visualization Controller
This module provides the central controller for managing all visualization components
of the Multiverse Simulation System.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import time
from typing import Dict, List, Any, Optional

# Try to import visualization components
try:
    from multiverse_visualization_dashboard import MultiverseVisualizationDashboard
    from reality_visualization import TimelineVisualizerApp
    from timeline_canvas import TimelineCanvas
except ImportError as e:
    print(f"Warning: Could not import visualization component: {e}")

# Try to import simulation components
try:
    from main import Multiverse
    from advanced_features_manager import AdvancedFeaturesManager
    from boot_loader import BootSequence
except ImportError as e:
    print(f"Warning: Could not import simulation component: {e}")


class MainVisualizationController:
    """Main controller for all multiverse visualization components"""
    
    def __init__(self):
        """Initialize the controller"""
        self.multiverse = None
        self.advanced_features = None
        self.boot_sequence = None
        self.dashboard = None
        self.is_initialized = False
    
    def boot_system(self, verbose=True):
        """Boot the simulation system"""
        try:
            print("Initializing boot sequence...")
            self.boot_sequence = BootSequence()
            success = self.boot_sequence.boot(verbose=verbose)
            
            if success:
                print("Boot sequence completed successfully.")
                self.multiverse = self.boot_sequence.get_system("multiverse")
                
                # Initialize advanced features
                print("Initializing advanced features...")
                self.advanced_features = AdvancedFeaturesManager(self.multiverse)
                
                self.is_initialized = True
                print("System initialization complete.")
                return True
            else:
                print(f"Boot sequence failed. Status: {self.boot_sequence.status}")
                return False
        except Exception as e:
            print(f"Error during system initialization: {e}")
            return False
    
    def launch_full_dashboard(self):
        """Launch the full visualization dashboard"""
        if not self.is_initialized:
            success = self.boot_system()
            if not success:
                print("Could not initialize system. Using sample data instead.")
        
        # Create dashboard
        root = tk.Tk()
        self.dashboard = MultiverseVisualizationDashboard(root)
        
        # Set multiverse if available
        if self.multiverse:
            self.dashboard.multiverse = self.multiverse
            self.dashboard.advanced_features = self.advanced_features
        
        # Run the dashboard
        self.dashboard.run()
    
    def launch_reality_visualizer(self):
        """Launch just the reality visualizer component"""
        if not self.is_initialized:
            success = self.boot_system(verbose=False)
        
        # Create visualizer
        root = tk.Tk()
        visualizer = TimelineVisualizerApp(root, self.multiverse)
        
        # Run the visualizer
        visualizer.run()
    
    def run_visualization_demo(self):
        """Run a demonstration of various visualization capabilities"""
        print("\n=== Multiverse Visualization System Demo ===\n")
        print("This demo will show various visualization capabilities of the system.")
        
        # Ask user which visualization to show
        print("\nAvailable visualization components:")
        print("1. Full Visualization Dashboard")
        print("2. Reality Visualizer")
        print("3. Timeline Visualization")
        print("4. Boot sequence then launch dashboard")
        print("0. Exit")
        
        choice = input("\nSelect a visualization to launch (0-4): ")
        
        if choice == "0":
            print("Exiting visualization demo.")
            return
        elif choice == "1":
            print("Launching full visualization dashboard...")
            self.launch_full_dashboard()
        elif choice == "2":
            print("Launching reality visualizer...")
            self.launch_reality_visualizer()
        elif choice == "3":
            print("Launching timeline visualization...")
            self._run_timeline_visualization_demo()
        elif choice == "4":
            print("Running boot sequence...")
            success = self.boot_system(verbose=True)
            if success:
                print("Boot sequence successful. Launching dashboard...")
                time.sleep(1)
                self.launch_full_dashboard()
            else:
                print("Boot sequence failed. Cannot launch dashboard.")
        else:
            print("Invalid choice. Exiting demo.")
    
    def _run_timeline_visualization_demo(self):
        """Run a demo of just the timeline visualization component"""
        root = tk.Tk()
        root.title("Timeline Visualization Demo")
        root.geometry("900x700")
        
        frame = ttk.Frame(root)
        frame.pack(fill=tk.BOTH, expand=True)
        
        canvas = TimelineCanvas(frame)
        
        # Add sample timelines
        canvas.add_timeline("Alpha Prime", 0.9)
        canvas.add_timeline("Beta Variant", 0.75)
        canvas.add_timeline("Gamma Nexus", 0.65)
        canvas.add_timeline("Delta Flux", 0.55)
        
        # Add some events
        canvas.add_event("Alpha Prime", "Timeline origin point", 2000)
        canvas.add_event("Alpha Prime", "Quantum computing breakthrough", 2025)
        canvas.add_event("Alpha Prime", "First contact", 2042)
        
        canvas.add_event("Beta Variant", "Timeline divergence from Alpha", 2010)
        canvas.add_event("Beta Variant", "Global catastrophe", 2028)
        canvas.add_event("Beta Variant", "Underground civilization", 2035)
        
        canvas.add_event("Gamma Nexus", "Artificial timeline creation", 1980)
        canvas.add_event("Gamma Nexus", "Robotic revolution", 2015)
        canvas.add_event("Gamma Nexus", "Consciousness upload", 2038)
        
        canvas.add_event("Delta Flux", "Quantum fluctuation event", 1995)
        canvas.add_event("Delta Flux", "Dimensional barrier discovery", 2022)
        canvas.add_event("Delta Flux", "Time manipulation tech", 2030)
        
        # Connect timelines
        canvas.connect_timelines("Alpha Prime", "Beta Variant", "branched")
        canvas.connect_timelines("Alpha Prime", "Gamma Nexus", "quantum_entangled")
        canvas.connect_timelines("Beta Variant", "Delta Flux")
        
        # Add control buttons
        control_frame = ttk.Frame(root)
        control_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(control_frame, text="Reset", 
                  command=lambda: (canvas.clear(), self._run_timeline_visualization_demo())
                 ).pack(side=tk.LEFT, padx=10)
        ttk.Button(control_frame, text="Exit", 
                  command=root.destroy).pack(side=tk.RIGHT, padx=10)
        
        root.mainloop()


def run_visualization_system():
    """Run the main visualization system"""
    controller = MainVisualizationController()
    controller.run_visualization_demo()
    return controller


if __name__ == "__main__":
    run_visualization_system()
