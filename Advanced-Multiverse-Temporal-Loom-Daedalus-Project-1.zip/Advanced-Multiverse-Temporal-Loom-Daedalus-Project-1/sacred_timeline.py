
"""
Sacred Timeline System
This module implements the Sacred Timeline concept with Temporal Radiation tracking
and monitoring capabilities.
"""

import random
import math
import time
from typing import List, Dict, Optional, Tuple, Any, Union
from temporal_physics import TimeDilation, ParadoxRegistry

class TemporalRadiation:
    """Represents temporal radiation emitted during timeline manipulation"""
    
    def __init__(self, intensity: float = 0.0, decay_rate: float = 0.05,
                isotope_signature: str = None):
        """
        Initialize temporal radiation
        
        Args:
            intensity: Initial radiation intensity (0.0-1.0)
            decay_rate: Rate at which radiation decays
            isotope_signature: Signature identifying radiation source
        """
        self.intensity = intensity
        self.decay_rate = decay_rate
        self.created_at = time.time()
        self.isotope_signature = isotope_signature or self._generate_signature()
        self.half_life = random.uniform(10, 100) * (1 / decay_rate)
        self.contamination_radius = intensity * 10  # Arbitrary units
        self.detection_threshold = 0.05
        
    def _generate_signature(self) -> str:
        """Generate a unique isotope signature for this radiation"""
        isotopes = ["Chronium", "Temporalite", "Paradoxium", "Nexusite", "Timewave"]
        numbers = [str(random.randint(1, 99)) for _ in range(2)]
        return f"{random.choice(isotopes)}-{numbers[0]}{numbers[1]}"
        
    def get_current_intensity(self) -> float:
        """Calculate current radiation intensity after decay"""
        elapsed_time = time.time() - self.created_at
        half_lives = elapsed_time / self.half_life
        
        # Standard radioactive decay formula: I = I₀ * (0.5)^(t/t½)
        current_intensity = self.intensity * (0.5 ** half_lives)
        return max(0.0, current_intensity)
    
    def is_detectable(self) -> bool:
        """Determine if radiation is above detection threshold"""
        return self.get_current_intensity() > self.detection_threshold
        
    def get_contamination_radius(self) -> float:
        """Get current contamination radius based on decayed intensity"""
        current_intensity = self.get_current_intensity()
        return current_intensity * 10
        
    def estimate_time_until_safe(self) -> float:
        """Estimate time (in seconds) until radiation reaches safe levels"""
        current_intensity = self.get_current_intensity()
        
        if current_intensity <= self.detection_threshold:
            return 0.0
            
        # Calculate how many half-lives needed to reach threshold
        target_intensity = self.detection_threshold
        half_lives_needed = math.log(target_intensity / current_intensity, 0.5)
        
        return max(0.0, half_lives_needed * self.half_life)
        
    def __str__(self) -> str:
        current = self.get_current_intensity()
        return f"{self.isotope_signature} Radiation: {current:.3f} intensity, {self.estimate_time_until_safe():.1f}s until safe"


class SacredTimeline:
    """Represents the Sacred Timeline that maintains multiversal stability"""
    
    def __init__(self, name: str = "Sacred Timeline", base_stability: float = 0.9):
        """
        Initialize the Sacred Timeline
        
        Args:
            name: Name of the sacred timeline
            base_stability: Base stability value (0.0-1.0)
        """
        self.name = name
        self.base_stability = base_stability
        self.current_stability = base_stability
        self.key_nexus_points = []
        self.created_at = time.time()
        self.last_pruning = time.time()
        self.radiation_history = []
        self.variance_threshold = 0.3
        self.paradox_registry = ParadoxRegistry()
        self.protected_events = []
        self.red_line_warnings = []
        
        # Initialize with some default nexus points
        self._initialize_nexus_points()
        
    def _initialize_nexus_points(self):
        """Initialize with some default nexus points"""
        self.add_nexus_point(2012, "Quantum Convergence Event", 0.9)
        self.add_nexus_point(2043, "Temporal Revolution", 0.85)
        self.add_nexus_point(2077, "Paradox Singularity", 0.95)
        
    def add_nexus_point(self, year: int, description: str, importance: float):
        """
        Add a key nexus point to the Sacred Timeline
        
        Args:
            year: Year of the nexus point
            description: Description of the event
            importance: Importance factor (0.0-1.0)
        """
        nexus_point = {
            "year": year,
            "description": description,
            "importance": importance,
            "stability": random.uniform(0.7, 1.0),
            "protected": importance > 0.8,
            "variance_count": 0
        }
        
        self.key_nexus_points.append(nexus_point)
        self.key_nexus_points.sort(key=lambda x: x["year"])
        
        if nexus_point["protected"]:
            self.protected_events.append(f"{description} ({year})")
        
    def prune_variant_timeline(self, variant_name: str, variant_stability: float) -> Tuple[bool, TemporalRadiation]:
        """
        Prune a variant timeline that exceeds variance threshold
        
        Args:
            variant_name: Name of the variant timeline
            variant_stability: Stability of the variant timeline
            
        Returns:
            Success flag and radiation produced
        """
        # Calculate prune difficulty based on variant stability
        # More stable variants are harder to prune
        prune_difficulty = variant_stability * 0.7
        
        # Generate radiation based on difficulty
        radiation_intensity = random.uniform(0.3, 0.7) * prune_difficulty
        radiation = TemporalRadiation(radiation_intensity, decay_rate=0.02)
        
        # Record pruning event
        self.last_pruning = time.time()
        self.radiation_history.append({
            "timestamp": time.time(),
            "variant": variant_name,
            "radiation": radiation,
            "success": True
        })
        
        # Small chance to generate red line warning
        if random.random() < 0.1:
            self.add_red_line_warning(
                variant_name, 
                f"Timeline pruning resulted in unexpected quantum fluctuations"
            )
        
        return True, radiation
        
    def check_timeline_variance(self, timeline_name: str, events: List[Tuple[int, str]]) -> Dict[str, Any]:
        """
        Check a timeline for variance against the Sacred Timeline
        
        Args:
            timeline_name: Name of the timeline to check
            events: List of (year, description) event tuples
            
        Returns:
            Variance report
        """
        if not events:
            return {
                "timeline": timeline_name,
                "variance_level": 0.0,
                "exceeds_threshold": False,
                "details": "No events to compare"
            }
            
        # Calculate variance by comparing events to nexus points
        total_variance = 0.0
        variant_events = []
        
        # For each nexus point, look for corresponding events
        for nexus in self.key_nexus_points:
            nexus_year = nexus["year"]
            nexus_desc = nexus["description"]
            
            # Look for events in similar years (±3 years)
            matching_events = [
                event for event in events 
                if abs(event[0] - nexus_year) <= 3
            ]
            
            # If no matching event found for a protected nexus point, that's a major variance
            if not matching_events and nexus["protected"]:
                total_variance += nexus["importance"] * 0.5
                variant_events.append({
                    "type": "missing_nexus",
                    "year": nexus_year,
                    "description": f"Missing critical event: {nexus_desc}",
                    "severity": nexus["importance"]
                })
                continue
                
            # Check for event text similarity (primitive check)
            for event_year, event_desc in matching_events:
                # Very basic similarity check - can be improved
                words_nexus = set(nexus_desc.lower().split())
                words_event = set(event_desc.lower().split())
                common_words = words_nexus.intersection(words_event)
                
                similarity = len(common_words) / max(1, len(words_nexus))
                
                # If event exists but is very different, that's a variance
                if similarity < 0.3:
                    variance_value = (0.6 - similarity) * nexus["importance"]
                    total_variance += variance_value
                    
                    variant_events.append({
                        "type": "altered_nexus",
                        "year": event_year,
                        "description": f"Altered event: {event_desc}",
                        "original": nexus_desc,
                        "severity": variance_value
                    })
                    
                    # Increment variance count for this nexus point
                    nexus["variance_count"] += 1
        
        # Check for events that don't correspond to any nexus points
        for event_year, event_desc in events:
            # Skip events that are far from our nexus timeline
            if not any(abs(event_year - nexus["year"]) <= 10 for nexus in self.key_nexus_points):
                continue
                
            # Look for nearby nexus points
            nearby_nexus = [
                nexus for nexus in self.key_nexus_points 
                if abs(event_year - nexus["year"]) <= 10
            ]
            
            # If event doesn't correspond to a nexus point, it's a variance
            if not nearby_nexus:
                continue
                
            # Check for event text similarity with nearby nexus points
            max_similarity = 0
            for nexus in nearby_nexus:
                words_nexus = set(nexus["description"].lower().split())
                words_event = set(event_desc.lower().split())
                common_words = words_nexus.intersection(words_event)
                
                similarity = len(common_words) / max(1, len(words_nexus))
                max_similarity = max(max_similarity, similarity)
            
            # If this event doesn't match any nearby nexus point, it's a new variant event
            if max_similarity < 0.2:
                variance_value = 0.2
                total_variance += variance_value
                
                variant_events.append({
                    "type": "new_event",
                    "year": event_year,
                    "description": f"New event: {event_desc}",
                    "severity": variance_value
                })
        
        # Normalize variance to 0-1 scale
        variance_level = min(1.0, total_variance)
        
        return {
            "timeline": timeline_name,
            "variance_level": variance_level,
            "exceeds_threshold": variance_level > self.variance_threshold,
            "variant_events": variant_events,
            "details": f"Found {len(variant_events)} variant events"
        }
        
    def add_red_line_warning(self, timeline_name: str, warning: str):
        """Add a red line warning for a timeline that has breached critical variance"""
        self.red_line_warnings.append({
            "timestamp": time.time(),
            "timeline": timeline_name,
            "warning": warning,
            "status": "Active"
        })
    
    def update_stability(self):
        """Update Sacred Timeline stability based on current conditions"""
        # Base stability decays slightly over time
        time_factor = 1.0 - (min(10, (time.time() - self.created_at) / (86400 * 30))) * 0.1
        
        # Time since last pruning affects stability
        prune_factor = 1.0 - (min(1.0, (time.time() - self.last_pruning) / (86400))) * 0.05
        
        # Active radiation reduces stability
        radiation_factor = 1.0
        active_radiation = [r["radiation"] for r in self.radiation_history 
                           if r["radiation"].is_detectable()]
        
        if active_radiation:
            total_intensity = sum(r.get_current_intensity() for r in active_radiation)
            radiation_factor = max(0.5, 1.0 - (total_intensity * 0.2))
        
        # Red line warnings have major impact
        active_warnings = [w for w in self.red_line_warnings if w["status"] == "Active"]
        warning_factor = max(0.7, 1.0 - (len(active_warnings) * 0.1))
        
        # Calculate new stability
        self.current_stability = (self.base_stability * time_factor * 
                                 prune_factor * radiation_factor * warning_factor)
        
        return self.current_stability
    
    def get_status_report(self) -> str:
        """Generate a status report for the Sacred Timeline"""
        self.update_stability()
        
        report = [f"=== SACRED TIMELINE STATUS REPORT ==="]
        report.append(f"Name: {self.name}")
        report.append(f"Current Stability: {self.current_stability:.2f}")
        
        # Show active radiation
        active_radiation = [r["radiation"] for r in self.radiation_history 
                           if r["radiation"].is_detectable()]
        
        if active_radiation:
            report.append(f"\nActive Temporal Radiation:")
            for radiation in active_radiation[:3]:  # Show top 3
                report.append(f"- {radiation}")
        
        # Show active red line warnings
        active_warnings = [w for w in self.red_line_warnings if w["status"] == "Active"]
        if active_warnings:
            report.append(f"\nRED LINE WARNINGS ({len(active_warnings)}):")
            for warning in active_warnings[:3]:  # Show top 3
                report.append(f"- {warning['timeline']}: {warning['warning']}")
        
        # Show protected nexus points
        report.append(f"\nProtected Nexus Points:")
        protected = [n for n in self.key_nexus_points if n["protected"]]
        for nexus in protected:
            report.append(f"- {nexus['year']}: {nexus['description']}")
            if nexus["variance_count"] > 0:
                report.append(f"  * {nexus['variance_count']} variance instances detected!")
        
        # Overall status
        if self.current_stability > 0.8:
            status = "STABLE"
        elif self.current_stability > 0.5:
            status = "CAUTION"
        else:
            status = "CRITICAL"
            
        report.append(f"\nOverall Status: {status}")
        
        return "\n".join(report)
    
    def __str__(self) -> str:
        self.update_stability()
        return f"Sacred Timeline: {self.current_stability:.2f} stability, {len(self.key_nexus_points)} nexus points"


def run_sacred_timeline_demo():
    """Run a demonstration of the Sacred Timeline system"""
    print("=== Sacred Timeline System Demonstration ===")
    
    # Create the Sacred Timeline
    sacred = SacredTimeline("Alpha Sacred Timeline", 0.95)
    
    # Add some nexus points
    sacred.add_nexus_point(2012, "Dimensional Convergence", 0.8)
    sacred.add_nexus_point(2023, "Quantum Breakthrough", 0.75)
    sacred.add_nexus_point(2036, "First Contact Event", 0.9)
    
    print(f"Created: {sacred}")
    
    # Show initial status
    print("\n" + sacred.get_status_report())
    
    # Create some variant timelines to check
    print("\nChecking variant timelines...")
    
    variant1_events = [
        (2012, "Dimensional Convergence"),
        (2023, "Quantum Failure"),  # Changed from breakthrough to failure
        (2036, "First Contact Event"),
        (2040, "New Variant Event")  # New event not in sacred timeline
    ]
    
    variant2_events = [
        (2012, "Dimensional Divergence"),  # Changed
        (2025, "Quantum Understanding"),  # Shifted and changed
        # Missing 2036 event entirely
        (2050, "Unexpected Development")  # New event
    ]
    
    # Check variants
    report1 = sacred.check_timeline_variance("Variant Alpha-2", variant1_events)
    report2 = sacred.check_timeline_variance("Variant Epsilon-7", variant2_events)
    
    print(f"\nVariant Alpha-2 Variance: {report1['variance_level']:.2f}")
    print(f"Exceeds threshold: {report1['exceeds_threshold']}")
    for event in report1.get("variant_events", []):
        print(f"- {event['type']} at {event['year']}: {event['description']}")
    
    print(f"\nVariant Epsilon-7 Variance: {report2['variance_level']:.2f}")
    print(f"Exceeds threshold: {report2['exceeds_threshold']}")
    for event in report2.get("variant_events", []):
        print(f"- {event['type']} at {event['year']}: {event['description']}")
    
    # Prune the variant that exceeds threshold
    if report2['exceeds_threshold']:
        print(f"\nPruning Variant Epsilon-7...")
        success, radiation = sacred.prune_variant_timeline("Variant Epsilon-7", 0.7)
        print(f"Pruning success: {success}")
        print(f"Generated radiation: {radiation}")
    
    # Show final status
    print("\nFinal Sacred Timeline status:")
    print(sacred.get_status_report())
    
    return sacred


if __name__ == "__main__":
    run_sacred_timeline_demo()
