"""
Multiverse Database Options Manager
This module provides functionality for managing database options, settings,
and save/load operations for the multiverse simulation.
"""

import os
import json
import time
from multiverse_db import MultiverseDatabase

class DatabaseOptionsManager:
    """
    Manages database settings and operations for the multiverse application.
    """

    def __init__(self, settings=None):
        """Initialize the database options manager."""
        # Try to import settings from menu system if available
        if settings is None:
            try:
                from menu_system import SimulationSettings
                self.settings = SimulationSettings()
            except ImportError:
                # Create default settings object
                self.settings = type('Settings', (), {'settings': {
                    'database_enabled': True,
                    'db_path': 'multiverse.db',
                    'auto_save': True,
                    'save_interval': 300,  # 5 minutes
                    'backup_enabled': True,  # Enabled by default in v2.0.0
                    'max_backups': 5,
                    'use_coordinates': True,
                    'default_reference_system': 'Earth-Centered',
                    'store_coordinates': True,
                    'coordinate_precision': 'high',
                    'system_version': '2.0.0',  # Added version tracking
                    'patch_notes_viewed': False  # Track if user has seen patch notes
                }, 'get': lambda self, key, default=None: self.settings.get(key, default)})()
        else:
            self.settings = settings

        # Initialize database
        self.db_path = self.settings.get('db_path', 'multiverse.db')
        self.database = MultiverseDatabase(self.db_path) if self.settings.get('database_enabled', True) else None
        self.last_save_time = time.time()

    def is_database_enabled(self):
        """Check if the database is enabled."""
        return self.settings.get('database_enabled', True)

    def enable_database(self, enabled=True):
        """Enable or disable the database."""
        if self.settings.settings:
            self.settings.settings['database_enabled'] = enabled

        if enabled and self.database is None:
            self.database = MultiverseDatabase(self.db_path)
        elif not enabled:
            self.database = None

        return enabled

    def set_database_path(self, db_path):
        """Set the database file path."""
        self.db_path = db_path
        if self.settings.settings:
            self.settings.settings['db_path'] = db_path

        # Reinitialize database with new path if enabled
        if self.database is not None:
            self.database = MultiverseDatabase(db_path)

        return True

    def toggle_auto_save(self):
        """Toggle auto-save functionality."""
        current = self.settings.get('auto_save', True)
        new_value = not current
        if self.settings.settings:
            self.settings.settings['auto_save'] = new_value
        return new_value

    def set_save_interval(self, interval):
        """Set the auto-save interval in seconds."""
        if self.settings.settings:
            self.settings.settings['save_interval'] = interval
        return interval

    def save_multiverse(self, multiverse, force=False):
        """Save the multiverse to the database if enabled."""
        if not self.is_database_enabled() or self.database is None:
            return False

        # Check if auto-save is enabled and if enough time has passed
        current_time = time.time()
        auto_save = self.settings.get('auto_save', True)
        save_interval = self.settings.get('save_interval', 300)

        if force or (auto_save and (current_time - self.last_save_time) >= save_interval):
            # Save all timelines
            for name, timeline in multiverse.timelines.items():
                self.database.update_timeline(timeline)

            # Save wormholes
            for wormhole in multiverse.wormholes:
                self.database.update_wormhole(wormhole)

            # Save connections between timelines
            for connection in multiverse.connections:
                self.database.save_timeline_connection(
                    connection['timeline1'], 
                    connection['timeline2'],
                    connection.get('quantum_entangled', False),
                    connection.get('entanglement_strength', None)
                )

            # Save timewaves
            for timewave in multiverse.timewaves:
                self.database.save_timewave(timewave)

            self.last_save_time = current_time
            return True

        return False

    def create_backup(self, export_path=None):
        """Create a backup of the current database state."""
        if not self.is_database_enabled() or self.database is None:
            return False

        if export_path is None:
            timestamp = time.strftime("%Y%m%d-%H%M%S")
            export_path = f"multiverse_backup_{timestamp}.json"

        return self.database.export_multiverse_state(export_path)

    def restore_backup(self, import_path):
        """Restore the database from a backup file."""
        if not self.is_database_enabled() or self.database is None:
            return False

        return self.database.import_multiverse_state(import_path)

    def create_rotation_backup(self):
        """Create a backup and maintain a rotation of backups."""
        if not self.is_database_enabled() or self.database is None:
            return False

        # Check if backups are enabled
        if not self.settings.get('backup_enabled', False):
            return False

        # Create new backup
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        backup_path = f"multiverse_backup_{timestamp}.json"
        self.database.export_multiverse_state(backup_path)

        # Manage backup rotation
        max_backups = self.settings.get('max_backups', 5)
        all_backups = sorted([f for f in os.listdir() if f.startswith("multiverse_backup_") and f.endswith(".json")])

        # Remove oldest backups if we have too many
        while len(all_backups) > max_backups:
            oldest = all_backups.pop(0)
            try:
                os.remove(oldest)
                print(f"Removed old backup: {oldest}")
            except Exception as e:
                print(f"Failed to remove old backup {oldest}: {e}")

        return backup_path

    def toggle_backup_enabled(self):
        """Toggle backup functionality."""
        current = self.settings.get('backup_enabled', False)
        new_value = not current
        if self.settings.settings:
            self.settings.settings['backup_enabled'] = new_value
        return new_value

    def set_max_backups(self, count):
        """Set the maximum number of backups to keep."""
        if self.settings.settings:
            self.settings.settings['max_backups'] = count
        return count

    def get_database_stats(self):
        """Get statistics about the database."""
        if not self.is_database_enabled() or self.database is None:
            return None

        stats = {
            "timeline_count": len(self.database.get_all_timelines()),
            "unstable_timelines": len(self.database.get_unstable_timelines()),
            "quantum_anomalies": len(self.database.get_quantum_anomalies()),
            "paradox_stats": self.database.get_paradox_statistics(),
            "db_size": os.path.getsize(self.db_path) if os.path.exists(self.db_path) else 0,
            "last_save": self.last_save_time
        }
        return stats

    def query_database(self, query_type, params=None):
        """Perform a predefined query on the database."""
        if not self.is_database_enabled() or self.database is None:
            return None

        params = params or {}

        if query_type == "unstable_timelines":
            threshold = params.get("threshold", 0.4)
            return self.database.get_unstable_timelines(threshold)

        elif query_type == "quantum_anomalies":
            return self.database.get_quantum_anomalies()

        elif query_type == "paradox_statistics":
            return self.database.get_paradox_statistics()

        elif query_type == "search_events":
            query = params.get("query", "")
            return self.database.search_events(query)

        elif query_type == "connected_timelines":
            timeline = params.get("timeline", "")
            return self.database.find_connected_timelines(timeline)

        return None

    def is_coordinates_enabled(self):
        """
        Check if coordinate system is enabled.
        """
        return self.settings.get('use_coordinates', True)

    def get_coordinate_precision(self):
        """
        Get the current coordinate precision setting.
        Returns 'high', 'medium', or 'low'.
        """
        return self.settings.get('coordinate_precision', 'high')

    def set_coordinate_precision(self, precision):
        """
        Set the coordinate precision (high, medium, low).
        """
        if precision in ['high', 'medium', 'low']:
            self.settings.settings['coordinate_precision'] = precision
            return True
        return False

    def get_default_reference_system(self):
        """
        Get the default spatial reference system.
        """
        return self.settings.get('default_reference_system', 'Earth-Centered')

    def set_default_reference_system(self, system):
        """
        Set the default spatial reference system.
        """
        valid_systems = ['Earth-Centered', 'Moon-Centered', 'Mars-Centered', 
                        'Solar-System', 'Galactic', 'Universal']
        if system in valid_systems:
            self.settings.settings['default_reference_system'] = system
            return True
        return False

    def should_store_coordinates(self):
        """
        Check if coordinates should be stored in the database.
        """
        return self.settings.get('store_coordinates', True)

    def save_multiverse_state(self, multiverse):
        """Save the current multiverse state to the database."""
        print("Saving multiverse state to database...")
        multiverse.save_multiverse_state()
        print("Multiverse state saved successfully.")

    def save_quantum_dimensions_state(self, reality_manager):
        """Save the quantum dimensions and realities to a file."""
        import json
        import os

        print("Saving quantum dimensions state...")

        try:
            # Create export directory if it doesn't exist
            if not os.path.exists('data'):
                os.makedirs('data')

            # Build the export data
            export_data = {
                'dimensions': {},
                'realities': {},
                'travelers': {},
                'breaches': []
            }

            # Export dimensions
            for dim_id, dimension in reality_manager.registry.dimensions.items():
                export_data['dimensions'][dim_id] = {
                    'name': dimension.name,
                    'complexity': dimension.complexity,
                    'stability': dimension.stability,
                    'accessibility': dimension.accessibility,
                    'time_flow_rate': dimension.time_flow_rate,
                    'spacial_dimensions': dimension.spacial_dimensions,
                    'energy_density': dimension.energy_density,
                    'quantum_state_persistence': dimension.quantum_state_persistence,
                    'dimensional_gates': list(dimension.dimensional_gates)
                }

            # Export realities
            for reality_id, reality in reality_manager.registry.realities.items():
                export_data['realities'][reality_id] = {
                    'name': reality.name,
                    'dimension_id': reality.dimension_id,
                    'divergence': reality.divergence,
                    'consistency': reality.consistency,
                    'time_variance': reality.time_variance,
                    'physical_constants_shift': reality.physical_constants_shift,
                    'causality_integrity': reality.causality_integrity,
                    'events': reality.events
                }

            # Export travelers
            for name, traveler in reality_manager.travelers.items():
                export_data['travelers'][name] = {
                    'current_dimension_id': traveler.current_dimension_id,
                    'current_reality_id': traveler.current_reality_id,
                    'dimensional_stability': traveler.dimensional_stability,
                    'quantum_resonance': traveler.quantum_resonance,
                    'origin_dimension': traveler.origin_dimension,
                    'origin_reality': traveler.origin_reality,
                    'reality_memory': traveler.reality_memory
                }

            # Export reality breaches
            for origin, dest, stability in reality_manager.reality_breach_points:
                export_data['breaches'].append({
                    'origin_dimension': origin.dimension_id,
                    'origin_reality': origin.reality_id,
                    'dest_dimension': dest.dimension_id,
                    'dest_reality': dest.reality_id,
                    'stability': stability
                })

            # Write to file
            with open('data/quantum_dimensions.json', 'w') as f:
                json.dump(export_data, f, indent=2)

            print(f"Quantum dimensions state saved to data/quantum_dimensions.json")
            print(f"Saved {len(export_data['dimensions'])} dimensions, {len(export_data['realities'])} realities")

            return True
        except Exception as e:
            print(f"Error saving quantum dimensions state: {e}")
            return False

    def load_multiverse_state(self, multiverse):
        """Load a multiverse state from the database."""
        print("Loading multiverse state from database...")
        multiverse.load_multiverse_state()
        print("Multiverse state loaded successfully.")

    def load_quantum_dimensions_state(self, reality_manager):
        """Load quantum dimensions and realities from a file."""
        import json
        import os

        print("Loading quantum dimensions state...")

        try:
            if not os.path.exists('data/quantum_dimensions.json'):
                print("No saved quantum dimensions state found.")
                return False

            with open('data/quantum_dimensions.json', 'r') as f:
                import_data = json.load(f)

            # Clear existing data
            reality_manager.registry.dimensions.clear()
            reality_manager.registry.realities.clear()
            reality_manager.travelers.clear()
            reality_manager.reality_breach_points.clear()

            # Import dimensions
            from quantum_dimensions import QuantumDimension
            for dim_id_str, dim_data in import_data['dimensions'].items():
                try:
                    dim_id = int(dim_id_str)
                    dimension = QuantumDimension(
                        dim_id,
                        dim_data['name'],
                        dim_data['complexity'],
                        dim_data['stability'],
                        dim_data['accessibility']
                    )
                    dimension.time_flow_rate = dim_data['time_flow_rate']
                    dimension.spacial_dimensions = dim_data['spacial_dimensions']
                    dimension.energy_density = dim_data['energy_density']
                    dimension.quantum_state_persistence = dim_data['quantum_state_persistence']

                    # Add dimensional gates later after all dimensions are loaded
                    reality_manager.registry.dimensions[dim_id] = dimension
                except (KeyError, ValueError) as e:
                    print(f"Error loading dimension {dim_id_str}: {e}")

            # Set dimensional gates now that all dimensions are loaded
            for dim_id_str, dim_data in import_data['dimensions'].items():
                try:
                    dim_id = int(dim_id_str)
                    dimension = reality_manager.registry.dimensions[dim_id]
                    for gate_data in dim_data['dimensional_gates']:
                        gate_id, stability = gate_data
                        dimension.dimensional_gates.add((gate_id, stability))
                except (KeyError, ValueError) as e:
                    print(f"Error setting gates for dimension {dim_id_str}: {e}")

            # Import realities
            from quantum_dimensions import QuantumReality
            for reality_id_str, reality_data in import_data['realities'].items():
                try:
                    reality_id = int(reality_id_str)
                    dimension_id = reality_data['dimension_id']

                    # Skip if dimension doesn't exist
                    if dimension_id not in reality_manager.registry.dimensions:
                        continue

                    # Create the reality
                    reality = QuantumReality(
                        reality_id,
                        dimension_id,
                        reality_data['name'],
                        reality_data['divergence'],
                        reality_data['consistency']
                    )
                    reality.time_variance = reality_data['time_variance']
                    reality.physical_constants_shift = reality_data['physical_constants_shift']
                    reality.causality_integrity = reality_data['causality_integrity']
                    reality.events = reality_data['events']

                    # Add to registry
                    reality_manager.registry.dimensions[dimension_id].realities[reality_id] = reality
                    reality_manager.registry.realities[reality_id] = reality
                except (KeyError, ValueError) as e:
                    print(f"Error loading reality {reality_id_str}: {e}")


            # Import travelers
            from alternate_realities import RealityTraveler
            for name, traveler_data in import_data['travelers'].items():
                try:
                    traveler = RealityTraveler(
                        name,
                        traveler_data['origin_dimension'],
                        traveler_data['origin_reality']
                    )
                    traveler.current_dimension_id = traveler_data['current_dimension_id']
                    traveler.current_reality_id = traveler_data['current_reality_id']
                    traveler.dimensional_stability = traveler_data['dimensional_stability']
                    traveler.quantum_resonance = traveler_data['quantum_resonance']
                    traveler.reality_memory = traveler_data['reality_memory']

                    # Add to registry
                    reality_manager.travelers[name] = traveler
                except (KeyError, ValueError) as e:
                    print(f"Error loading traveler {name}: {e}")

            # Import reality breaches
            from alternate_realities import RealityCoordinate
            for breach_data in import_data['breaches']:
                try:
                    origin_coord = RealityCoordinate.from_dimension(
                        breach_data['origin_dimension'],
                        breach_data['origin_reality']
                    )
                    dest_coord = RealityCoordinate.from_dimension(
                        breach_data['dest_dimension'],
                        breach_data['dest_reality']
                    )

                    # Add to registry
                    reality_manager.reality_breach_points.append(
                        (origin_coord, dest_coord, breach_data['stability'])
                    )
                except (KeyError, ValueError) as e:
                    print(f"Error loading reality breach: {e}")

            print(f"Quantum dimensions state loaded from data/quantum_dimensions.json")
            print(f"Loaded {len(reality_manager.registry.dimensions)} dimensions, {len(reality_manager.registry.realities)} realities")

            return True
        except (FileNotFoundError, json.JSONDecodeError, Exception) as e:
            print(f"Error loading quantum dimensions state: {e}")
            return False