
#!/usr/bin/env python3
"""
Run the Temporal Loom Quantum Computer demonstration
"""

from temporal_loom_quantum_computer import run_quantum_computer_demo

if __name__ == "__main__":
    print("Starting Temporal Loom Quantum Computer demonstration...")
    quantum_computer = run_quantum_computer_demo()
    print("\nDemonstration completed successfully.")
