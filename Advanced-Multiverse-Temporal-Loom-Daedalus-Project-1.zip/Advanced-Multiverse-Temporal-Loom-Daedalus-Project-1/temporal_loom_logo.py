
"""
Temporal Loom Logo Generator
This script creates a visual logo for the Temporal Loom engine.
"""

from PIL import Image, ImageDraw, ImageFont
import math
import random
import os

def create_temporal_loom_logo(output_path="temporal_loom_logo.png", size=(800, 800)):
    """
    Create a visual logo for the Temporal Loom.
    
    Args:
        output_path: Path to save the output image
        size: Size of the output image (width, height)
    """
    # Create a new image with a dark background
    img = Image.new('RGBA', size, color=(15, 24, 43, 255))  # Dark blue background
    draw = ImageDraw.Draw(img)
    
    # Center of the image
    center_x, center_y = size[0] // 2, size[1] // 2
    
    # Draw the loom structure
    draw_loom_structure(draw, center_x, center_y, size)
    
    # Draw thread patterns
    draw_threads(draw, center_x, center_y, size)
    
    # Add text
    add_text(draw, size)
    
    # Save the image
    img.save(output_path)
    print(f"Logo saved to {output_path}")
    return output_path

def draw_loom_structure(draw, center_x, center_y, size):
    """Draw the main loom structure"""
    # Draw outer circle (loom frame)
    radius = min(center_x, center_y) - 50
    draw.ellipse((center_x - radius, center_y - radius, 
                  center_x + radius, center_y + radius), 
                 outline=(200, 200, 255, 200), width=5)
    
    # Draw inner circle
    inner_radius = radius * 0.85
    draw.ellipse((center_x - inner_radius, center_y - inner_radius, 
                  center_x + inner_radius, center_y + inner_radius), 
                 outline=(150, 150, 220, 180), width=3)
    
    # Draw spokes
    spokes = 12
    for i in range(spokes):
        angle = math.radians(i * (360 / spokes))
        x1 = center_x + inner_radius * math.cos(angle)
        y1 = center_y + inner_radius * math.sin(angle)
        x2 = center_x + radius * math.cos(angle)
        y2 = center_y + radius * math.sin(angle)
        draw.line((x1, y1, x2, y2), fill=(150, 150, 220, 180), width=2)

def draw_threads(draw, center_x, center_y, size):
    """Draw the temporal threads on the loom"""
    # Define thread colors
    thread_colors = [
        (255, 215, 0, 180),    # Gold
        (192, 192, 192, 180),  # Silver
        (255, 50, 50, 180),    # Red
        (50, 50, 255, 180),    # Blue
        (50, 200, 50, 180),    # Green
        (200, 50, 200, 180),   # Purple
    ]
    
    # Draw multiple thread patterns
    for _ in range(15):
        color = random.choice(thread_colors)
        
        # Draw a random thread pattern
        pattern_type = random.choice(['spiral', 'wave', 'zigzag'])
        
        if pattern_type == 'spiral':
            draw_spiral_thread(draw, center_x, center_y, size, color)
        elif pattern_type == 'wave':
            draw_wave_thread(draw, center_x, center_y, size, color)
        else:
            draw_zigzag_thread(draw, center_x, center_y, size, color)
            
def draw_spiral_thread(draw, center_x, center_y, size, color):
    """Draw a spiral thread pattern"""
    radius = min(center_x, center_y) - 60
    start_angle = random.uniform(0, math.pi*2)
    revolutions = random.uniform(1.5, 3.5)
    
    points = []
    for i in range(200):
        angle = start_angle + (i / 200) * math.pi * 2 * revolutions
        dist = (i / 200) * radius
        x = center_x + dist * math.cos(angle)
        y = center_y + dist * math.sin(angle)
        points.append((x, y))
        
    if len(points) > 1:
        draw.line(points, fill=color, width=2)

def draw_wave_thread(draw, center_x, center_y, size, color):
    """Draw a wave-like thread pattern"""
    radius = min(center_x, center_y) - 60
    start_angle = random.uniform(0, math.pi*2)
    amplitude = random.uniform(10, 40)
    frequency = random.uniform(4, 8)
    
    points = []
    for i in range(200):
        angle = start_angle + (i / 200) * math.pi * 2
        dist = radius * 0.5 + amplitude * math.sin(angle * frequency)
        x = center_x + dist * math.cos(angle)
        y = center_y + dist * math.sin(angle)
        points.append((x, y))
        
    if len(points) > 1:
        draw.line(points, fill=color, width=2)

def draw_zigzag_thread(draw, center_x, center_y, size, color):
    """Draw a zigzag thread pattern"""
    radius = min(center_x, center_y) - 60
    start_angle = random.uniform(0, math.pi*2)
    
    points = []
    segments = random.randint(12, 24)
    for i in range(segments + 1):
        angle = start_angle + (i / segments) * math.pi * 2
        dist = radius * (0.4 + 0.2 * (-1)**(i))
        x = center_x + dist * math.cos(angle)
        y = center_y + dist * math.sin(angle)
        points.append((x, y))
        
    if len(points) > 1:
        draw.line(points, fill=color, width=2)

def add_text(draw, size):
    """Add text to the logo"""
    # Try to load a font, with fallbacks for different systems
    font_size = size[0] // 15
    small_font_size = size[0] // 25
    
    try:
        # Try to find a suitable font
        possible_fonts = [
            "Arial.ttf", "DejaVuSans.ttf", "FreeSans.ttf", 
            "LiberationSans-Regular.ttf", "NotoSans-Regular.ttf"
        ]
        
        font = None
        small_font = None
        
        for font_name in possible_fonts:
            try:
                font = ImageFont.truetype(font_name, font_size)
                small_font = ImageFont.truetype(font_name, small_font_size)
                break
            except IOError:
                continue
                
        # If no font found, use default
        if font is None:
            font = ImageFont.load_default()
            small_font = ImageFont.load_default()
            
    except Exception:
        # Fall back to default font if there's any error
        font = ImageFont.load_default()
        small_font = ImageFont.load_default()
    
    # Add main title
    title = "TEMPORAL LOOM"
    draw.text((size[0]//2, size[1]//6), title, 
              fill=(255, 255, 255, 255), font=font, anchor="mm")
    
    # Add subtitle
    subtitle = "WEAVING THE FABRIC OF TIME"
    draw.text((size[0]//2, size[1]//6 + font_size + 10), subtitle, 
              fill=(180, 180, 255, 220), font=small_font, anchor="mm")
    
    # Add footer text
    footer = "MULTIVERSE SIMULATION SYSTEM"
    draw.text((size[0]//2, size[1] - size[1]//6), footer, 
              fill=(180, 180, 255, 220), font=small_font, anchor="mm")

if __name__ == "__main__":
    # Create logo in different sizes
    create_temporal_loom_logo("temporal_loom_logo_large.png", (800, 800))
    create_temporal_loom_logo("temporal_loom_logo_medium.png", (400, 400))
    create_temporal_loom_logo("temporal_loom_logo_small.png", (200, 200))
    create_temporal_loom_logo("temporal_loom_logo_icon.png", (64, 64))
