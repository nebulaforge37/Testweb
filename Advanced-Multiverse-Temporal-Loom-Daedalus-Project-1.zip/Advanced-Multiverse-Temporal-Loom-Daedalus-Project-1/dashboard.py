
"""
Dashboard Launcher for Multiverse Simulation
This module provides a modern dashboard interface to launch different simulation components.
"""

import tkinter as tk
from tkinter import ttk, PhotoImage
import random
import math
import colorsys
import time
import sys
import os

# Import our custom theme
from modern_theme import ModernTheme

class DashboardTile:
    """Interactive dashboard tile for module access"""
    
    def __init__(self, canvas, x, y, width, height, title, description, icon_text, command=None):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.title = title
        self.description = description
        self.icon_text = icon_text
        self.command = command
        self.hovered = False
        
        # Colors
        self.bg_color = "#1D2951"
        self.bg_hover_color = "#2A3A6A"
        self.text_color = "#FFFFFF"
        self.accent_color = "#4080FF"
        
        # Create tile with initial state
        self.create_tile()
    
    def create_tile(self):
        """Create the tile on the canvas"""
        # Background rectangle with rounded corners (simulated)
        self.bg_id = self.canvas.create_rectangle(
            self.x, self.y, 
            self.x + self.width, self.y + self.height,
            fill=self.bg_color, outline=self.accent_color, width=1,
            tags=f"tile_{id(self)}"
        )
        
        # Icon circle
        icon_size = min(self.width, self.height) * 0.25
        icon_x = self.x + icon_size + 10
        icon_y = self.y + self.height/2
        
        self.icon_bg = self.canvas.create_oval(
            icon_x - icon_size/2, icon_y - icon_size/2,
            icon_x + icon_size/2, icon_y + icon_size/2,
            fill=self.accent_color, outline="",
            tags=f"tile_{id(self)}"
        )
        
        # Icon text
        self.icon_id = self.canvas.create_text(
            icon_x, icon_y, text=self.icon_text,
            fill=self.text_color, font=("Arial", int(icon_size * 0.5)),
            tags=f"tile_{id(self)}"
        )
        
        # Title text
        title_x = self.x + self.width/2 + icon_size/2
        self.title_id = self.canvas.create_text(
            title_x, self.y + self.height * 0.3,
            text=self.title, fill=self.text_color,
            font=("Arial", 14, "bold"), anchor="center",
            tags=f"tile_{id(self)}"
        )
        
        # Description text
        self.desc_id = self.canvas.create_text(
            title_x, self.y + self.height * 0.6,
            text=self.description, fill=self.text_color + "AA",
            font=("Arial", 10), width=self.width - icon_size*2 - 20,
            anchor="center", justify="center",
            tags=f"tile_{id(self)}"
        )
        
        # Bind events
        for item in self.canvas.find_withtag(f"tile_{id(self)}"):
            self.canvas.tag_bind(item, "<Enter>", self.on_enter)
            self.canvas.tag_bind(item, "<Leave>", self.on_leave)
            self.canvas.tag_bind(item, "<Button-1>", self.on_click)
    
    def on_enter(self, event=None):
        """Handle mouse enter event"""
        if not self.hovered:
            self.hovered = True
            self.canvas.itemconfig(self.bg_id, fill=self.bg_hover_color)
            self.canvas.itemconfig(self.icon_bg, fill=self.accent_color+"FF")
    
    def on_leave(self, event=None):
        """Handle mouse leave event"""
        if self.hovered:
            self.hovered = False
            self.canvas.itemconfig(self.bg_id, fill=self.bg_color)
            self.canvas.itemconfig(self.icon_bg, fill=self.accent_color)
    
    def on_click(self, event=None):
        """Handle mouse click event"""
        if self.command:
            self.command()


class MultiverseDashboard:
    """Main dashboard for launching multiverse simulation components"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Multiverse Simulation Dashboard")
        self.root.geometry("1200x800")
        self.root.minsize(800, 600)
        
        # Apply the modern theme
        self.theme = ModernTheme(self.root, theme='dark')
        
        # Initialize UI
        self.setup_ui()
        
        # Start background animation
        self.animate_background()
    
    def setup_ui(self):
        """Set up the UI components"""
        # Main container
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Top header with gradient
        self.header = self.theme.create_gradient_frame(
            self.main_frame, 
            start_color="#1D2951", 
            end_color="#0A1128",
            height=100,
            width=self.root.winfo_width()
        )
        self.header.pack(fill=tk.X)
        
        # Add title to header
        self.header.create_text(
            602, 42, text="Multiverse Simulation Dashboard", 
            fill="#202040", font=('Arial', 24, 'bold'), 
            tags="title_shadow"
        )
        self.header.create_text(
            600, 40, text="Multiverse Simulation Dashboard",
            fill="#4080FF", font=('Arial', 24, 'bold'),
            tags="title"
        )
        
        # Subtitle
        self.header.create_text(
            600, 70, text="Advanced Quantum Field Theoretical Modeling System",
            fill="#AABBCC", font=('Arial', 12),
            tags="subtitle"
        )
        
        # Theme toggle button
        theme_btn = self.theme.create_custom_button(
            self.header, "Toggle Theme", 
            command=self.toggle_theme, 
            width=120, height=30
        )
        theme_btn.place(x=20, y=20)
        
        # Create animated background
        self.bg_canvas = tk.Canvas(
            self.main_frame, bg="#0A1128", 
            highlightthickness=0
        )
        self.bg_canvas.pack(fill=tk.BOTH, expand=True)
        
        # Create grid background
        self.create_grid_background()
        
        # Add dashboard content
        self.create_dashboard_content()
    
    def create_grid_background(self):
        """Create an animated grid background"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        
        # Ensure minimum dimensions
        width = max(800, width)
        height = max(600, height)
        
        # Grid lines
        grid_spacing = 40
        for x in range(0, width, grid_spacing):
            line = self.bg_canvas.create_line(
                x, 0, x, height, 
                fill="#1A2A4030", 
                width=1, dash=(2, 6),
                tags="grid"
            )
        
        for y in range(0, height, grid_spacing):
            line = self.bg_canvas.create_line(
                0, y, width, y, 
                fill="#1A2A4030", 
                width=1, dash=(2, 6),
                tags="grid"
            )
        
        # Add some "quantum particles"
        for _ in range(20):
            x = random.randint(0, width)
            y = random.randint(0, height)
            size = random.uniform(1, 3)
            
            particle = self.bg_canvas.create_oval(
                x-size, y-size, x+size, y+size,
                fill=self.random_quantum_color(),
                outline="",
                tags="particle"
            )
    
    def random_quantum_color(self):
        """Generate a random quantum particle color"""
        hue = random.random()  # Random hue
        saturation = random.uniform(0.7, 1.0)
        value = random.uniform(0.8, 1.0)
        
        r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)
        color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        
        # Add random alpha
        alpha = random.randint(180, 255)
        return f"{color}{alpha:02x}"
    
    def animate_background(self):
        """Animate the background elements"""
        # Move particles randomly
        particles = self.bg_canvas.find_withtag("particle")
        for particle in particles:
            # Random movement
            dx = random.uniform(-1, 1)
            dy = random.uniform(-1, 1)
            self.bg_canvas.move(particle, dx, dy)
            
            # Random color change with small probability
            if random.random() < 0.05:
                self.bg_canvas.itemconfig(particle, fill=self.random_quantum_color())
            
            # Keep particles within bounds by wrapping
            x1, y1, x2, y2 = self.bg_canvas.coords(particle)
            width = self.bg_canvas.winfo_width()
            height = self.bg_canvas.winfo_height()
            
            if x2 < 0:
                self.bg_canvas.move(particle, width + x2 - x1, 0)
            elif x1 > width:
                self.bg_canvas.move(particle, -width - (x2 - x1), 0)
                
            if y2 < 0:
                self.bg_canvas.move(particle, 0, height + y2 - y1)
            elif y1 > height:
                self.bg_canvas.move(particle, 0, -height - (y2 - y1))
        
        # Continue animation
        self.root.after(50, self.animate_background)
    
    def create_dashboard_content(self):
        """Create the main dashboard content with tiles"""
        # Dashboard header
        header_frame = ttk.Frame(self.bg_canvas)
        self.bg_canvas.create_window(600, 50, window=header_frame, anchor="center")
        
        ttk.Label(header_frame, text="Choose Simulation Module", style="Title.TLabel").pack(pady=(20, 10))
        
        # Create module tiles
        modules = [
            {
                "title": "Multiverse Simulator",
                "description": "Simulate quantum timelines and paradoxes with advanced visualization",
                "icon": "MS",
                "command": self.launch_multiverse_simulator
            },
            {
                "title": "Reality Visualization",
                "description": "Interactive 3D visualization of the multiverse structure",
                "icon": "RV",
                "command": self.launch_reality_visualization
            },
            {
                "title": "Quantum Archaeology",
                "description": "Recover traces of collapsed timelines and reconstruct events",
                "icon": "QA",
                "command": self.launch_quantum_archaeology
            },
            {
                "title": "Temporal Loom",
                "description": "Manipulate the fabric of spacetime and timeline connections",
                "icon": "TL",
                "command": self.launch_temporal_loom
            },
            {
                "title": "Sacred Timeline",
                "description": "Monitor and protect the primary timeline from disruptions",
                "icon": "ST",
                "command": self.launch_sacred_timeline
            },
            {
                "title": "Fusion Demo",
                "description": "Quantum fusion reactor technology demonstration",
                "icon": "FD",
                "command": self.launch_fusion_demo
            }
        ]
        
        # Calculate grid layout
        tile_width = 350
        tile_height = 150
        columns = 2
        
        # Create tiles
        self.tiles = []
        for i, module in enumerate(modules):
            row = i // columns
            col = i % columns
            
            x = 300 + col * (tile_width + 50)
            y = 120 + row * (tile_height + 30)
            
            tile = DashboardTile(
                self.bg_canvas, x, y, tile_width, tile_height,
                module["title"], module["description"], module["icon"],
                command=module["command"]
            )
            self.tiles.append(tile)
        
        # Add animated status indicator
        status_frame = ttk.Frame(self.bg_canvas)
        self.bg_canvas.create_window(600, 650, window=status_frame, anchor="center")
        
        self.status_label = ttk.Label(
            status_frame, 
            text="System Ready - Quantum Field Stabilized", 
            style="Info.TLabel"
        )
        self.status_label.pack(side=tk.LEFT)
        
        # Animated indicator
        self.indicator_canvas = tk.Canvas(status_frame, width=20, height=20, bg="#0A1128", highlightthickness=0)
        self.indicator_canvas.pack(side=tk.LEFT, padx=10)
        
        self.indicator = self.indicator_canvas.create_oval(4, 4, 16, 16, fill="#00CC99", outline="")
        
        # Start indicator animation
        self.animate_indicator()
    
    def animate_indicator(self):
        """Animate the status indicator"""
        t = time.time() * 3  # Time factor
        # Pulsing effect
        size = 6 + 4 * abs(math.sin(t))
        self.indicator_canvas.coords(
            self.indicator, 
            10-size, 10-size, 10+size, 10+size
        )
        
        # Color cycling for quantum effect
        r, g, b = colorsys.hsv_to_rgb((math.sin(t*0.1) + 1) / 4, 0.8, 0.9)  # Mostly in green/blue range
        color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        self.indicator_canvas.itemconfig(self.indicator, fill=color)
        
        self.root.after(50, self.animate_indicator)
    
    def toggle_theme(self):
        """Toggle between dark and light themes"""
        self.theme.toggle_theme()
        
        # Update background color
        if self.theme.theme == 'dark':
            self.bg_canvas.config(bg="#0A1128")
        else:
            self.bg_canvas.config(bg="#F0F4FF")
        
        # Update tile colors
        for tile in self.tiles:
            if self.theme.theme == 'dark':
                tile.bg_color = "#1D2951"
                tile.bg_hover_color = "#2A3A6A"
                tile.text_color = "#FFFFFF"
            else:
                tile.bg_color = "#D0DCFF"
                tile.bg_hover_color = "#C0D0FF"
                tile.text_color = "#0A1128"
            
            # Apply new colors
            tile.canvas.itemconfig(tile.bg_id, fill=tile.bg_color)
            tile.canvas.itemconfig(tile.title_id, fill=tile.text_color)
            tile.canvas.itemconfig(tile.desc_id, fill=tile.text_color+"AA")
    
    def launch_multiverse_simulator(self):
        """Launch the main multiverse simulator"""
        print("Launching Multiverse Simulator...")
        
        # Update status
        self.status_label.config(text="Launching Multiverse Simulator...")
        
        # Close dashboard and start simulator
        self.root.after(1000, self.start_simulator)
    
    def start_simulator(self):
        """Start the actual simulator"""
        self.root.destroy()
        
        # Launch main simulator
        os.system(f"{sys.executable} main.py")
    
    def launch_reality_visualization(self):
        """Launch the reality visualization module"""
        print("Launching Reality Visualization...")
        
        # Update status
        self.status_label.config(text="Launching Reality Visualization...")
        
        # Import and run reality visualization
        try:
            from reality_visualization import run_visualization_demo
            self.root.withdraw()  # Hide main window
            run_visualization_demo()
            self.root.deiconify()  # Show main window again
            self.status_label.config(text="System Ready - Quantum Field Stabilized")
        except Exception as e:
            print(f"Error: {e}")
            self.status_label.config(text=f"Error: {e}")
    
    def launch_quantum_archaeology(self):
        """Launch quantum archaeology module"""
        print("Launching Quantum Archaeology...")
        self.status_label.config(text="Launching Quantum Archaeology...")
        
        try:
            from quantum_archaeology import run_quantum_archaeology_demo
            self.root.withdraw()
            run_quantum_archaeology_demo()
            self.root.deiconify()
            self.status_label.config(text="System Ready - Quantum Field Stabilized")
        except Exception as e:
            print(f"Error: {e}")
            self.status_label.config(text=f"Error: {e}")
    
    def launch_temporal_loom(self):
        """Launch temporal loom module"""
        print("Launching Temporal Loom...")
        self.status_label.config(text="Launching Temporal Loom...")
        
        try:
            from temporal_loom import run_temporal_loom_demo
            self.root.withdraw()
            run_temporal_loom_demo()
            self.root.deiconify()
            self.status_label.config(text="System Ready - Quantum Field Stabilized")
        except Exception as e:
            print(f"Error: {e}")
            self.status_label.config(text=f"Error: {e}")
    
    def launch_sacred_timeline(self):
        """Launch sacred timeline module"""
        print("Launching Sacred Timeline...")
        self.status_label.config(text="Launching Sacred Timeline...")
        
        try:
            from sacred_timeline import run_sacred_timeline_demo
            self.root.withdraw()
            run_sacred_timeline_demo()
            self.root.deiconify()
            self.status_label.config(text="System Ready - Quantum Field Stabilized")
        except Exception as e:
            print(f"Error: {e}")
            self.status_label.config(text=f"Error: {e}")
    
    def launch_fusion_demo(self):
        """Launch fusion demo module"""
        print("Launching Fusion Demo...")
        self.status_label.config(text="Launching Fusion Demo...")
        
        try:
            from fusion_demo import run_advanced_fusion_demo
            self.root.withdraw()
            run_advanced_fusion_demo()
            self.root.deiconify()
            self.status_label.config(text="System Ready - Quantum Field Stabilized")
        except Exception as e:
            print(f"Error: {e}")
            self.status_label.config(text=f"Error: {e}")


def run_dashboard():
    """Run the multiverse dashboard"""
    root = tk.Tk()
    dashboard = MultiverseDashboard(root)
    root.mainloop()


if __name__ == "__main__":
    run_dashboard()
