
"""
Temporal Calculus Algorithm Cheat Sheet
======================================
A comprehensive reference for mathematical formulas used in time travel operations.
"""

import math
import numpy as np
from typing import Dict, List, Tuple, Optional

class TemporalCalculusReference:
    """
    Reference class containing key temporal physics calculations
    used throughout the multiverse simulation system.
    """
    
    @staticmethod
    def time_dilation_factor(relative_velocity: float, gravity_factor: float = 1.0) -> float:
        """
        Calculate relativistic time dilation factor
        
        Parameters:
            relative_velocity: Velocity as fraction of c (0.0 to 0.99)
            gravity_factor: Gravitational time dilation (1.0 = Earth normal)
            
        Returns:
            Combined time dilation factor
        
        Formula: γ = 1/√(1-v²/c²) * (1/gravity_factor)
        """
        if relative_velocity >= 1.0:
            raise ValueError("Relative velocity must be less than speed of light (1.0)")
            
        velocity_dilation = 1.0 / math.sqrt(1.0 - (relative_velocity ** 2))
        gravity_dilation = 1.0 / gravity_factor
        
        return velocity_dilation * gravity_dilation
    
    @staticmethod
    def worldline_integrity(stability: float, paradox_count: int, 
                          quantum_entanglement: float) -> float:
        """
        Calculate worldline integrity value
        
        Parameters:
            stability: Timeline stability coefficient (0.0 to 1.0)
            paradox_count: Number of active paradoxes
            quantum_entanglement: Quantum entanglement level (0.0 to 1.0)
            
        Returns:
            Worldline integrity value (0.0 to 1.0)
            
        Formula: I = S * (1 - P/10) * (1 - E/2)
        where:
            I = integrity
            S = stability
            P = paradox count with max effect at 10
            E = entanglement level
        """
        paradox_factor = max(0.0, 1.0 - (paradox_count / 10))
        entanglement_factor = max(0.0, 1.0 - (quantum_entanglement / 2))
        
        return stability * paradox_factor * entanglement_factor
    
    @staticmethod
    def timeline_bifurcation_probability(event_impact: float, timeline_stability: float, 
                                       quantum_field_energy: float) -> float:
        """
        Calculate the probability of a timeline bifurcating (splitting)
        
        Parameters:
            event_impact: Impact magnitude of event (0.0 to 1.0)
            timeline_stability: Timeline stability (0.0 to 1.0)
            quantum_field_energy: Quantum field energy level
            
        Returns:
            Bifurcation probability (0.0 to 1.0)
            
        Formula: P(bifurcation) = I * (1 - S) * (Q/5)
        where:
            I = event impact
            S = stability
            Q = quantum field energy
        """
        instability = 1.0 - timeline_stability
        quantum_factor = min(1.0, quantum_field_energy / 5.0)
        
        return event_impact * instability * quantum_factor
    
    @staticmethod
    def spacetime_distance(coord1: Tuple[float, float, float, float], 
                         coord2: Tuple[float, float, float, float],
                         temporal_weight: float = 0.1) -> float:
        """
        Calculate spacetime distance between two 4D coordinates
        
        Parameters:
            coord1: (x, y, z, t) for first coordinate
            coord2: (x, y, z, t) for second coordinate
            temporal_weight: Weighting factor for time dimension
            
        Returns:
            Spacetime distance value
            
        Formula: d = √(Δx² + Δy² + Δz² + (wt * Δt)²)
        where:
            wt = temporal_weight
        """
        x1, y1, z1, t1 = coord1
        x2, y2, z2, t2 = coord2
        
        spatial_distance_squared = (x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2
        temporal_distance_squared = ((t2 - t1) * temporal_weight)**2
        
        return math.sqrt(spatial_distance_squared + temporal_distance_squared)
    
    @staticmethod
    def quantum_entanglement_factor(dimensions: int, particles: int, 
                                  coherence: float) -> float:
        """
        Calculate quantum entanglement factor
        
        Parameters:
            dimensions: Number of quantum dimensions involved
            particles: Number of entangled particles
            coherence: Quantum coherence factor (0.0 to 1.0)
            
        Returns:
            Entanglement factor (higher means stronger entanglement)
            
        Formula: E = (P^0.5) * (D^0.3) * C
        where:
            P = particles
            D = dimensions
            C = coherence
        """
        return (particles ** 0.5) * (dimensions ** 0.3) * coherence
    
    @staticmethod
    def paradox_severity(timeline_stability: float, paradox_type_factor: float,
                       event_magnitude: float) -> float:
        """
        Calculate the severity of a temporal paradox
        
        Parameters:
            timeline_stability: Timeline stability (0.0 to 1.0)
            paradox_type_factor: Severity modifier for paradox type
            event_magnitude: Magnitude of the paradoxical event
            
        Returns:
            Paradox severity (0.0 to 10.0)
            
        Formula: S = (P * M) / √S * 10
        where:
            P = paradox type factor
            M = event magnitude
            S = timeline stability
        """
        # Prevent division by zero
        stability_factor = max(0.01, timeline_stability)
        
        return (paradox_type_factor * event_magnitude) / math.sqrt(stability_factor) * 10
    
    @staticmethod
    def timeline_merging_compatibility(timeline1_stability: float, timeline2_stability: float,
                                     quantum_similarity: float, event_overlap: float) -> float:
        """
        Calculate the compatibility for merging two timelines
        
        Parameters:
            timeline1_stability: Stability of first timeline (0.0 to 1.0)
            timeline2_stability: Stability of second timeline (0.0 to 1.0)
            quantum_similarity: Quantum similarity between timelines (0.0 to 1.0)
            event_overlap: Proportion of overlapping events (0.0 to 1.0)
            
        Returns:
            Merging compatibility (0.0 to 1.0)
            
        Formula: C = (S₁ * S₂)^0.5 * (Q + E)/2
        where:
            S₁, S₂ = timeline stabilities
            Q = quantum similarity
            E = event overlap
        """
        stability_factor = math.sqrt(timeline1_stability * timeline2_stability)
        similarity_factor = (quantum_similarity + event_overlap) / 2
        
        return stability_factor * similarity_factor
    
    @staticmethod
    def quantum_tunneling_probability(barrier_height: float, particle_energy: float,
                                    barrier_width: float) -> float:
        """
        Calculate quantum tunneling probability
        
        Parameters:
            barrier_height: Height of energy barrier
            particle_energy: Energy of the particle
            barrier_width: Width of the barrier
            
        Returns:
            Tunneling probability (0.0 to 1.0)
            
        Formula: P ≈ exp(-2 * w * √(2m(V-E)/ħ²))
        Simplified as: P = exp(-k * w * √(V-E))
        where k is a constant
        """
        if particle_energy >= barrier_height:
            return 1.0  # No tunneling needed if energy exceeds barrier
            
        # Simplified calculation with constant k = 2.0
        k = 2.0
        return math.exp(-k * barrier_width * math.sqrt(barrier_height - particle_energy))
    
    @staticmethod
    def wormhole_stability(diameter: float, energy_density: float, 
                         negative_energy: float) -> float:
        """
        Calculate wormhole stability factor
        
        Parameters:
            diameter: Wormhole throat diameter (meters)
            energy_density: Energy density around wormhole
            negative_energy: Amount of negative energy available
            
        Returns:
            Stability factor (0.0 to 1.0)
            
        Formula: S = min(1.0, N / (E * D^2))
        where:
            N = negative energy
            E = energy density
            D = diameter
        """
        if diameter <= 0 or energy_density <= 0:
            return 0.0
            
        # Negative energy counteracts the tendency of wormholes to collapse
        stability = negative_energy / (energy_density * diameter**2)
        
        return min(1.0, stability)
    
    @staticmethod
    def timeline_restoration_energy(damage_level: float, timeline_age: int,
                                  quantum_integrity: float) -> float:
        """
        Calculate energy required to restore a damaged timeline
        
        Parameters:
            damage_level: Level of timeline damage (0.0 to 1.0)
            timeline_age: Age of timeline in years
            quantum_integrity: Quantum integrity factor (0.0 to 1.0)
            
        Returns:
            Energy required (relative units)
            
        Formula: E = D * A^0.4 / I
        where:
            D = damage level
            A = age
            I = quantum integrity
        """
        # Prevent division by zero
        integrity = max(0.01, quantum_integrity)
        
        # Age factor - older timelines require more energy
        age_factor = timeline_age ** 0.4
        
        return damage_level * age_factor / integrity
    
    @staticmethod
    def temporal_loop_resonance(loop_count: int, loop_duration: float,
                              stability_factor: float) -> float:
        """
        Calculate temporal loop resonance strength
        
        Parameters:
            loop_count: Number of existing loops
            loop_duration: Duration of loop in years
            stability_factor: Stability factor (0.0 to 1.0)
            
        Returns:
            Resonance strength (higher means stronger coupling between loops)
            
        Formula: R = √C * D^0.3 * (1 - S + 0.1)
        where:
            C = loop count
            D = duration
            S = stability
        """
        count_factor = math.sqrt(max(1, loop_count))
        duration_factor = loop_duration ** 0.3
        stability_term = (1.0 - stability_factor + 0.1)  # Never goes to zero
        
        return count_factor * duration_factor * stability_term
    
    @staticmethod
    def quantum_superposition_strength(entangled_states: int, decoherence_rate: float,
                                     observation_probability: float) -> float:
        """
        Calculate quantum superposition strength
        
        Parameters:
            entangled_states: Number of entangled quantum states
            decoherence_rate: Rate of quantum decoherence (0.0 to 1.0)
            observation_probability: Probability of observation (0.0 to 1.0)
            
        Returns:
            Superposition strength (0.0 to 1.0)
            
        Formula: S = (√N * (1 - D)) * (1 - O)
        where:
            N = entangled states
            D = decoherence rate
            O = observation probability
        """
        states_factor = math.sqrt(entangled_states)
        coherence_factor = 1.0 - decoherence_rate
        observation_factor = 1.0 - observation_probability
        
        strength = (states_factor * coherence_factor) * observation_factor
        return min(1.0, strength)
    
    @staticmethod
    def dimensional_boundary_permeability(energy_differential: float, 
                                        spacetime_curvature: float,
                                        quantum_fluctuation: float) -> float:
        """
        Calculate dimensional boundary permeability
        
        Parameters:
            energy_differential: Energy difference between dimensions
            spacetime_curvature: Curvature of spacetime at boundary
            quantum_fluctuation: Quantum fluctuation amplitude
            
        Returns:
            Permeability factor (0.0 to 1.0)
            
        Formula: P = (Q * C) / (1 + E)
        where:
            Q = quantum fluctuation
            C = spacetime curvature
            E = energy differential
        """
        return (quantum_fluctuation * spacetime_curvature) / (1.0 + energy_differential)
    
    @staticmethod
    def traveler_temporal_displacement(origin_year: int, destination_year: int,
                                     traveler_mass: float, stability: float) -> float:
        """
        Calculate temporal displacement energy for a time traveler
        
        Parameters:
            origin_year: Year of origin
            destination_year: Year of destination
            traveler_mass: Mass of traveler in kg
            stability: Stability factor of travel method (0.0 to 1.0)
            
        Returns:
            Energy required for temporal displacement
            
        Formula: E = m * |T₂ - T₁| * (1.5 - S) * 10^6
        where:
            m = mass
            T₁, T₂ = origin and destination times
            S = stability
        """
        time_difference = abs(destination_year - origin_year)
        stability_factor = 1.5 - stability  # Lower stability = higher energy needed
        
        # Base energy in joules
        base_energy = traveler_mass * time_difference * stability_factor * 1e6
        
        return base_energy
    
    @staticmethod
    def quantum_memory_retention(timeline_shifts: int, temporal_protection: float,
                               memory_reinforcement: float) -> float:
        """
        Calculate probability of retaining memories across timeline changes
        
        Parameters:
            timeline_shifts: Number of timeline shifts experienced
            temporal_protection: Level of temporal protection (0.0 to 1.0)
            memory_reinforcement: Memory reinforcement factor (0.0 to 1.0)
            
        Returns:
            Memory retention probability (0.0 to 1.0)
            
        Formula: R = (P + M) / 2 * (0.9^N)
        where:
            P = temporal protection
            M = memory reinforcement
            N = timeline shifts
        """
        protection_memory_avg = (temporal_protection + memory_reinforcement) / 2
        shift_degradation = 0.9 ** timeline_shifts
        
        return protection_memory_avg * shift_degradation


def main():
    """Demonstrate the temporal calculus formulas with examples"""
    
    calc = TemporalCalculusReference()
    
    print("=== TEMPORAL CALCULUS ALGORITHM CHEAT SHEET ===\n")
    
    # Demonstrate time dilation
    velocity = 0.8  # 80% of light speed
    gravity = 2.0   # Twice Earth's gravity
    dilation = calc.time_dilation_factor(velocity, gravity)
    print(f"Time Dilation Factor: {dilation:.4f}")
    print(f"  At {velocity:.0%} of light speed and {gravity:.1f}x Earth gravity")
    print(f"  Time passes {dilation:.2f}x slower for the traveler\n")
    
    # Demonstrate worldline integrity
    stability = 0.75
    paradoxes = 2
    entanglement = 0.3
    integrity = calc.worldline_integrity(stability, paradoxes, entanglement)
    print(f"Worldline Integrity: {integrity:.4f}")
    print(f"  Timeline stability: {stability:.2f}")
    print(f"  Active paradoxes: {paradoxes}")
    print(f"  Quantum entanglement: {entanglement:.2f}\n")
    
    # Demonstrate bifurcation probability
    impact = 0.8
    stability = 0.6
    q_energy = 3.5
    bifurcation = calc.timeline_bifurcation_probability(impact, stability, q_energy)
    print(f"Timeline Bifurcation Probability: {bifurcation:.4f}")
    print(f"  Event impact: {impact:.2f}")
    print(f"  Timeline stability: {stability:.2f}")
    print(f"  Quantum field energy: {q_energy:.2f}\n")
    
    # Demonstrate spacetime distance
    coord1 = (0, 0, 0, 2020)
    coord2 = (1000, 2000, 500, 1950)
    distance = calc.spacetime_distance(coord1, coord2, 0.1)
    print(f"Spacetime Distance: {distance:.2f}")
    print(f"  Between coordinates: {coord1} and {coord2}")
    print(f"  Temporal weight: 0.1\n")
    
    # Demonstrate quantum entanglement
    dimensions = 4
    particles = 25
    coherence = 0.8
    entanglement = calc.quantum_entanglement_factor(dimensions, particles, coherence)
    print(f"Quantum Entanglement Factor: {entanglement:.4f}")
    print(f"  Dimensions: {dimensions}")
    print(f"  Particles: {particles}")
    print(f"  Coherence: {coherence:.2f}\n")

    # Show a few more examples
    print("Additional Key Formulas:")
    print("  - Paradox Severity: S = (P * M) / √S * 10")
    print("  - Timeline Merging Compatibility: C = (S₁ * S₂)^0.5 * (Q + E)/2")
    print("  - Wormhole Stability: S = min(1.0, N / (E * D^2))")
    print("  - Quantum Tunneling: P = exp(-k * w * √(V-E))")


if __name__ == "__main__":
    main()
