
"""
Timeline Visualization Module
This module provides enhanced visual representation of timelines and quantum events.
"""

import tkinter as tk
from tkinter import ttk, Canvas
import math
import random
import colorsys
from timeline_canvas import TimelineCanvas  # Import from timeline_canvas instead

class EnhancedTimelineCanvas:
    """Enhanced canvas for displaying timelines with improved visual effects"""
    
    def __init__(self, parent, width=800, height=600):
        """Initialize the enhanced timeline canvas"""
        self.parent = parent
        self.width = width
        self.height = height
        
        # Create themed canvas with dark background
        self.canvas = Canvas(parent, width=width, height=height, bg='#0A1128', highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Tracking variables
        self.timelines = {}  # timeline_id -> details dict
        self.events = {}     # event_id -> details dict
        self.connections = []
        self.animations = []
        self.selected = None
        self.hover_text_id = None
        
        # Set up event bindings
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<Button-1>", self.on_click)
        
        # Animation variables
        self.is_animating = False
        self.animation_frame = 0
        
        # Create background effect
        self.create_background()

    def create_background(self):
        """Create animated quantum field background"""
        # Background grid
        grid_spacing = 40
        for x in range(0, self.width, grid_spacing):
            # Vertical lines
            alpha = max(30, min(120, 30 + (x / self.width) * 90))
            self.canvas.create_line(x, 0, x, self.height, 
                                   fill=f"#{int(alpha):02x}{int(alpha):02x}FF", 
                                   dash=(1, 3), width=0.5, tags="grid")
        
        for y in range(0, self.height, grid_spacing):
            # Horizontal lines
            alpha = max(30, min(120, 30 + (y / self.height) * 90))
            self.canvas.create_line(0, y, self.width, y, 
                                   fill=f"#{int(alpha):02x}{int(alpha):02x}FF", 
                                   dash=(1, 3), width=0.5, tags="grid")
        
        # Create some random "quantum particles"
        for _ in range(30):
            x = random.randint(10, self.width-10)
            y = random.randint(10, self.height-10)
            size = random.randint(2, 5)
            hue = random.random()  # Random color in HSV space
            r, g, b = colorsys.hsv_to_rgb(hue, 0.8, 0.9)
            color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
            
            self.canvas.create_oval(x-size, y-size, x+size, y+size,
                                  fill=color, outline="", tags="quantum_particle")
    
    def start_animation(self):
        """Start the animation loop"""
        if not self.is_animating:
            self.is_animating = True
            self.animate()
    
    def animate(self):
        """Animation loop"""
        if not self.is_animating:
            return
            
        self.animation_frame += 1
        
        # Animate quantum particles
        particles = self.canvas.find_withtag("quantum_particle")
        for particle in particles:
            # Subtle movement based on sine wave
            dx = math.sin(self.animation_frame * 0.05 + int(particle) * 0.3) * 0.5
            dy = math.cos(self.animation_frame * 0.05 + int(particle) * 0.7) * 0.5
            self.canvas.move(particle, dx, dy)
            
            # Occasionally change color
            if random.random() < 0.02:
                hue = random.random()
                r, g, b = colorsys.hsv_to_rgb(hue, 0.8, 0.9)
                color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
                self.canvas.itemconfig(particle, fill=color)
        
        # Animate timeline pulses
        for timeline_id, timeline in self.timelines.items():
            if timeline.get('pulse_objs'):
                for pulse_obj in timeline['pulse_objs']:
                    # Expand and fade pulse
                    coords = self.canvas.coords(pulse_obj)
                    if coords:
                        center_x = timeline['x']
                        center_y = timeline['y']
                        current_radius = (coords[2] - coords[0]) / 2
                        
                        # Expand radius
                        new_radius = current_radius + 0.5
                        
                        # Fade color
                        current_fill = self.canvas.itemcget(pulse_obj, "fill")
                        if current_fill.startswith('#') and len(current_fill) >= 7:
                            alpha = int(current_fill[7:9], 16) if len(current_fill) > 7 else 255
                            alpha = max(0, alpha - 5)
                            new_fill = current_fill[:7] + f"{alpha:02x}"
                            self.canvas.itemconfig(pulse_obj, fill=new_fill)
                        
                        # Update coordinates
                        self.canvas.coords(pulse_obj, 
                                          center_x - new_radius, center_y - new_radius,
                                          center_x + new_radius, center_y + new_radius)
                        
                        # Remove if completely faded
                        if alpha <= 10:
                            self.canvas.delete(pulse_obj)
                            timeline['pulse_objs'].remove(pulse_obj)
            
            # Occasionally add new pulse
            if random.random() < 0.01 * timeline.get('quantum_activity', 0.5):
                self.add_timeline_pulse(timeline_id)
        
        # Continue animation
        self.parent.after(30, self.animate)
    
    def add_timeline(self, timeline_id, name, stability, x=None, y=None, quantum_activity=0.5):
        """Add a timeline to the canvas with enhanced visuals"""
        if x is None:
            x = random.randint(100, self.width - 100)
        if y is None:
            y = random.randint(100, self.height - 100)
        
        # Timeline size based on importance
        base_radius = 35
        radius = base_radius + int(quantum_activity * 10)
        
        # Generate a more visually appealing color based on stability
        hue = 0.65 - (stability * 0.65)  # Blue (stable) to red (unstable)
        saturation = 0.7 + (0.3 * (1 - stability))  # More saturated if unstable
        value = 0.9
        r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)
        color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        
        # Inner glow effect
        glow_radius = radius * 1.2
        glow_color = f"{color}80"  # Add 50% transparency
        
        glow_id = self.canvas.create_oval(
            x - glow_radius, y - glow_radius, x + glow_radius, y + glow_radius,
            fill=glow_color, outline="", tags=f"timeline_glow_{timeline_id}"
        )
        
        # Main timeline circle with gradient effect
        obj_id = self.canvas.create_oval(
            x - radius, y - radius, x + radius, y + radius, 
            fill=color, outline="white", width=2, tags=f"timeline_{timeline_id}"
        )
        
        # Stability indicator (inner ring)
        inner_radius = radius * 0.7
        inner_r, inner_g, inner_b = colorsys.hsv_to_rgb(hue, saturation * 0.7, value * 1.2)
        inner_color = f"#{int(inner_r*255):02x}{int(inner_g*255):02x}{int(inner_b*255):02x}"
        
        inner_id = self.canvas.create_oval(
            x - inner_radius, y - inner_radius, x + inner_radius, y + inner_radius, 
            fill=inner_color, outline="", tags=f"timeline_inner_{timeline_id}"
        )
        
        # Add text label with glow effect
        text_shadow_id = self.canvas.create_text(
            x+2, y+2, text=name, fill="#00000080", 
            font=("Arial", 12, "bold"), tags=f"timeline_label_shadow_{timeline_id}"
        )
        
        label_id = self.canvas.create_text(
            x, y, text=name, fill="white", 
            font=("Arial", 12, "bold"), tags=f"timeline_label_{timeline_id}"
        )
        
        # Add stability indicator below
        stability_text = f"Stability: {stability:.2f}"
        stability_id = self.canvas.create_text(
            x, y + radius + 15, text=stability_text, fill="#AAAAAA", 
            font=("Arial", 9), tags=f"timeline_stability_{timeline_id}"
        )
        
        # Store timeline info
        self.timelines[timeline_id] = {
            'x': x, 'y': y, 'radius': radius, 'color': color, 
            'obj_id': obj_id, 'glow_id': glow_id, 'inner_id': inner_id,
            'label_id': label_id, 'label_shadow_id': text_shadow_id,
            'stability_id': stability_id, 'name': name, 'stability': stability,
            'quantum_activity': quantum_activity, 'events': [],
            'pulse_objs': []
        }
        
        # Add initial pulse
        self.add_timeline_pulse(timeline_id)
        
        # Ensure animation is running
        self.start_animation()
        
        return obj_id
    
    def add_timeline_pulse(self, timeline_id):
        """Add a pulse effect to a timeline"""
        if timeline_id not in self.timelines:
            return None
            
        timeline = self.timelines[timeline_id]
        x, y = timeline['x'], timeline['y']
        
        # Use timeline's color but with high transparency
        base_color = timeline['color']
        pulse_color = f"{base_color}90"  # 56% transparency
        
        # Start with radius slightly larger than timeline
        start_radius = timeline['radius'] * 1.1
        
        pulse_id = self.canvas.create_oval(
            x - start_radius, y - start_radius, 
            x + start_radius, y + start_radius,
            fill=pulse_color, outline="", tags=f"timeline_pulse_{timeline_id}"
        )
        
        if 'pulse_objs' not in timeline:
            timeline['pulse_objs'] = []
            
        timeline['pulse_objs'].append(pulse_id)
        return pulse_id
    
    def add_event(self, timeline_id, event_id, year, description, significance=0.5):
        """Add a timeline event with enhanced visual representation"""
        if timeline_id not in self.timelines:
            return None
            
        timeline = self.timelines[timeline_id]
        
        # Calculate position based on year and angle
        timeline_center_x = timeline['x']
        timeline_center_y = timeline['y']
        
        # Position events in chronological order around the timeline
        events_count = len(timeline['events'])
        angle = (events_count * (2 * math.pi / max(6, events_count + 1))) + random.uniform(-0.2, 0.2)
        
        # Distance from center is proportional to timeline radius
        distance = timeline['radius'] * 2.2
        
        x = timeline_center_x + distance * math.cos(angle)
        y = timeline_center_y + distance * math.sin(angle)
        
        # Event size based on significance
        size = 6 + int(significance * 8)
        
        # Generate a color based on event significance
        hue = (0.65 + significance * 0.3) % 1.0  # Color based on significance
        saturation = 0.7 + significance * 0.3
        value = 0.9
        r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)
        color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        
        # Glowing effect for the event
        glow_size = size * 1.5
        glow_color = f"{color}70"  # 44% transparency
        
        glow_id = self.canvas.create_oval(
            x - glow_size, y - glow_size, x + glow_size, y + glow_size,
            fill=glow_color, outline="", tags=f"event_glow_{event_id}"
        )
        
        # Main event marker
        obj_id = self.canvas.create_oval(
            x - size, y - size, x + size, y + size, 
            fill=color, outline="white", width=1, tags=f"event_{event_id}"
        )
        
        # Connect event to timeline with a line
        line_id = self.canvas.create_line(
            timeline_center_x, timeline_center_y, x, y,
            fill=f"{color}AA", width=1, dash=(3, 2), 
            tags=f"event_line_{event_id}"
        )
        
        # Event details
        year_id = self.canvas.create_text(
            x, y - size - 10, text=str(year),
            fill="white", font=("Arial", 9, "bold"),
            tags=f"event_year_{event_id}"
        )
        
        # Store event info
        self.events[event_id] = {
            'x': x, 'y': y, 'size': size, 'color': color,
            'obj_id': obj_id, 'glow_id': glow_id, 'line_id': line_id,
            'year_id': year_id, 'timeline_id': timeline_id,
            'year': year, 'description': description,
            'significance': significance
        }
        
        # Add to timeline's events
        timeline['events'].append(event_id)
        
        return obj_id
    
    def connect_timelines(self, from_id, to_id, strength=1.0, connection_type="standard"):
        """Connect two timelines with an enhanced visual connection"""
        if from_id not in self.timelines or to_id not in self.timelines:
            return None
            
        from_timeline = self.timelines[from_id]
        to_timeline = self.timelines[to_id]
        
        # Generate connection visuals based on type
        if connection_type == "quantum_entangled":
            base_color = "#FF00FF"  # Magenta for quantum entanglement
            line_width = 2
            dash_pattern = (5, 3)
            particles = True
        elif connection_type == "temporal_bridge":
            base_color = "#00FFFF"  # Cyan for temporal bridges
            line_width = 2
            dash_pattern = None
            particles = True
        elif connection_type == "unstable":
            base_color = "#FF6600"  # Orange for unstable connections
            line_width = 2
            dash_pattern = (8, 4, 2, 4)
            particles = False
        else:  # standard
            base_color = "#4080FF"  # Blue for normal connections
            line_width = 2
            dash_pattern = None
            particles = False
            
        # Adjust transparency based on strength
        alpha = int(min(255, max(40, strength * 255)))
        color = f"{base_color}{alpha:02x}"
        
        # Get positions
        x1, y1 = from_timeline['x'], from_timeline['y']
        x2, y2 = to_timeline['x'], to_timeline['y']
        
        # Calculate control points for curved line
        dist = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        mid_x = (x1 + x2) / 2
        mid_y = (y1 + y2) / 2
        
        # Add some randomness to the curve
        normal_x = (y2 - y1) / dist
        normal_y = -(x2 - x1) / dist
        
        curve_height = dist * 0.2
        ctrl_x = mid_x + normal_x * curve_height
        ctrl_y = mid_y + normal_y * curve_height
        
        # Create the connection line
        line_id = self.canvas.create_line(
            x1, y1, ctrl_x, ctrl_y, x2, y2,
            fill=color, width=line_width, dash=dash_pattern,
            smooth=True, splinesteps=24,
            tags=f"connection_{from_id}_{to_id}"
        )
        
        # Add particles along the connection if needed
        particle_ids = []
        if particles:
            particle_color = f"{base_color}CC"
            
            for i in range(5):
                # Position particles along the curve
                t = random.uniform(0.2, 0.8)  # Position along the curve
                
                # Quadratic Bezier curve formula
                px = (1-t)**2 * x1 + 2*(1-t)*t * ctrl_x + t**2 * x2
                py = (1-t)**2 * y1 + 2*(1-t)*t * ctrl_y + t**2 * y2
                
                size = random.uniform(2, 4)
                particle_id = self.canvas.create_oval(
                    px-size, py-size, px+size, py+size,
                    fill=particle_color, outline="",
                    tags=f"connection_particle_{from_id}_{to_id}"
                )
                particle_ids.append(particle_id)
        
        # Store the connection
        connection = {
            'from_id': from_id, 'to_id': to_id,
            'line_id': line_id, 'strength': strength,
            'type': connection_type, 'particle_ids': particle_ids,
            'color': base_color, 'particles': particles
        }
        self.connections.append(connection)
        
        return connection
    
    def on_mouse_move(self, event):
        """Handle mouse movement for hover effects"""
        # Clear previous hover text
        if self.hover_text_id:
            self.canvas.delete(self.hover_text_id)
            self.hover_text_id = None
            
        # Check for object under mouse
        items = self.canvas.find_overlapping(event.x-2, event.y-2, event.x+2, event.y+2)
        if not items:
            return
            
        # Check timelines first
        for item_id in items:
            tags = self.canvas.gettags(item_id)
            
            for tag in tags:
                # Timeline hover
                if tag.startswith("timeline_") and not tag.startswith("timeline_glow_") and not tag.startswith("timeline_label_"):
                    timeline_id = int(tag.split("_")[1])
                    if timeline_id in self.timelines:
                        timeline = self.timelines[timeline_id]
                        
                        # Show enhanced info box
                        info = (f"{timeline['name']}\n" + 
                               f"Stability: {timeline['stability']:.2f}\n" + 
                               f"Events: {len(timeline['events'])}")
                        
                        self.hover_text_id = self.create_info_box(
                            event.x, event.y - 15, info
                        )
                        return
                
                # Event hover
                elif tag.startswith("event_") and not tag.startswith("event_glow_") and not tag.startswith("event_line_"):
                    event_id = int(tag.split("_")[1])
                    if event_id in self.events:
                        event = self.events[event_id]
                        timeline = self.timelines.get(event['timeline_id'])
                        
                        # Show enhanced info box
                        if timeline:
                            info = (f"Year: {event['year']}\n" + 
                                   f"{event['description']}\n" + 
                                   f"Timeline: {timeline['name']}")
                        else:
                            info = (f"Year: {event['year']}\n" + 
                                   f"{event['description']}")
                            
                        self.hover_text_id = self.create_info_box(
                            event.x, event.y - 15, info
                        )
                        return
    
    def create_info_box(self, x, y, text):
        """Create an enhanced info box with background"""
        lines = text.count('\n') + 1
        padding = 5
        line_height = 14
        width = max(len(line) * 6 for line in text.split('\n'))
        height = lines * line_height
        
        # Background rectangle with rounded corners and gradient
        box_id = self.canvas.create_rectangle(
            x - width/2 - padding, y - height - padding,
            x + width/2 + padding, y + padding,
            fill="#10173080", outline="#4080FF", width=1,
            stipple="gray50"
        )
        
        # Info text with shadow for better readability
        shadow_id = self.canvas.create_text(
            x+1, y-height/2+1, text=text, fill="#00000080",
            font=("Arial", 9), width=width, justify="center"
        )
        
        text_id = self.canvas.create_text(
            x, y-height/2, text=text, fill="#FFFFFF",
            font=("Arial", 9), width=width, justify="center"
        )
        
        # Group all objects
        group_id = f"info_box_{box_id}"
        self.canvas.addtag_withtag(group_id, box_id)
        self.canvas.addtag_withtag(group_id, shadow_id)
        self.canvas.addtag_withtag(group_id, text_id)
        
        return group_id
    
    def on_click(self, event):
        """Handle mouse clicks for selection"""
        # Find closest items
        items = self.canvas.find_overlapping(event.x-2, event.y-2, event.x+2, event.y+2)
        if not items:
            # Deselect if clicking empty space
            if self.selected:
                self.clear_selection()
            return
            
        selected_item = None
        
        # Check for clickable items
        for item_id in items:
            tags = self.canvas.gettags(item_id)
            
            for tag in tags:
                # Timeline selection
                if tag.startswith("timeline_") and not tag.startswith("timeline_glow_") and not tag.startswith("timeline_label_"):
                    timeline_id = int(tag.split("_")[1])
                    if timeline_id in self.timelines:
                        selected_item = {
                            'type': 'timeline', 
                            'id': timeline_id
                        }
                        break
                        
                # Event selection
                elif tag.startswith("event_") and not tag.startswith("event_glow_") and not tag.startswith("event_line_"):
                    event_id = int(tag.split("_")[1])
                    if event_id in self.events:
                        selected_item = {
                            'type': 'event',
                            'id': event_id
                        }
                        break
            
            if selected_item:
                break
        
        # Update selection
        if selected_item:
            # Clear previous selection
            self.clear_selection()
            
            # Mark new selection
            if selected_item['type'] == 'timeline':
                timeline = self.timelines[selected_item['id']]
                # Highlight selected timeline
                self.canvas.itemconfig(timeline['obj_id'], width=3)
                # Make glow brighter
                self.canvas.itemconfig(timeline['glow_id'], fill=f"{timeline['color']}CC")
                
                # Highlight connected timelines
                for conn in self.connections:
                    if conn['from_id'] == selected_item['id'] or conn['to_id'] == selected_item['id']:
                        self.canvas.itemconfig(conn['line_id'], width=conn.get('width', 1) + 1)
                
            elif selected_item['type'] == 'event':
                event = self.events[selected_item['id']]
                # Highlight selected event
                self.canvas.itemconfig(event['obj_id'], width=2)
                # Make glow brighter
                self.canvas.itemconfig(event['glow_id'], fill=f"{event['color']}CC")
                # Highlight connection line
                self.canvas.itemconfig(event['line_id'], width=2)
            
            self.selected = selected_item
            
            # Trigger selection callback if defined
            if hasattr(self, 'on_selection_change'):
                self.on_selection_change(self.selected)
        else:
            # Clear selection if clicking on nothing
            self.clear_selection()
    
    def clear_selection(self):
        """Clear the current selection"""
        if not self.selected:
            return
            
        if self.selected['type'] == 'timeline':
            timeline = self.timelines[self.selected['id']]
            # Reset timeline appearance
            self.canvas.itemconfig(timeline['obj_id'], width=2)
            self.canvas.itemconfig(timeline['glow_id'], fill=f"{timeline['color']}80")
            
            # Reset connected timelines
            for conn in self.connections:
                if conn['from_id'] == self.selected['id'] or conn['to_id'] == self.selected['id']:
                    self.canvas.itemconfig(conn['line_id'], width=conn.get('width', 1))
                    
        elif self.selected['type'] == 'event':
            event = self.events[self.selected['id']]
            # Reset event appearance
            self.canvas.itemconfig(event['obj_id'], width=1)
            self.canvas.itemconfig(event['glow_id'], fill=f"{event['color']}70")
            self.canvas.itemconfig(event['line_id'], width=1)
        
        self.selected = None
        
        # Trigger selection callback if defined
        if hasattr(self, 'on_selection_change'):
            self.on_selection_change(None)
    
    def clear(self):
        """Clear all elements from the canvas"""
        self.canvas.delete("all")
        self.timelines = {}
        self.events = {}
        self.connections = []
        self.selected = None
        self.hover_text_id = None
        
        # Recreate background
        self.create_background()
