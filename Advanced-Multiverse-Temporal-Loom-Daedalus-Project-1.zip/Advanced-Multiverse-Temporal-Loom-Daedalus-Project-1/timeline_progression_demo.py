
"""
Timeline Progression Demonstration
Shows different timeline progression types and their evolution over time.
"""

import random
import time
import math
import numpy as np
import matplotlib.pyplot as plt
from typing import List, Dict, Tuple
from timeline_types import TimelineProgression, TimelineType, TypedTimeline

class TimelineProgressionDemo:
    """Demonstration of different timeline progression types"""
    
    def __init__(self):
        """Initialize the demo"""
        self.progressions = []
        self.timelines = []
        self.projection_data = {}
        
    def create_progressions(self):
        """Create different progression types for demonstration"""
        # Create one of each progression type
        for prog_type in TimelineProgression.ProgressionType:
            progression = TimelineProgression(
                progression_type=prog_type,
                rate=random.uniform(0.05, 0.2),
                stability=random.uniform(0.7, 0.9)
            )
            
            self.progressions.append(progression)
            
        return self.progressions
        
    def create_typed_timelines(self):
        """Create typed timelines with different progression types"""
        timeline_types = [
            TimelineType.STATIC,
            TimelineType.DYNAMIC,
            TimelineType.LOOPED,
            TimelineType.BRANCHING,
            TimelineType.QUANTUM
        ]
        
        for i, timeline_type in enumerate(timeline_types):
            # Create timeline with appropriate type
            timeline = TypedTimeline(
                name=f"{timeline_type.value.title()} Timeline",
                timeline_type=timeline_type,
                stability=random.uniform(0.7, 0.9)
            )
            
            # Add some events
            base_year = 2000
            timeline.add_event("Timeline origin point", base_year)
            timeline.add_event("Early development", base_year + 10)
            timeline.add_event("Key historical moment", base_year + 25)
            timeline.add_event("Technological breakthrough", base_year + 40)
            
            # Add type-specific events
            if timeline_type == TimelineType.LOOPED:
                timeline.add_event("Time loop discovery", base_year + 20)
                timeline.add_event("Temporal echo detected", base_year + 35)
            elif timeline_type == TimelineType.BRANCHING:
                timeline.add_event("Decision point", base_year + 15)
                timeline.add_event("Reality split observed", base_year + 30)
            elif timeline_type == TimelineType.QUANTUM:
                timeline.add_event("Quantum superposition begins", base_year + 15)
                timeline.add_event("Wave function fluctuation", base_year + 30)
                
            self.timelines.append(timeline)
            
        return self.timelines
        
    def project_progression(self, years: int = 100, data_points: int = 100):
        """
        Project progression changes over a number of years
        
        Args:
            years: Number of years to project
            data_points: Number of data points to record
        """
        self.projection_data = {}
        
        # Project each progression type
        for progression in self.progressions:
            # Reset progression
            progression.total_change = 0.0
            progression.last_update_time = time.time()
            
            # Storage for this progression's data
            prog_type = progression.progression_type.value
            self.projection_data[prog_type] = {
                'years': [],
                'change': [],
                'total_change': []
            }
            
            # Project forward in time
            step_size = years / data_points
            current_year = 0
            
            for i in range(data_points):
                # Update the progression
                result = progression.update(step_size)
                
                # Store the results
                current_year += step_size
                self.projection_data[prog_type]['years'].append(current_year)
                self.projection_data[prog_type]['change'].append(result['change'])
                self.projection_data[prog_type]['total_change'].append(result['total_change'])
                
        return self.projection_data
        
    def project_timeline_stability(self, years: int = 100, data_points: int = 100):
        """
        Project timeline stability changes over time
        
        Args:
            years: Number of years to project
            data_points: Number of data points to record
        """
        timeline_data = {}
        
        # Project each timeline
        for timeline in self.timelines:
            # Storage for this timeline's data
            timeline_type = timeline.timeline_type.value
            timeline_data[timeline_type] = {
                'years': [],
                'stability': [],
                'mutability': []
            }
            
            # Reset stability to starting value
            original_stability = timeline.stability
            timeline.stability = original_stability
            
            # Project forward in time
            step_size = years / data_points
            current_year = 0
            
            for i in range(data_points):
                # Update the timeline
                result = timeline.update(step_size)
                
                # Store the results
                current_year += step_size
                timeline_data[timeline_type]['years'].append(current_year)
                timeline_data[timeline_type]['stability'].append(timeline.stability)
                timeline_data[timeline_type]['mutability'].append(timeline.mutability)
                
        return timeline_data
        
    def create_progression_chart(self):
        """
        Create a chart showing different progression types over time
        """
        # Ensure we have data
        if not self.projection_data:
            self.create_progressions()
            self.project_progression()
            
        # Create the plot
        plt.figure(figsize=(12, 8))
        
        # Plot each progression type
        for prog_type, data in self.projection_data.items():
            plt.plot(data['years'], data['total_change'], label=prog_type.title())
            
        # Add labels and legend
        plt.title('Timeline Progression Types Over Time')
        plt.xlabel('Years')
        plt.ylabel('Total Change')
        plt.legend()
        plt.grid(True)
        
        # Save the plot
        plt.savefig('timeline_progression_types.png')
        print("Saved progression chart to 'timeline_progression_types.png'")
        
    def create_stability_chart(self, data):
        """
        Create a chart showing timeline stability over time
        
        Args:
            data: Timeline stability data to plot
        """
        # Create the plot
        plt.figure(figsize=(12, 8))
        
        # Plot each timeline type
        for timeline_type, timeline_data in data.items():
            plt.plot(timeline_data['years'], timeline_data['stability'], label=f"{timeline_type.title()} Stability")
            
        # Add labels and legend
        plt.title('Timeline Stability Over Time by Type')
        plt.xlabel('Years')
        plt.ylabel('Stability')
        plt.legend()
        plt.grid(True)
        
        # Save the plot
        plt.savefig('timeline_stability_types.png')
        print("Saved stability chart to 'timeline_stability_types.png'")
        
    def run_demonstration(self):
        """Run a full demonstration of timeline progression"""
        print("=== Timeline Progression Demonstration ===")
        
        # Create progression types
        print("\nCreating timeline progression types...")
        progressions = self.create_progressions()
        
        for progression in progressions:
            print(f"Created: {progression}")
            
        # Project progression over time
        print("\nProjecting progression changes over 100 years...")
        self.project_progression(100, 100)
        
        # Create typed timelines
        print("\nCreating various typed timelines...")
        timelines = self.create_typed_timelines()
        
        for timeline in timelines:
            print(f"Created: {timeline}")
            
        # Project timeline stability
        print("\nProjecting timeline stability over 100 years...")
        stability_data = self.project_timeline_stability(100, 100)
        
        # Show some specific projections
        print("\nProgression change after 100 years:")
        for prog_type, data in self.projection_data.items():
            total_change = data['total_change'][-1]
            print(f"  {prog_type.title()}: {total_change:.2f}")
            
        print("\nTimeline stability after 100 years:")
        for timeline_type, data in stability_data.items():
            final_stability = data['stability'][-1]
            print(f"  {timeline_type.title()}: {final_stability:.2f}")
            
        # Create charts
        try:
            import matplotlib.pyplot as plt
            print("\nCreating charts...")
            self.create_progression_chart()
            self.create_stability_chart(stability_data)
        except ImportError:
            print("\nMatplotlib not available - skipping chart creation")
            
        # Timeline predictions
        print("\nMaking timeline predictions:")
        for timeline in self.timelines:
            prediction = timeline.predict_future(50)
            print(f"\n{timeline.name} prediction (confidence: {prediction['confidence']:.2f}):")
            print(f"  Current stability: {prediction['current_stability']:.2f}")
            print(f"  Predicted stability: {prediction['predicted_stability']:.2f}")
            
        return {
            'progressions': self.progressions,
            'timelines': self.timelines,
            'progression_data': self.projection_data
        }

def run_demo():
    """Run the timeline progression demonstration"""
    demo = TimelineProgressionDemo()
    return demo.run_demonstration()

if __name__ == "__main__":
    run_demo()
