
#!/usr/bin/env python3
"""
Temporal Loom CAD Viewer
An interactive viewer for exploring CAD design documents for the Temporal Loom.
"""

import os
import sys
import time
import random
from typing import Dict, List, Any

from temporal_loom_cad_specs import TemporalLoomCADSpecs
from temporal_loom_blueprint_renderer import BlueprintRenderer

class TemporalLoomCADViewer:
    """Interactive viewer for Temporal Loom CAD documents"""
    
    def __init__(self, frame=None, width=800, height=600):
        """Initialize the CAD viewer"""
        self.cad_specs = TemporalLoomCADSpecs()
        self.blueprint_renderer = BlueprintRenderer()
        self.current_view = None
        self.history = []
        self.frame = frame
        
        # If we're in a tkinter frame, create a canvas for visualization
        if frame:
            import tkinter as tk
            self.canvas = tk.Canvas(frame, width=width, height=600, bg="#0A1128")
            self.canvas.pack(fill=tk.BOTH, expand=True)
    
    def clear_screen(self):
        """Clear the terminal screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def display_header(self):
        """Display the viewer header"""
        self.clear_screen()
        print("\n" + "=" * 80)
        print("TEMPORAL LOOM CAD DOCUMENT VIEWER".center(80))
        print("TVA ENGINEERING DIVISION".center(80))
        print("=" * 80 + "\n")
    
    def display_main_menu(self):
        """Display the main menu options"""
        self.display_header()
        print("Main Menu:")
        print("1. View Technical Specifications")
        print("2. View CAD Blueprints")
        print("3. View Component List")
        print("4. View Engineering Report")
        print("5. View Maintenance Schedule")
        print("6. View ASCII Overview")
        print("7. Exit Viewer")
        
        choice = input("\nEnter your choice (1-7): ")
        
        if choice == '1':
            self.view_technical_specs()
        elif choice == '2':
            self.view_blueprints_menu()
        elif choice == '3':
            self.view_component_list()
        elif choice == '4':
            self.view_engineering_report()
        elif choice == '5':
            self.view_maintenance_schedule()
        elif choice == '6':
            self.view_ascii_overview()
        elif choice == '7':
            print("\nExiting CAD Viewer. Thank you for using the Temporal Loom CAD Viewer.")
            sys.exit(0)
        else:
            print("\nInvalid choice. Please try again.")
            time.sleep(1)
            self.display_main_menu()
    
    def view_technical_specs(self):
        """Display technical specifications"""
        self.display_header()
        print("TEMPORAL LOOM TECHNICAL SPECIFICATIONS".center(80))
        print("-" * 80 + "\n")
        
        specs = self.cad_specs.get_full_specifications()
        
        print(f"Model: {specs['model_name']}")
        print(f"Version: {specs['version']}\n")
        
        print("Physical Dimensions:")
        for component, dims in specs['dimensions'].items():
            dim_str = ""
            for key, value in dims.items():
                if key != "unit":
                    dim_str += f"{key.capitalize()}: {value} {dims.get('unit', 'm')}, "
            print(f"  {component.replace('_', ' ').title()}: {dim_str[:-2]}")
        
        print("\nMaterials:")
        for component, material in specs['materials'].items():
            print(f"  {component.replace('_', ' ').title()}: {material}")
        
        print("\nOperational Specifications:")
        for spec, value in specs['operational_specs'].items():
            print(f"  {spec.replace('_', ' ').title()}: {value}")
        
        print("\nInterface Specifications:")
        for interface, details in specs['interfaces'].items():
            print(f"  {interface.replace('_', ' ').title()}:")
            for key, value in details.items():
                print(f"    {key.capitalize()}: {value}")
        
        self.wait_for_input()
    
    def view_blueprints_menu(self):
        """Display blueprint selection menu"""
        self.display_header()
        print("TEMPORAL LOOM CAD BLUEPRINTS".center(80))
        print("-" * 80 + "\n")
        
        blueprints = self.blueprint_renderer.list_available_blueprints()
        
        print("Available Blueprints:")
        for i, name in enumerate(blueprints, 1):
            print(f"{i}. {name.capitalize()} View")
        
        print("\n0. Return to Main Menu")
        
        try:
            choice = int(input("\nEnter your choice (0-7): "))
            
            if choice == 0:
                self.display_main_menu()
            elif 1 <= choice <= len(blueprints):
                blueprint_name = blueprints[choice - 1]
                self.view_blueprint(blueprint_name)
            else:
                print("\nInvalid choice. Please try again.")
                time.sleep(1)
                self.view_blueprints_menu()
        except ValueError:
            print("\nInvalid input. Please enter a number.")
            time.sleep(1)
            self.view_blueprints_menu()
    
    def view_blueprint(self, blueprint_name: str):
        """Display a specific blueprint"""
        self.display_header()
        
        metadata = self.blueprint_renderer.get_blueprint_metadata(blueprint_name)
        print(f"{metadata['title']}".center(80))
        print(f"DRAWING: {metadata['drawing_id']}  SCALE: {metadata['scale']}  REVISION: {metadata['revision']}".center(80))
        print("-" * 80 + "\n")
        
        blueprint = self.blueprint_renderer.render_blueprint(blueprint_name)
        print(blueprint)
        
        print("\nMetadata:")
        print(f"Date: {metadata['date']}")
        print(f"Engineer: {metadata['engineer']}")
        print(f"Material: {metadata['material']}")
        print(f"Classification: {metadata['classification']}")
        
        self.wait_for_input()
    
    def view_component_list(self):
        """Display component list"""
        self.display_header()
        print("TEMPORAL LOOM COMPONENT LIST".center(80))
        print("-" * 80 + "\n")
        
        components = self.cad_specs.generate_component_list()
        
        print(f"{'ID':<12} {'Name':<30} {'Quantity':<10} {'Material':<30}")
        print("-" * 82)
        
        for component in components:
            print(f"{component['id']:<12} {component['name']:<30} {component['quantity']:<10} {component['material'][:30]:<30}")
        
        print("\nTotal Components: " + str(len(components)))
        
        self.wait_for_input()
    
    def view_engineering_report(self):
        """Display engineering report"""
        self.display_header()
        print(self.cad_specs.display_engineering_report())
        self.wait_for_input()
    
    def view_maintenance_schedule(self):
        """Display maintenance schedule"""
        self.display_header()
        print("TEMPORAL LOOM MAINTENANCE SCHEDULE".center(80))
        print("-" * 80 + "\n")
        
        for period, tasks in self.cad_specs.maintenance_schedule.items():
            print(f"{period.upper()} MAINTENANCE TASKS:")
            for i, task in enumerate(tasks, 1):
                print(f"{i}. {task}")
            print()
        
        self.wait_for_input()
    
    def view_ascii_overview(self):
        """Display ASCII overview of the Temporal Loom"""
        self.display_header()
        print("TEMPORAL LOOM ASCII OVERVIEW".center(80))
        print("-" * 80 + "\n")
        
        print(self.cad_specs.display_specs_ascii())
        
        self.wait_for_input()
    
    def wait_for_input(self):
        """Wait for user input to continue"""
        print("\nPress Enter to return to the main menu...")
        input()
        self.display_main_menu()

def main():
    """Main function to run the CAD viewer"""
    viewer = TemporalLoomCADViewer()
    viewer.display_main_menu()

if __name__ == "__main__":
    main()
