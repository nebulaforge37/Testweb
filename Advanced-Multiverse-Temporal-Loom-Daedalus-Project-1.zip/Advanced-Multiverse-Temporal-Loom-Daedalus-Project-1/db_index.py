
"""
Database Index Module
This module provides database indexing functionality for the multiverse database.
"""

import time
import re
from enum import Enum
from typing import List, Dict, Tuple, Any, Optional, Union

class IndexType(Enum):
    """Types of database indexes"""
    BTREE = "B-Tree"
    HASH = "Hash"
    FULLTEXT = "Fulltext"
    SPATIAL = "Spatial"

class DatabaseIndex:
    """
    A class to represent a database index for improved query performance
    """
    
    def __init__(self, name: str, index_type: IndexType = IndexType.BTREE):
        """Initialize a database index"""
        self.name = name
        self.index_type = index_type
        self.entries: Dict[str, Any] = {}
        self.creation_time = time.time()
        self.access_count = 0
        self.last_accessed = None
        
        # For full-text search
        self.inverted_index: Dict[str, List[int]] = {}
        
        # For spatial index
        if index_type == IndexType.SPATIAL:
            try:
                from rtree import index
                p = index.Property()
                p.dimension = 3  # 3D space for x, y, z coordinates
                self.spatial_index = index.Index(properties=p)
            except ImportError:
                print("Warning: rtree not available. Spatial index will use fallback method.")
                self.spatial_index = None
    
    def add_entry(self, key: str, value: Any) -> bool:
        """
        Add an entry to the index
        
        Args:
            key: The key to index
            value: The value associated with the key
            
        Returns:
            bool: True if successful
        """
        if self.index_type == IndexType.FULLTEXT:
            return self._add_fulltext_entry(key, value)
        elif self.index_type == IndexType.SPATIAL:
            return self._add_spatial_entry(key, value)
        else:
            self.entries[key] = value
            
            # If it's a B-Tree index, we also add to inverted index for partial matches
            if self.index_type == IndexType.BTREE:
                words = self._tokenize(key)
                for word in words:
                    if word not in self.inverted_index:
                        self.inverted_index[word] = []
                    if value not in self.inverted_index[word]:
                        self.inverted_index[word].append(value)
            
            return True
    
    def _add_fulltext_entry(self, text: str, document_id: int) -> bool:
        """Add entry to fulltext index"""
        words = self._tokenize(text)
        for word in words:
            if word not in self.inverted_index:
                self.inverted_index[word] = []
            if document_id not in self.inverted_index[word]:
                self.inverted_index[word].append(document_id)
        return True
    
    def _add_spatial_entry(self, key: str, coordinates: Tuple[float, float, float]) -> bool:
        """Add entry to spatial index"""
        if self.spatial_index:
            # For rtree, we need a bounding box which is (minx, miny, minz, maxx, maxy, maxz)
            x, y, z = coordinates
            self.spatial_index.insert(hash(key), (x, y, z, x, y, z))
        
        # Always store in our basic dictionary too
        self.entries[key] = coordinates
        return True
    
    def _tokenize(self, text: str) -> List[str]:
        """Break text into tokens for indexing"""
        # Convert to lowercase and split on non-alphanumeric characters
        return [word.lower() for word in re.findall(r'\w+', text) if word]
    
    def get(self, key: str) -> Any:
        """Get a value by exact key match"""
        self.access_count += 1
        self.last_accessed = time.time()
        return self.entries.get(key)
    
    def search(self, query: str) -> List[Tuple[str, Any]]:
        """Search the index for matches"""
        self.access_count += 1
        self.last_accessed = time.time()
        
        if self.index_type == IndexType.FULLTEXT:
            return self._fulltext_search(query)
        elif self.index_type == IndexType.HASH:
            # For hash indexes, only exact matches
            if query in self.entries:
                return [(query, self.entries[query])]
            return []
        elif self.index_type == IndexType.SPATIAL:
            return self._spatial_search(query)
        else:
            # B-Tree allows partial matches
            results = []
            
            # Try exact match first
            if query in self.entries:
                results.append((query, self.entries[query]))
            
            # Try partial matches
            query_words = self._tokenize(query)
            for word in query_words:
                if word in self.inverted_index:
                    for value in self.inverted_index[word]:
                        # Find the original key(s) for this value
                        for k, v in self.entries.items():
                            if v == value and (k, v) not in results:
                                results.append((k, v))
            
            return results
    
    def _fulltext_search(self, query: str) -> List[Tuple[str, int]]:
        """Perform a fulltext search"""
        query_words = self._tokenize(query)
        if not query_words:
            return []
        
        # Start with the first word's document IDs
        if query_words[0] not in self.inverted_index:
            return []
            
        result_doc_ids = set(self.inverted_index[query_words[0]])
        
        # Intersect with other words' document IDs
        for word in query_words[1:]:
            if word not in self.inverted_index:
                result_doc_ids = set()
                break
            result_doc_ids &= set(self.inverted_index[word])
        
        # Find the original texts for these document IDs
        results = []
        for doc_id in result_doc_ids:
            # We need to find the original text, which is harder
            # In a real implementation, we'd have a reverse mapping
            # For this demo, we'll just add the ID
            results.append((f"Document #{doc_id}", doc_id))
        
        return results
    
    def _spatial_search(self, query: str) -> List[Tuple[str, Tuple[float, float, float]]]:
        """Perform a spatial search"""
        # In a real implementation, this would parse the query for coordinates
        # For this demo, we'll just do a basic search
        return [(k, v) for k, v in self.entries.items() if query.lower() in k.lower()]
    
    def bulk_add(self, entries: List[Tuple[str, Any]]) -> bool:
        """Add multiple entries at once"""
        for key, value in entries:
            self.add_entry(key, value)
        return True
    
    def remove(self, key: str) -> bool:
        """Remove an entry from the index"""
        if key in self.entries:
            # If it's a B-Tree, also clean up inverted index
            if self.index_type == IndexType.BTREE:
                value = self.entries[key]
                words = self._tokenize(key)
                for word in words:
                    if word in self.inverted_index and value in self.inverted_index[word]:
                        self.inverted_index[word].remove(value)
            
            del self.entries[key]
            return True
        return False
    
    def size(self) -> int:
        """Get the number of entries in the index"""
        return len(self.entries)
    
    def memory_usage(self) -> float:
        """Estimate memory usage in KB"""
        # This is a very rough estimation
        size_in_bytes = 0
        
        # Estimate entries dictionary
        for k, v in self.entries.items():
            size_in_bytes += len(k) * 2  # UTF-8 chars
            
            # Estimate value size based on type
            if isinstance(v, int):
                size_in_bytes += 8
            elif isinstance(v, float):
                size_in_bytes += 8
            elif isinstance(v, str):
                size_in_bytes += len(v) * 2
            elif isinstance(v, tuple) and len(v) == 3:
                size_in_bytes += 24  # 3 floats
        
        # Estimate inverted index
        for k, v_list in self.inverted_index.items():
            size_in_bytes += len(k) * 2  # UTF-8 chars
            size_in_bytes += len(v_list) * 8  # List of references
        
        return size_in_bytes / 1024  # Convert to KB
    
    def rebuild(self) -> bool:
        """Rebuild the index"""
        old_entries = self.entries.copy()
        self.entries = {}
        self.inverted_index = {}
        
        for key, value in old_entries.items():
            self.add_entry(key, value)
        
        return True
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about the index"""
        return {
            "name": self.name,
            "type": self.index_type.value,
            "size": self.size(),
            "creation_time": self.creation_time,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "memory_usage_kb": self.memory_usage()
        }
