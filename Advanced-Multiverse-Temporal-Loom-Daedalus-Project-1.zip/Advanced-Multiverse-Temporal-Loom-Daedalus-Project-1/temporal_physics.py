
"""
Temporal Physics Module
This module contains classes and utilities for advanced temporal physics including
specialized paradox types and time dilation effects.
"""

import math
import random
from typing import List, Dict, Optional, Tuple, Any, Union

class TemporalParadoxType:
    """Base class for temporal paradox types"""
    name: str
    description: str
    severity_modifier: float
    resolution_difficulty: float
    
    def __init__(self, name: str, description: str, severity_mod: float = 1.0, resolution_diff: float = 1.0):
        self.name = name
        self.description = description
        self.severity_modifier = severity_mod
        self.resolution_difficulty = resolution_diff
    
    def calculate_impact(self, timeline_stability: float) -> float:
        """Calculate the impact of this paradox on a timeline based on its stability"""
        base_impact = (1 - timeline_stability) * 0.5
        return base_impact * self.severity_modifier
    
    def calculate_resolution_chance(self, resolver_capability: float) -> float:
        """Calculate the chance of successfully resolving this paradox"""
        base_chance = resolver_capability * 0.7
        return max(0.1, min(0.9, base_chance / self.resolution_difficulty))
    
    def __str__(self) -> str:
        return f"{self.name}: {self.description}"


class BootstrapParadox(TemporalParadoxType):
    """
    Bootstrap Paradox: Information or object with no discernible origin because 
    it's caught in a time loop
    """
    def __init__(self):
        super().__init__(
            "Bootstrap Paradox",
            "Information or object with no discernible origin because it's caught in a time loop",
            severity_mod=1.2,
            resolution_diff=1.3
        )
    
    def specific_effects(self, timeline):
        """Apply specific effects of this paradox type to a timeline"""
        # Increase quantum field energy due to looping information
        energy_increase = random.uniform(0.1, 0.3)
        timeline.quantum_state.update_quantum_field(energy_increase)
        
        # Bootstrap paradoxes create temporal loops that can actually stabilize
        # a timeline slightly in some ways while destabilizing it in others
        timeline.worldline_integrity -= 0.1
        if random.random() < 0.3:
            timeline.stability += 0.05  # Occasionally provides stability


class GrandfatherParadox(TemporalParadoxType):
    """
    Grandfather Paradox: A causality violation where an effect prevents its own cause
    """
    def __init__(self):
        super().__init__(
            "Grandfather Paradox",
            "A causality violation where an effect prevents its own cause",
            severity_mod=1.8,
            resolution_diff=1.6
        )
    
    def specific_effects(self, timeline):
        """Apply specific effects of this paradox type to a timeline"""
        # Severe reduction in timeline stability
        timeline.stability = max(0.1, timeline.stability - 0.2)
        
        # Major worldline damage
        timeline.worldline_integrity = max(0.05, timeline.worldline_integrity - 0.25)
        
        # Often causes quantum wave function collapse
        if random.random() < 0.7:
            timeline.quantum_state.wave_function_collapse = True
            timeline.add_event("CRITICAL: Wave function collapse due to Grandfather Paradox", 
                              timeline.events[-1][0] if timeline.events else 2000)


class PredestinationParadox(TemporalParadoxType):
    """
    Predestination Paradox: Attempts to change past result in causing known events
    """
    def __init__(self):
        super().__init__(
            "Predestination Paradox",
            "Attempts to change the past result in causing the very events the time traveler tried to prevent",
            severity_mod=0.7,
            resolution_diff=0.8
        )
    
    def specific_effects(self, timeline):
        """Apply specific effects of this paradox type to a timeline"""
        # Predestination paradoxes actually reinforce causality
        timeline.worldline_integrity += 0.1
        
        # Slight stability increase as the timeline "protects itself"
        if random.random() < 0.6:
            timeline.stability = min(1.0, timeline.stability + 0.05)
            
        # However, can increase quantum entanglement as causality reinforces
        timeline.quantum_state.entanglement_level = min(1.0, 
                                                        timeline.quantum_state.entanglement_level + 0.15)


class ConsistencyParadox(TemporalParadoxType):
    """
    Consistency Paradox: Timeline modifications causing contradictions in reality
    """
    def __init__(self):
        super().__init__(
            "Consistency Paradox",
            "Timeline modifications causing contradictions in established reality",
            severity_mod=1.4,
            resolution_diff=1.2
        )
    
    def specific_effects(self, timeline):
        """Apply specific effects of this paradox type to a timeline"""
        # Reduces worldline integrity significantly
        timeline.worldline_integrity = max(0.2, timeline.worldline_integrity - 0.15)
        
        # Moderate stability reduction
        timeline.stability = max(0.2, timeline.stability - 0.1)
        
        # Can cause superposition as multiple contradictory states try to exist
        if random.random() < 0.4 and not timeline.quantum_state.superposition:
            timeline.quantum_state.enter_superposition()
            timeline.add_event("Timeline entered quantum superposition due to Consistency Paradox", 
                              timeline.events[-1][0] if timeline.events else 2000)


class TemporalDisplacementParadox(TemporalParadoxType):
    """
    Temporal Displacement Paradox: Objects or people existing in two places at once
    """
    def __init__(self):
        super().__init__(
            "Temporal Displacement Paradox",
            "Objects or people existing in two places at once due to time travel",
            severity_mod=1.1,
            resolution_diff=1.4
        )
    
    def specific_effects(self, timeline):
        """Apply specific effects of this paradox type to a timeline"""
        # Increases quantum field energy
        timeline.quantum_state.update_quantum_field(random.uniform(0.2, 0.4))
        
        # Can cause superposition
        if random.random() < 0.5 and not timeline.quantum_state.superposition:
            timeline.quantum_state.enter_superposition()
            
        # Moderate worldline damage
        timeline.worldline_integrity = max(0.3, timeline.worldline_integrity - 0.1)


class TimeDilation:
    """
    Class representing relativistic time dilation effects in temporal physics
    """
    def __init__(self, relative_velocity: float = 0.0, gravity_factor: float = 1.0):
        """
        Initialize time dilation with relative velocity (as fraction of c) and gravity factor
        
        Args:
            relative_velocity: Velocity relative to observer (0.0 to 0.99)
            gravity_factor: Gravitational time dilation (1.0 = Earth normal)
        """
        self.relative_velocity = max(0.0, min(0.99, relative_velocity))
        self.gravity_factor = max(0.1, gravity_factor)
        
    def calculate_velocity_dilation(self) -> float:
        """Calculate relativistic time dilation factor from velocity"""
        # γ = 1/√(1-v²/c²) where v is expressed as fraction of c
        if self.relative_velocity == 0:
            return 1.0
        return 1.0 / math.sqrt(1.0 - (self.relative_velocity ** 2))
    
    def calculate_gravity_dilation(self) -> float:
        """Calculate time dilation due to gravitational effects"""
        # Simplified model: stronger gravity = slower time
        return 1.0 / self.gravity_factor
    
    def calculate_total_dilation(self) -> float:
        """Calculate combined time dilation effect"""
        velocity_factor = self.calculate_velocity_dilation()
        gravity_factor = self.calculate_gravity_dilation()
        return velocity_factor * gravity_factor
    
    def apply_dilation_to_timespan(self, time_units: float) -> float:
        """Apply time dilation to a given timespan"""
        dilation = self.calculate_total_dilation()
        return time_units * dilation
    
    def __str__(self) -> str:
        velocity_dilation = self.calculate_velocity_dilation()
        gravity_dilation = self.calculate_gravity_dilation()
        total = self.calculate_total_dilation()
        
        return (f"Time Dilation - Velocity: {velocity_dilation:.2f}x " + 
                f"Gravity: {gravity_dilation:.2f}x Total: {total:.2f}x")


class InfiniteMonkeyParadox(TemporalParadoxType):
    """
    Infinite Monkey Theorem Paradox: Given enough time, random processes 
    could recreate any finite text, including a timeline's history
    """
    def __init__(self):
        super().__init__(
            "Infinite Monkey Theorem Paradox",
            "A paradox where random quantum fluctuations reproduce events perfectly, creating indistinguishable alternate timelines",
            severity_mod=1.5,
            resolution_diff=1.7
        )
        self.alphabet = "abcdefghijklmnopqrstuvwxyz "
        
    def specific_effects(self, timeline):
        """Apply specific effects of this paradox type to a timeline"""
        # Increases probabilistic anomalies
        if not hasattr(timeline.quantum_state, 'probabilistic_anomalies'):
            timeline.quantum_state.probabilistic_anomalies = 0
        
        timeline.quantum_state.probabilistic_anomalies += random.randint(1, 3)
        
        # Can cause major reality fluctuations
        timeline.stability = max(0.2, timeline.stability - random.uniform(0.05, 0.15))
        
        # Creates information paradoxes as authentic history becomes
        # indistinguishable from random recreations
        timeline.worldline_integrity = max(0.3, timeline.worldline_integrity - 0.1)
        
        # Add event describing the paradox
        event_year = timeline.events[-1][0] if timeline.events else 2000
        timeline.add_event(
            f"Infinite Monkey Theorem Paradox detected: reality fluctuations causing probabilistic duplications",
            event_year
        )
    
    def generate_random_text(self, length=100):
        """Generate random text as an example of the paradox in action"""
        return ''.join(random.choice(self.alphabet) for _ in range(length))
    
    def calculate_emergence_probability(self, target_text, word_length=5):
        """
        Calculate the probability of a specific text emerging randomly
        
        This demonstrates the infinite improbability at the heart of the paradox
        """
        # Probability of each character being correct
        p_char = 1 / len(self.alphabet)
        
        # Probability of the entire text matching
        # For n characters, it's (1/27)^n
        return p_char ** len(target_text)


class ParadoxRegistry:
    """Registry of all available temporal paradox types"""
    
    def __init__(self):
        self.paradox_types = {
            "bootstrap": BootstrapParadox(),
            "grandfather": GrandfatherParadox(),
            "predestination": PredestinationParadox(),
            "consistency": ConsistencyParadox(),
            "displacement": TemporalDisplacementParadox(),
            "infinite_monkey": InfiniteMonkeyParadox()
        }
    
    def get_paradox_by_name(self, name: str) -> Optional[TemporalParadoxType]:
        """Get a paradox type by its key name"""
        return self.paradox_types.get(name.lower())
    
    def get_random_paradox(self) -> TemporalParadoxType:
        """Get a random paradox type"""
        return random.choice(list(self.paradox_types.values()))
    
    def get_all_paradox_types(self) -> List[TemporalParadoxType]:
        """Get a list of all paradox types"""
        return list(self.paradox_types.values())
