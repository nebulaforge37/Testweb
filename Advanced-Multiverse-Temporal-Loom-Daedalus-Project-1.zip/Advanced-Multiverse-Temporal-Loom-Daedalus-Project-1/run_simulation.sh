
#!/bin/bash
# Multiverse Simulation System launcher script

# Print banner
echo "=================================="
echo "  Multiverse Simulation System    "
echo "=================================="
echo

# Check Python availability
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is required but not found."
    exit 1
fi

# Check for launch.py or app_launcher.py
if [ -f "launch.py" ]; then
    echo "Starting the simulation system..."
    python3 launch.py "$@"
elif [ -f "app_launcher.py" ]; then
    echo "Starting via app launcher..."
    python3 app_launcher.py "$@"
elif [ -f "app_system.py" ]; then
    echo "Starting via app system..."
    python3 app_system.py "$@"
elif [ -f "menu_system.py" ]; then
    echo "Starting via menu system..."
    python3 menu_system.py "$@"
else
    echo "Starting main simulation..."
    python3 main.py "$@"
fi
