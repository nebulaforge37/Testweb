
#!/usr/bin/env python3
"""
Quantum Dimensions and Alternate Realities Demo
This script demonstrates the quantum dimensions and alternate realities system.
"""

import random
import time
from quantum_dimensions import DimensionalRegistry, generate_dimension_name
from alternate_realities import RealityManager, RealityCoordinate

def run_quantum_demo():
    """Run a demonstration of the quantum dimensions and realities system"""
    print("=== Quantum Dimensions and Alternate Realities Demo ===")
    print("Initializing quantum dimensional registry...")
    
    # Create a registry and initialize dimensions
    registry = DimensionalRegistry()
    dimensions = registry.initialize_dimensions(count=30, max_id=10000)
    
    # Initialize reality manager with our registry
    reality_manager = RealityManager(registry)
    
    # Display some information about the dimensions
    print(f"\nInitialized {len(dimensions)} quantum dimensions:")
    for i, dimension in enumerate(dimensions[:5]):
        print(f"{i+1}. {dimension} - {dimension.physical_laws_description()}")
    print("...")  # Indicate more dimensions exist
    
    # Show some realities
    print("\nSample realities across dimensions:")
    sample_count = 0
    for dimension in dimensions[:3]:
        print(f"\nRealities in Dimension {dimension.dimension_id} ({dimension.name}):")
        for reality_id, reality in dimension.realities.items():
            print(f"  - {reality}")
            sample_count += 1
            if sample_count >= 8:
                break
        if sample_count >= 8:
            break
    
    # Find paths between dimensions
    print("\nFinding paths between dimensions:")
    # From the prime dimension to a random high-numbered dimension
    high_dim = max(d.dimension_id for d in dimensions)
    print(f"Path from Prime Dimension (1) to Dimension {high_dim}:")
    path = registry.find_path_between_dimensions(1, high_dim)
    if path:
        path_str = " → ".join(str(dim_id) for dim_id in path)
        print(f"Found path: {path_str}")
        
        # Get difficulty
        difficulty, reason = registry.calculate_dimensional_travel_difficulty(1, high_dim)
        print(f"Travel difficulty: {difficulty:.2f} - {reason}")
    else:
        print("No path found.")
    
    # Create some reality travelers
    print("\nRegistering reality travelers...")
    travelers = [
        reality_manager.register_traveler("Dr. Quantum", 1, 1),
        reality_manager.register_traveler("Reality Explorer Kai", 5, 2),
        reality_manager.register_traveler("Professor Dimensional", 10, 3)
    ]
    
    for traveler in travelers:
        print(f"- {traveler}")
    
    # Create some reality breaches
    print("\nCreating reality breaches...")
    for i in range(3):
        # Create random origin and destination
        origin_dim = random.choice(dimensions)
        dest_dim = random.choice([d for d in dimensions if d.dimension_id != origin_dim.dimension_id])
        
        origin_reality = random.choice(list(origin_dim.realities.values()))
        dest_reality = random.choice(list(dest_dim.realities.values()))
        
        origin_coord = RealityCoordinate.from_dimension(
            origin_dim.dimension_id, origin_reality.reality_id, 2030)
        dest_coord = RealityCoordinate.from_dimension(
            dest_dim.dimension_id, dest_reality.reality_id, 2030)
        
        stability = reality_manager.create_reality_breach(origin_coord, dest_coord)
        print(f"Breach {i+1}: {origin_coord} → {dest_coord} (Stability: {stability:.2f})")
    
    # Perform some reality travel
    print("\n=== Simulating Reality Travel ===")
    
    # Travel 1: Successful travel to a close dimension
    print("\nTravel 1: Dr. Quantum traveling to nearby dimension")
    event = reality_manager.perform_reality_travel("Dr. Quantum", 5, 1)
    print(event.generate_report())
    
    # Travel 2: Travel to a distant dimension (higher difficulty)
    print("\nTravel 2: Reality Explorer Kai traveling to distant dimension")
    event = reality_manager.perform_reality_travel("Reality Explorer Kai", high_dim, 3)
    print(event.generate_report())
    
    # Travel 3: Using a breach
    print("\nTravel 3: Professor Dimensional using a reality breach")
    # Find a breach where the professor is at the origin
    for breach_origin, breach_dest, _ in reality_manager.reality_breach_points:
        if breach_origin.dimension_id == 10 and breach_origin.reality_id == 3:
            # Set the destination based on the breach
            dest_dim = breach_dest.dimension_id
            dest_reality = breach_dest.reality_id
            
            # Perform the travel using the breach
            event = reality_manager.perform_reality_travel(
                "Professor Dimensional", dest_dim, dest_reality, use_breach=True)
            print(event.generate_report())
            break
    else:
        # No suitable breach found, create one for demo purposes
        dr_dim = 10
        dr_reality = 3
        dest_dim = 1
        dest_reality = 1
        
        origin_coord = RealityCoordinate.from_dimension(dr_dim, dr_reality, 2030)
        dest_coord = RealityCoordinate.from_dimension(dest_dim, dest_reality, 2030)
        
        reality_manager.create_reality_breach(origin_coord, dest_coord, 0.9)
        print("Creating emergency breach for demonstration...")
        
        event = reality_manager.perform_reality_travel(
            "Professor Dimensional", dest_dim, dest_reality, use_breach=True)
        print(event.generate_report())
    
    # Find nearby realities
    print("\n=== Finding Nearby Realities ===")
    
    # Get the current location of Dr. Quantum
    dr_quantum = reality_manager.travelers["Dr. Quantum"]
    dr_dim = dr_quantum.current_dimension_id
    dr_reality = dr_quantum.current_reality_id
    
    nearby = reality_manager.find_nearby_realities(dr_dim, dr_reality, 5)
    
    print(f"Realities near Dr. Quantum's location (D{dr_dim}:R{dr_reality}):")
    for reality, compatibility in nearby:
        print(f"- {reality} (Compatibility: {compatibility:.2f})")
    
    # Multiple sequential travels for one traveler
    print("\n=== Sequential Reality Travel ===")
    traveler_name = "Reality Explorer Kai"
    
    # Create a sequence of 5 random destinations
    destinations = []
    for _ in range(5):
        dim = random.choice(dimensions)
        # Get a random reality from this dimension
        if dim.realities:
            reality = random.choice(list(dim.realities.values()))
            destinations.append((dim.dimension_id, reality.reality_id))
    
    print(f"Sequential travel for {traveler_name}:")
    for i, (dim_id, reality_id) in enumerate(destinations, 1):
        print(f"\nJump {i}: To Dimension {dim_id}, Reality {reality_id}")
        event = reality_manager.perform_reality_travel(traveler_name, dim_id, reality_id)
        
        # Just show success/failure and side effects for brevity
        if event.success:
            print(f"Travel successful")
            if event.side_effects:
                print("Side effects:")
                for effect in event.side_effects:
                    print(f"  - {effect}")
        else:
            print(f"Travel failed: {event.side_effects[0] if event.side_effects else 'Unknown error'}")
            break
    
    # Generate overall report
    print("\n=== Reality System Status Report ===")
    print(reality_manager.generate_reality_report())
    
    print("\nQuantum dimensions and realities demo completed!")

if __name__ == "__main__":
    run_quantum_demo()
