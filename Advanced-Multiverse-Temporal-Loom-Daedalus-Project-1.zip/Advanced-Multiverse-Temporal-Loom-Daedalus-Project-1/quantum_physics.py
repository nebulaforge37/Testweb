
"""
Quantum Physics Module
This module extends the quantum dimensions system with quantum fusion concepts
and fundamental quantum mechanics principles.
"""

import random
import math
from typing import Dict, List, Tuple, Optional, Any, Set
from quantum_dimensions import QuantumDimension, QuantumReality, DimensionalRegistry

class QuantumFusionType:
    """Represents different types of quantum fusion processes"""
    
    def __init__(self, name: str, description: str, energy_output: float, stability: float):
        """
        Initialize a quantum fusion type
        
        Args:
            name: Name of the fusion process
            description: Description of how it works
            energy_output: Relative energy output (0.0-10.0)
            stability: How stable the process is (0.0-1.0)
        """
        self.name = name
        self.description = description
        self.energy_output = energy_output
        self.stability = stability
        
    def calculate_quantum_effect(self, dimension: QuantumDimension) -> float:
        """Calculate how effective this fusion is in a given quantum dimension"""
        # Factors that affect fusion in different dimensions
        dimension_factor = min(1.5, dimension.energy_density)
        stability_factor = dimension.stability * 0.8 + 0.2  # Allow some fusion even in unstable dimensions
        
        # Higher dimensional spaces can enable more efficient fusion
        spatial_bonus = 1.0 + (max(0, dimension.spacial_dimensions - 3) * 0.1)
        
        return self.energy_output * dimension_factor * stability_factor * spatial_bonus
    
    def __str__(self) -> str:
        return f"{self.name}: {self.description} (Energy: {self.energy_output:.1f}, Stability: {self.stability:.2f})"


class QuantumFusionRegistry:
    """Registry of quantum fusion types"""
    
    def __init__(self):
        """Initialize the quantum fusion registry with predefined fusion types"""
        self.fusion_types = {
            "artificial": QuantumFusionType(
                "Artificial Quantum Fusion", 
                "Engineered fusion process harnessing quantum tunneling for barrier penetration",
                energy_output=5.0,
                stability=0.7
            ),
            "thermonuclear": QuantumFusionType(
                "Thermonuclear Quantum Fusion",
                "High-temperature fusion enhanced by quantum field manipulation",
                energy_output=8.0,
                stability=0.5
            ),
            "beam": QuantumFusionType(
                "Beam–Beam Quantum Fusion",
                "Directed energy beams colliding in quantum-aligned trajectories",
                energy_output=6.5,
                stability=0.65
            ),
            "muon": QuantumFusionType(
                "Muon-Catalyzed Quantum Fusion",
                "Using muon particles to bring nuclei close enough for quantum tunneling",
                energy_output=4.0,
                stability=0.85
            ),
            "dimensional": QuantumFusionType(
                "Dimensional Boundary Fusion",
                "Fusion occurring at the boundaries between quantum dimensions",
                energy_output=9.5,
                stability=0.3
            )
        }
    
    def get_fusion_type(self, type_name: str) -> Optional[QuantumFusionType]:
        """Get a fusion type by name"""
        return self.fusion_types.get(type_name.lower())
    
    def get_all_fusion_types(self) -> List[QuantumFusionType]:
        """Get all fusion types"""
        return list(self.fusion_types.values())
    
    def get_most_efficient_fusion(self, dimension: QuantumDimension) -> Tuple[QuantumFusionType, float]:
        """Find the most efficient fusion type for a given dimension"""
        best_type = None
        best_efficiency = 0.0
        
        for fusion_type in self.fusion_types.values():
            efficiency = fusion_type.calculate_quantum_effect(dimension)
            if efficiency > best_efficiency:
                best_efficiency = efficiency
                best_type = fusion_type
                
        return best_type, best_efficiency


class QuantumMechanicsPrinciple:
    """Represents a fundamental principle of quantum mechanics"""
    
    def __init__(self, name: str, description: str, effect_on_reality: float):
        """
        Initialize a quantum mechanics principle
        
        Args:
            name: Name of the principle
            description: Description of how it works
            effect_on_reality: How strongly it affects reality (0.0-1.0)
        """
        self.name = name
        self.description = description
        self.effect_on_reality = effect_on_reality
        
    def apply_to_reality(self, reality: QuantumReality) -> List[str]:
        """
        Apply this quantum principle to a reality and return effects
        
        Returns:
            List of effect descriptions
        """
        effects = []
        effect_strength = self.effect_on_reality * random.uniform(0.7, 1.3)
        
        # Each principle has different effects on reality
        if self.name == "Quantization":
            # Quantization can make reality more discrete/digital
            reality.consistency = min(1.0, reality.consistency + 0.1 * effect_strength)
            effects.append(f"Reality consistency increased to {reality.consistency:.2f}")
            
        elif self.name == "Quantum Entanglement":
            # Entanglement can connect this reality to others
            connector_effect = effect_strength * 0.2
            reality.add_event(f"Quantum entanglement with other realities increased by {connector_effect:.2f}")
            effects.append(f"Reality now more strongly connected to other quantum states")
            
        elif self.name == "Uncertainty Principle":
            # Uncertainty makes reality less deterministic
            reality.consistency = max(0.1, reality.consistency - 0.15 * effect_strength)
            effects.append(f"Reality consistency decreased to {reality.consistency:.2f}")
            effects.append("Causality patterns have become less predictable")
            
        elif self.name == "Wave-Particle Duality":
            # Duality can cause reality to exhibit wave-like properties
            if random.random() < effect_strength * 0.5:
                reality.add_event("Reality exhibiting wave-like temporal oscillations")
                effects.append("Time flow now exhibits wavelike properties")
                
        return effects
    
    def __str__(self) -> str:
        return f"{self.name}: {self.description} (Reality Effect: {self.effect_on_reality:.2f})"


class QuantumMechanicsRegistry:
    """Registry of quantum mechanics principles"""
    
    def __init__(self):
        """Initialize the quantum mechanics registry with the four fundamental principles"""
        self.principles = {
            "quantization": QuantumMechanicsPrinciple(
                "Quantization", 
                "Physical properties taking discrete values rather than continuous",
                effect_on_reality=0.7
            ),
            "entanglement": QuantumMechanicsPrinciple(
                "Quantum Entanglement",
                "Quantum states of multiple particles are interdependent regardless of distance",
                effect_on_reality=0.85
            ),
            "uncertainty": QuantumMechanicsPrinciple(
                "Uncertainty Principle",
                "Impossibility of precisely knowing both position and momentum simultaneously",
                effect_on_reality=0.8
            ),
            "duality": QuantumMechanicsPrinciple(
                "Wave-Particle Duality",
                "Particles exhibiting both wave-like and particle-like properties",
                effect_on_reality=0.75
            )
        }
    
    def get_principle(self, principle_name: str) -> Optional[QuantumMechanicsPrinciple]:
        """Get a principle by name"""
        return self.principles.get(principle_name.lower())
    
    def get_all_principles(self) -> List[QuantumMechanicsPrinciple]:
        """Get all quantum principles"""
        return list(self.principles.values())
    
    def apply_all_principles(self, reality: QuantumReality) -> Dict[str, List[str]]:
        """Apply all quantum principles to a reality and return all effects"""
        effects = {}
        for name, principle in self.principles.items():
            principle_effects = principle.apply_to_reality(reality)
            effects[name] = principle_effects
        return effects


class QuantumFusionReactor:
    """Simulates a quantum fusion reactor that works across dimensions"""
    
    def __init__(self, name: str, base_dimension_id: int, 
                base_power: float = 1.0, stability: float = 0.7):
        """
        Initialize a quantum fusion reactor
        
        Args:
            name: Name of this reactor
            base_dimension_id: The dimension where the reactor is anchored
            base_power: Base power output capacity (1.0 = standard)
            stability: How stable the reactor is (0.0-1.0)
        """
        self.name = name
        self.base_dimension_id = base_dimension_id
        self.base_power = base_power
        self.stability = stability
        self.active_fusion_type = None
        self.efficiency = 0.0
        self.connected_dimensions = set()
        self.operation_log = []
        
    def connect_dimension(self, dimension_id: int, connection_strength: float = 0.5):
        """Connect this reactor to another dimension"""
        self.connected_dimensions.add((dimension_id, connection_strength))
        self.operation_log.append(f"Connected to dimension {dimension_id} (strength: {connection_strength:.2f})")
        
    def activate_fusion(self, fusion_registry: QuantumFusionRegistry, 
                      dimensional_registry: DimensionalRegistry,
                      fusion_type_name: str) -> bool:
        """
        Activate fusion using a specific type
        
        Returns:
            Success (True) or failure (False)
        """
        # Get the fusion type
        fusion_type = fusion_registry.get_fusion_type(fusion_type_name)
        if not fusion_type:
            self.operation_log.append(f"ERROR: Unknown fusion type '{fusion_type_name}'")
            return False
            
        # Get the base dimension
        base_dimension = dimensional_registry.get_dimension(self.base_dimension_id)
        if not base_dimension:
            self.operation_log.append(f"ERROR: Base dimension {self.base_dimension_id} not found")
            return False
            
        # Calculate base efficiency
        self.efficiency = fusion_type.calculate_quantum_effect(base_dimension) * self.stability
        
        # Factor in connected dimensions
        dimension_boost = 0.0
        for dim_id, connection_strength in self.connected_dimensions:
            dimension = dimensional_registry.get_dimension(dim_id)
            if dimension:
                # Connected dimensions can provide additional energy
                dimension_effect = fusion_type.calculate_quantum_effect(dimension) * connection_strength * 0.3
                dimension_boost += dimension_effect
                
        # Apply the boost (up to 50% additional efficiency)
        self.efficiency += min(self.efficiency * 0.5, dimension_boost)
        
        # Record the activation
        self.active_fusion_type = fusion_type
        self.operation_log.append(
            f"Activated {fusion_type.name} with efficiency {self.efficiency:.2f}")
        
        # Success depends on stability and process stability
        success_chance = self.stability * fusion_type.stability
        success = random.random() < success_chance
        
        if not success:
            self.operation_log.append(f"ALERT: Fusion activation failed!")
            self.active_fusion_type = None
            self.efficiency = 0.0
            
        return success
    
    def calculate_power_output(self) -> float:
        """Calculate the current power output"""
        if not self.active_fusion_type:
            return 0.0
            
        return self.base_power * self.active_fusion_type.energy_output * self.efficiency
    
    def get_status_report(self) -> str:
        """Get a status report of the reactor"""
        status = [f"=== {self.name} Quantum Fusion Reactor Status ==="]
        
        if self.active_fusion_type:
            power = self.calculate_power_output()
            status.append(f"Status: ACTIVE - {self.active_fusion_type.name}")
            status.append(f"Power Output: {power:.2f} units")
            status.append(f"Efficiency: {self.efficiency:.2f}")
            status.append(f"Stability: {self.stability:.2f}")
        else:
            status.append("Status: INACTIVE")
            status.append(f"Stability: {self.stability:.2f}")
            
        status.append(f"Base Dimension: {self.base_dimension_id}")
        status.append(f"Connected Dimensions: {len(self.connected_dimensions)}")
        
        # Add recent log entries
        if self.operation_log:
            status.append("\nRecent Operations:")
            for log in self.operation_log[-5:]:
                status.append(f"- {log}")
                
        return "\n".join(status)
    
    def __str__(self) -> str:
        if self.active_fusion_type:
            return f"{self.name}: ACTIVE - {self.calculate_power_output():.1f} units"
        else:
            return f"{self.name}: INACTIVE"


def run_fusion_demo(dimensional_registry: DimensionalRegistry = None):
    """Run a demonstration of quantum fusion and mechanics concepts"""
    print("=== Quantum Fusion and Mechanics Demonstration ===")
    
    # Initialize registries
    fusion_registry = QuantumFusionRegistry()
    mechanics_registry = QuantumMechanicsRegistry()
    
    # Create dimensional registry if not provided
    if not dimensional_registry:
        dimensional_registry = DimensionalRegistry()
        dimensions = dimensional_registry.initialize_dimensions(count=10)
    else:
        dimensions = list(dimensional_registry.dimensions.values())
    
    # Show available fusion types
    print("\nAvailable Quantum Fusion Types:")
    for fusion_type in fusion_registry.get_all_fusion_types():
        print(f"- {fusion_type}")
    
    # Show quantum mechanics principles
    print("\nFundamental Quantum Mechanics Principles:")
    for principle in mechanics_registry.get_all_principles():
        print(f"- {principle}")
    
    # Create a quantum fusion reactor
    print("\nCreating Quantum Fusion Reactor...")
    # Use the first dimension as the base
    base_dimension = dimensions[0]
    reactor = QuantumFusionReactor(
        "Nexus Prime", base_dimension.dimension_id, 2.0, 0.8)
    
    # Connect to a few random dimensions
    for _ in range(3):
        dimension = random.choice(dimensions)
        if dimension.dimension_id != base_dimension.dimension_id:
            connection_strength = random.uniform(0.3, 0.9)
            reactor.connect_dimension(dimension.dimension_id, connection_strength)
            print(f"Connected reactor to dimension {dimension.dimension_id} ({dimension.name})")
    
    # Try different fusion types
    print("\n=== Testing Different Fusion Types ===")
    fusion_types = ["artificial", "thermonuclear", "beam", "muon", "dimensional"]
    
    for fusion_type in fusion_types:
        print(f"\nTesting {fusion_type} fusion...")
        success = reactor.activate_fusion(fusion_registry, dimensional_registry, fusion_type)
        
        if success:
            print(f"Success! Power output: {reactor.calculate_power_output():.2f} units")
        else:
            print("Activation failed.")
            
        # Show reactor status
        print("\n" + reactor.get_status_report())
    
    # Apply quantum principles to a reality
    print("\n=== Applying Quantum Principles to Realities ===")
    if dimensional_registry.realities:
        # Pick a random reality
        reality = random.choice(list(dimensional_registry.realities.values()))
        print(f"Selected reality: {reality}")
        
        # Apply all principles
        effects = mechanics_registry.apply_all_principles(reality)
        
        # Show effects
        for principle, principle_effects in effects.items():
            if principle_effects:
                print(f"\nEffects of {principle.capitalize()}:")
                for effect in principle_effects:
                    print(f"- {effect}")
    
    # Find the most efficient fusion type for each dimension
    print("\n=== Most Efficient Fusion Type by Dimension ===")
    for i, dimension in enumerate(dimensions[:5]):  # Show first 5 dimensions
        best_type, efficiency = fusion_registry.get_most_efficient_fusion(dimension)
        print(f"Dimension {dimension.dimension_id} ({dimension.name}):")
        print(f"  Best fusion type: {best_type.name}")
        print(f"  Efficiency: {efficiency:.2f}")
    
    print("\nQuantum fusion and mechanics demonstration completed!")


if __name__ == "__main__":
    run_fusion_demo()
"""
Quantum Physics Module
This module provides quantum physics functionality and fusion reactor management
for the multiverse simulator.
"""

import random
import math
from typing import List, Dict, Tuple, Optional

class FusionType:
    """Represents a type of quantum fusion process"""
    
    def __init__(self, name: str, energy_output: float, stability: float, description: str):
        self.name = name
        self.energy_output = energy_output  # Relative energy output (0-10)
        self.stability = stability          # Stability factor (0-1)
        self.description = description
        self.quantum_resonance = random.uniform(0.5, 1.0)
        
    def calculate_efficiency(self, quantum_field_strength: float) -> float:
        """Calculate the efficiency of this fusion type under given quantum field conditions"""
        base_efficiency = self.energy_output * self.stability
        field_factor = 1.0 + (quantum_field_strength - 0.5) * 0.5
        resonance_factor = 1.0 + (self.quantum_resonance - 0.5) * 0.3
        
        return base_efficiency * field_factor * resonance_factor
    
    def __str__(self) -> str:
        stability_desc = "High" if self.stability > 0.8 else "Medium" if self.stability > 0.5 else "Low"
        return f"{self.name} (Energy: {self.energy_output:.1f}, Stability: {stability_desc})"


class FusionReactorSystem:
    """Manages fusion reactors and their operations"""
    
    def __init__(self):
        self.fusion_types: Dict[str, FusionType] = {}
        self.active_reactors: Dict[str, Dict] = {}
        self.initialize_fusion_types()
        
    def initialize_fusion_types(self):
        """Initialize standard fusion reaction types"""
        fusion_types = [
            FusionType("Deuterium-Tritium", 8.7, 0.76, 
                      "Standard fusion reaction used in most conventional reactors"),
            FusionType("Deuterium-Deuterium", 6.2, 0.83, 
                      "More difficult to initiate but requires only deuterium fuel"),
            FusionType("Helium-3 Aneutronic", 7.5, 0.65, 
                      "Produces fewer neutrons, reducing radiation and material damage"),
            FusionType("Proton-Boron", 5.3, 0.58, 
                      "Truly aneutronic but requires extreme temperatures"),
            FusionType("Quantum Catalyzed D-T", 9.4, 0.72, 
                      "D-T fusion enhanced with quantum field catalysts"),
            FusionType("Muon-Catalyzed", 7.0, 0.68, 
                      "Uses muons to shield the repulsive force between nuclei"),
            FusionType("Dimensional Resonance", 9.8, 0.45, 
                      "Utilizes quantum resonance between dimensions, highly unstable"),
            FusionType("Quantum Entangled D-D", 8.3, 0.52, 
                      "Entangles deuterium nuclei to enhance fusion probability")
        ]
        
        for fusion_type in fusion_types:
            self.fusion_types[fusion_type.name] = fusion_type
            
    def create_reactor(self, name: str, fusion_type_name: str, size: float = 1.0) -> bool:
        """Create a new fusion reactor"""
        if name in self.active_reactors:
            return False
            
        if fusion_type_name not in self.fusion_types:
            return False
            
        fusion_type = self.fusion_types[fusion_type_name]
        
        # Initialize reactor properties
        reactor = {
            "name": name,
            "fusion_type": fusion_type_name,
            "size": size,
            "temperature": 0.0,  # Kelvin / 10^7
            "containment_field": fusion_type.stability,
            "status": "offline",
            "efficiency": 0.0,
            "energy_output": 0.0,
            "runtime": 0,
            "quantum_field_strength": random.uniform(0.4, 0.7),
            "maintenance_required": False
        }
        
        self.active_reactors[name] = reactor
        return True
        
    def start_reactor(self, name: str) -> Tuple[bool, str]:
        """Start a fusion reactor"""
        if name not in self.active_reactors:
            return (False, "Reactor not found")
            
        reactor = self.active_reactors[name]
        
        if reactor["status"] != "offline":
            return (False, f"Reactor is already {reactor['status']}")
            
        # Start the reactor
        reactor["status"] = "starting"
        fusion_type = self.fusion_types[reactor["fusion_type"]]
        
        # Calculate initial temperature based on fusion type
        base_temp = 1.5 + fusion_type.energy_output * 0.1
        reactor["temperature"] = base_temp
        
        # Update efficiency and energy output
        self._update_reactor_metrics(reactor)
        
        reactor["status"] = "online"
        return (True, f"Reactor {name} started successfully")
        
    def shutdown_reactor(self, name: str) -> Tuple[bool, str]:
        """Shutdown a fusion reactor"""
        if name not in self.active_reactors:
            return (False, "Reactor not found")
            
        reactor = self.active_reactors[name]
        
        if reactor["status"] == "offline":
            return (False, "Reactor is already offline")
            
        # Emergency shutdown if containment is failing
        emergency = reactor["containment_field"] < 0.3
        
        if emergency:
            reactor["status"] = "emergency shutdown"
            message = f"Emergency shutdown of reactor {name} initiated!"
        else:
            reactor["status"] = "shutting down"
            message = f"Controlled shutdown of reactor {name} initiated"
        
        # Cool down the reactor
        reactor["temperature"] = max(0.1, reactor["temperature"] * 0.3)
        
        # Update metrics
        self._update_reactor_metrics(reactor)
        
        reactor["status"] = "offline"
        return (True, message)
        
    def _update_reactor_metrics(self, reactor):
        """Update reactor efficiency and output metrics"""
        fusion_type = self.fusion_types[reactor["fusion_type"]]
        
        # Calculate base efficiency
        base_efficiency = fusion_type.calculate_efficiency(reactor["quantum_field_strength"])
        
        # Adjust for temperature and containment
        temp_factor = min(1.0, reactor["temperature"] / 2.0)
        containment_factor = reactor["containment_field"]
        
        # Calculate final efficiency
        reactor["efficiency"] = base_efficiency * temp_factor * containment_factor
        
        # Calculate energy output
        size_factor = reactor["size"] ** 0.7  # Not linear with size
        reactor["energy_output"] = reactor["efficiency"] * size_factor * 100  # Arbitrary units
        
    def run_maintenance(self, name: str) -> Tuple[bool, str]:
        """Perform maintenance on a reactor"""
        if name not in self.active_reactors:
            return (False, "Reactor not found")
            
        reactor = self.active_reactors[name]
        
        if reactor["status"] != "offline":
            return (False, "Reactor must be offline for maintenance")
            
        # Improve containment field
        reactor["containment_field"] = min(0.95, reactor["containment_field"] + random.uniform(0.1, 0.2))
        
        # Reset maintenance flag
        reactor["maintenance_required"] = False
        
        return (True, f"Maintenance completed on reactor {name}. Containment field improved.")
        
    def update_reactors(self, time_units: int = 1):
        """Update all active reactors, simulating the passage of time"""
        for name, reactor in self.active_reactors.items():
            if reactor["status"] == "online":
                # Update runtime
                reactor["runtime"] += time_units
                
                # Random containment field degradation
                field_change = random.uniform(-0.05, 0.02) * time_units
                reactor["containment_field"] = max(0.1, min(1.0, reactor["containment_field"] + field_change))
                
                # Chance of needing maintenance increases with runtime
                maintenance_chance = min(0.5, reactor["runtime"] / 100) * time_units
                if random.random() < maintenance_chance:
                    reactor["maintenance_required"] = True
                
                # Small random fluctuations in quantum field strength
                field_fluctuation = random.uniform(-0.05, 0.05) * time_units
                reactor["quantum_field_strength"] = max(0.1, min(0.9, 
                                                             reactor["quantum_field_strength"] + field_fluctuation))
                
                # Update metrics
                self._update_reactor_metrics(reactor)
                
                # Critical containment failure check
                if reactor["containment_field"] < 0.2 and random.random() < 0.3 * time_units:
                    reactor["status"] = "CONTAINMENT FAILURE"
                    reactor["temperature"] = max(0.1, reactor["temperature"] * 0.1)
                    reactor["energy_output"] = 0
                    
    def get_fusion_types_list(self) -> List[FusionType]:
        """Get a list of all available fusion types"""
        return list(self.fusion_types.values())
        
    def get_reactor_status_report(self, name: str = None) -> str:
        """Generate a status report for a specific reactor or all reactors"""
        if name and name in self.active_reactors:
            # Report for a specific reactor
            r = self.active_reactors[name]
            fusion_type = self.fusion_types[r["fusion_type"]]
            
            report = [
                f"=== REACTOR: {r['name']} ===",
                f"Type: {r['fusion_type']}",
                f"Status: {r['status'].upper()}",
                f"Size: {r['size']:.1f} units",
                f"Temperature: {r['temperature']:.2f} (×10^7 K)",
                f"Containment Field: {r['containment_field']:.2f}",
                f"Quantum Field: {r['quantum_field_strength']:.2f}",
                f"Efficiency: {r['efficiency']:.2f}",
                f"Energy Output: {r['energy_output']:.2f} units",
                f"Runtime: {r['runtime']} time units",
                f"Maintenance Required: {'YES' if r['maintenance_required'] else 'No'}"
            ]
            
            return "\n".join(report)
        else:
            # Summary report for all reactors
            report = ["=== FUSION REACTOR SYSTEMS REPORT ==="]
            
            total_output = 0
            online_count = 0
            
            for name, r in self.active_reactors.items():
                status_indicator = "⚠️" if r["maintenance_required"] else "✓"
                if r["status"] == "CONTAINMENT FAILURE":
                    status_indicator = "❌"
                
                report.append(f"{name}: {r['status'].upper()} {status_indicator} | " +
                             f"Output: {r['energy_output']:.1f} | " +
                             f"Containment: {r['containment_field']:.2f}")
                
                if r["status"] == "online":
                    total_output += r["energy_output"]
                    online_count += 1
            
            report.append(f"\nTotal Reactors: {len(self.active_reactors)}")
            report.append(f"Online Reactors: {online_count}")
            report.append(f"Total Energy Output: {total_output:.1f} units")
            
            return "\n".join(report)


class QuantumPrinciple:
    """Represents a quantum principle that can be applied to experiments"""
    
    def __init__(self, name: str, description: str, complexity: float, effects: Dict[str, float]):
        self.name = name
        self.description = description
        self.complexity = complexity  # 0.0 to 1.0, higher is more complex
        self.effects = effects  # Dictionary of effects on different properties
        
    def __str__(self) -> str:
        return f"{self.name}: {self.description}"


class QuantumMechanicsSystem:
    """Manages quantum mechanics principles and applications"""
    
    def __init__(self):
        self.quantum_principles: Dict[str, QuantumPrinciple] = {}
        self.initialize_principles()
        
    def initialize_principles(self):
        """Initialize the fundamental quantum principles"""
        principles = [
            QuantumPrinciple(
                "Superposition", 
                "Quantum particles can exist in multiple states simultaneously until observed",
                0.5,
                {"entanglement": 0.3, "coherence": 0.8, "stability": -0.2}
            ),
            QuantumPrinciple(
                "Entanglement",
                "Quantum states of particles can become correlated so their properties are interdependent",
                0.7,
                {"information_transfer": 0.9, "coherence": 0.4, "stability": -0.1}
            ),
            QuantumPrinciple(
                "Uncertainty",
                "Cannot precisely know both position and momentum of a particle simultaneously",
                0.6,
                {"precision": -0.5, "knowledge": -0.2, "stability": 0.1}
            ),
            QuantumPrinciple(
                "Wave-Particle Duality",
                "Quantum entities exhibit both wave and particle properties depending on observation",
                0.4,
                {"flexibility": 0.6, "adaptability": 0.7, "predictability": -0.4}
            ),
            QuantumPrinciple(
                "Quantum Tunneling",
                "Particles can pass through energy barriers that classical physics prohibits",
                0.8,
                {"barrier_penetration": 0.9, "energy_efficiency": 0.4, "containment": -0.5}
            ),
            QuantumPrinciple(
                "Quantum Decoherence",
                "Quantum systems lose coherence through interaction with the environment",
                0.75,
                {"stability": 0.6, "coherence": -0.8, "isolation": -0.4}
            ),
            QuantumPrinciple(
                "Quantum Teleportation",
                "Transfer quantum information between locations using entangled particles",
                0.9,
                {"information_transfer": 1.0, "energy_cost": 0.8, "precision": 0.7}
            ),
            QuantumPrinciple(
                "Quantum Zeno Effect",
                "Frequent observation of a quantum system inhibits its evolution",
                0.85,
                {"stability": 0.8, "evolution": -0.7, "energy_efficiency": -0.3}
            )
        ]
        
        for principle in principles:
            self.quantum_principles[principle.name] = principle
            
    def apply_principle(self, principle_name: str, target_system: Dict) -> Tuple[bool, str, Dict]:
        """Apply a quantum principle to a target system and get results"""
        if principle_name not in self.quantum_principles:
            return (False, "Principle not found", {})
            
        principle = self.quantum_principles[principle_name]
        
        # Deep copy the target system for modifications
        result_system = target_system.copy()
        
        # Calculate success probability based on complexity
        success_probability = 1.0 - (principle.complexity * 0.5)
        success = random.random() < success_probability
        
        effects_description = []
        
        if success:
            # Apply effects
            for property_name, effect_value in principle.effects.items():
                if property_name in result_system:
                    # Apply effect with some randomness
                    effect_magnitude = effect_value * random.uniform(0.7, 1.3)
                    
                    # Different properties might be affected differently
                    if property_name in ["stability", "coherence", "precision"]:
                        # These are usually 0-1 values
                        result_system[property_name] = max(0.0, min(1.0, 
                                                                result_system[property_name] + effect_magnitude * 0.2))
                    else:
                        # Other values might be scaled differently
                        result_system[property_name] = result_system[property_name] * (1.0 + effect_magnitude * 0.1)
                    
                    effect_dir = "increased" if effect_magnitude > 0 else "decreased"
                    effects_description.append(f"{property_name} {effect_dir}")
            
            return (True, f"Applied {principle.name} successfully. Effects: {', '.join(effects_description)}", 
                   result_system)
        else:
            failure_message = f"Failed to apply {principle.name} due to high complexity."
            return (False, failure_message, result_system)
            
    def get_principles_list(self) -> List[QuantumPrinciple]:
        """Get a list of all quantum principles"""
        return list(self.quantum_principles.values())
        
    def get_principle_description(self, name: str) -> Optional[str]:
        """Get a detailed description of a quantum principle"""
        if name in self.quantum_principles:
            principle = self.quantum_principles[name]
            
            description = [
                f"=== {principle.name} ===",
                principle.description,
                f"Complexity Level: {principle.complexity:.1f}/1.0",
                "\nEffects on systems:",
            ]
            
            for property_name, effect_value in principle.effects.items():
                effect_dir = "Increases" if effect_value > 0 else "Decreases"
                effect_strength = abs(effect_value)
                strength_desc = "significantly" if effect_strength > 0.7 else \
                              "moderately" if effect_strength > 0.3 else "slightly"
                
                description.append(f"• {effect_dir} {property_name} {strength_desc}")
                
            return "\n".join(description)
        
        return None


# Initialize global instances
fusion_system = FusionReactorSystem()
quantum_mechanics = QuantumMechanicsSystem()

def get_quantum_sectors_info():
    """Return information about the four sectors of quantum mechanics"""
    sectors = [
        {
            "name": "Quantization of physical properties",
            "description": "Physical properties like energy can only take specific discrete values",
            "examples": ["Energy levels in atoms", "Photon energy", "Angular momentum"],
            "applications": ["Spectroscopy", "Lasers", "Quantum computing"]
        },
        {
            "name": "Quantum entanglement",
            "description": "Quantum states of multiple particles are interdependent regardless of distance",
            "examples": ["Bell states", "EPR pairs", "Quantum teleportation"],
            "applications": ["Quantum cryptography", "Quantum communication", "Quantum sensors"]
        },
        {
            "name": "Uncertainty principle",
            "description": "Impossibility of knowing both position and momentum precisely at the same time",
            "examples": ["Heisenberg's uncertainty relation", "Energy-time uncertainty", "Zero-point energy"],
            "applications": ["Quantum tunneling", "Quantum field theory", "Scanning tunneling microscopy"]
        },
        {
            "name": "Wave-particle duality",
            "description": "Quantum entities exhibit both wave and particle properties depending on measurement",
            "examples": ["Double-slit experiment", "Electron diffraction", "Photon behavior"],
            "applications": ["Electron microscopy", "Wave-function collapse", "Quantum optics"]
        }
    ]
    
    return sectors
