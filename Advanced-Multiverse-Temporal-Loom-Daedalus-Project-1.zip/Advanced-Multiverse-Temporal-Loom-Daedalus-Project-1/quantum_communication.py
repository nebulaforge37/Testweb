
"""
Quantum Communication System
This module enables communication between timelines and realities
using quantum entanglement and temporal resonance.
"""

import random
import math
from typing import Dict, List, Tuple, Optional, Any

class QuantumMessage:
    """Represents a message sent through quantum channels"""
    
    def __init__(self, 
                 sender_timeline: str,
                 sender_year: int,
                 target_timeline: str,
                 target_year: int,
                 content: str,
                 priority: float = 0.5):
        """
        Initialize a quantum message
        
        Args:
            sender_timeline: Origin timeline name
            sender_year: Year in origin timeline
            target_timeline: Destination timeline name
            target_year: Target year in destination timeline
            content: Message content
            priority: Priority level (0.0-1.0) affecting transmission chances
        """
        self.sender_timeline = sender_timeline
        self.sender_year = sender_year
        self.target_timeline = target_timeline
        self.target_year = target_year
        self.content = content
        self.priority = min(1.0, max(0.0, priority))
        
        # Transmission properties
        self.entanglement_key = random.random()  # Unique key for this transmission
        self.transmission_integrity = 1.0  # Will degrade during transmission
        self.timestamp = random.randint(1000000000, 9999999999)  # Random timestamp
        self.received = False
        self.corrupted = False
        
    def apply_quantum_interference(self, intensity: float):
        """Apply quantum interference to the message, potentially corrupting it"""
        self.transmission_integrity -= intensity
        
        # Check if message becomes corrupted
        if self.transmission_integrity < 0.5:
            self.corrupted = True
            
            if self.transmission_integrity < 0.3:
                # Severely corrupt the message
                words = self.content.split()
                for i in range(min(len(words), int(len(words) * (1 - self.transmission_integrity)))):
                    idx = random.randint(0, len(words) - 1)
                    words[idx] = "[corrupted]"
                self.content = " ".join(words)
    
    def __str__(self) -> str:
        status = "RECEIVED" if self.received else "PENDING"
        if self.corrupted:
            status = "CORRUPTED"
            
        return (f"QUANTUM MESSAGE [{status}]\n"
                f"From: {self.sender_timeline} ({self.sender_year})\n"
                f"To: {self.target_timeline} ({self.target_year})\n"
                f"Integrity: {self.transmission_integrity:.2f}\n"
                f"Priority: {self.priority:.2f}\n"
                f"Content: {self.content}")


class QuantumTransceiver:
    """Quantum device for sending and receiving messages across timelines"""
    
    def __init__(self, timeline_name: str, timeline_year: int):
        """Initialize a quantum transceiver in a specific timeline"""
        self.timeline_name = timeline_name
        self.timeline_year = timeline_year
        self.entanglement_level = 0.5  # Base entanglement with quantum network
        self.message_queue = []  # Outgoing messages
        self.received_messages = []  # Received messages
        self.connection_quality = random.uniform(0.7, 1.0)  # Connection to quantum network
        
    def send_message(self, 
                    target_timeline: str, 
                    target_year: int, 
                    content: str,
                    priority: float = 0.5) -> QuantumMessage:
        """
        Queue a message to be sent to another timeline
        Returns the created message
        """
        message = QuantumMessage(
            self.timeline_name,
            self.timeline_year,
            target_timeline,
            target_year,
            content,
            priority
        )
        
        self.message_queue.append(message)
        return message
    
    def receive_message(self, message: QuantumMessage):
        """Receive an incoming quantum message"""
        message.received = True
        self.received_messages.append(message)
    
    def boost_entanglement(self, amount: float = 0.1):
        """Boost entanglement level with the quantum network"""
        self.entanglement_level = min(1.0, self.entanglement_level + amount)
        
    def repair_connection(self):
        """Repair connection to the quantum network"""
        self.connection_quality = min(1.0, self.connection_quality + random.uniform(0.1, 0.3))
    
    def get_message_list(self) -> str:
        """Get a formatted list of received messages"""
        if not self.received_messages:
            return "No messages received."
            
        output = []
        for i, message in enumerate(self.received_messages):
            output.append(f"Message {i+1}: From {message.sender_timeline} ({message.sender_year})")
            status = "OK" if not message.corrupted else "CORRUPTED"
            output.append(f"Status: {status} | Integrity: {message.transmission_integrity:.2f}")
            output.append(f"Content: {message.content}")
            output.append("---")
            
        return "\n".join(output)
    
    def __str__(self) -> str:
        return (f"Quantum Transceiver: {self.timeline_name} ({self.timeline_year})\n"
                f"Entanglement Level: {self.entanglement_level:.2f}\n"
                f"Connection Quality: {self.connection_quality:.2f}\n"
                f"Outgoing Messages: {len(self.message_queue)}\n"
                f"Received Messages: {len(self.received_messages)}")


class QuantumNetwork:
    """Manages quantum communication across the multiverse"""
    
    def __init__(self, multiverse = None):
        """Initialize the quantum network"""
        self.transceivers = {}  # Dict of timeline_name -> transceiver
        self.multiverse = multiverse
        self.network_stability = 0.8
        self.entanglement_matrix = {}  # Stores entanglement levels between timelines
        self.message_history = []  # All messages ever sent
        
    def register_transceiver(self, timeline_name: str, year: int) -> QuantumTransceiver:
        """Register a new transceiver for a timeline"""
        key = f"{timeline_name}:{year}"
        
        if key in self.transceivers:
            return self.transceivers[key]
            
        transceiver = QuantumTransceiver(timeline_name, year)
        self.transceivers[key] = transceiver
        
        # Initialize entanglement with other transceivers
        for other_key, other in self.transceivers.items():
            if other_key != key:
                entanglement = random.uniform(0.1, 0.5)
                self.entanglement_matrix[(key, other_key)] = entanglement
                self.entanglement_matrix[(other_key, key)] = entanglement
        
        return transceiver
    
    def get_transceiver(self, timeline_name: str, year: int) -> Optional[QuantumTransceiver]:
        """Get a transceiver for a timeline at a specific year"""
        key = f"{timeline_name}:{year}"
        return self.transceivers.get(key)
    
    def process_transmissions(self):
        """Process all pending message transmissions in the network"""
        # For each transceiver
        for key, transceiver in self.transceivers.items():
            # Process outgoing message queue
            for message in list(transceiver.message_queue):  # Create a copy to iterate
                # Try to send the message
                target_key = f"{message.target_timeline}:{message.target_year}"
                target = self.transceivers.get(target_key)
                
                if not target:
                    # No receiver at destination timeline/year
                    continue
                    
                # Calculate transmission success probability
                entanglement = self.entanglement_matrix.get((key, target_key), 0.1)
                
                base_probability = (transceiver.entanglement_level * 0.4 +
                                  target.entanglement_level * 0.3 +
                                  entanglement * 0.3)
                
                # Modify by connection quality and priority
                success_chance = (base_probability * 
                                transceiver.connection_quality * 
                                target.connection_quality *
                                (0.7 + message.priority * 0.3))
                
                # Also affected by network stability
                success_chance *= self.network_stability
                
                # Determine if transmission succeeds
                if random.random() < success_chance:
                    # Success - apply some quantum interference
                    interference = random.uniform(0, 0.5) * (2 - self.network_stability)
                    message.apply_quantum_interference(interference)
                    
                    # Deliver the message
                    target.receive_message(message)
                    transceiver.message_queue.remove(message)
                    
                    # Boost entanglement between the timelines
                    new_entanglement = min(1.0, entanglement + 0.05)
                    self.entanglement_matrix[(key, target_key)] = new_entanglement
                    self.entanglement_matrix[(target_key, key)] = new_entanglement
                    
                    # Record in history
                    self.message_history.append(message)
                    
                    # Check if multiverse is available to record the event
                    if self.multiverse and message.target_timeline in self.multiverse.timelines:
                        self.multiverse.timelines[message.target_timeline].add_event(
                            f"Quantum message received from {message.sender_timeline}", 
                            message.target_year
                        )
    
    def get_timeline_entanglement(self, timeline1: str, timeline2: str) -> float:
        """Get the entanglement level between two timelines"""
        total_entanglement = 0.0
        count = 0
        
        for (t1, y1), (t2, y2) in self.entanglement_matrix:
            if (t1 == timeline1 and t2 == timeline2) or (t1 == timeline2 and t2 == timeline1):
                total_entanglement += self.entanglement_matrix[((t1, y1), (t2, y2))]
                count += 1
                
        return total_entanglement / max(1, count)
    
    def network_status_report(self) -> str:
        """Generate a status report for the quantum network"""
        active_transceivers = len(self.transceivers)
        pending_messages = sum(len(t.message_queue) for t in self.transceivers.values())
        delivered_messages = len(self.message_history)
        
        # Calculate average entanglement and connection quality
        avg_entanglement = sum(t.entanglement_level for t in self.transceivers.values()) / max(1, active_transceivers)
        avg_connection = sum(t.connection_quality for t in self.transceivers.values()) / max(1, active_transceivers)
        
        report = [
            "=== QUANTUM NETWORK STATUS ===",
            f"Network Stability: {self.network_stability:.2f}",
            f"Active Transceivers: {active_transceivers}",
            f"Average Entanglement: {avg_entanglement:.2f}",
            f"Average Connection Quality: {avg_connection:.2f}",
            f"Pending Messages: {pending_messages}",
            f"Successfully Delivered: {delivered_messages}",
            "",
            "Most Entangled Timeline Pairs:"
        ]
        
        # Find the most entangled timeline pairs
        timeline_pairs = {}
        for (t1_key, t2_key), level in self.entanglement_matrix.items():
            t1 = t1_key.split(":")[0]
            t2 = t2_key.split(":")[0]
            
            if t1 != t2:
                pair = tuple(sorted([t1, t2]))
                if pair in timeline_pairs:
                    timeline_pairs[pair] = max(timeline_pairs[pair], level)
                else:
                    timeline_pairs[pair] = level
        
        # Sort and display top 3
        top_pairs = sorted(timeline_pairs.items(), key=lambda x: x[1], reverse=True)[:3]
        for (t1, t2), level in top_pairs:
            report.append(f"  {t1} ⟷ {t2}: {level:.2f}")
            
        return "\n".join(report)

    def simulate_network_disturbance(self, intensity: float = 0.3):
        """Simulate a disturbance in the quantum network"""
        self.network_stability = max(0.3, self.network_stability - intensity)
        
        # Affect all transceivers
        for transceiver in self.transceivers.values():
            transceiver.connection_quality = max(0.2, transceiver.connection_quality - 
                                              random.uniform(0, intensity))
        
        # Affect entanglement matrix
        for key in self.entanglement_matrix:
            self.entanglement_matrix[key] = max(0.1, self.entanglement_matrix[key] - 
                                              random.uniform(0, intensity))
        
        return f"Network disturbance occurred. Stability reduced to {self.network_stability:.2f}"
    
    def repair_network(self):
        """Attempt to repair and stabilize the quantum network"""
        self.network_stability = min(1.0, self.network_stability + 0.2)
        
        # Improve all transceiver connections slightly
        for transceiver in self.transceivers.values():
            transceiver.connection_quality = min(1.0, transceiver.connection_quality + 0.1)
        
        return f"Network repairs complete. Stability improved to {self.network_stability:.2f}"


def run_quantum_communication_demo():
    """Run a demonstration of the quantum communication system"""
    print("=== Quantum Communication Network Demonstration ===")
    
    # Initialize network
    network = QuantumNetwork()
    
    # Create transceivers in different timelines
    alpha = network.register_transceiver("Alpha Prime", 2050)
    beta = network.register_transceiver("Beta Variant", 2035)
    gamma = network.register_transceiver("Gamma Nexus", 2070)
    omega = network.register_transceiver("Omega Point", 2100)
    
    print("Created quantum transceivers in multiple timelines:")
    print(f"- {alpha}")
    print(f"- {beta}")
    print(f"- {gamma}")
    print(f"- {omega}")
    
    # Send some test messages
    print("\nSending test messages:")
    
    msg1 = alpha.send_message("Beta Variant", 2035, 
                           "WARNING: Temporal incursion detected in sector 7. Requesting assistance.", 
                           priority=0.9)
    print(f"- Message from Alpha Prime to Beta Variant: Priority {msg1.priority}")
    
    msg2 = beta.send_message("Gamma Nexus", 2070,
                          "Research data on quantum field stabilization attached. Please review.", 
                          priority=0.6)
    print(f"- Message from Beta Variant to Gamma Nexus: Priority {msg2.priority}")
    
    msg3 = gamma.send_message("Alpha Prime", 2050,
                           "Historical records indicate a paradox is forming in your timeline. Exercise caution.", 
                           priority=0.8)
    print(f"- Message from Gamma Nexus to Alpha Prime: Priority {msg3.priority}")
    
    msg4 = omega.send_message("Alpha Prime", 2050,
                           "Your current actions will lead to timeline collapse. Abort operation immediately.", 
                           priority=1.0)
    print(f"- Message from Omega Point to Alpha Prime: Priority {msg4.priority}")
    
    # Process the transmissions
    print("\nProcessing quantum transmissions...")
    network.process_transmissions()
    
    # Check received messages
    print("\nChecking received messages:")
    
    for name, transceiver in [("Alpha Prime", alpha), ("Beta Variant", beta), 
                             ("Gamma Nexus", gamma), ("Omega Point", omega)]:
        print(f"\n{name} received messages:")
        print(transceiver.get_message_list())
    
    # Simulate a network disturbance
    print("\nSimulating quantum network disturbance...")
    result = network.simulate_network_disturbance(0.4)
    print(result)
    
    # Send more messages in disturbed conditions
    msg5 = alpha.send_message("Omega Point", 2100,
                           "Connection unstable. Attempting to boost signal strength.", 
                           priority=0.7)
    print(f"- Sending message during disturbance: Priority {msg5.priority}")
    
    # Process transmissions again
    print("\nProcessing transmissions during disturbance...")
    network.process_transmissions()
    
    # Repair the network
    print("\nAttempting network repairs...")
    result = network.repair_network()
    print(result)
    
    # Boosting some connections
    print("\nBoosting entanglement for Alpha transceiver...")
    alpha.boost_entanglement(0.3)
    
    # Final network status
    print("\n" + network.network_status_report())
    
    print("\nQuantum Communication Demo completed!")


if __name__ == "__main__":
    run_quantum_communication_demo()
"""
Quantum Communication Network
This module enables communication across different timelines and dimensions
using quantum entanglement principles.
"""

import random
import time
import math
from typing import List, Dict, Tuple, Optional, Any
from main import Multiverse, Timeline


class QuantumMessage:
    """Represents a message sent through the quantum network"""
    
    def __init__(self, 
                message_id: int,
                content: str, 
                origin_timeline: str,
                origin_year: int,
                destination_timeline: str,
                destination_year: int,
                priority: float = 0.5,
                sender: str = "Anonymous"):
        """
        Initialize a quantum message
        
        Args:
            message_id: Unique identifier for this message
            content: The message content
            origin_timeline: Timeline where the message was sent from
            origin_year: Year in the origin timeline
            destination_timeline: Timeline where the message should be delivered
            destination_year: Year in the destination timeline
            priority: Priority level (0.0-1.0)
            sender: Name of the sender
        """
        self.message_id = message_id
        self.content = content
        self.origin_timeline = origin_timeline
        self.origin_year = origin_year
        self.destination_timeline = destination_timeline
        self.destination_year = destination_year
        self.priority = priority
        self.sender = sender
        self.timestamp = time.time()
        self.sent = False
        self.received = False
        self.receive_timestamp = None
        self.transit_time = None
        self.delivery_error = None
        self.quantum_signature = random.random()  # Unique quantum signature
        
    def mark_sent(self):
        """Mark the message as sent"""
        self.sent = True
        
    def mark_received(self):
        """Mark the message as received"""
        self.received = True
        self.receive_timestamp = time.time()
        self.transit_time = self.receive_timestamp - self.timestamp
        
    def mark_failed(self, error: str):
        """Mark the message as failed with an error"""
        self.delivery_error = error
        
    def get_age(self) -> float:
        """Get the age of the message in seconds"""
        return time.time() - self.timestamp
        
    def __str__(self) -> str:
        status = "Delivered" if self.received else "Failed" if self.delivery_error else "Sent" if self.sent else "Pending"
        return (f"Message to {self.destination_timeline} ({self.destination_year}) - {status}\n"
                f"From: {self.sender} in {self.origin_timeline} ({self.origin_year})\n"
                f"Content: {self.content}")


class QuantumTransceiver:
    """A device capable of sending and receiving quantum messages"""
    
    def __init__(self, transceiver_id: str, timeline_name: str, timeline_year: int):
        """
        Initialize a quantum transceiver
        
        Args:
            transceiver_id: Unique identifier for this transceiver
            timeline_name: Timeline where this transceiver is located
            timeline_year: Year in the timeline
        """
        self.transceiver_id = transceiver_id
        self.timeline_name = timeline_name
        self.timeline_year = timeline_year
        self.entanglement_level = random.uniform(0.6, 0.9)  # How strongly entangled with network
        self.connection_quality = random.uniform(0.7, 1.0)  # Quality of quantum connection
        self.received_messages = []
        self.sent_messages = []
        self.message_queue = []
        self.last_maintenance = time.time()
        
    def send_message(self, destination_timeline: str, destination_year: int, 
                   content: str, priority: float = 0.5) -> QuantumMessage:
        """
        Queue a message for sending
        
        Returns:
            The created QuantumMessage object
        """
        message_id = len(self.sent_messages) + 1
        message = QuantumMessage(
            message_id,
            content,
            self.timeline_name,
            self.timeline_year,
            destination_timeline,
            destination_year,
            priority,
            f"Transceiver-{self.transceiver_id}"
        )
        
        self.message_queue.append(message)
        return message
        
    def receive_message(self, message: QuantumMessage) -> bool:
        """
        Receive a quantum message
        
        Returns:
            Success (True) or failure (False)
        """
        # Check if connection is good enough to receive
        receive_chance = self.connection_quality * self.entanglement_level
        
        # Priority messages have better chance of receipt
        receive_chance *= (1.0 + message.priority * 0.5)
        
        if random.random() < receive_chance:
            message.mark_received()
            self.received_messages.append(message)
            return True
        else:
            error = "Insufficient quantum connection quality for receipt"
            message.mark_failed(error)
            return False
            
    def get_message_list(self) -> str:
        """Get a formatted list of received messages"""
        if not self.received_messages:
            return "No messages received."
            
        messages = []
        for i, msg in enumerate(self.received_messages, 1):
            messages.append(f"{i}. From: {msg.sender} in {msg.origin_timeline} ({msg.origin_year})")
            messages.append(f"   Received: {time.ctime(msg.receive_timestamp)}")
            messages.append(f"   Message: {msg.content}")
            messages.append("")
            
        return "\n".join(messages)
        
    def process_message_queue(self, network) -> List[QuantumMessage]:
        """
        Process outgoing messages from queue
        
        Returns:
            List of messages that were processed (sent or failed)
        """
        if not self.message_queue:
            return []
            
        processed_messages = []
        
        # Sort by priority
        self.message_queue.sort(key=lambda m: m.priority, reverse=True)
        
        # Process up to 5 messages at once
        for _ in range(min(5, len(self.message_queue))):
            message = self.message_queue.pop(0)
            
            # Try to send through the network
            send_chance = self.connection_quality * self.entanglement_level
            
            if random.random() < send_chance:
                message.mark_sent()
                self.sent_messages.append(message)
                network.route_message(message)
            else:
                error = "Failed to establish quantum entanglement for transmission"
                message.mark_failed(error)
                self.sent_messages.append(message)
                
            processed_messages.append(message)
            
        return processed_messages
        
    def boost_entanglement(self, amount: float = 0.1):
        """Boost the entanglement level"""
        self.entanglement_level = min(1.0, self.entanglement_level + amount)
        
    def repair_connection(self):
        """Repair the connection quality"""
        self.connection_quality = min(1.0, self.connection_quality + random.uniform(0.1, 0.3))
        self.last_maintenance = time.time()
        
    def update(self):
        """Update the transceiver state"""
        # Connection quality gradually degrades over time
        time_since_maintenance = time.time() - self.last_maintenance
        degradation = min(0.2, time_since_maintenance / (24 * 3600) * 0.01)  # Max 0.2 per day
        self.connection_quality = max(0.1, self.connection_quality - degradation)
        
    def __str__(self) -> str:
        return (f"Transceiver in {self.timeline_name} ({self.timeline_year}) - "
                f"Entanglement: {self.entanglement_level:.2f}, Connection: {self.connection_quality:.2f}")


class QuantumNetwork:
    """Manages quantum communication across timelines and dimensions"""
    
    def __init__(self, multiverse: Optional[Multiverse] = None):
        """Initialize the quantum network"""
        self.multiverse = multiverse
        self.transceivers = {}  # transceiver_id -> QuantumTransceiver
        self.message_log = []
        self.network_stability = random.uniform(0.7, 0.9)
        self.next_transceiver_id = 1
        self.network_entanglement_field = {}  # timeline_name -> entanglement strength
        self.temporal_noise = random.uniform(0.1, 0.3)
        
    def register_transceiver(self, timeline_name: str, timeline_year: int) -> QuantumTransceiver:
        """
        Register a new transceiver in the network
        
        Returns:
            The created transceiver
        """
        transceiver_id = f"{self.next_transceiver_id:04d}"
        self.next_transceiver_id += 1
        
        transceiver = QuantumTransceiver(transceiver_id, timeline_name, timeline_year)
        
        # Adjust entanglement based on timeline's presence in network
        if timeline_name in self.network_entanglement_field:
            # Existing timeline has better entanglement
            transceiver.entanglement_level = max(
                transceiver.entanglement_level,
                self.network_entanglement_field[timeline_name] * random.uniform(0.9, 1.1)
            )
        else:
            # New timeline in the network
            self.network_entanglement_field[timeline_name] = transceiver.entanglement_level * 0.8
            
        self.transceivers[transceiver_id] = transceiver
        return transceiver
        
    def get_transceiver(self, transceiver_id: str) -> Optional[QuantumTransceiver]:
        """Get a transceiver by ID"""
        return self.transceivers.get(transceiver_id)
        
    def find_transceivers_in_timeline(self, timeline_name: str, 
                                    timeline_year: Optional[int] = None) -> List[QuantumTransceiver]:
        """Find all transceivers in a specific timeline and optionally year"""
        results = []
        
        for transceiver in self.transceivers.values():
            if transceiver.timeline_name == timeline_name:
                if timeline_year is None or transceiver.timeline_year == timeline_year:
                    results.append(transceiver)
                    
        return results
        
    def route_message(self, message: QuantumMessage) -> bool:
        """
        Route a message to its destination
        
        Returns:
            Success (True) or failure (False)
        """
        if not message.sent:
            return False
            
        # Log the message
        self.message_log.append({
            "id": message.message_id,
            "origin": message.origin_timeline,
            "destination": message.destination_timeline,
            "timestamp": message.timestamp
        })
        
        # Find transceivers at the destination
        destination_transceivers = self.find_transceivers_in_timeline(
            message.destination_timeline,
            message.destination_year
        )
        
        if not destination_transceivers:
            message.mark_failed("No receivers found at destination")
            return False
            
        # Sort by connection quality for best chance of receipt
        destination_transceivers.sort(key=lambda t: t.connection_quality * t.entanglement_level, reverse=True)
        
        # Try to deliver to the best transceiver
        best_transceiver = destination_transceivers[0]
        return best_transceiver.receive_message(message)
        
    def process_transmissions(self):
        """Process all pending message transmissions"""
        # First update all transceivers
        for transceiver in self.transceivers.values():
            transceiver.update()
            
        # Process each transceiver's queue
        for transceiver in self.transceivers.values():
            transceiver.process_message_queue(self)
            
        # Network stability can fluctuate
        stability_change = random.uniform(-0.05, 0.05)
        self.network_stability = max(0.3, min(1.0, self.network_stability + stability_change))
        
        # Temporal noise can fluctuate
        noise_change = random.uniform(-0.03, 0.03)
        self.temporal_noise = max(0.05, min(0.5, self.temporal_noise + noise_change))
        
    def simulate_network_disturbance(self, intensity: float = 0.5) -> str:
        """
        Simulate a disturbance in the quantum network
        
        Args:
            intensity: Intensity of the disturbance (0.0-1.0)
            
        Returns:
            Description of the disturbance effects
        """
        # Affect network stability
        old_stability = self.network_stability
        self.network_stability = max(0.1, self.network_stability - (intensity * 0.5))
        
        # Increase temporal noise
        old_noise = self.temporal_noise
        self.temporal_noise = min(0.9, self.temporal_noise + (intensity * 0.4))
        
        # Affect all transceivers
        affected_count = 0
        for transceiver in self.transceivers.values():
            # More intense disturbances affect more transceivers
            if random.random() < intensity * 0.8:
                affected_count += 1
                
                # Reduce connection quality
                reduction = random.uniform(0.1, 0.3) * intensity
                transceiver.connection_quality = max(0.1, transceiver.connection_quality - reduction)
                
                # Small chance to completely disconnect
                if intensity > 0.7 and random.random() < 0.2:
                    transceiver.connection_quality = 0.1
        
        # Generate description of effects
        effects = (
            f"Quantum network disturbance detected! Intensity: {intensity:.2f}\n"
            f"Network stability reduced: {old_stability:.2f} → {self.network_stability:.2f}\n"
            f"Temporal noise increased: {old_noise:.2f} → {self.temporal_noise:.2f}\n"
            f"Affected {affected_count} out of {len(self.transceivers)} transceivers."
        )
        
        if intensity > 0.7:
            effects += "\nWARNING: Severe disruption to quantum entanglement field detected."
            
        return effects
        
    def repair_network(self) -> str:
        """
        Repair the quantum network
        
        Returns:
            Description of repair effects
        """
        old_stability = self.network_stability
        old_noise = self.temporal_noise
        
        # Improve network stability
        self.network_stability = min(1.0, self.network_stability + random.uniform(0.1, 0.3))
        
        # Reduce temporal noise
        self.temporal_noise = max(0.1, self.temporal_noise - random.uniform(0.1, 0.2))
        
        # Repair all transceivers
        repaired_count = 0
        for transceiver in self.transceivers.values():
            if transceiver.connection_quality < 0.7:
                repaired_count += 1
                transceiver.repair_connection()
        
        # Generate description of effects
        effects = (
            f"Quantum network repairs completed.\n"
            f"Network stability improved: {old_stability:.2f} → {self.network_stability:.2f}\n"
            f"Temporal noise reduced: {old_noise:.2f} → {self.temporal_noise:.2f}\n"
            f"Repaired {repaired_count} out of {len(self.transceivers)} transceivers."
        )
        
        return effects
        
    def network_status_report(self) -> str:
        """Get a status report of the network"""
        timelines_covered = len(self.network_entanglement_field)
        total_transceivers = len(self.transceivers)
        
        # Count active transceivers (good connection quality)
        active_count = sum(1 for t in self.transceivers.values() if t.connection_quality > 0.5)
        
        status = (
            f"=== Quantum Communication Network Status ===\n"
            f"Network Stability: {self.network_stability:.2f}\n"
            f"Temporal Noise Level: {self.temporal_noise:.2f}\n"
            f"Timelines Connected: {timelines_covered}\n"
            f"Total Transceivers: {total_transceivers}\n"
            f"Active Transceivers: {active_count}\n"
            f"Messages Routed: {len(self.message_log)}"
        )
        
        # Add status indicator
        if self.network_stability > 0.7 and active_count == total_transceivers:
            status += "\nOverall Status: OPTIMAL"
        elif self.network_stability > 0.5 and active_count >= total_transceivers * 0.7:
            status += "\nOverall Status: GOOD"
        elif self.network_stability > 0.3 and active_count >= total_transceivers * 0.4:
            status += "\nOverall Status: DEGRADED"
        else:
            status += "\nOverall Status: CRITICAL"
            
        return status


def run_quantum_communication_demo():
    """Run a demonstration of the quantum communication system"""
    print("=== Quantum Communication Network Demonstration ===")
    
    # Create the network
    network = QuantumNetwork()
    
    # Create sample transceivers in different timelines
    print("\nRegistering transceivers in various timelines...")
    transceivers = [
        network.register_transceiver("Alpha", 2050),
        network.register_transceiver("Beta", 2045),
        network.register_transceiver("Gamma", 2060),
        network.register_transceiver("Alpha", 2070)  # Second one in Alpha
    ]
    
    for transceiver in transceivers:
        print(f"Registered: {transceiver}")
    
    # Display network status
    print("\n" + network.network_status_report())
    
    # Send some test messages
    print("\nSending test messages...")
    
    # From Alpha to Beta
    message1 = transceivers[0].send_message(
        "Beta", 2045,
        "Greetings from Alpha timeline. This is a test of the quantum communication system.",
        priority=0.8
    )
    
    # From Beta to Gamma
    message2 = transceivers[1].send_message(
        "Gamma", 2060,
        "Warning: Temporal anomaly detected in sector 7. Recommend increasing chronofield stabilization.",
        priority=0.9
    )
    
    # From Gamma to Alpha (different year)
    message3 = transceivers[2].send_message(
        "Alpha", 2070,
        "Research update: Quantum entanglement enhancement successful. Transmission capacity increased by 42%.",
        priority=0.7
    )
    
    # Process the messages
    print("Processing message transmissions...")
    network.process_transmissions()
    
    # Check message status
    print("\nMessage Status:")
    for i, message in enumerate([message1, message2, message3], 1):
        status = "Delivered" if message.received else "Failed" if message.delivery_error else "Pending"
        print(f"Message {i}: {status}")
        if message.delivery_error:
            print(f"  Error: {message.delivery_error}")
            
    # Display received messages
    print("\nChecking received messages...")
    for i, transceiver in enumerate(transceivers):
        received = len(transceiver.received_messages)
        if received > 0:
            print(f"\nTransceiver in {transceiver.timeline_name} ({transceiver.timeline_year}) has {received} message(s):")
            print(transceiver.get_message_list())
        else:
            print(f"\nTransceiver in {transceiver.timeline_name} ({transceiver.timeline_year}) has no messages.")
    
    # Demonstrate network disturbance
    print("\n=== Simulating Network Disturbance ===")
    intensity = 0.7
    print(network.simulate_network_disturbance(intensity))
    
    # Show changes to network
    print("\nUpdated Network Status:")
    print(network.network_status_report())
    
    # Try sending a message during disturbance
    print("\nAttempting to send message during disturbance...")
    disturbance_message = transceivers[0].send_message(
        "Gamma", 2060,
        "Emergency: Network stability compromised. Initiating backup protocols.",
        priority=1.0
    )
    
    network.process_transmissions()
    
    status = "Delivered" if disturbance_message.received else "Failed" if disturbance_message.delivery_error else "Pending"
    print(f"Message status: {status}")
    if disturbance_message.delivery_error:
        print(f"Error: {disturbance_message.delivery_error}")
    
    # Repair the network
    print("\n=== Repairing Network ===")
    print(network.repair_network())
    
    print("\nFinal Network Status:")
    print(network.network_status_report())
    
    # Summary
    print("\n=== Quantum Communication Demonstration Summary ===")
    print(f"Messages sent: {len(network.message_log)}")
    delivered = sum(1 for t in transceivers for m in t.received_messages)
    print(f"Messages delivered: {delivered}")
    print(f"Network transceivers: {len(network.transceivers)}")
    print(f"Network stability: {network.network_stability:.2f}")
    
    return network


if __name__ == "__main__":
    run_quantum_communication_demo()
