
"""
Multiverse Telemetry System
Provides GPS-like tracking and telemetry data across the multiverse.
"""

import time
import math
import random
from typing import List, Dict, Tuple, Optional, Any
from temporal_coordinates import SpatialCoordinate, TemporalCoordinate, SpaceTimeCoordinate
from multiverse_coordinates import CoordinateEnhancedMultiverse, CoordinateEnhancedTimeline

class TelemetrySignal:
    """Represents a single telemetry signal from an entity in the multiverse"""
    
    def __init__(
        self, 
        entity_id: str,
        coordinate: SpaceTimeCoordinate,
        signal_strength: float = 1.0,
        metadata: Dict[str, Any] = None
    ):
        """
        Initialize a telemetry signal
        
        Args:
            entity_id: Unique identifier for the entity
            coordinate: The space-time coordinate of the entity
            signal_strength: Signal strength (0.0 to 1.0)
            metadata: Additional information about the signal
        """
        self.entity_id = entity_id
        self.coordinate = coordinate
        self.signal_strength = min(1.0, max(0.0, signal_strength))
        self.timestamp = time.time()  # Real-world timestamp when signal was created
        self.metadata = metadata or {}
    
    def get_age(self) -> float:
        """Get the age of this signal in seconds"""
        return time.time() - self.timestamp
    
    def is_valid(self, max_age_seconds: float = 300.0) -> bool:
        """Check if the signal is still valid based on age and strength"""
        if self.get_age() > max_age_seconds:
            return False
        if self.signal_strength < 0.1:
            return False
        return True
    
    def __str__(self) -> str:
        return (f"Signal from {self.entity_id} at {self.coordinate.timeline_name}, "
                f"year {self.coordinate.temporal.year}, "
                f"strength: {self.signal_strength:.2f}")


class TelemetryTrack:
    """Represents a series of signals from the same entity, forming a track through spacetime"""
    
    def __init__(self, entity_id: str, max_signals: int = 100):
        """
        Initialize a telemetry track
        
        Args:
            entity_id: Unique identifier for the entity
            max_signals: Maximum number of signals to keep in history
        """
        self.entity_id = entity_id
        self.signals: List[TelemetrySignal] = []
        self.max_signals = max_signals
        self.last_update = time.time()
        self.metadata: Dict[str, Any] = {}
    
    def add_signal(self, signal: TelemetrySignal) -> None:
        """Add a new signal to this track"""
        if signal.entity_id != self.entity_id:
            raise ValueError(f"Signal entity ID {signal.entity_id} does not match track ID {self.entity_id}")
        
        self.signals.append(signal)
        self.last_update = time.time()
        
        # Trim to max size
        if len(self.signals) > self.max_signals:
            self.signals = self.signals[-self.max_signals:]
    
    def get_current_position(self) -> Optional[SpaceTimeCoordinate]:
        """Get the most recent position"""
        if not self.signals:
            return None
        return self.signals[-1].coordinate
    
    def get_velocity_vector(self) -> Optional[Tuple[float, float, float, float]]:
        """
        Calculate velocity vector (spatial and temporal)
        Returns (dx, dy, dz, dt) if possible, None otherwise
        """
        if len(self.signals) < 2:
            return None
            
        latest = self.signals[-1].coordinate
        previous = self.signals[-2].coordinate
        
        # Check for same reference system
        if latest.spatial.reference_system != previous.spatial.reference_system:
            return None
            
        # Calculate spatial differences
        dx = latest.spatial.x - previous.spatial.x
        dy = latest.spatial.y - previous.spatial.y
        dz = latest.spatial.z - previous.spatial.z
        
        # Calculate temporal difference (in days)
        dt = latest.temporal.days_between(previous.temporal) or 0
        
        return (dx, dy, dz, dt)
    
    def predict_position(self, days_future: float) -> Optional[SpaceTimeCoordinate]:
        """
        Predict future position based on current velocity
        This is a simple linear prediction
        """
        velocity = self.get_velocity_vector()
        current = self.get_current_position()
        
        if not velocity or not current:
            return None
            
        dx, dy, dz, dt = velocity
        
        # Avoid division by zero
        if dt == 0:
            dt = 0.1
            
        # Calculate rates of change
        rate_x = dx / dt
        rate_y = dy / dt
        rate_z = dz / dt
        
        # Predict new spatial coordinates
        new_x = current.spatial.x + (rate_x * days_future)
        new_y = current.spatial.y + (rate_y * days_future)
        new_z = current.spatial.z + (rate_z * days_future)
        
        # Create the predicted coordinate
        spatial = SpatialCoordinate(
            new_x, new_y, new_z, 
            current.spatial.uncertainty * 1.5,  # Increase uncertainty for predictions
            current.spatial.reference_system
        )
        
        # Calculate new temporal coordinate
        # Clone current and add days
        if current.temporal.calendar_system == "Gregorian" and current.temporal._datetime:
            import datetime
            new_datetime = current.temporal._datetime + datetime.timedelta(days=days_future)
            temporal = TemporalCoordinate.from_datetime(
                new_datetime, 
                current.temporal.uncertainty_days * 1.5  # Increase uncertainty
            )
        else:
            # Approximate for non-Gregorian calendars
            new_year = current.temporal.year + int(days_future / 365)
            new_month = current.temporal.month
            new_day = current.temporal.day
            temporal = TemporalCoordinate(
                new_year, new_month, new_day,
                current.temporal.hour, current.temporal.minute, current.temporal.second,
                current.temporal.uncertainty_days * 1.5,
                current.temporal.calendar_system
            )
        
        return SpaceTimeCoordinate(
            spatial, temporal, current.timeline_name, current.quantum_signature
        )
    
    def get_timeline_crossings(self) -> List[Tuple[int, str, str]]:
        """
        Get a list of timeline crossing events
        Returns list of (signal_index, from_timeline, to_timeline) tuples
        """
        crossings = []
        for i in range(1, len(self.signals)):
            prev_timeline = self.signals[i-1].coordinate.timeline_name
            curr_timeline = self.signals[i].coordinate.timeline_name
            
            if prev_timeline != curr_timeline:
                crossings.append((i, prev_timeline, curr_timeline))
        
        return crossings
    
    def get_multiverse_distance_traveled(self) -> float:
        """
        Calculate total multiverse distance traveled along this track
        This combines spatial, temporal, and timeline crossing distances
        """
        if len(self.signals) < 2:
            return 0.0
            
        total_distance = 0.0
        
        for i in range(1, len(self.signals)):
            prev = self.signals[i-1].coordinate
            curr = self.signals[i].coordinate
            
            # Add energy cost as a proxy for distance
            total_distance += prev.calculate_transit_energy(curr)
        
        return total_distance
    
    def prune_invalid_signals(self, max_age_seconds: float = 300.0) -> int:
        """
        Remove signals that are no longer valid
        Returns the number of signals removed
        """
        valid_signals = [s for s in self.signals if s.is_valid(max_age_seconds)]
        removed = len(self.signals) - len(valid_signals)
        self.signals = valid_signals
        return removed
    
    def __str__(self) -> str:
        current = self.get_current_position()
        if current:
            return f"Track: {self.entity_id} - Current position: {current.timeline_name} year {current.temporal.year}"
        return f"Track: {self.entity_id} - No current position"


class MultiverseTelemetry:
    """Main telemetry system for tracking entities across the multiverse"""
    
    def __init__(self, multiverse: CoordinateEnhancedMultiverse = None):
        """Initialize the telemetry system"""
        self.multiverse = multiverse
        self.tracks: Dict[str, TelemetryTrack] = {}
        self.entity_metadata: Dict[str, Dict[str, Any]] = {}
        self.anomalies: List[Dict[str, Any]] = []
        self.last_prune = time.time()
    
    def register_entity(self, entity_id: str, metadata: Dict[str, Any] = None) -> None:
        """Register a new entity for tracking"""
        if entity_id not in self.tracks:
            self.tracks[entity_id] = TelemetryTrack(entity_id)
        
        if metadata:
            self.entity_metadata[entity_id] = metadata
    
    def record_signal(self, signal: TelemetrySignal) -> None:
        """Record a new telemetry signal"""
        entity_id = signal.entity_id
        
        # Create track if it doesn't exist
        if entity_id not in self.tracks:
            self.register_entity(entity_id)
        
        # Add signal to track
        self.tracks[entity_id].add_signal(signal)
        
        # Check for anomalies
        self._check_for_anomalies(entity_id)
        
        # Periodically prune old signals
        if time.time() - self.last_prune > 60:  # Every minute
            self._prune_old_data()
    
    def get_entity_position(self, entity_id: str) -> Optional[SpaceTimeCoordinate]:
        """Get the current position of an entity"""
        if entity_id in self.tracks:
            return self.tracks[entity_id].get_current_position()
        return None
    
    def predict_entity_position(self, 
                               entity_id: str, 
                               days_future: float) -> Optional[SpaceTimeCoordinate]:
        """Predict future position of an entity"""
        if entity_id in self.tracks:
            return self.tracks[entity_id].predict_position(days_future)
        return None
    
    def get_entities_in_timeline(self, timeline_name: str) -> List[str]:
        """Get IDs of entities currently in a specific timeline"""
        entities = []
        
        for entity_id, track in self.tracks.items():
            position = track.get_current_position()
            if position and position.timeline_name == timeline_name:
                entities.append(entity_id)
        
        return entities
    
    def get_entities_near_coordinate(self, 
                                   coordinate: SpaceTimeCoordinate,
                                   spatial_radius: float = 100.0,
                                   temporal_radius_days: float = 30.0) -> List[Tuple[str, float]]:
        """
        Get entities near a specific coordinate
        Returns list of (entity_id, distance) tuples, sorted by distance
        """
        nearby = []
        
        for entity_id, track in self.tracks.items():
            position = track.get_current_position()
            
            if not position:
                continue
                
            # Only check entities in the same timeline
            if position.timeline_name != coordinate.timeline_name:
                continue
                
            # Calculate spatial distance
            spatial_distance = position.spatial.distance_to(coordinate.spatial)
            
            # Calculate temporal distance
            temporal_distance = abs(position.temporal.days_between(coordinate.temporal) or 0)
            
            # Ensure both distances are within radius
            if spatial_distance <= spatial_radius and temporal_distance <= temporal_radius_days:
                # Combined distance for sorting
                combined_distance = math.sqrt(
                    (spatial_distance / spatial_radius)**2 + 
                    (temporal_distance / temporal_radius_days)**2
                )
                nearby.append((entity_id, combined_distance))
        
        # Sort by distance
        nearby.sort(key=lambda x: x[1])
        return nearby
    
    def calculate_timeline_traffic(self) -> Dict[str, int]:
        """Calculate the number of entities in each timeline"""
        traffic = {}
        
        for track in self.tracks.values():
            position = track.get_current_position()
            if position:
                timeline = position.timeline_name
                traffic[timeline] = traffic.get(timeline, 0) + 1
        
        return traffic
    
    def generate_telemetry_report(self) -> Dict[str, Any]:
        """Generate a comprehensive telemetry report"""
        report = {
            "timestamp": time.time(),
            "total_entities": len(self.tracks),
            "active_entities": sum(1 for t in self.tracks.values() if t.get_current_position()),
            "timeline_traffic": self.calculate_timeline_traffic(),
            "anomalies": len(self.anomalies),
            "entity_summaries": {},
            "recent_crossings": []
        }
        
        # Add entity summaries
        for entity_id, track in self.tracks.items():
            position = track.get_current_position()
            if position:
                report["entity_summaries"][entity_id] = {
                    "timeline": position.timeline_name,
                    "year": position.temporal.year,
                    "signals_count": len(track.signals),
                    "distance_traveled": track.get_multiverse_distance_traveled()
                }
        
        # Find recent timeline crossings
        recent_crossings = []
        for entity_id, track in self.tracks.items():
            crossings = track.get_timeline_crossings()
            for idx, from_tl, to_tl in crossings:
                if idx >= len(track.signals) - 5:  # Only recent crossings
                    recent_crossings.append({
                        "entity_id": entity_id,
                        "from_timeline": from_tl,
                        "to_timeline": to_tl,
                        "when": track.signals[idx].timestamp
                    })
        
        # Sort by recency and add to report
        recent_crossings.sort(key=lambda x: x["when"], reverse=True)
        report["recent_crossings"] = recent_crossings[:10]  # Top 10 most recent
        
        return report
    
    def _check_for_anomalies(self, entity_id: str) -> None:
        """Check for telemetry anomalies for a specific entity"""
        track = self.tracks.get(entity_id)
        if not track or len(track.signals) < 2:
            return
            
        latest = track.signals[-1]
        previous = track.signals[-2]
        
        # Check for quantum signature anomalies
        if abs(latest.coordinate.quantum_signature - previous.coordinate.quantum_signature) > 0.5:
            self.anomalies.append({
                "type": "quantum_signature_shift",
                "entity_id": entity_id,
                "timestamp": time.time(),
                "description": "Significant shift in quantum signature detected",
                "severity": "high",
                "coordinate": latest.coordinate
            })
        
        # Check for abnormal velocity
        velocity = track.get_velocity_vector()
        if velocity:
            dx, dy, dz, dt = velocity
            if dt != 0:
                spatial_velocity = math.sqrt(dx*dx + dy*dy + dz*dz) / abs(dt)
                if spatial_velocity > 10000:  # Arbitrary threshold
                    self.anomalies.append({
                        "type": "abnormal_velocity",
                        "entity_id": entity_id,
                        "timestamp": time.time(),
                        "description": f"Abnormal velocity detected: {spatial_velocity:.2f} km/day",
                        "severity": "medium",
                        "coordinate": latest.coordinate
                    })
    
    def _prune_old_data(self) -> None:
        """Remove old signals and inactive tracks"""
        self.last_prune = time.time()
        
        # Prune old signals from all tracks
        for track in self.tracks.values():
            track.prune_invalid_signals()
        
        # Remove empty tracks
        empty_tracks = [entity_id for entity_id, track in self.tracks.items() 
                       if not track.signals]
        for entity_id in empty_tracks:
            del self.tracks[entity_id]
            if entity_id in self.entity_metadata:
                del self.entity_metadata[entity_id]
    
    def simulate_entity_movement(self, 
                               entity_id: str,
                               path: List[SpaceTimeCoordinate],
                               signal_interval: float = 1.0) -> None:
        """
        Simulate an entity moving along a predefined path
        Useful for testing and demonstrations
        
        Args:
            entity_id: The entity ID to simulate
            path: List of coordinates defining the path
            signal_interval: Time between signals in seconds
        """
        import threading
        import time
        
        def _simulate_path():
            for coord in path:
                # Create a signal with slight variations
                signal = TelemetrySignal(
                    entity_id,
                    coord,
                    signal_strength=random.uniform(0.7, 1.0),
                    metadata={"simulated": True}
                )
                
                # Record the signal
                self.record_signal(signal)
                
                # Wait for the next interval
                time.sleep(signal_interval)
        
        # Start simulation in a background thread
        threading.Thread(target=_simulate_path).start()


def demo_multiverse_telemetry():
    """Run a demonstration of the multiverse telemetry system"""
    from multiverse_coordinates import CoordinateEnhancedMultiverse
    import time
    
    print("=== Multiverse Telemetry System Demo ===")
    
    # Create a multiverse
    multiverse = CoordinateEnhancedMultiverse()
    
    # Create timelines
    alpha = multiverse.create_timeline("Alpha Prime", 0.9)
    beta = multiverse.create_timeline("Beta Variant", 0.75)
    gamma = multiverse.create_timeline("Gamma Nexus", 0.6)
    
    # Create telemetry system
    telemetry = MultiverseTelemetry(multiverse)
    
    # Register some entities
    telemetry.register_entity("Explorer-1", {
        "type": "time_traveler",
        "name": "Dr. Elena Kowalski",
        "mission": "Survey of pre-industrial civilizations"
    })
    
    telemetry.register_entity("Observer-7", {
        "type": "quantum_observer",
        "name": "Quantum AI Sentinel",
        "mission": "Monitor timeline stability"
    })
    
    telemetry.register_entity("Anomaly-X", {
        "type": "unknown",
        "detection_source": "quantum scanner",
        "threat_level": "unknown"
    })
    
    # Create some coordinates for our entities
    explorer_path = [
        # Start in Alpha Prime, 2023
        SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.1, "Earth-Centered"),
            TemporalCoordinate(2023, 5, 15),
            "Alpha Prime",
            0.423
        ),
        # Travel to Alpha Prime, 1850
        SpaceTimeCoordinate(
            SpatialCoordinate(1000, 2000, 0, 0.2, "Earth-Centered"),
            TemporalCoordinate(1850, 6, 10),
            "Alpha Prime",
            0.426
        ),
        # Cross to Beta Variant, 1851
        SpaceTimeCoordinate(
            SpatialCoordinate(1100, 2100, 50, 0.3, "Earth-Centered"),
            TemporalCoordinate(1851, 1, 5),
            "Beta Variant",
            0.512
        ),
        # Travel to Beta Variant, 1870
        SpaceTimeCoordinate(
            SpatialCoordinate(1500, 2500, 100, 0.2, "Earth-Centered"),
            TemporalCoordinate(1870, 3, 15),
            "Beta Variant",
            0.515
        )
    ]
    
    observer_path = [
        # Observer stays in Alpha Prime but moves through space
        SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.05, "Earth-Centered"),
            TemporalCoordinate(2023, 5, 15),
            "Alpha Prime",
            0.777
        ),
        SpaceTimeCoordinate(
            SpatialCoordinate(1000, 0, 0, 0.05, "Earth-Centered"),
            TemporalCoordinate(2023, 5, 15),
            "Alpha Prime",
            0.778
        ),
        SpaceTimeCoordinate(
            SpatialCoordinate(1000, 1000, 0, 0.05, "Earth-Centered"),
            TemporalCoordinate(2023, 5, 15),
            "Alpha Prime",
            0.779
        ),
        SpaceTimeCoordinate(
            SpatialCoordinate(0, 1000, 0, 0.05, "Earth-Centered"),
            TemporalCoordinate(2023, 5, 15),
            "Alpha Prime",
            0.780
        )
    ]
    
    anomaly_path = [
        # The anomaly appears suddenly in Gamma Nexus
        SpaceTimeCoordinate(
            SpatialCoordinate(-5000, -3000, 2000, 0.8, "Earth-Centered"),
            TemporalCoordinate(2100, 10, 30),
            "Gamma Nexus",
            0.999
        ),
        # It exhibits erratic quantum signature behavior
        SpaceTimeCoordinate(
            SpatialCoordinate(-5100, -3100, 2100, 0.8, "Earth-Centered"),
            TemporalCoordinate(2100, 10, 30, 1, 0, 0),
            "Gamma Nexus",
            0.001  # Dramatic change in quantum signature
        ),
        # And then moves rapidly through space
        SpaceTimeCoordinate(
            SpatialCoordinate(-8000, -6000, 4000, 0.7, "Earth-Centered"),
            TemporalCoordinate(2100, 10, 30, 2, 0, 0),
            "Gamma Nexus",
            0.002
        )
    ]
    
    # Start simulations with minimal delay for demo
    telemetry.simulate_entity_movement("Explorer-1", explorer_path, 0.5)
    telemetry.simulate_entity_movement("Observer-7", observer_path, 0.7)
    telemetry.simulate_entity_movement("Anomaly-X", anomaly_path, 1.0)
    
    # Wait for some signals to accumulate
    print("Collecting telemetry data...")
    for i in range(5):
        time.sleep(1)
        print(".", end="", flush=True)
    print("\n")
    
    # Show entity positions
    print("=== Current Entity Positions ===")
    for entity_id in telemetry.tracks:
        position = telemetry.get_entity_position(entity_id)
        if position:
            print(f"{entity_id}: {position.timeline_name}, Year {position.temporal.year}")
    
    # Show timeline traffic
    print("\n=== Timeline Traffic ===")
    traffic = telemetry.calculate_timeline_traffic()
    for timeline, count in traffic.items():
        print(f"{timeline}: {count} entities")
    
    # Show future predictions
    print("\n=== Future Position Predictions (30 days ahead) ===")
    for entity_id in telemetry.tracks:
        future_pos = telemetry.predict_entity_position(entity_id, 30)
        if future_pos:
            print(f"{entity_id} predicted position: {future_pos.timeline_name}, Year {future_pos.temporal.year}")
    
    # Show detected anomalies
    print("\n=== Detected Anomalies ===")
    if telemetry.anomalies:
        for anomaly in telemetry.anomalies:
            print(f"- {anomaly['type']} - Entity: {anomaly['entity_id']}, Severity: {anomaly['severity']}")
            print(f"  {anomaly['description']}")
    else:
        print("No anomalies detected")
    
    # Generate and show report
    print("\n=== Telemetry Report ===")
    report = telemetry.generate_telemetry_report()
    print(f"Total entities: {report['total_entities']}")
    print(f"Active entities: {report['active_entities']}")
    print(f"Anomalies: {report['anomalies']}")
    
    print("\nRecent timeline crossings:")
    for crossing in report['recent_crossings']:
        print(f"- {crossing['entity_id']}: {crossing['from_timeline']} → {crossing['to_timeline']}")
    
    print("\nDemo complete!")


if __name__ == "__main__":
    demo_multiverse_telemetry()
