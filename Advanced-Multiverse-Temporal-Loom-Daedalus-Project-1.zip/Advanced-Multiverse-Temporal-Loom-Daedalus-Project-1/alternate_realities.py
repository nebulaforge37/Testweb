
"""
Alternate Realities System
This module extends the multiverse system with alternate realities 
and offers functions for reality travel and interaction.
"""

import random
import math
from typing import Dict, List, Tuple, Optional, Any, Set
from quantum_dimensions import QuantumDimension, QuantumReality, DimensionalRegistry
from temporal_coordinates import SpaceTimeCoordinate, SpatialCoordinate, TemporalCoordinate
from temporal_physics import TemporalParadoxType, ParadoxRegistry

class RealityTraveler:
    """Class representing an entity that can travel between realities"""
    
    def __init__(self, name: str, origin_dimension_id: int = 1, origin_reality_id: int = 1):
        """Initialize a reality traveler"""
        self.name = name
        self.current_dimension_id = origin_dimension_id
        self.current_reality_id = origin_reality_id
        self.dimensional_stability = 1.0  # How stable traveler is in dimensional transitions
        self.quantum_resonance = random.uniform(0.5, 1.0)  # Resonance with quantum fields
        self.reality_memory = []  # History of realities visited
        self.origin_dimension = origin_dimension_id
        self.origin_reality = origin_reality_id
        
    def record_reality_shift(self, dimension_id: int, reality_id: int):
        """Record a shift to a new reality"""
        previous = (self.current_dimension_id, self.current_reality_id)
        self.current_dimension_id = dimension_id
        self.current_reality_id = reality_id
        self.reality_memory.append((previous, (dimension_id, reality_id)))
        
        # Being far from origin dimension reduces dimensional stability
        dimension_distance = abs(dimension_id - self.origin_dimension)
        if dimension_distance > 100:
            stability_loss = min(0.1, dimension_distance / 10000)
            self.dimensional_stability = max(0.1, self.dimensional_stability - stability_loss)
    
    def calculate_dimensional_fatigue(self) -> float:
        """Calculate dimensional fatigue (high = more fatigue)"""
        # More transitions = more fatigue
        transition_factor = min(0.5, len(self.reality_memory) * 0.05)
        
        # Lower stability = more fatigue
        stability_factor = (1.0 - self.dimensional_stability) * 0.3
        
        # Lower quantum resonance = more fatigue
        resonance_factor = (1.0 - self.quantum_resonance) * 0.2
        
        return min(1.0, transition_factor + stability_factor + resonance_factor)
    
    def can_safely_travel(self) -> bool:
        """Determine if traveler can safely perform another reality transition"""
        fatigue = self.calculate_dimensional_fatigue()
        return fatigue < 0.7 and self.dimensional_stability > 0.3
    
    def __str__(self) -> str:
        current = f"D{self.current_dimension_id}:R{self.current_reality_id}"
        fatigue = self.calculate_dimensional_fatigue()
        return (f"Traveler: {self.name} - Currently in {current}, "
                f"Stability: {self.dimensional_stability:.2f}, "
                f"Fatigue: {fatigue:.2f}, "
                f"Transitions: {len(self.reality_memory)}")


class RealityCoordinate:
    """Coordinate combining quantum dimension, reality, and space-time location"""
    
    def __init__(self, 
                 dimension_id: int, 
                 reality_id: int,
                 space_time: SpaceTimeCoordinate = None,
                 reality_phase: float = None):
        """
        Initialize a reality coordinate
        
        Args:
            dimension_id: The quantum dimension
            reality_id: The specific reality
            space_time: Space-time coordinate within this reality
            reality_phase: Phase in the quantum reality (0.0-1.0)
        """
        self.dimension_id = dimension_id
        self.reality_id = reality_id
        self.space_time = space_time
        self.reality_phase = reality_phase or random.random()
    
    @classmethod
    def from_dimension(cls, dimension_id: int, reality_id: int, 
                      year: int = None, timeline_name: str = "Alpha Prime"):
        """Create a reality coordinate from dimension and reality IDs"""
        # Create default space-time coordinate if not specified
        if year is None:
            year = random.randint(1900, 2200)
            
        space_time = SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.1, "Earth-Centered"),
            TemporalCoordinate(year),
            timeline_name,
            random.random()
        )
        
        return cls(dimension_id, reality_id, space_time)
    
    def calculate_distance(self, other: 'RealityCoordinate') -> float:
        """Calculate 'distance' between reality coordinates"""
        # Different dimensions are very distant
        if self.dimension_id != other.dimension_id:
            dimension_distance = abs(self.dimension_id - other.dimension_id) / 1000
            base_distance = 5.0 + dimension_distance
        else:
            base_distance = 0.0
            
        # Different realities add distance
        if self.reality_id != other.reality_id:
            base_distance += 1.0
            
        # Add space-time distance if both coordinates have space-time
        if self.space_time and other.space_time:
            # Calculate temporal distance in years
            days = self.space_time.temporal.days_between(other.space_time.temporal) or 0
            years_diff = abs(days) / 365.0
            
            # Scale years to a reasonable distance value
            temporal_distance = min(3.0, years_diff / 100)
            
            # Add spatial distance if same reference system
            if (self.space_time.spatial.reference_system == 
                other.space_time.spatial.reference_system):
                spatial_distance = min(1.0, self.space_time.spatial.distance_to(
                    other.space_time.spatial) / 10000)
            else:
                spatial_distance = 0.5  # Different reference systems
                
            base_distance += temporal_distance + spatial_distance
            
        # Reality phase difference (quantum phase)
        phase_diff = abs(self.reality_phase - other.reality_phase)
        phase_distance = phase_diff * 0.5
        
        return base_distance + phase_distance
    
    def __str__(self) -> str:
        dim_reality = f"D{self.dimension_id}:R{self.reality_id}"
        if self.space_time:
            return f"{dim_reality} @ {self.space_time.temporal.year} (Phase: {self.reality_phase:.2f})"
        else:
            return f"{dim_reality} (Phase: {self.reality_phase:.2f})"


class RealityTransitEvent:
    """Represents a transit event between realities"""
    
    def __init__(self, 
                 traveler_name: str,
                 origin: RealityCoordinate, 
                 destination: RealityCoordinate,
                 success: bool,
                 stability_factor: float,
                 side_effects: List[str] = None):
        """Initialize a reality transit event"""
        self.traveler_name = traveler_name
        self.origin = origin
        self.destination = destination
        self.success = success
        self.stability_factor = stability_factor
        self.side_effects = side_effects or []
        self.timestamp = random.randint(1000000000, 9999999999)  # Random timestamp
    
    def generate_report(self) -> str:
        """Generate a report of this transit event"""
        status = "SUCCESS" if self.success else "FAILURE"
        
        report = [
            f"REALITY TRANSIT EVENT REPORT [{status}]",
            f"Traveler: {self.traveler_name}",
            f"Origin: {self.origin}",
            f"Destination: {self.destination}",
            f"Stability Factor: {self.stability_factor:.2f}"
        ]
        
        if self.side_effects:
            report.append("Side Effects:")
            for effect in self.side_effects:
                report.append(f"  - {effect}")
        else:
            report.append("Side Effects: None")
            
        return "\n".join(report)
    
    def __str__(self) -> str:
        success_str = "✓" if self.success else "✗"
        return (f"Transit [{success_str}]: {self.traveler_name} - "
                f"{self.origin.dimension_id}:{self.origin.reality_id} → "
                f"{self.destination.dimension_id}:{self.destination.reality_id}")


class RealityManager:
    """
    Manager class for handling reality creation, travel and interaction
    between the multiverse and quantum dimensions
    """
    
    def __init__(self, dimensional_registry: DimensionalRegistry = None):
        """Initialize the reality manager"""
        self.registry = dimensional_registry or DimensionalRegistry()
        self.travelers: Dict[str, RealityTraveler] = {}
        self.transit_events: List[RealityTransitEvent] = []
        self.paradox_registry = ParadoxRegistry()
        
        # Reality breach points (where realities are thin/connecting)
        self.reality_breach_points: List[Tuple[RealityCoordinate, RealityCoordinate, float]] = []
    
    def initialize_dimensions(self, count: int = 50, max_id: int = 10000):
        """Initialize quantum dimensions in the registry"""
        return self.registry.initialize_dimensions(count, max_id)
    
    def register_traveler(self, name: str, origin_dimension_id: int = 1, 
                        origin_reality_id: int = 1) -> RealityTraveler:
        """Register a new reality traveler"""
        traveler = RealityTraveler(name, origin_dimension_id, origin_reality_id)
        self.travelers[name] = traveler
        return traveler
    
    def create_reality_breach(self, origin: RealityCoordinate, 
                            destination: RealityCoordinate, 
                            stability: float = None) -> float:
        """
        Create a breach between two reality points
        Returns the stability of the breach
        """
        if stability is None:
            # Calculate stability based on distance
            distance = origin.calculate_distance(destination)
            stability = max(0.1, min(0.9, 1.0 - (distance / 10.0)))
        
        self.reality_breach_points.append((origin, destination, stability))
        return stability
    
    def perform_reality_travel(self, traveler_name: str, 
                             destination_dimension: int, 
                             destination_reality: int,
                             use_breach: bool = False) -> RealityTransitEvent:
        """
        Perform travel from traveler's current reality to a destination reality
        Returns the transit event
        """
        # Get the traveler
        traveler = self.travelers.get(traveler_name)
        if not traveler:
            # Create a new traveler if not found
            traveler = self.register_traveler(traveler_name)
            
        # Get dimensions and realities
        origin_dimension = self.registry.get_dimension(traveler.current_dimension_id)
        origin_reality = self.registry.get_reality(traveler.current_reality_id)
        dest_dimension = self.registry.get_dimension(destination_dimension)
        dest_reality = self.registry.get_reality(destination_reality)
        
        if not origin_dimension or not origin_reality or not dest_dimension or not dest_reality:
            # Missing dimension or reality, travel fails
            origin_coord = RealityCoordinate.from_dimension(
                traveler.current_dimension_id, traveler.current_reality_id)
            dest_coord = RealityCoordinate.from_dimension(
                destination_dimension, destination_reality)
                
            event = RealityTransitEvent(
                traveler_name, origin_coord, dest_coord, False, 0.0,
                ["Invalid dimension or reality ID"]
            )
            self.transit_events.append(event)
            return event
        
        # Create origin and destination coordinates
        origin_coord = RealityCoordinate.from_dimension(
            traveler.current_dimension_id, traveler.current_reality_id)
        dest_coord = RealityCoordinate.from_dimension(
            destination_dimension, destination_reality)
            
        # Check if traveler can safely travel
        if not traveler.can_safely_travel():
            # Traveler is experiencing too much dimensional fatigue
            event = RealityTransitEvent(
                traveler_name, origin_coord, dest_coord, False, 0.0,
                ["Traveler experiencing severe dimensional fatigue", 
                 f"Dimensional stability at {traveler.dimensional_stability:.2f}"]
            )
            self.transit_events.append(event)
            return event
        
        # Calculate travel difficulty
        difficulty, reason = self.registry.calculate_dimensional_travel_difficulty(
            traveler.current_dimension_id, destination_dimension)
            
        # Check for reality breaches that might help
        breach_stability = 0.0
        if use_breach:
            for breach_origin, breach_dest, stability in self.reality_breach_points:
                if (breach_origin.dimension_id == traveler.current_dimension_id and
                    breach_origin.reality_id == traveler.current_reality_id and
                    breach_dest.dimension_id == destination_dimension and
                    breach_dest.reality_id == destination_reality):
                    
                    breach_stability = stability
                    break
        
        # Calculate overall success probability
        if breach_stability > 0:
            # Using a breach makes travel easier
            success_probability = 0.7 + (breach_stability * 0.3)
            difficulty_modifier = f"Using reality breach (stability: {breach_stability:.2f})"
        else:
            # Normal travel
            success_probability = 1.0 - difficulty
            difficulty_modifier = reason
            
        # Adjust based on traveler's stability
        success_probability *= traveler.dimensional_stability
        
        # Determine success
        success = random.random() < success_probability
        
        # Possible side effects
        side_effects = []
        if difficulty > 0.6 or not success:
            # Generate side effects
            possible_effects = [
                "Quantum dispersion causing memory fragments",
                "Temporal displacement by ±" + str(random.randint(1, 100)) + " hours",
                "Reality echo creating duplicate memory traces",
                "Partial quantum entanglement with origin reality",
                "Dimensional sickness (fatigue, disorientation)",
                "Reality perception shift",
                "Temporal perception alterations",
                "Quantum field hypersensitivity"
            ]
            
            # More difficult travels have more side effects
            effect_count = random.randint(0, 3 if difficulty > 0.8 else 
                                         2 if difficulty > 0.6 else 1)
            
            if effect_count > 0:
                side_effects = random.sample(possible_effects, effect_count)
        
        # Add the difficulty explanation
        if difficulty_modifier:
            side_effects.append(f"Travel difficulty: {difficulty_modifier}")
            
        # Create the transit event
        event = RealityTransitEvent(
            traveler_name, origin_coord, dest_coord, success, 
            success_probability, side_effects
        )
        
        # Update traveler's state
        if success:
            traveler.record_reality_shift(destination_dimension, destination_reality)
            # Add events to both origin and destination realities
            origin_reality.add_event(f"Traveler {traveler_name} departed to D{destination_dimension}:R{destination_reality}")
            dest_reality.add_event(f"Traveler {traveler_name} arrived from D{traveler.current_dimension_id}:R{traveler.current_reality_id}")
            
        # Record the event
        self.transit_events.append(event)
        return event
    
    def find_nearby_realities(self, dimension_id: int, reality_id: int, 
                            count: int = 5) -> List[Tuple[QuantumReality, float]]:
        """Find nearby realities to the specified reality"""
        current_reality = self.registry.get_reality(reality_id)
        if not current_reality:
            return []
            
        # Get all realities from the same dimension first
        dimension = self.registry.get_dimension(dimension_id)
        if not dimension:
            return []
            
        same_dimension_realities = [
            (r, r.calculate_compatibility(current_reality))
            for r in dimension.realities.values()
            if r.reality_id != reality_id
        ]
        
        # Sort by compatibility (higher is closer)
        same_dimension_realities.sort(key=lambda x: x[1], reverse=True)
        
        # If we need more, add some from other dimensions
        if len(same_dimension_realities) < count:
            # Find connected dimensions
            connected_dims = [gate_id for gate_id, _ in dimension.dimensional_gates]
            
            other_realities = []
            for dim_id in connected_dims:
                dim = self.registry.get_dimension(dim_id)
                if dim:
                    for r in dim.realities.values():
                        # More distant because different dimension
                        compatibility = r.calculate_compatibility(current_reality) * 0.7
                        other_realities.append((r, compatibility))
            
            other_realities.sort(key=lambda x: x[1], reverse=True)
            combined = same_dimension_realities + other_realities
        else:
            combined = same_dimension_realities
            
        return combined[:count]
    
    def generate_reality_report(self) -> str:
        """Generate a report of reality statistics"""
        total_dimensions = len(self.registry.dimensions)
        total_realities = len(self.registry.realities)
        total_travelers = len(self.travelers)
        total_transits = len(self.transit_events)
        
        # Count successful transits
        successful_transits = sum(1 for event in self.transit_events if event.success)
        
        report = [
            "REALITY SYSTEM STATUS REPORT",
            f"Total Quantum Dimensions: {total_dimensions}",
            f"Total Alternate Realities: {total_realities}",
            f"Registered Reality Travelers: {total_travelers}",
            f"Reality Transit Events: {total_transits} (Success rate: {successful_transits/max(1,total_transits):.1%})",
            f"Reality Breach Points: {len(self.reality_breach_points)}"
        ]
        
        # Get unstable dimensions
        unstable = self.registry.get_most_unstable_dimensions(3)
        if unstable:
            report.append("\nMost Unstable Dimensions:")
            for dim in unstable:
                report.append(f"  - {dim.dimension_id}: {dim.name} (Stability: {dim.stability:.2f})")
        
        # Get active travelers
        if self.travelers:
            report.append("\nActive Reality Travelers:")
            for name, traveler in self.travelers.items():
                report.append(f"  - {traveler}")
        
        return "\n".join(report)
    
    def create_random_reality(self, dimension_id: int = None) -> QuantumReality:
        """Create a new random reality in a random or specified dimension"""
        if dimension_id is None:
            # Choose a random dimension
            dimension_id = random.choice(list(self.registry.dimensions.keys()))
            
        return self.registry.create_reality(dimension_id)
    
    def __str__(self) -> str:
        return f"Reality Manager: {len(self.registry.dimensions)} dimensions, {len(self.registry.realities)} realities"
