
"""
Multiversal Synchronicity Events
This module handles events that occur simultaneously across multiple timelines,
creating resonance patterns in the multiverse.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any
import time

class SynchronicityEvent:
    """Represents a synchronicity event occurring across multiple timelines"""
    
    def __init__(self, event_id: int, name: str, description: str, magnitude: float = 0.5):
        """
        Initialize a synchronicity event
        
        Args:
            event_id: Unique identifier for this event
            name: Name of this synchronicity event
            description: Description of the event
            magnitude: Power/magnitude of the synchronicity (0.0-1.0)
        """
        self.event_id = event_id
        self.name = name
        self.event_type = random.choice(["Quantum", "Temporal", "Spatial", "Paradoxical", "Causal"])
        self.description = description
        self.magnitude = magnitude
        self.affected_timelines = []
        self.creation_timestamp = time.time()
        self.duration = random.uniform(1.0, 10.0) * magnitude  # Duration in arbitrary units
        self.peak_time = None  # When the event reaches peak intensity
        self.resolution_status = "Pending"  # Pending, Active, Resolved, Failed
        
        # Event-specific properties
        self.resonance_pattern = random.random()  # Unique pattern for this event
        self.quantum_signature = random.random()  # Quantum signature
        self.effects = {}  # Timeline-specific effects
        
    def add_affected_timeline(self, timeline_name: str, year: int,
                            effect_description: str = None):
        """Add a timeline affected by this synchronicity event"""
        effect = effect_description or f"Synchronicity event: {self.name}"
        
        self.affected_timelines.append({
            "timeline": timeline_name,
            "year": year,
            "effect": effect,
            "intensity": random.uniform(0.7, 1.0) * self.magnitude,
            "status": "Pending"
        })
        
    def activate(self):
        """Activate the synchronicity event across all affected timelines"""
        if not self.affected_timelines:
            return False
            
        self.peak_time = time.time() + (self.duration / 2)
        self.resolution_status = "Active"
        
        for timeline in self.affected_timelines:
            timeline["status"] = "Active"
            
        return True
        
    def calculate_current_intensity(self) -> float:
        """Calculate the current intensity of the event based on time"""
        if self.resolution_status != "Active" or not self.peak_time:
            return 0.0
            
        time_to_peak = abs(time.time() - self.peak_time)
        half_duration = self.duration / 2
        
        if time_to_peak > half_duration:
            # Event is ending
            self.resolution_status = "Resolved"
            return 0.0
            
        # Bell curve intensity
        normalized_time = time_to_peak / half_duration
        intensity = math.exp(-(normalized_time ** 2) * 4) * self.magnitude
        
        return intensity
        
    def get_effect_for_timeline(self, timeline_name: str) -> Dict[str, Any]:
        """Get the specific effect for a timeline"""
        for timeline in self.affected_timelines:
            if timeline["timeline"] == timeline_name:
                intensity = timeline["intensity"] * self.calculate_current_intensity()
                
                return {
                    "intensity": intensity,
                    "effect": timeline["effect"],
                    "status": timeline["status"]
                }
                
        return {
            "intensity": 0.0,
            "effect": "No effect",
            "status": "Unaffected"
        }
        
    def resolve(self, success: bool = True):
        """Resolve the synchronicity event"""
        self.resolution_status = "Resolved" if success else "Failed"
        
        for timeline in self.affected_timelines:
            timeline["status"] = "Resolved" if success else "Failed"
            
    def __str__(self) -> str:
        status_str = f"[{self.resolution_status}]"
        intensity = self.calculate_current_intensity()
        return f"{self.name} {status_str} - {self.event_type} Synchronicity (Magnitude: {self.magnitude:.2f}, Current Intensity: {intensity:.2f})"


class SynchronicityManager:
    """Manages synchronicity events across the multiverse"""
    
    def __init__(self, multiverse = None):
        """Initialize the synchronicity manager"""
        self.multiverse = multiverse
        self.events = {}
        self.active_events = []
        self.next_event_id = 1
        self.templates = self._initialize_templates()
        
    def _initialize_templates(self) -> List[Dict[str, Any]]:
        """Initialize event templates"""
        return [
            {
                "name": "Quantum Resonance Cascade",
                "description": "A cascading resonance in quantum fields causing synchronized phenomena",
                "magnitude_range": (0.6, 0.9),
                "timeline_count": (3, 7),
                "effects": [
                    "Quantum field distortion causing parallel events",
                    "Synchronized quantum collapse across realities",
                    "Reality echoes manifesting identical outcomes",
                    "Quantum entanglement causing mirrored decisions"
                ]
            },
            {
                "name": "Temporal Lightning Storm",
                "description": "Simultaneous temporal discharge across multiple timelines",
                "magnitude_range": (0.5, 0.8),
                "timeline_count": (2, 5),
                "effects": [
                    "Temporal lightning strikes causing time skips",
                    "Chronological distortions creating time loops",
                    "Synchronized time dilation events",
                    "Temporal energy discharges freezing moments in time"
                ]
            },
            {
                "name": "Causal Convergence",
                "description": "Multiple timelines experience the same causal chain spontaneously",
                "magnitude_range": (0.4, 0.7),
                "timeline_count": (4, 8),
                "effects": [
                    "Identical events unfolding regardless of timeline differences",
                    "Causal chains aligning across divergent histories",
                    "Convergent evolution of critical moments",
                    "Synchronized decision points creating multiversal nodes"
                ]
            },
            {
                "name": "Reality Echo",
                "description": "Echoing of a significant event across multiple realities",
                "magnitude_range": (0.3, 0.6),
                "timeline_count": (5, 10),
                "effects": [
                    "Ghostly echoes of events appearing in multiple timelines",
                    "Shadow manifestations of alternate decisions",
                    "Phantom reality overlaps showing what might have been",
                    "Deja vu phenomena experienced by multiple timeline inhabitants"
                ]
            },
            {
                "name": "Paradox Wave",
                "description": "A wave of paradoxical energy affecting multiple points in the multiverse",
                "magnitude_range": (0.7, 1.0),
                "timeline_count": (2, 4),
                "effects": [
                    "Paradoxical energy causing timeline contradictions",
                    "Causal loops forming spontaneously",
                    "Bootstrap paradoxes manifesting identical artifacts",
                    "Grandfather paradoxes creating quantum uncertainty bubbles"
                ]
            }
        ]
        
    def create_random_event(self) -> SynchronicityEvent:
        """Create a random synchronicity event"""
        # Select a random template
        template = random.choice(self.templates)
        
        # Generate event from template
        name = template["name"]
        description = template["description"]
        magnitude = random.uniform(*template["magnitude_range"])
        
        event = SynchronicityEvent(self.next_event_id, name, description, magnitude)
        self.next_event_id += 1
        
        # Add to registry
        self.events[event.event_id] = event
        
        # Determine number of affected timelines
        if self.multiverse and hasattr(self.multiverse, 'timelines'):
            available_timelines = list(self.multiverse.timelines.keys())
            
            if available_timelines:
                timeline_count = min(len(available_timelines), 
                                   random.randint(*template["timeline_count"]))
                
                # Select random timelines
                selected_timelines = random.sample(available_timelines, timeline_count)
                
                # Add each timeline with a random effect
                for timeline_name in selected_timelines:
                    effect = random.choice(template["effects"])
                    year = random.randint(2000, 2100)  # Random year
                    
                    event.add_affected_timeline(timeline_name, year, effect)
                    
                    # Add the event to the timeline if possible
                    if self.multiverse and timeline_name in self.multiverse.timelines:
                        timeline = self.multiverse.timelines[timeline_name]
                        timeline.add_event(f"SYNCHRONICITY: {name} - {effect}", year)
        
        return event
        
    def activate_event(self, event_id: int) -> bool:
        """Activate a specific synchronicity event"""
        event = self.events.get(event_id)
        if not event:
            return False
            
        success = event.activate()
        if success:
            self.active_events.append(event)
            
        return success
        
    def update_all_events(self):
        """Update all active events and remove completed ones"""
        remaining_active = []
        
        for event in self.active_events:
            intensity = event.calculate_current_intensity()
            
            if intensity > 0:
                remaining_active.append(event)
            else:
                # Event has completed
                event.resolve(True)
                
        self.active_events = remaining_active
        
    def get_active_effects(self, timeline_name: str) -> List[Dict[str, Any]]:
        """Get all active effects for a specific timeline"""
        effects = []
        
        for event in self.active_events:
            effect = event.get_effect_for_timeline(timeline_name)
            if effect["intensity"] > 0:
                effects.append({
                    "event_id": event.event_id,
                    "event_name": event.name,
                    "event_type": event.event_type,
                    "intensity": effect["intensity"],
                    "effect": effect["effect"]
                })
                
        return effects
        
    def get_event(self, event_id: int) -> Optional[SynchronicityEvent]:
        """Get an event by ID"""
        return self.events.get(event_id)
        
    def get_events_report(self) -> str:
        """Generate a report of all events"""
        if not self.events:
            return "No synchronicity events recorded."
            
        report = ["=== MULTIVERSAL SYNCHRONICITY REPORT ==="]
        
        active_count = len(self.active_events)
        total_count = len(self.events)
        report.append(f"Active Events: {active_count}")
        report.append(f"Total Events: {total_count}")
        
        if self.active_events:
            report.append("\nCurrent Active Events:")
            for event in self.active_events:
                intensity = event.calculate_current_intensity()
                affected = len(event.affected_timelines)
                report.append(f"- {event.name} ({event.event_type}): Affecting {affected} timelines, Intensity: {intensity:.2f}")
                
        report.append("\nEvent History:")
        for event_id, event in sorted(self.events.items()):
            if event.resolution_status != "Pending":
                affected = len(event.affected_timelines)
                report.append(f"- {event.name} [{event.resolution_status}]: Affected {affected} timelines, Magnitude: {event.magnitude:.2f}")
                
        return "\n".join(report)


def run_synchronicity_demo(multiverse=None):
    """Run a demonstration of synchronicity events"""
    print("=== Multiversal Synchronicity Events Demonstration ===")
    
    # Create manager
    manager = SynchronicityManager(multiverse)
    
    # Create a few random events
    print("\nGenerating random synchronicity events...")
    events = []
    for i in range(3):
        event = manager.create_random_event()
        events.append(event)
        print(f"Created: {event}")
        
        # Show affected timelines
        for timeline in event.affected_timelines:
            print(f"  > {timeline['timeline']} ({timeline['year']}): {timeline['effect']}")
    
    # Activate an event
    if events:
        event = events[0]
        print(f"\nActivating event: {event.name}...")
        manager.activate_event(event.event_id)
        
        # Show initial intensity
        intensity = event.calculate_current_intensity()
        print(f"Initial intensity: {intensity:.2f}")
        
        # Simulate the passage of time
        print("\nSimulating event progression...")
        for i in range(5):
            # Simulate time passing
            event.peak_time = time.time() - (event.duration * (i / 10))
            
            # Update
            manager.update_all_events()
            
            # Show current intensity
            intensity = event.calculate_current_intensity()
            print(f"Time {i+1}: Intensity = {intensity:.2f}")
            
            # Show effects on some timelines
            if event.affected_timelines:
                timeline = event.affected_timelines[0]["timeline"]
                effect = event.get_effect_for_timeline(timeline)
                print(f"  Effect on {timeline}: {effect['effect']} (Intensity: {effect['intensity']:.2f})")
    
    # Generate report
    print("\n" + manager.get_events_report())
    
    return manager


if __name__ == "__main__":
    run_synchronicity_demo()
