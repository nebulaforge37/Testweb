
#!/usr/bin/env python3
"""
Multiverse GPS Demonstration
This script demonstrates the GPS-like navigation system across the multiverse.
"""

import os
import sys
import time
import random
import math
from typing import List, Dict, Tuple, Optional

# Import required modules
from temporal_coordinates import SpatialCoordinate, TemporalCoordinate, SpaceTimeCoordinate
from multiverse_coordinates import CoordinateEnhancedMultiverse, CoordinateEnhancedTimeline
from multiverse_telemetry import MultiverseTelemetry, TelemetrySignal

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class MultiverseGPS:
    """GPS-like navigation system for the multiverse"""
    
    def __init__(self, multiverse: CoordinateEnhancedMultiverse, telemetry: MultiverseTelemetry):
        self.multiverse = multiverse
        self.telemetry = telemetry
        self.waypoints = {}
        self.navigation_history = []
        
    def add_waypoint(self, name: str, coordinate: SpaceTimeCoordinate, description: str = None):
        """Add a navigation waypoint"""
        self.waypoints[name] = {
            "coordinate": coordinate,
            "description": description,
            "added_timestamp": time.time()
        }
        
    def calculate_route(self, 
                       start: SpaceTimeCoordinate, 
                       end: SpaceTimeCoordinate,
                       max_jumps: int = 3,
                       safe_route: bool = True) -> List[SpaceTimeCoordinate]:
        """
        Calculate a route from start to end coordinates
        
        Args:
            start: Starting coordinate
            end: Destination coordinate
            max_jumps: Maximum number of intermediate stops
            safe_route: If True, prefer safer routes over shorter ones
        
        Returns:
            List of coordinates forming the route
        """
        # Start with direct route
        direct_route = [start, end]
        direct_risk = start.stability_risk(end)
        
        # If direct route is safe enough or we don't care about safety, return it
        if direct_risk < 0.3 or not safe_route:
            return direct_route
            
        # Find stable routes using coordinate registry
        routes = self.multiverse.coordinate_registry.find_stable_routes(start, end, max_jumps)
        
        if not routes:
            # If no routes found, use waypoints as potential intermediate points
            custom_routes = []
            
            for name, waypoint_data in self.waypoints.items():
                waypoint = waypoint_data["coordinate"]
                
                # Check if this waypoint makes a good intermediate point
                to_waypoint_risk = start.stability_risk(waypoint)
                from_waypoint_risk = waypoint.stability_risk(end)
                
                if to_waypoint_risk < 0.5 and from_waypoint_risk < 0.5:
                    custom_routes.append([start, waypoint, end])
            
            if custom_routes:
                # Find the safest route
                safest_route = None
                lowest_max_risk = 1.0
                
                for route in custom_routes:
                    max_risk = max(route[0].stability_risk(route[1]), 
                                  route[1].stability_risk(route[2]))
                    
                    if max_risk < lowest_max_risk:
                        lowest_max_risk = max_risk
                        safest_route = route
                
                if safest_route:
                    return safest_route
            
            # If still no good route, return direct route
            return direct_route
        
        # Convert the best route to a list of coordinates
        best_route = routes[0]  # First route is the most stable
        route_coords = [start]
        
        for name, coord in best_route:
            route_coords.append(coord)
        
        return route_coords
    
    def navigate_entity(self, 
                       entity_id: str, 
                       destination: SpaceTimeCoordinate,
                       safe_route: bool = True) -> Dict:
        """
        Navigate an entity to a destination
        
        Args:
            entity_id: ID of the entity to navigate
            destination: Destination coordinate
            safe_route: If True, prefer safer routes
            
        Returns:
            Navigation details dictionary
        """
        # First check if entity exists in telemetry
        current_position = self.telemetry.get_entity_position(entity_id)
        if not current_position:
            return {
                "success": False,
                "message": f"Entity {entity_id} not found in telemetry"
            }
        
        # Calculate route
        route = self.calculate_route(current_position, destination, safe_route=safe_route)
        
        # Calculate route statistics
        total_distance = 0
        max_risk = 0
        jumps = len(route) - 1
        
        for i in range(jumps):
            from_coord = route[i]
            to_coord = route[i+1]
            
            total_distance += from_coord.calculate_transit_energy(to_coord)
            risk = from_coord.stability_risk(to_coord)
            max_risk = max(max_risk, risk)
        
        # Record navigation in history
        navigation_record = {
            "timestamp": time.time(),
            "entity_id": entity_id,
            "from": current_position,
            "to": destination,
            "route_length": len(route),
            "distance": total_distance,
            "max_risk": max_risk
        }
        self.navigation_history.append(navigation_record)
        
        # Return navigation details
        return {
            "success": True,
            "entity_id": entity_id,
            "route": route,
            "waypoints": len(route),
            "distance": total_distance,
            "max_risk": max_risk,
            "estimated_energy": total_distance * (1 + max_risk)
        }
    
    def find_nearest_entity(self, coordinate: SpaceTimeCoordinate, max_distance: float = 1000) -> Optional[str]:
        """Find the nearest entity to a coordinate"""
        entities = self.telemetry.get_entities_near_coordinate(
            coordinate, 
            spatial_radius=max_distance,
            temporal_radius_days=365  # Within a year
        )
        
        if entities:
            return entities[0][0]  # Return closest entity ID
        return None
    
    def generate_coordinate_from_description(self, description: str) -> Optional[SpaceTimeCoordinate]:
        """
        Generate a coordinate from a natural language description
        This is a simplified version that looks for key patterns
        """
        import re
        
        # Look for timeline name
        timeline_match = re.search(r"(Alpha Prime|Beta Variant|Gamma Nexus|Delta Flux|Omega Point)", description)
        timeline_name = timeline_match.group(1) if timeline_match else "Alpha Prime"
        
        # Look for year
        year_match = re.search(r"(\d{4})", description)
        year = int(year_match.group(1)) if year_match else 2023
        
        # Look for location mentions
        spatial_x, spatial_y, spatial_z = 0, 0, 0
        
        if "earth" in description.lower() or "earth-centered" in description.lower():
            reference_system = "Earth-Centered"
            # Random position near Earth
            spatial_x = random.uniform(-100, 100) 
            spatial_y = random.uniform(-100, 100)
            spatial_z = random.uniform(-100, 100)
        elif "moon" in description.lower() or "lunar" in description.lower():
            reference_system = "Moon-Centered"
            # Position near Moon
            spatial_x = random.uniform(-10, 10)
            spatial_y = random.uniform(-10, 10)
            spatial_z = random.uniform(-10, 10)
        elif "mars" in description.lower():
            reference_system = "Mars-Centered"
            spatial_x = random.uniform(-20, 20)
            spatial_y = random.uniform(-20, 20)
            spatial_z = random.uniform(-20, 20)
        else:
            reference_system = "Earth-Centered"
            # Random position in wider space
            spatial_x = random.uniform(-5000, 5000)
            spatial_y = random.uniform(-5000, 5000)
            spatial_z = random.uniform(-5000, 5000)
        
        # Create spatial coordinate
        spatial = SpatialCoordinate(
            spatial_x, spatial_y, spatial_z,
            0.2,  # Some uncertainty
            reference_system
        )
        
        # Create temporal coordinate
        temporal = TemporalCoordinate.from_year(year, 5.0)  # 5 days uncertainty
        
        # Create space-time coordinate
        return SpaceTimeCoordinate(
            spatial, temporal, timeline_name, random.random()
        )


def run_multiverse_gps_demo():
    """Run a demonstration of the Multiverse GPS system"""
    clear_screen()
    print("=== Multiverse GPS Navigation System Demo ===")
    print("Initializing simulation environment...")
    
    # Create multiverse and telemetry systems
    multiverse = CoordinateEnhancedMultiverse()
    telemetry = MultiverseTelemetry(multiverse)
    gps = MultiverseGPS(multiverse, telemetry)
    
    # Create timelines
    print("\nCreating timelines...")
    alpha = multiverse.create_timeline("Alpha Prime", 0.9)
    beta = multiverse.create_timeline("Beta Variant", 0.75) 
    gamma = multiverse.create_timeline("Gamma Nexus", 0.6)
    
    # Register tracked entities
    print("\nRegistering tracked entities...")
    entities = [
        ("Explorer-1", "Time traveler expedition team"),
        ("Research-Vessel-42", "Quantum research ship"),
        ("Diplomat-7", "Cross-timeline ambassador"),
        ("Maintenance-Bot-X", "Timeline stability maintenance robot")
    ]
    
    for entity_id, description in entities:
        telemetry.register_entity(entity_id, {"description": description})
    
    # Create some initial positions
    print("\nInitializing entity positions...")
    initial_positions = {
        "Explorer-1": SpaceTimeCoordinate(
            SpatialCoordinate(100, 200, 50, 0.1, "Earth-Centered"),
            TemporalCoordinate(2023, 6, 15),
            "Alpha Prime",
            0.423
        ),
        "Research-Vessel-42": SpaceTimeCoordinate(
            SpatialCoordinate(5000, 3000, 1000, 0.05, "Earth-Centered"),
            TemporalCoordinate(2045, 3, 10),
            "Beta Variant", 
            0.567
        ),
        "Diplomat-7": SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.01, "Mars-Centered"),
            TemporalCoordinate(2050, 8, 22),
            "Gamma Nexus",
            0.789
        ),
        "Maintenance-Bot-X": SpaceTimeCoordinate(
            SpatialCoordinate(-2000, -1000, -500, 0.2, "Earth-Centered"),
            TemporalCoordinate(1999, 12, 31, 23, 59, 59),
            "Alpha Prime",
            0.321
        )
    }
    
    # Record initial signals
    for entity_id, position in initial_positions.items():
        signal = TelemetrySignal(entity_id, position)
        telemetry.record_signal(signal)
    
    # Add some navigation waypoints
    print("\nAdding navigation waypoints...")
    waypoints = [
        ("Alpha-Earth-2000", SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.01, "Earth-Centered"),
            TemporalCoordinate(2000, 1, 1),
            "Alpha Prime",
            0.5
        ), "Standard reference point at Earth, year 2000"),
        
        ("Beta-Mars-Colony", SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.01, "Mars-Centered"),
            TemporalCoordinate(2045, 5, 15),
            "Beta Variant",
            0.5
        ), "Mars Colony in Beta timeline"),
        
        ("Quantum-Nexus-Core", SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 6371, 0.01, "Earth-Centered"),
            TemporalCoordinate(2100, 1, 1),
            "Gamma Nexus",
            0.99
        ), "The quantum nexus core point"),
        
        ("Ancient-Rome", SpaceTimeCoordinate(
            SpatialCoordinate(1500, 1200, 0, 0.3, "Earth-Centered"),
            TemporalCoordinate(44, 3, 15, 12, 0, 0, 0, "Julian"),
            "Alpha Prime",
            0.5
        ), "Ancient Rome, Ides of March")
    ]
    
    for name, coordinate, description in waypoints:
        gps.add_waypoint(name, coordinate, description)
        # Also add to multiverse registry
        multiverse.coordinate_registry.add_historical_event(name, coordinate)
    
    # Main demo
    print("\nMultiverse GPS system initialized!")
    time.sleep(1)
    
    # Demonstrate natural language destination generation
    print("\n=== Natural Language Destination Generation ===")
    descriptions = [
        "Earth in Alpha Prime, year 2050",
        "Mars colony in Beta Variant, 2045",
        "The quantum anomaly in Gamma Nexus, 2100",
        "Moon landing site, Alpha Prime, 1969"
    ]
    
    for desc in descriptions:
        coord = gps.generate_coordinate_from_description(desc)
        print(f"\nDescription: '{desc}'")
        print(f"Generated coordinate: {coord.timeline_name}, year {coord.temporal.year}")
        print(f"Position: {coord.spatial}")
    
    # Demonstrate navigation
    print("\n=== Navigation Examples ===")
    
    # Example 1: Navigate Explorer-1 to Mars Colony
    print("\nExample 1: Navigating Explorer-1 to Mars Colony in Beta Variant")
    destination = gps.waypoints["Beta-Mars-Colony"]["coordinate"]
    nav_result = gps.navigate_entity("Explorer-1", destination)
    
    if nav_result["success"]:
        print(f"Route calculated with {nav_result['waypoints']} waypoints")
        print(f"Total distance: {nav_result['distance']:.2f} units")
        print(f"Maximum risk factor: {nav_result['max_risk']:.2f}")
        print(f"Estimated energy required: {nav_result['estimated_energy']:.2f} units")
        
        print("\nDetailed route:")
        for i, coord in enumerate(nav_result["route"]):
            print(f"  {i+1}. {coord.timeline_name}, {coord.temporal.year} - {coord.spatial.reference_system}")
    else:
        print(f"Navigation failed: {nav_result['message']}")
    
    # Example 2: Navigate to a challenging destination
    print("\nExample 2: Navigating Diplomat-7 to Ancient Rome (challenging destination)")
    destination = gps.waypoints["Ancient-Rome"]["coordinate"]
    nav_result = gps.navigate_entity("Diplomat-7", destination, safe_route=True)
    
    if nav_result["success"]:
        print(f"Route calculated with {nav_result['waypoints']} waypoints")
        print(f"Total distance: {nav_result['distance']:.2f} units")
        print(f"Maximum risk factor: {nav_result['max_risk']:.2f}")
        print(f"Estimated energy required: {nav_result['estimated_energy']:.2f} units")
        
        print("\nDetailed route:")
        for i, coord in enumerate(nav_result["route"]):
            print(f"  {i+1}. {coord.timeline_name}, {coord.temporal.year} - {coord.spatial.reference_system}")
    else:
        print(f"Navigation failed: {nav_result['message']}")
    
    # Find nearest entity to a point
    print("\n=== Find Nearest Entity ===")
    search_point = SpaceTimeCoordinate(
        SpatialCoordinate(0, 0, 0, 0.1, "Earth-Centered"),
        TemporalCoordinate(2023, 1, 1),
        "Alpha Prime",
        0.5
    )
    
    print(f"Searching for entities near Earth in Alpha Prime, 2023...")
    nearest = gps.find_nearest_entity(search_point, max_distance=5000)
    
    if nearest:
        print(f"Found entity: {nearest}")
        entity_pos = telemetry.get_entity_position(nearest)
        print(f"Position: {entity_pos.timeline_name}, {entity_pos.temporal.year}")
        print(f"Coordinates: {entity_pos.spatial}")
    else:
        print("No entities found within the specified range")
    
    print("\nDemo complete!")


if __name__ == "__main__":
    run_multiverse_gps_demo()
