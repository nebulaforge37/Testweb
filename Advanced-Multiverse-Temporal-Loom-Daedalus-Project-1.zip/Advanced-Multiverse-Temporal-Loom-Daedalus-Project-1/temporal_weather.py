
"""
Temporal Weather System
This module simulates weather patterns in the temporal field that affect
time travel and can cause random temporal disturbances.
"""

import random
import math
import time
from typing import List, Dict, Tuple, Optional
from main import Multiverse, Timeline

class TemporalWeatherPattern:
    """Represents a specific temporal weather pattern"""
    
    def __init__(self, name: str, stability_effect: float, duration: int, 
                severity: float, description: str):
        """
        Initialize a temporal weather pattern
        
        Args:
            name: Name of the weather pattern
            stability_effect: Effect on timeline stability (-1.0 to 1.0)
            duration: Duration in simulation cycles
            severity: Severity of the pattern (0.0-1.0)
            description: Description of the pattern and its effects
        """
        self.name = name
        self.stability_effect = stability_effect
        self.duration = duration
        self.severity = severity
        self.description = description
        self.remaining_duration = duration
        self.affected_timelines = set()
        self.affected_quantum_state = {}  # Specific effects on quantum states
        
    def is_active(self) -> bool:
        """Check if the weather pattern is still active"""
        return self.remaining_duration > 0
        
    def update(self) -> Dict:
        """Update the weather pattern for one cycle"""
        if not self.is_active():
            return {"active": False}
            
        self.remaining_duration -= 1
        
        # Weather patterns often change in intensity over time
        if self.remaining_duration > 0:
            # Fluctuate severity
            fluctuation = random.uniform(-0.1, 0.1)
            self.severity = max(0.1, min(1.0, self.severity + fluctuation))
        
        return {
            "active": True,
            "severity": self.severity,
            "remaining": self.remaining_duration,
            "stability_effect": self.get_current_stability_effect()
        }
        
    def get_current_stability_effect(self) -> float:
        """Get the current stability effect based on severity"""
        return self.stability_effect * self.severity
        
    def affect_timeline(self, timeline: Timeline) -> Dict:
        """Apply the weather pattern effects to a timeline"""
        if not self.is_active():
            return {"affected": False}
            
        # Record that this timeline was affected
        self.affected_timelines.add(timeline.name)
        
        # Apply stability effect
        old_stability = timeline.stability
        effect = self.get_current_stability_effect()
        timeline.stability = max(0.1, min(1.0, timeline.stability + effect))
        
        # Apply quantum effects if available
        quantum_effects = []
        if hasattr(timeline, 'quantum_state'):
            # Different weather patterns affect quantum states differently
            if "storm" in self.name.lower():
                # Temporal storms increase entanglement
                old_entanglement = timeline.quantum_state.entanglement_level
                timeline.quantum_state.entanglement_level = min(
                    1.0, 
                    timeline.quantum_state.entanglement_level + (0.1 * self.severity)
                )
                quantum_effects.append(
                    f"Entanglement level changed from {old_entanglement:.2f} to " + 
                    f"{timeline.quantum_state.entanglement_level:.2f}"
                )
                
            elif "wave" in self.name.lower():
                # Temporal waves can induce superposition
                if not timeline.quantum_state.superposition and random.random() < (self.severity * 0.3):
                    timeline.quantum_state.superposition = True
                    quantum_effects.append("Induced quantum superposition state")
                    
            elif "frost" in self.name.lower() or "freeze" in self.name.lower():
                # Temporal frost can cause wave function collapse
                if timeline.quantum_state.superposition and random.random() < (self.severity * 0.5):
                    timeline.quantum_state.superposition = False
                    timeline.quantum_state.wave_function_collapse = True
                    quantum_effects.append("Caused wave function collapse")
        
        return {
            "affected": True,
            "timeline": timeline.name,
            "stability_before": old_stability,
            "stability_after": timeline.stability,
            "stability_change": timeline.stability - old_stability,
            "quantum_effects": quantum_effects
        }
    
    def __str__(self) -> str:
        status = "Active" if self.is_active() else "Inactive"
        severity_desc = "Mild" if self.severity < 0.4 else "Moderate" if self.severity < 0.7 else "Severe"
        return f"{self.name} ({severity_desc}, {status}, {self.remaining_duration} cycles remaining)"


class TemporalWeatherSystem:
    """System for simulating and managing temporal weather patterns"""
    
    def __init__(self, multiverse: Multiverse):
        """Initialize the temporal weather system"""
        self.multiverse = multiverse
        self.active_patterns = []
        self.weather_history = []
        self.current_cycle = 0
        self.base_pattern_probability = 0.2  # Base probability of new pattern per cycle
        self.pattern_templates = self._initialize_pattern_templates()
        
    def _initialize_pattern_templates(self) -> Dict[str, Dict]:
        """Initialize templates for weather patterns"""
        return {
            "temporal_storm": {
                "name": "Temporal Storm",
                "stability_effect": -0.15,
                "duration_range": (3, 7),
                "severity_range": (0.6, 0.9),
                "description": "A violent disturbance in the temporal field that disrupts timeline stability and increases quantum entanglement."
            },
            "chrono_calm": {
                "name": "Chronological Calm",
                "stability_effect": 0.1,
                "duration_range": (4, 8),
                "severity_range": (0.5, 0.8),
                "description": "A period of unusual stability in the temporal field, strengthening timelines and enabling safer time travel."
            },
            "quantum_fog": {
                "name": "Quantum Fog",
                "stability_effect": -0.05,
                "duration_range": (2, 6),
                "severity_range": (0.4, 0.7),
                "description": "A misty quantum uncertainty that blurs the lines between possibilities, making precision time travel difficult."
            },
            "temporal_frost": {
                "name": "Temporal Frost",
                "stability_effect": -0.1,
                "duration_range": (3, 5),
                "severity_range": (0.5, 0.8),
                "description": "A crystallizing effect in the time field that can freeze quantum states and cause wave function collapse."
            },
            "reality_wave": {
                "name": "Reality Wave",
                "stability_effect": -0.2,
                "duration_range": (2, 4),
                "severity_range": (0.7, 1.0),
                "description": "A powerful wave of reality fluctuation that can induce superposition and enable crossing between normally separate timelines."
            },
            "chrono_lightning": {
                "name": "Chronological Lightning",
                "stability_effect": -0.3,
                "duration_range": (1, 3),
                "severity_range": (0.8, 1.0),
                "description": "Brief but intense bursts of temporal energy that can cause sudden paradoxes and timeline jumps."
            },
            "temporal_rainbow": {
                "name": "Temporal Rainbow",
                "stability_effect": 0.15,
                "duration_range": (2, 5),
                "severity_range": (0.6, 0.9),
                "description": "A beautiful harmonic alignment of temporal frequencies that increases stability and reveals connections between timelines."
            }
        }
    
    def update(self) -> Dict:
        """Update the weather system for one cycle"""
        self.current_cycle += 1
        cycle_report = {
            "cycle": self.current_cycle,
            "new_patterns": [],
            "active_patterns": [],
            "ended_patterns": [],
            "affected_timelines": {}
        }
        
        # Update existing patterns
        ended_patterns = []
        for pattern in self.active_patterns:
            update_result = pattern.update()
            
            if update_result["active"]:
                cycle_report["active_patterns"].append({
                    "name": pattern.name,
                    "severity": pattern.severity,
                    "remaining": pattern.remaining_duration
                })
            else:
                ended_patterns.append(pattern)
                cycle_report["ended_patterns"].append(pattern.name)
        
        # Remove ended patterns
        for pattern in ended_patterns:
            self.active_patterns.remove(pattern)
            self.weather_history.append({
                "type": pattern.name,
                "start_cycle": self.current_cycle - pattern.duration,
                "end_cycle": self.current_cycle,
                "affected_timelines": list(pattern.affected_timelines)
            })
        
        # Potentially generate new patterns
        self._generate_new_patterns(cycle_report)
        
        # Apply effects to timelines
        self._apply_weather_effects(cycle_report)
        
        return cycle_report
    
    def _generate_new_patterns(self, cycle_report: Dict):
        """Potentially generate new weather patterns"""
        # Base probability modified by number of active patterns
        probability = self.base_pattern_probability * (1.0 - (len(self.active_patterns) * 0.2))
        
        if random.random() < probability:
            # Select a pattern type
            pattern_type = random.choice(list(self.pattern_templates.keys()))
            template = self.pattern_templates[pattern_type]
            
            # Create the pattern with some randomness
            duration = random.randint(*template["duration_range"])
            severity = random.uniform(*template["severity_range"])
            
            pattern = TemporalWeatherPattern(
                template["name"], 
                template["stability_effect"],
                duration,
                severity,
                template["description"]
            )
            
            self.active_patterns.append(pattern)
            cycle_report["new_patterns"].append({
                "name": pattern.name,
                "severity": pattern.severity,
                "duration": pattern.duration,
                "description": pattern.description
            })
    
    def _apply_weather_effects(self, cycle_report: Dict):
        """Apply weather effects to timelines"""
        if not self.active_patterns:
            return
            
        # Get a list of timelines
        timelines = list(self.multiverse.timelines.values())
        if not timelines:
            return
            
        # Each pattern affects a subset of timelines
        for pattern in self.active_patterns:
            # Determine which timelines are affected
            # More severe patterns affect more timelines
            affected_count = max(1, int(len(timelines) * pattern.severity * 0.7))
            affected_timelines = random.sample(timelines, min(affected_count, len(timelines)))
            
            for timeline in affected_timelines:
                result = pattern.affect_timeline(timeline)
                
                if result["affected"]:
                    # Record in cycle report
                    timeline_name = result["timeline"]
                    if timeline_name not in cycle_report["affected_timelines"]:
                        cycle_report["affected_timelines"][timeline_name] = []
                        
                    cycle_report["affected_timelines"][timeline_name].append({
                        "pattern": pattern.name,
                        "stability_change": result["stability_change"],
                        "quantum_effects": result["quantum_effects"]
                    })
    
    def get_current_weather_report(self) -> str:
        """Get a human-readable report of current temporal weather"""
        if not self.active_patterns:
            return "The temporal field is currently calm with no significant weather patterns."
            
        report = [f"=== Temporal Weather Report (Cycle {self.current_cycle}) ==="]
        
        for pattern in self.active_patterns:
            severity_desc = "mild" if pattern.severity < 0.4 else "moderate" if pattern.severity < 0.7 else "severe"
            report.append(f"{pattern.name}: {severity_desc} ({pattern.remaining_duration} cycles remaining)")
            report.append(f"  {pattern.description}")
            
            # Add specific timeline effects
            if pattern.affected_timelines:
                report.append(f"  Affecting {len(pattern.affected_timelines)} timelines")
                
        # Add travel advisory
        has_dangerous = any(p.stability_effect < -0.2 and p.severity > 0.7 for p in self.active_patterns)
        has_beneficial = any(p.stability_effect > 0.1 for p in self.active_patterns)
        
        report.append("\nTime Travel Advisory:")
        if has_dangerous:
            report.append("  ⚠️ CAUTION: Dangerous temporal conditions present. Time travel not recommended.")
        elif has_beneficial:
            report.append("  ✓ FAVORABLE: Current conditions are beneficial for time travel.")
        else:
            report.append("  ℹ️ NORMAL: Standard temporal travel conditions.")
            
        return "\n".join(report)
    
    def get_forecast(self, cycles: int = 3) -> str:
        """Get a forecast for upcoming temporal weather"""
        forecast = [f"=== Temporal Weather Forecast (Next {cycles} cycles) ==="]
        
        # Current conditions
        forecast.append("\nCurrent Conditions:")
        if not self.active_patterns:
            forecast.append("  No significant weather patterns.")
        else:
            for pattern in self.active_patterns:
                remaining = pattern.remaining_duration
                forecast.append(f"  {pattern.name}: {pattern.severity:.2f} severity, {remaining} cycles remaining")
        
        # Forecast for upcoming cycles
        forecast.append("\nForecast:")
        
        # Simple prediction model based on current patterns and random factors
        predicted_stability = {}
        overall_trend = random.choice(["improving", "worsening", "steady"])
        
        for cycle in range(1, cycles + 1):
            forecast_cycle = self.current_cycle + cycle
            
            # Predict continuing patterns
            continuing_patterns = []
            for pattern in self.active_patterns:
                if pattern.remaining_duration >= cycle:
                    continuing_patterns.append(pattern.name)
            
            # Predict general conditions
            if cycle == 1:
                forecast.append(f"  Cycle {forecast_cycle}: {', '.join(continuing_patterns) if continuing_patterns else 'No significant patterns'}")
                continue
                
            # Later cycles have more uncertainty
            probability_new = 0.3 + (cycle * 0.1)
            if random.random() < probability_new:
                possible_patterns = list(self.pattern_templates.keys())
                pattern_template = self.pattern_templates[random.choice(possible_patterns)]
                
                if overall_trend == "improving":
                    if pattern_template["stability_effect"] < 0:
                        # Reduce likelihood of negative patterns
                        if random.random() < 0.7:
                            continue
                elif overall_trend == "worsening":
                    if pattern_template["stability_effect"] > 0:
                        # Reduce likelihood of positive patterns
                        if random.random() < 0.7:
                            continue
                
                forecast.append(f"  Cycle {forecast_cycle}: Possible {pattern_template['name']}")
            else:
                forecast.append(f"  Cycle {forecast_cycle}: Similar conditions to cycle {forecast_cycle-1}")
        
        # Add trend prediction
        forecast.append(f"\nOverall Trend: Conditions appear to be {overall_trend}.")
        
        # Add time travel recommendations
        forecast.append("\nTravel Recommendations:")
        if overall_trend == "improving":
            forecast.append("  Consider delaying non-essential time travel as conditions are expected to improve.")
        elif overall_trend == "worsening":
            forecast.append("  Consider completing any necessary time travel before conditions deteriorate.")
        else:
            forecast.append("  Standard travel protocols advised, no significant changes expected.")
        
        return "\n".join(forecast)
    
    def affect_time_travel(self, origin_timeline: Timeline, destination_timeline: Timeline,
                         traveler: str, year: int) -> Dict:
        """
        Modify a time travel event based on current weather conditions
        
        Returns:
            Dictionary with weather effects on the time travel
        """
        if not self.active_patterns:
            return {"affected": False, "message": "No temporal weather effects."}
            
        # Calculate combined weather impact
        stability_impact = 0
        precision_impact = 0
        danger_level = 0
        quantum_effects = []
        
        for pattern in self.active_patterns:
            # More severe patterns have stronger effects
            effect_strength = pattern.severity
            
            # Different patterns affect different aspects of time travel
            if "storm" in pattern.name.lower():
                stability_impact -= 0.2 * effect_strength
                precision_impact -= 0.3 * effect_strength
                danger_level += 0.4 * effect_strength
                
                if random.random() < (0.3 * effect_strength):
                    quantum_effects.append("Increased quantum entanglement during transit")
                    
            elif "calm" in pattern.name.lower():
                stability_impact += 0.2 * effect_strength
                precision_impact += 0.3 * effect_strength
                danger_level -= 0.2 * effect_strength
                
            elif "fog" in pattern.name.lower():
                precision_impact -= 0.4 * effect_strength
                
                if random.random() < (0.4 * effect_strength):
                    quantum_effects.append("Temporal destination obscured by quantum uncertainty")
                    
            elif "frost" in pattern.name.lower():
                stability_impact -= 0.1 * effect_strength
                
                if random.random() < (0.3 * effect_strength):
                    quantum_effects.append("Partial quantum state freeze during transit")
                    
            elif "wave" in pattern.name.lower():
                stability_impact -= 0.3 * effect_strength
                danger_level += 0.3 * effect_strength
                
                if random.random() < (0.5 * effect_strength):
                    quantum_effects.append("Reality fluctuations may cause brief superposition")
                    
            elif "lightning" in pattern.name.lower():
                stability_impact -= 0.4 * effect_strength
                danger_level += 0.5 * effect_strength
                
                if random.random() < (0.4 * effect_strength):
                    quantum_effects.append("Risk of temporal lightning strike during transit")
                    
            elif "rainbow" in pattern.name.lower():
                stability_impact += 0.3 * effect_strength
                precision_impact += 0.2 * effect_strength
                danger_level -= 0.3 * effect_strength
                
                if random.random() < (0.4 * effect_strength):
                    quantum_effects.append("Enhanced timeline connectivity visualization")
        
        # Determine if travel is affected and how
        is_affected = abs(stability_impact) > 0.1 or abs(precision_impact) > 0.1 or danger_level > 0.2
        
        if not is_affected:
            return {"affected": False, "message": "Minimal temporal weather effects."}
            
        # Apply effects
        effects = {
            "affected": True,
            "stability_impact": stability_impact,
            "precision_impact": precision_impact,
            "danger_level": danger_level,
            "quantum_effects": quantum_effects,
            "year_shift": 0,
            "destination_change": False,
            "paradox_risk_increase": max(0, danger_level * 0.5),
            "message": ""
        }
        
        # Potential year shift due to precision impact
        if precision_impact < -0.2:
            max_shift = int(abs(precision_impact) * 10)
            effects["year_shift"] = random.randint(-max_shift, max_shift)
            
        # Potential destination change due to severe conditions
        if danger_level > 0.7 and random.random() < (danger_level - 0.5):
            effects["destination_change"] = True
            # In actual implementation, would modify destination timeline here
            
        # Generate message
        weather_desc = []
        if stability_impact < -0.3:
            weather_desc.append("highly unstable")
        elif stability_impact < -0.1:
            weather_desc.append("unstable")
        elif stability_impact > 0.3:
            weather_desc.append("exceptionally stable")
        elif stability_impact > 0.1:
            weather_desc.append("stable")
            
        if precision_impact < -0.3:
            weather_desc.append("extremely imprecise")
        elif precision_impact < -0.1:
            weather_desc.append("imprecise")
        elif precision_impact > 0.3:
            weather_desc.append("highly precise")
        elif precision_impact > 0.1:
            weather_desc.append("precise")
            
        if danger_level > 0.6:
            weather_desc.append("dangerous")
        elif danger_level > 0.3:
            weather_desc.append("hazardous")
            
        conditions = " and ".join(weather_desc) if weather_desc else "normal"
        
        effects["message"] = f"Time travel occurring under {conditions} temporal weather conditions."
        
        if effects["year_shift"] != 0:
            effects["message"] += f" Temporal currents shifted destination by {effects['year_shift']} years."
            
        if effects["destination_change"]:
            effects["message"] += " WARNING: Severe conditions may alter intended destination timeline!"
            
        return effects


def run_weather_demonstration(multiverse=None):
    """Run a demonstration of the temporal weather system"""
    print("=== Temporal Weather System Demonstration ===")
    
    # Create multiverse if not provided
    if not multiverse:
        from main import Multiverse
        multiverse = Multiverse()
        
        # Create some timelines for the demo
        multiverse.create_timeline("Alpha", 0.9)
        multiverse.create_timeline("Beta", 0.8)
        multiverse.create_timeline("Gamma", 0.7)
        print("Created demo timelines: Alpha, Beta, Gamma")
    
    # Create the weather system
    weather_system = TemporalWeatherSystem(multiverse)
    
    print("\nInitializing temporal weather simulation...")
    print("The system will simulate 10 cycles of temporal weather patterns.")
    
    # Run a few cycles to generate some weather
    for _ in range(3):
        weather_system.update()
    
    print("\nCurrent Weather Conditions:")
    print(weather_system.get_current_weather_report())
    
    print("\nWeather Forecast:")
    print(weather_system.get_forecast(5))
    
    # Let the user interact with the system
    print("\nInteractive Weather Simulation")
    print("Options:")
    print("1. Advance one cycle")
    print("2. View current weather")
    print("3. View forecast")
    print("4. Simulate time travel under current conditions")
    print("5. Exit demonstration")
    
    while True:
        choice = input("\nEnter your choice (1-5): ")
        
        if choice == "1":
            print("\nAdvancing one weather cycle...")
            result = weather_system.update()
            
            # Report on new patterns
            if result["new_patterns"]:
                for pattern in result["new_patterns"]:
                    print(f"NEW PATTERN: {pattern['name']} (Severity: {pattern['severity']:.2f})")
                    print(f"  {pattern['description']}")
            else:
                print("No new weather patterns this cycle.")
                
            # Report on timeline effects
            if result["affected_timelines"]:
                print("\nTimeline Effects:")
                for timeline, effects in result["affected_timelines"].items():
                    print(f"Timeline {timeline} affected by {len(effects)} patterns")
                    for effect in effects:
                        stability_change = effect["stability_change"]
                        direction = "increased" if stability_change > 0 else "decreased"
                        print(f"  {effect['pattern']}: Stability {direction} by {abs(stability_change):.2f}")
                        
                        if effect["quantum_effects"]:
                            print(f"    Quantum effects: {', '.join(effect['quantum_effects'])}")
            
            # Report on ended patterns
            if result["ended_patterns"]:
                print("\nEnded Patterns:")
                for pattern in result["ended_patterns"]:
                    print(f"  {pattern} has dissipated")
                    
        elif choice == "2":
            print("\n" + weather_system.get_current_weather_report())
            
        elif choice == "3":
            cycles = input("How many cycles to forecast? (1-10): ")
            try:
                cycles = int(cycles)
                cycles = max(1, min(10, cycles))
                print("\n" + weather_system.get_forecast(cycles))
            except ValueError:
                print("Please enter a number between 1 and 10.")
                
        elif choice == "4":
            # Get timelines for simulation
            timeline_names = list(multiverse.timelines.keys())
            if len(timeline_names) < 2:
                print("Need at least two timelines for time travel simulation.")
                continue
                
            print("\nSelect origin timeline:")
            for i, name in enumerate(timeline_names):
                print(f"{i+1}. {name}")
                
            try:
                origin_idx = int(input("Enter number: ")) - 1
                origin_timeline = multiverse.timelines[timeline_names[origin_idx]]
                
                print("\nSelect destination timeline:")
                for i, name in enumerate(timeline_names):
                    if i != origin_idx:
                        print(f"{i+1}. {name}")
                        
                dest_idx = int(input("Enter number: ")) - 1
                destination_timeline = multiverse.timelines[timeline_names[dest_idx]]
                
                year = int(input("\nEnter travel year: "))
                traveler = input("Enter traveler name: ")
                
                print("\nSimulating time travel under current weather conditions...")
                effects = weather_system.affect_time_travel(
                    origin_timeline, destination_timeline, traveler, year
                )
                
                print("\n=== Time Travel Weather Effects ===")
                print(effects["message"])
                
                if effects["affected"]:
                    print("\nDetailed Effects:")
                    print(f"Stability Impact: {effects['stability_impact']:.2f}")
                    print(f"Precision Impact: {effects['precision_impact']:.2f}")
                    print(f"Danger Level: {effects['danger_level']:.2f}")
                    
                    if effects["year_shift"] != 0:
                        shifted_year = year + effects["year_shift"]
                        print(f"Destination year shifted: {year} → {shifted_year}")
                        
                    if effects["destination_change"]:
                        print("WARNING: Destination timeline may be altered!")
                        
                    if effects["paradox_risk_increase"] > 0:
                        print(f"Paradox risk increased by {effects['paradox_risk_increase']:.2f}")
                        
                    if effects["quantum_effects"]:
                        print("\nQuantum Effects:")
                        for effect in effects["quantum_effects"]:
                            print(f"- {effect}")
            except (ValueError, IndexError):
                print("Invalid selection. Please try again.")
                
        elif choice == "5":
            print("\nExiting temporal weather demonstration.")
            break
            
        else:
            print("Invalid choice. Please enter a number between 1 and 5.")
    
    return weather_system


if __name__ == "__main__":
    run_weather_demonstration()
"""
Temporal Weather System
This module simulates and predicts weather-like phenomena in the temporal landscape,
including temporal storms, quantum fog, probability rain, and timeline auroras.
"""

import random
import math
import time
from typing import Dict, List, Tuple, Any, Optional
from enum import Enum

class WeatherType(Enum):
    """Types of temporal weather phenomena"""
    CLEAR = 0
    PROBABILITY_RAIN = 1
    QUANTUM_FOG = 2
    TEMPORAL_STORM = 3
    CHRONOSTATIC_SNOW = 4
    CAUSALITY_WIND = 5
    TIMELINE_AURORA = 6
    PARADOX_LIGHTNING = 7
    ENTROPY_HAIL = 8
    POSSIBILITY_DRIZZLE = 9

class WeatherSeverity(Enum):
    """Severity levels for temporal weather"""
    NONE = 0
    LIGHT = 1
    MODERATE = 2
    HEAVY = 3
    SEVERE = 4
    CATASTROPHIC = 5

class WeatherForecast:
    """
    A forecast of temporal weather conditions for a specific timeline and time period
    """
    
    def __init__(self, 
                timeline_name: str,
                start_year: int,
                end_year: int,
                weather_type: WeatherType,
                severity: WeatherSeverity,
                center_x: float = 0.0,
                center_y: float = 0.0,
                center_z: float = 0.0,
                radius: float = 1000.0):
        """
        Initialize a weather forecast
        
        Args:
            timeline_name: The timeline this forecast applies to
            start_year: Beginning of the affected time period
            end_year: End of the affected time period
            weather_type: Type of weather phenomenon
            severity: Severity level
            center_x, center_y, center_z: Spatial coordinates of center
            radius: Radius of affected area in km
        """
        self.timeline_name = timeline_name
        self.start_year = start_year
        self.end_year = end_year
        self.weather_type = weather_type
        self.severity = severity
        self.center_x = center_x
        self.center_y = center_y
        self.center_z = center_z
        self.radius = radius
        
        # Forecast properties
        self.creation_time = time.time()
        self.confidence = random.uniform(0.6, 0.95)
        self.peak_year = start_year + (end_year - start_year) // 2
        self.movement_vector = (
            random.uniform(-1.0, 1.0),
            random.uniform(-1.0, 1.0),
            random.uniform(-1.0, 1.0)
        )
        self.decay_rate = random.uniform(0.01, 0.05)
        self.special_properties = {}
        
        # Generate special properties based on weather type
        self._generate_special_properties()
    
    def _generate_special_properties(self):
        """Generate special properties specific to each weather type"""
        if self.weather_type == WeatherType.PROBABILITY_RAIN:
            self.special_properties["alteration_radius"] = self.radius * 0.7
            self.special_properties["probability_shift"] = random.uniform(0.1, 0.4) * self.severity.value
            
        elif self.weather_type == WeatherType.QUANTUM_FOG:
            self.special_properties["visibility"] = max(0.1, 1.0 - (self.severity.value * 0.15))
            self.special_properties["entanglement_factor"] = min(1.0, self.severity.value * 0.2)
            
        elif self.weather_type == WeatherType.TEMPORAL_STORM:
            self.special_properties["time_distortion"] = random.uniform(0.5, 2.0) * self.severity.value
            self.special_properties["turbulence"] = self.severity.value / 5
            self.special_properties["energy_discharge"] = self.severity.value * 20
            
        elif self.weather_type == WeatherType.CHRONOSTATIC_SNOW:
            self.special_properties["time_slowdown"] = random.uniform(0.2, 0.8) * self.severity.value
            self.special_properties["crystallization_risk"] = self.severity.value * 0.15
            
        elif self.weather_type == WeatherType.CAUSALITY_WIND:
            self.special_properties["wind_speed"] = random.uniform(20, 100) * self.severity.value
            self.special_properties["direction_shift"] = random.choice([-1, 1]) * random.uniform(15, 45)
            
        elif self.weather_type == WeatherType.TIMELINE_AURORA:
            self.special_properties["reality_bleedthrough"] = min(1.0, self.severity.value * 0.2)
            self.special_properties["vision_clarity"] = random.uniform(0.7, 0.95)
            self.special_properties["alternate_timelines_visible"] = min(5, self.severity.value * 2)
            
        elif self.weather_type == WeatherType.PARADOX_LIGHTNING:
            self.special_properties["strike_frequency"] = self.severity.value * 5
            self.special_properties["paradox_creation_chance"] = min(0.3, self.severity.value * 0.05)
            
        elif self.weather_type == WeatherType.ENTROPY_HAIL:
            self.special_properties["decay_acceleration"] = self.severity.value * 0.3
            self.special_properties["hail_size"] = random.uniform(0.5, 5.0) * self.severity.value
            
        elif self.weather_type == WeatherType.POSSIBILITY_DRIZZLE:
            self.special_properties["possibility_factor"] = random.uniform(1.1, 1.5)
            self.special_properties["new_paths_opening"] = self.severity.value * 3
            
    def calculate_intensity_at_coordinates(self, 
                                        year: int, 
                                        x: float, 
                                        y: float, 
                                        z: float) -> float:
        """
        Calculate the intensity of weather effects at specific coordinates
        
        Args:
            year: The year to check
            x, y, z: Spatial coordinates
            
        Returns:
            Intensity from 0.0 (no effect) to 1.0 (full effect)
        """
        # Check if within time range
        if year < self.start_year or year > self.end_year:
            return 0.0
        
        # Calculate temporal intensity - peaks at peak_year
        years_from_peak = abs(year - self.peak_year)
        half_duration = (self.end_year - self.start_year) / 2
        
        if half_duration == 0:
            temporal_intensity = 1.0
        else:
            temporal_intensity = 1.0 - (years_from_peak / half_duration)
        
        # Calculate spatial intensity - decreases with distance from center
        distance = math.sqrt(
            (x - self.center_x) ** 2 +
            (y - self.center_y) ** 2 +
            (z - self.center_z) ** 2
        )
        
        if distance > self.radius:
            return 0.0
        
        spatial_intensity = 1.0 - (distance / self.radius)
        
        # Combine intensities, with temporal having slightly more influence
        combined_intensity = (temporal_intensity * 0.6) + (spatial_intensity * 0.4)
        
        # Scale by severity
        scaled_intensity = combined_intensity * (self.severity.value / 5)
        
        # Ensure within range
        return min(1.0, max(0.0, scaled_intensity))
    
    def get_weather_effects(self, intensity: float) -> Dict[str, Any]:
        """
        Get the specific effects of this weather at a given intensity
        
        Args:
            intensity: The calculated intensity (0.0-1.0)
            
        Returns:
            Dictionary of effects and their values
        """
        effects = {
            "type": self.weather_type.name,
            "intensity": intensity,
            "severity": self.severity.name,
            "base_danger_level": min(10, intensity * self.severity.value * 2)
        }
        
        # Add special effects based on weather type
        if self.weather_type == WeatherType.PROBABILITY_RAIN:
            effects["probability_shift"] = self.special_properties["probability_shift"] * intensity
            effects["random_events_likelihood"] = intensity * 5
            effects["timeline_stability_change"] = -0.05 * intensity * self.severity.value
            
        elif self.weather_type == WeatherType.QUANTUM_FOG:
            effects["visibility_reduction"] = 1.0 - (self.special_properties["visibility"] * (1.0 - intensity))
            effects["entanglement_risk"] = self.special_properties["entanglement_factor"] * intensity
            effects["quantum_state_uncertainty"] = intensity * 0.7
            
        elif self.weather_type == WeatherType.TEMPORAL_STORM:
            effects["time_flow_distortion"] = self.special_properties["time_distortion"] * intensity
            effects["timeline_integrity_damage"] = 0.1 * intensity * self.severity.value
            effects["navigation_difficulty"] = intensity * 8
            effects["energy_discharge_risk"] = self.special_properties["energy_discharge"] * intensity
            
        elif self.weather_type == WeatherType.CHRONOSTATIC_SNOW:
            effects["time_flow_reduction"] = self.special_properties["time_slowdown"] * intensity
            effects["temporal_freezing_risk"] = self.special_properties["crystallization_risk"] * intensity
            effects["energy_consumption_increase"] = intensity * 3
            
        elif self.weather_type == WeatherType.CAUSALITY_WIND:
            effects["causal_displacement"] = self.special_properties["wind_speed"] * intensity
            effects["directional_shift"] = self.special_properties["direction_shift"] * intensity
            effects["event_reordering_chance"] = min(0.5, intensity * self.severity.value * 0.1)
            
        elif self.weather_type == WeatherType.TIMELINE_AURORA:
            effects["reality_bleedthrough"] = self.special_properties["reality_bleedthrough"] * intensity
            effects["alternate_timeline_visibility"] = self.special_properties["alternate_timelines_visible"] * intensity
            effects["insight_bonus"] = intensity * 5
            
        elif self.weather_type == WeatherType.PARADOX_LIGHTNING:
            effects["strike_chance"] = self.special_properties["strike_frequency"] * intensity
            effects["paradox_creation_risk"] = self.special_properties["paradox_creation_chance"] * intensity
            effects["energy_spike_magnitude"] = intensity * 10 * self.severity.value
            
        elif self.weather_type == WeatherType.ENTROPY_HAIL:
            effects["decay_acceleration"] = self.special_properties["decay_acceleration"] * intensity
            effects["structure_damage_rate"] = intensity * self.special_properties["hail_size"]
            effects["timeline_aging"] = intensity * self.severity.value * 0.2
            
        elif self.weather_type == WeatherType.POSSIBILITY_DRIZZLE:
            effects["possibility_expansion"] = self.special_properties["possibility_factor"] * intensity
            effects["new_paths_generated"] = round(self.special_properties["new_paths_opening"] * intensity)
            effects["creativity_boost"] = intensity * 5
        
        return effects
    
    def get_recommendations(self) -> List[str]:
        """Get recommendations for handling this weather"""
        recommendations = []
        
        # General recommendations based on severity
        if self.severity == WeatherSeverity.LIGHT:
            recommendations.append("Standard precautions sufficient")
        elif self.severity == WeatherSeverity.MODERATE:
            recommendations.append("Exercise caution when traveling")
            recommendations.append("Monitor temporal conditions regularly")
        elif self.severity == WeatherSeverity.HEAVY:
            recommendations.append("Avoid unnecessary temporal travel")
            recommendations.append("Increase timeline monitoring frequency")
            recommendations.append("Prepare contingency plans for timeline fluctuations")
        elif self.severity == WeatherSeverity.SEVERE:
            recommendations.append("ALERT: Severe temporal conditions")
            recommendations.append("Suspend all non-essential temporal travel")
            recommendations.append("Activate timeline stabilizers")
            recommendations.append("Establish emergency response protocols")
        elif self.severity == WeatherSeverity.CATASTROPHIC:
            recommendations.append("EMERGENCY: Catastrophic temporal conditions")
            recommendations.append("Evacuate temporal region immediately")
            recommendations.append("Deploy all available stabilization resources")
            recommendations.append("Prepare for possible timeline fracturing")
            recommendations.append("Initiate reality anchor emergency protocols")
        
        # Specific recommendations based on weather type
        if self.weather_type == WeatherType.PROBABILITY_RAIN:
            recommendations.append("Secure deterministic events with causal anchors")
            recommendations.append("Avoid probability-sensitive operations")
            
        elif self.weather_type == WeatherType.QUANTUM_FOG:
            recommendations.append("Use quantum resonance beacons for navigation")
            recommendations.append("Maintain direct contact with base timeline")
            recommendations.append("Avoid quantum entanglement operations")
            
        elif self.weather_type == WeatherType.TEMPORAL_STORM:
            recommendations.append("Seek temporal shelter immediately")
            recommendations.append("Synchronize chronometers frequently")
            recommendations.append("Prepare for sudden timeline shifts")
            
        elif self.weather_type == WeatherType.CHRONOSTATIC_SNOW:
            recommendations.append("Increase temporal propulsion power")
            recommendations.append("Maintain movement to prevent temporal freezing")
            recommendations.append("Use thermal-temporal shielding")
            
        elif self.weather_type == WeatherType.CAUSALITY_WIND:
            recommendations.append("Secure causal connections")
            recommendations.append("Travel against the causal flow")
            recommendations.append("Monitor event sequences for alterations")
            
        elif self.weather_type == WeatherType.TIMELINE_AURORA:
            recommendations.append("Opportunity for multiverse observation")
            recommendations.append("Record alternate timeline data")
            recommendations.append("Maintain reality anchoring to prevent drift")
            
        elif self.weather_type == WeatherType.PARADOX_LIGHTNING:
            recommendations.append("Use paradox-absorbing shielding")
            recommendations.append("Avoid proximity to critical timeline nexus points")
            recommendations.append("Prepare paradox resolution protocols")
            
        elif self.weather_type == WeatherType.ENTROPY_HAIL:
            recommendations.append("Shelter under temporal stabilizing fields")
            recommendations.append("Apply anti-entropy measures to sensitive objects")
            recommendations.append("Prepare for accelerated timeline decay")
            
        elif self.weather_type == WeatherType.POSSIBILITY_DRIZZLE:
            recommendations.append("Opportunity for timeline exploration")
            recommendations.append("Document new possibilities as they emerge")
            recommendations.append("Prepare for increased decision branches")
        
        return recommendations
    
    def __str__(self) -> str:
        return (f"{self.weather_type.name} ({self.severity.name}) " +
                f"in {self.timeline_name}, {self.start_year}-{self.end_year}")


class TemporalWeatherSystem:
    """
    System for forecasting and tracking temporal weather across the multiverse.
    """
    
    def __init__(self, multiverse = None):
        """
        Initialize the temporal weather system
        
        Args:
            multiverse: Optional reference to the multiverse
        """
        self.multiverse = multiverse
        self.forecasts: List[WeatherForecast] = []
        self.last_update = time.time()
        self.update_interval = 3600  # 1 hour in seconds
        self.climate_patterns: Dict[str, Dict[str, Any]] = {}
        
        # Weather generation parameters
        self.base_weather_chance = 0.7
        self.severe_weather_chance = 0.3
        self.weather_distribution = {
            WeatherType.CLEAR: 20,
            WeatherType.PROBABILITY_RAIN: 15,
            WeatherType.QUANTUM_FOG: 15,
            WeatherType.TEMPORAL_STORM: 10,
            WeatherType.CHRONOSTATIC_SNOW: 10,
            WeatherType.CAUSALITY_WIND: 10,
            WeatherType.TIMELINE_AURORA: 5,
            WeatherType.PARADOX_LIGHTNING: 5,
            WeatherType.ENTROPY_HAIL: 5,
            WeatherType.POSSIBILITY_DRIZZLE: 5
        }
        
        # Initialize some forecasts
        if multiverse:
            self._initialize_forecasts()
    
    def _initialize_forecasts(self) -> None:
        """Initialize some initial forecasts"""
        if not hasattr(self.multiverse, 'timelines'):
            return
            
        # Generate forecasts for each timeline
        for timeline_name in self.multiverse.timelines:
            # 70% chance of weather for each timeline
            if random.random() < self.base_weather_chance:
                self._generate_forecast_for_timeline(timeline_name)
    
    def _generate_forecast_for_timeline(self, timeline_name: str) -> Optional[WeatherForecast]:
        """Generate a new weather forecast for a timeline"""
        # Determine weather type based on distribution
        weather_types = list(self.weather_distribution.keys())
        weights = list(self.weather_distribution.values())
        weather_type = random.choices(weather_types, weights=weights, k=1)[0]
        
        # Skip if it's clear weather
        if weather_type == WeatherType.CLEAR:
            return None
        
        # Determine severity
        severity_weights = [20, 40, 25, 10, 5, 2]  # NONE to CATASTROPHIC
        severity = WeatherSeverity(random.choices(range(6), weights=severity_weights, k=1)[0])
        
        # Generate time range (centered on the current year with a variable span)
        current_year = 2023  # Default
        
        # Try to get the current year from the timeline
        if (self.multiverse and timeline_name in getattr(self.multiverse, 'timelines', {}) and 
            hasattr(self.multiverse.timelines[timeline_name], 'events') and 
            self.multiverse.timelines[timeline_name].events):
            current_year = self.multiverse.timelines[timeline_name].events[-1][0]
        
        # Duration based on severity
        duration = random.randint(1, 3) * severity.value
        start_year = current_year - random.randint(0, duration)
        end_year = start_year + duration
        
        # Generate spatial coordinates
        center_x = random.uniform(-1000, 1000)
        center_y = random.uniform(-1000, 1000)
        center_z = random.uniform(-1000, 1000)
        
        # Radius based on severity
        radius = random.uniform(100, 300) * math.sqrt(severity.value)
        
        # Create the forecast
        forecast = WeatherForecast(
            timeline_name, start_year, end_year,
            weather_type, severity,
            center_x, center_y, center_z, radius
        )
        
        self.forecasts.append(forecast)
        return forecast
    
    def update(self) -> None:
        """Update weather forecasts"""
        current_time = time.time()
        
        # Check if it's time for an update
        if current_time - self.last_update < self.update_interval:
            return
            
        self.last_update = current_time
        
        # Remove expired forecasts (using a simple decay mechanism)
        active_forecasts = []
        for forecast in self.forecasts:
            # Apply decay rate
            forecast.confidence -= forecast.decay_rate
            
            # Keep if still confident enough
            if forecast.confidence > 0.2:
                active_forecasts.append(forecast)
        
        removed_count = len(self.forecasts) - len(active_forecasts)
        self.forecasts = active_forecasts
        
        # Generate new forecasts to replace removed ones
        if self.multiverse and hasattr(self.multiverse, 'timelines'):
            for _ in range(removed_count):
                # Pick a random timeline
                if self.multiverse.timelines:
                    timeline_name = random.choice(list(self.multiverse.timelines.keys()))
                    # 70% chance of generating new weather
                    if random.random() < self.base_weather_chance:
                        self._generate_forecast_for_timeline(timeline_name)
    
    def get_current_weather(self, 
                          timeline_name: str,
                          year: int,
                          x: float = 0.0,
                          y: float = 0.0,
                          z: float = 0.0) -> Dict[str, Any]:
        """
        Get the current weather at specific coordinates
        
        Args:
            timeline_name: Timeline name
            year: Year
            x, y, z: Spatial coordinates
            
        Returns:
            Dictionary with weather information
        """
        # Ensure forecasts are up to date
        self.update()
        
        # Find all forecasts affecting this location
        affecting_forecasts = []
        for forecast in self.forecasts:
            if forecast.timeline_name == timeline_name:
                intensity = forecast.calculate_intensity_at_coordinates(year, x, y, z)
                if intensity > 0.01:  # Threshold for noticeable weather
                    affecting_forecasts.append((forecast, intensity))
        
        # If no weather effects, return clear conditions
        if not affecting_forecasts:
            return {
                "current_conditions": "Clear",
                "type": WeatherType.CLEAR.name,
                "intensity": 0.0,
                "severity": WeatherSeverity.NONE.name,
                "effects": {},
                "recommendations": ["No special precautions needed"]
            }
        
        # Sort by intensity, highest first
        affecting_forecasts.sort(key=lambda x: x[1], reverse=True)
        
        # Take the most intense weather as the primary condition
        primary_forecast, primary_intensity = affecting_forecasts[0]
        
        # Get weather effects
        effects = primary_forecast.get_weather_effects(primary_intensity)
        
        # Get recommendations
        recommendations = primary_forecast.get_recommendations()
        
        # Add information about secondary conditions if present
        secondary_conditions = []
        for forecast, intensity in affecting_forecasts[1:]:
            if intensity > 0.2:  # Only include significant secondary conditions
                secondary_conditions.append({
                    "type": forecast.weather_type.name,
                    "intensity": intensity,
                    "severity": forecast.severity.name
                })
        
        result = {
            "current_conditions": primary_forecast.weather_type.name,
            "type": primary_forecast.weather_type.name,
            "intensity": primary_intensity,
            "severity": primary_forecast.severity.name,
            "effects": effects,
            "recommendations": recommendations,
            "forecast_confidence": primary_forecast.confidence,
            "secondary_conditions": secondary_conditions
        }
        
        return result
    
    def get_forecasts_for_timeline(self, timeline_name: str) -> List[WeatherForecast]:
        """Get all forecasts for a specific timeline"""
        return [f for f in self.forecasts if f.timeline_name == timeline_name]
    
    def get_severe_weather_alerts(self) -> List[Dict[str, Any]]:
        """Get alerts for severe or catastrophic weather"""
        alerts = []
        
        for forecast in self.forecasts:
            if forecast.severity in [WeatherSeverity.SEVERE, WeatherSeverity.CATASTROPHIC]:
                alerts.append({
                    "timeline": forecast.timeline_name,
                    "years": f"{forecast.start_year}-{forecast.end_year}",
                    "type": forecast.weather_type.name,
                    "severity": forecast.severity.name,
                    "confidence": forecast.confidence,
                    "recommendations": forecast.get_recommendations()
                })
        
        return alerts
    
    def get_detailed_forecast(self, forecast_id: int) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific forecast"""
        if 0 <= forecast_id < len(self.forecasts):
            forecast = self.forecasts[forecast_id]
            
            return {
                "id": forecast_id,
                "timeline": forecast.timeline_name,
                "type": forecast.weather_type.name,
                "severity": forecast.severity.name,
                "period": f"{forecast.start_year}-{forecast.end_year}",
                "peak_year": forecast.peak_year,
                "center_coordinates": (forecast.center_x, forecast.center_y, forecast.center_z),
                "radius": forecast.radius,
                "confidence": forecast.confidence,
                "special_properties": forecast.special_properties,
                "recommendations": forecast.get_recommendations(),
                "effects_at_peak": forecast.get_weather_effects(1.0)
            }
        
        return None
    
    def generate_weather_report(self) -> Dict[str, Any]:
        """Generate a comprehensive weather report for all timelines"""
        # Ensure forecasts are up to date
        self.update()
        
        report = {
            "timestamp": time.time(),
            "total_forecasts": len(self.forecasts),
            "timeline_conditions": {},
            "severe_alerts": self.get_severe_weather_alerts(),
            "weather_distribution": {}
        }
        
        # Get weather counts by type
        weather_counts = {}
        for forecast in self.forecasts:
            wtype = forecast.weather_type.name
            weather_counts[wtype] = weather_counts.get(wtype, 0) + 1
        
        report["weather_distribution"] = weather_counts
        
        # Get conditions for each timeline
        timeline_forecasts = {}
        for forecast in self.forecasts:
            timeline = forecast.timeline_name
            if timeline not in timeline_forecasts:
                timeline_forecasts[timeline] = []
            timeline_forecasts[timeline].append(forecast)
        
        # Summarize conditions for each timeline
        for timeline, forecasts in timeline_forecasts.items():
            # Find the most severe condition
            if forecasts:
                most_severe = max(forecasts, key=lambda f: f.severity.value)
                
                report["timeline_conditions"][timeline] = {
                    "primary_condition": most_severe.weather_type.name,
                    "severity": most_severe.severity.name,
                    "total_phenomena": len(forecasts),
                    "alert_level": "HIGH" if most_severe.severity.value >= 3 else "NORMAL"
                }
            else:
                report["timeline_conditions"][timeline] = {
                    "primary_condition": "CLEAR",
                    "severity": "NONE",
                    "total_phenomena": 0,
                    "alert_level": "NORMAL"
                }
        
        return report


def run_temporal_weather_demo():
    """Run a demonstration of the temporal weather system"""
    print("\n=== Temporal Weather System Demonstration ===\n")
    
    # Create the weather system
    weather_system = TemporalWeatherSystem()
    
    # Create some sample timelines
    timelines = ["Alpha Prime", "Beta Variant", "Gamma Nexus", "Delta Flux"]
    
    # Generate forecasts for each timeline
    print("Generating temporal weather forecasts...")
    
    for timeline in timelines:
        for _ in range(random.randint(1, 3)):
            weather_system._generate_forecast_for_timeline(timeline)
    
    # Display forecasts
    print("\n=== Current Temporal Weather Forecasts ===\n")
    
    for i, forecast in enumerate(weather_system.forecasts):
        print(f"{i+1}. {forecast}")
        print(f"   Period: {forecast.start_year}-{forecast.end_year}, Confidence: {forecast.confidence:.2f}")
        
        # Brief description of special properties
        if forecast.special_properties:
            props = list(forecast.special_properties.keys())
            print(f"   Special properties: {', '.join(props)}")
    
    # Display current conditions for some locations
    print("\n=== Current Conditions at Specific Locations ===\n")
    
    for timeline in timelines:
        year = 2050
        coords = (random.uniform(-500, 500), 
                 random.uniform(-500, 500), 
                 random.uniform(-500, 500))
        
        print(f"Location: {timeline}, Year {year}, Coordinates {coords}")
        conditions = weather_system.get_current_weather(timeline, year, *coords)
        
        print(f"  Current Conditions: {conditions['current_conditions']}")
        print(f"  Intensity: {conditions['intensity']:.2f}")
        print(f"  Severity: {conditions['severity']}")
        
        if conditions['effects']:
            print("  Key Effects:")
            for effect, value in conditions['effects'].items():
                if effect not in ['type', 'intensity', 'severity']:
                    print(f"    - {effect}: {value}")
        
        print("  Primary Recommendation:", conditions['recommendations'][0] if conditions['recommendations'] else "None")
        print()
    
    # Display severe weather alerts
    alerts = weather_system.get_severe_weather_alerts()
    if alerts:
        print("\n=== SEVERE WEATHER ALERTS ===\n")
        for alert in alerts:
            print(f"ALERT: {alert['severity']} {alert['type']} in {alert['timeline']}, {alert['years']}")
            print(f"Recommendations: {alert['recommendations'][0]}")
            print()
    
    # Generate and display weather report
    print("\n=== Temporal Weather Report Summary ===\n")
    report = weather_system.generate_weather_report()
    
    print(f"Total weather phenomena: {report['total_forecasts']}")
    print("\nTimeline Conditions:")
    for timeline, conditions in report['timeline_conditions'].items():
        print(f"  {timeline}: {conditions['primary_condition']} ({conditions['severity']})")
        print(f"    Alert Level: {conditions['alert_level']}")
    
    print("\nWeather Distribution:")
    for weather_type, count in report['weather_distribution'].items():
        print(f"  {weather_type}: {count}")
    
    return weather_system


def get_weather_description(weather_type: WeatherType) -> str:
    """Get a detailed description of a weather type"""
    descriptions = {
        WeatherType.PROBABILITY_RAIN: 
            "Probability Rain manifests as glistening droplets of alternate possibilities that " +
            "shift and change the probabilities of events. Areas experiencing this phenomenon " +
            "will see increased variations in outcomes, with unlikely events becoming more common. " +
            "Probability cascades can occur in severe conditions, creating chains of improbable events.",
            
        WeatherType.QUANTUM_FOG:
            "Quantum Fog appears as a shimmering haze that obscures both vision and certainty. " +
            "Objects and events within the fog exist in multiple states simultaneously, and observation " +
            "becomes difficult. Navigation systems malfunction, and quantum entanglement occurs " +
            "spontaneously between objects. The fog can linger for extended periods in timeline valleys.",
            
        WeatherType.TEMPORAL_STORM:
            "Temporal Storms are violent disturbances in the fabric of spacetime, characterized by " +
            "swirling vortices of temporal energy. Time flows at inconsistent rates within the storm, " +
            "with some areas experiencing acceleration and others slowing to near-stasis. Electrical " +
            "discharges of chronon particles create brilliant displays but can damage temporal equipment.",
            
        WeatherType.CHRONOSTATIC_SNOW:
            "Chronostatic Snow appears as crystallized moments of time falling gently through the air. " +
            "Areas affected experience gradual time deceleration, with severe cases resulting in complete " +
            "temporal freezing. The snow accumulates on surfaces, creating pockets of slowed time that can " +
            "persist for days after the snowfall ends. Objects caught in deep chronostatic drifts may age " +
            "differently than their surroundings.",
            
        WeatherType.CAUSALITY_WIND:
            "Causality Winds blow through the timeline, shifting the relationship between causes and " +
            "effects. These directional forces can disconnect events from their origins or create new " +
            "causal connections. High-speed causality winds can completely reorder sequences of events, " +
            "leaving confusion in their wake. In severe cases, cyclonic causality formations can create " +
            "isolated loops of cause and effect.",
            
        WeatherType.TIMELINE_AURORA:
            "Timeline Auroras manifest as beautiful, shifting curtains of light in the temporal sky, " +
            "revealing glimpses of alternate timelines. These brilliant displays occur when reality " +
            "boundaries thin, allowing bleedthrough between neighboring timelines. Observers often report " +
            "heightened insight and occasionally glimpse potential futures or alternate pasts. The auroras " +
            "are harmless but can be disorienting.",
            
        WeatherType.PARADOX_LIGHTNING:
            "Paradox Lightning strikes with brilliant flashes when timeline contradictions reach critical " +
            "levels. These discharges can create small, temporary paradoxes at their impact points or " +
            "resolve existing paradoxical tensions. The lightning is attracted to areas of high causal " +
            "importance and can jump between temporally distant points. Electronic systems are particularly " +
            "vulnerable to damage.",
            
        WeatherType.ENTROPY_HAIL:
            "Entropy Hail falls as concentrated pellets of accelerated decay, rapidly aging anything they " +
            "contact. Organic materials are particularly susceptible, potentially aging years in seconds. " +
            "The hailstones vary in size from tiny entropy drizzle to massive entropy hailstones in severe " +
            "storms. Timeline infrastructure can be severely damaged by prolonged exposure, leading to " +
            "weakened causal structures.",
            
        WeatherType.POSSIBILITY_DRIZZLE:
            "Possibility Drizzle appears as a light, refreshing temporal rain that opens new pathways " +
            "and opportunities. Areas experiencing this phenomenon see an increase in fortuitous " +
            "coincidences and serendipitous encounters. New timeline branches form more easily, and " +
            "creative solutions emerge to previously intractable problems. Many travelers deliberately " +
            "seek out regions experiencing possibility weather."
    }
    
    return descriptions.get(weather_type, "No detailed description available.")


if __name__ == "__main__":
    run_temporal_weather_demo()
