
"""
Timeline Canvas Component
This module provides a canvas for visualizing timelines and their relationships.
"""

import tkinter as tk
from tkinter import ttk
import random
import math
from typing import Dict, List, Any, Optional, Tuple

class TimelineCanvas:
    """Canvas for displaying timelines, events and temporal relationships"""
    
    def __init__(self, parent, width=800, height=600):
        """Initialize the timeline canvas"""
        self.parent = parent
        self.width = width
        self.height = height
        
        # Create canvas
        self.canvas = tk.Canvas(parent, width=width, height=height, bg='#0F182B')
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Timeline data storage
        self.timelines = {}  # name -> {'x', 'y', 'length', 'color', 'obj_id', 'stability'}
        self.events = {}     # (timeline_name, event_id) -> {'x', 'y', 'year', 'description', 'obj_id'}
        self.connections = [] # [(timeline1, timeline2, connection_id)]
        self.selected = None
        self.hover_text_id = None
        
        # Time range for events
        self.min_year = 1900
        self.max_year = 2100
        self.time_axis_height = height - 100
        
        # Set up event bindings
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<Button-1>", self.on_click)
        
        # Draw timeline axis
        self.draw_time_axis()
    
    def clear(self):
        """Clear all elements from the canvas"""
        self.canvas.delete("all")
        self.timelines = {}
        self.events = {}
        self.connections = []
        self.selected = None
        self.hover_text_id = None
        
        # Redraw time axis
        self.draw_time_axis()
    
    def draw_time_axis(self):
        """Draw the time axis"""
        # Draw vertical time axis
        axis_x = 100
        top_y = 50
        bottom_y = self.height - 50
        
        # Main axis line
        self.canvas.create_line(
            axis_x, top_y, axis_x, bottom_y,
            fill="white", width=2, tags="time_axis"
        )
        
        # Tick marks and labels
        year_range = self.max_year - self.min_year
        years_to_show = min(10, year_range // 10 + 1)  # Show at most 10 ticks
        step = year_range // (years_to_show - 1)
        
        for i in range(years_to_show):
            year = self.min_year + i * step
            y = bottom_y - (i * (bottom_y - top_y) / (years_to_show - 1))
            
            # Tick mark
            self.canvas.create_line(
                axis_x - 5, y, axis_x + 5, y,
                fill="white", width=1, tags="time_axis"
            )
            
            # Year label
            self.canvas.create_text(
                axis_x - 20, y, text=str(year),
                fill="white", anchor="e", font=("Arial", 9),
                tags="time_axis"
            )
            
            # Light horizontal guide line
            self.canvas.create_line(
                axis_x + 5, y, self.width - 20, y,
                fill="#FFFFFF30", dash=(2, 4), tags="time_axis"
            )
        
        # Title
        self.canvas.create_text(
            axis_x, top_y - 20, text="TIMELINE VISUALIZATION",
            fill="white", anchor="center", font=("Arial", 12, "bold"),
            tags="time_axis"
        )
    
    def add_timeline(self, name, stability=0.7, color=None):
        """Add a timeline to the visualization"""
        # Calculate position
        timeline_count = len(self.timelines)
        
        # Position timeline to the right of the time axis
        base_x = 150
        spacing = 80
        x = base_x + (timeline_count * spacing)
        
        # Calculate color based on stability if not provided
        if color is None:
            r = min(255, int(255 * (1.0 - stability)))
            g = min(255, int(200 * stability))
            b = 100 + min(155, int(155 * stability))
            color = f"#{r:02x}{g:02x}{b:02x}"
        
        # Timeline length based on stability
        length = int(self.time_axis_height * 0.8 * stability)
        top_y = 50 + int((self.time_axis_height - length) / 2)
        
        # Create timeline line
        line_id = self.canvas.create_line(
            x, top_y, x, top_y + length,
            fill=color, width=4, tags=f"timeline_{name}"
        )
        
        # Add timeline label
        label_id = self.canvas.create_text(
            x, top_y - 10, text=name,
            fill=color, anchor="center", font=("Arial", 10),
            tags=f"timeline_label_{name}"
        )
        
        # Add stability indicator
        stability_label = self.canvas.create_text(
            x, top_y + length + 15, text=f"Stability: {stability:.2f}",
            fill="white", anchor="center", font=("Arial", 8),
            tags=f"timeline_stab_{name}"
        )
        
        # Store timeline data
        self.timelines[name] = {
            'x': x,
            'top_y': top_y,
            'length': length,
            'color': color,
            'obj_id': line_id,
            'label_id': label_id,
            'stability_id': stability_label,
            'stability': stability
        }
        
        return line_id
    
    def add_event(self, timeline_name, description, year):
        """Add an event to a timeline"""
        if timeline_name not in self.timelines:
            return None
            
        timeline = self.timelines[timeline_name]
        
        # Calculate position along timeline based on year
        year_ratio = (year - self.min_year) / (self.max_year - self.min_year)
        y = timeline['top_y'] + timeline['length'] * year_ratio
        
        # Create event marker
        marker_size = 6
        marker_id = self.canvas.create_oval(
            timeline['x'] - marker_size, y - marker_size,
            timeline['x'] + marker_size, y + marker_size,
            fill="#FFFFFF", outline=timeline['color'], width=2,
            tags=f"event_{timeline_name}_{len(self.events)}"
        )
        
        # Create small event text
        text_id = self.canvas.create_text(
            timeline['x'] + marker_size + 5, y,
            text=description[:15] + "..." if len(description) > 15 else description,
            fill="white", anchor="w", font=("Arial", 8),
            tags=f"event_text_{timeline_name}_{len(self.events)}"
        )
        
        # Store event data
        event_id = len(self.events)
        self.events[(timeline_name, event_id)] = {
            'x': timeline['x'],
            'y': y,
            'year': year,
            'description': description,
            'obj_id': marker_id,
            'text_id': text_id
        }
        
        return marker_id
    
    def connect_timelines(self, timeline1, timeline2, connection_type="standard"):
        """Connect two timelines"""
        if timeline1 not in self.timelines or timeline2 not in self.timelines:
            return None
            
        t1 = self.timelines[timeline1]
        t2 = self.timelines[timeline2]
        
        # Determine line style based on connection type
        if connection_type == "quantum_entangled":
            line_color = "#FF00FF"  # Magenta for quantum entanglement
            line_width = 2
            line_dash = (5, 3)
        elif connection_type == "branched":
            line_color = "#00FFFF"  # Cyan for timeline branching
            line_width = 2
            line_dash = (8, 4)
        elif connection_type == "merged":
            line_color = "#FFFF00"  # Yellow for timeline merging
            line_width = 2
            line_dash = (2, 2)
        else:  # standard
            line_color = "#4080FF"  # Blue for normal connections
            line_width = 1
            line_dash = None
        
        # Calculate connection points (middle of timelines)
        y1 = t1['top_y'] + t1['length'] / 2
        y2 = t2['top_y'] + t2['length'] / 2
        
        # Create connection line
        connection_id = self.canvas.create_line(
            t1['x'], y1, t2['x'], y2,
            fill=line_color, width=line_width, dash=line_dash,
            tags=f"connection_{timeline1}_{timeline2}"
        )
        
        # Store connection data
        self.connections.append((timeline1, timeline2, connection_id))
        
        return connection_id
    
    def on_mouse_move(self, event):
        """Handle mouse movement for hover effects"""
        # Clear previous hover text
        if self.hover_text_id:
            self.canvas.delete(self.hover_text_id)
            self.hover_text_id = None
            
        # Check for object under mouse
        item_ids = self.canvas.find_overlapping(event.x-2, event.y-2, event.x+2, event.y+2)
        if not item_ids:
            return
            
        # Get tags for all overlapping items
        for item_id in item_ids:
            tags = self.canvas.gettags(item_id)
            
            # Show information for timelines
            for tag in tags:
                if tag.startswith("timeline_") and not tag.startswith("timeline_label_") and not tag.startswith("timeline_stab_"):
                    timeline_name = tag[9:]
                    if timeline_name in self.timelines:
                        timeline = self.timelines[timeline_name]
                        info = f"Timeline: {timeline_name}\nStability: {timeline['stability']:.2f}"
                        self.hover_text_id = self.canvas.create_text(
                            event.x + 10, event.y - 10, text=info, fill="white", 
                            font=("Arial", 9), anchor="w"
                        )
                        return
                        
                # Show information for events
                elif tag.startswith("event_") and not tag.startswith("event_text_"):
                    parts = tag.split("_")
                    if len(parts) >= 3:
                        timeline_name = parts[1]
                        event_id = int(parts[2])
                        key = (timeline_name, event_id)
                        if key in self.events:
                            event = self.events[key]
                            info = f"Event: {event['description']}\nYear: {event['year']}\nTimeline: {timeline_name}"
                            self.hover_text_id = self.canvas.create_text(
                                event.x + 15, event.y - 10, text=info, fill="white", 
                                font=("Arial", 9), anchor="w"
                            )
                            return
    
    def on_click(self, event):
        """Handle mouse clicks for selection"""
        # Find items under click
        item_ids = self.canvas.find_overlapping(event.x-2, event.y-2, event.x+2, event.y+2)
        if not item_ids:
            return
            
        # Get tags for all overlapping items
        for item_id in item_ids:
            tags = self.canvas.gettags(item_id)
            
            # Process timeline selection
            for tag in tags:
                if tag.startswith("timeline_") and not tag.startswith("timeline_label_") and not tag.startswith("timeline_stab_"):
                    timeline_name = tag[9:]
                    self.select_timeline(timeline_name)
                    return
                    
                # Process event selection
                elif tag.startswith("event_") and not tag.startswith("event_text_"):
                    parts = tag.split("_")
                    if len(parts) >= 3:
                        timeline_name = parts[1]
                        event_id = int(parts[2])
                        self.select_event(timeline_name, event_id)
                        return
    
    def select_timeline(self, timeline_name):
        """Select a timeline"""
        # Clear previous selection
        self.clear_selection()
        
        if timeline_name not in self.timelines:
            return
            
        timeline = self.timelines[timeline_name]
        
        # Highlight the timeline
        self.canvas.itemconfig(timeline['obj_id'], width=6)
        
        # Remember selection
        self.selected = {'type': 'timeline', 'id': timeline_name}
        
        # Trigger selection event if we have a callback
        if hasattr(self, 'on_selection_change'):
            self.on_selection_change(self.selected)
    
    def select_event(self, timeline_name, event_id):
        """Select an event"""
        # Clear previous selection
        self.clear_selection()
        
        key = (timeline_name, event_id)
        if key not in self.events:
            return
            
        event = self.events[key]
        
        # Highlight the event
        self.canvas.itemconfig(event['obj_id'], width=3)
        
        # Remember selection
        self.selected = {'type': 'event', 'id': key}
        
        # Trigger selection event if we have a callback
        if hasattr(self, 'on_selection_change'):
            self.on_selection_change(self.selected)
    
    def clear_selection(self):
        """Clear current selection"""
        if not self.selected:
            return
            
        if self.selected['type'] == 'timeline':
            timeline_name = self.selected['id']
            if timeline_name in self.timelines:
                timeline = self.timelines[timeline_name]
                self.canvas.itemconfig(timeline['obj_id'], width=4)
                
        elif self.selected['type'] == 'event':
            timeline_name, event_id = self.selected['id']
            key = (timeline_name, event_id)
            if key in self.events:
                event = self.events[key]
                self.canvas.itemconfig(event['obj_id'], width=2)
                
        self.selected = None
