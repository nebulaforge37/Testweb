
"""
Algebra, Functions, and Calculus Algorithm Cheat Sheet
======================================================
A comprehensive reference for mathematical formulas and algorithms 
used in algebra, functions, and calculus operations.
"""

import math
import numpy as np
from typing import Dict, List, Tuple, Optional, Callable, Union

class MathAlgorithmsReference:
    """
    Reference class containing key mathematical calculations and algorithms
    for algebra, functions, and calculus operations.
    """
    
    # ======== ALGEBRA SECTION ========
    
    @staticmethod
    def quadratic_formula(a: float, b: float, c: float) -> Tuple[Optional[float], Optional[float]]:
        """
        Solves a quadratic equation of the form ax² + bx + c = 0
        
        Parameters:
            a: Coefficient of x²
            b: Coefficient of x
            c: Constant term
            
        Returns:
            Tuple containing the two solutions (None if no real solutions)
            
        Formula: x = (-b ± √(b² - 4ac)) / 2a
        """
        if a == 0:  # Not a quadratic equation
            if b == 0:  # No variable term
                return None, None
            return -c / b, None  # Linear equation
            
        discriminant = b**2 - 4*a*c
        
        if discriminant < 0:  # No real solutions
            return None, None
            
        x1 = (-b + math.sqrt(discriminant)) / (2*a)
        x2 = (-b - math.sqrt(discriminant)) / (2*a)
        
        return x1, x2
    
    @staticmethod
    def linear_system_solver(A: List[List[float]], b: List[float]) -> Optional[List[float]]:
        """
        Solves a system of linear equations using Gaussian elimination
        
        Parameters:
            A: Coefficient matrix
            b: Constants vector
            
        Returns:
            Solution vector or None if no unique solution
        """
        try:
            # Convert to numpy arrays for efficient computation
            A_np = np.array(A, dtype=float)
            b_np = np.array(b, dtype=float)
            
            # Solve using numpy's linear algebra solver
            x = np.linalg.solve(A_np, b_np)
            
            return x.tolist()
        except np.linalg.LinAlgError:
            # No unique solution
            return None
    
    @staticmethod
    def matrix_operations(A: List[List[float]], B: List[List[float]], operation: str) -> List[List[float]]:
        """
        Performs matrix operations
        
        Parameters:
            A: First matrix
            B: Second matrix
            operation: One of 'add', 'subtract', 'multiply'
            
        Returns:
            Resulting matrix
        """
        A_np = np.array(A, dtype=float)
        B_np = np.array(B, dtype=float)
        
        if operation == 'add':
            result = A_np + B_np
        elif operation == 'subtract':
            result = A_np - B_np
        elif operation == 'multiply':
            result = np.matmul(A_np, B_np)
        else:
            raise ValueError("Operation must be one of 'add', 'subtract', 'multiply'")
            
        return result.tolist()
    
    @staticmethod
    def matrix_determinant(A: List[List[float]]) -> float:
        """
        Calculates the determinant of a matrix
        
        Parameters:
            A: Input matrix
            
        Returns:
            Determinant value
        """
        A_np = np.array(A, dtype=float)
        return float(np.linalg.det(A_np))
    
    @staticmethod
    def matrix_inverse(A: List[List[float]]) -> Optional[List[List[float]]]:
        """
        Calculates the inverse of a matrix
        
        Parameters:
            A: Input matrix
            
        Returns:
            Inverse matrix or None if not invertible
        """
        try:
            A_np = np.array(A, dtype=float)
            inv = np.linalg.inv(A_np)
            return inv.tolist()
        except np.linalg.LinAlgError:
            # Matrix is not invertible
            return None
    
    # ======== FUNCTIONS SECTION ========
    
    @staticmethod
    def function_composition(f: Callable[[float], float], g: Callable[[float], float]) -> Callable[[float], float]:
        """
        Creates a function composition (f ∘ g)(x) = f(g(x))
        
        Parameters:
            f: Outer function
            g: Inner function
            
        Returns:
            Composed function
        """
        def composed_function(x: float) -> float:
            return f(g(x))
        
        return composed_function
    
    @staticmethod
    def function_inverse(f: Callable[[float], float], domain: Tuple[float, float], 
                        precision: float = 0.0001) -> Callable[[float], float]:
        """
        Approximates the inverse of a function numerically
        
        Parameters:
            f: Original function
            domain: Domain interval where the function is invertible
            precision: Desired precision level
            
        Returns:
            Approximate inverse function
        """
        def inverse_function(y: float) -> float:
            # Binary search to find x such that f(x) = y
            a, b = domain
            while (b - a) > precision:
                midpoint = (a + b) / 2
                if f(midpoint) < y:
                    a = midpoint
                else:
                    b = midpoint
            return (a + b) / 2
        
        return inverse_function
    
    @staticmethod
    def function_interpolation(points: List[Tuple[float, float]], x: float) -> float:
        """
        Performs linear interpolation between data points
        
        Parameters:
            points: List of (x, y) coordinate pairs
            x: Point at which to interpolate
            
        Returns:
            Interpolated y value
        """
        # Sort points by x value
        sorted_points = sorted(points)
        
        # Check bounds
        if x <= sorted_points[0][0]:
            return sorted_points[0][1]
        if x >= sorted_points[-1][0]:
            return sorted_points[-1][1]
        
        # Find the two points to interpolate between
        for i in range(len(sorted_points) - 1):
            x1, y1 = sorted_points[i]
            x2, y2 = sorted_points[i + 1]
            
            if x1 <= x <= x2:
                # Linear interpolation formula
                t = (x - x1) / (x2 - x1)
                return y1 + t * (y2 - y1)
        
        return 0.0  # Should not reach here

    @staticmethod
    def polynomial_evaluation(coefficients: List[float], x: float) -> float:
        """
        Evaluates a polynomial at a specific point using Horner's method
        
        Parameters:
            coefficients: Polynomial coefficients [a_n, a_{n-1}, ..., a_1, a_0]
            x: Point at which to evaluate
            
        Returns:
            Result of p(x)
        """
        result = 0
        for coefficient in coefficients:
            result = result * x + coefficient
            
        return result
    
    # ======== CALCULUS SECTION ========
    
    @staticmethod
    def numerical_differentiation(f: Callable[[float], float], x: float, h: float = 0.0001) -> float:
        """
        Calculates the numerical derivative of a function at a point
        
        Parameters:
            f: Function to differentiate
            x: Point at which to calculate derivative
            h: Step size
            
        Returns:
            Approximate derivative
            
        Formula: f'(x) ≈ (f(x + h) - f(x - h)) / (2h)  [Central difference]
        """
        return (f(x + h) - f(x - h)) / (2 * h)
    
    @staticmethod
    def numerical_integration(f: Callable[[float], float], a: float, b: float, n: int = 1000) -> float:
        """
        Computes the numerical definite integral using Simpson's rule
        
        Parameters:
            f: Function to integrate
            a: Lower bound
            b: Upper bound
            n: Number of intervals (must be even)
            
        Returns:
            Approximate integral
            
        Formula: ∫(a,b) f(x) dx ≈ (h/3) * [f(a) + 4*f(a+h) + 2*f(a+2h) + ... + 4*f(b-h) + f(b)]
        """
        if n % 2 != 0:
            n += 1  # Ensure n is even
            
        h = (b - a) / n
        integral = f(a) + f(b)
        
        for i in range(1, n):
            x = a + i * h
            integral += f(x) * (4 if i % 2 else 2)
            
        return integral * h / 3
    
    @staticmethod
    def gradient_descent(f: Callable[[List[float]], float], grad_f: Callable[[List[float]], List[float]], 
                       initial_point: List[float], learning_rate: float = 0.01, 
                       tolerance: float = 1e-6, max_iterations: int = 1000) -> Tuple[List[float], float]:
        """
        Finds the minimum of a function using gradient descent
        
        Parameters:
            f: Function to minimize
            grad_f: Gradient function of f
            initial_point: Starting point
            learning_rate: Learning rate for gradient steps
            tolerance: Convergence tolerance
            max_iterations: Maximum iterations
            
        Returns:
            Tuple of (minimum point, minimum value)
        """
        point = initial_point.copy()
        value = f(point)
        
        for _ in range(max_iterations):
            gradient = grad_f(point)
            
            # Update point
            new_point = [p - learning_rate * g for p, g in zip(point, gradient)]
            new_value = f(new_point)
            
            # Check convergence
            if abs(new_value - value) < tolerance:
                point = new_point
                value = new_value
                break
                
            point = new_point
            value = new_value
            
        return point, value
    
    @staticmethod
    def newton_method(f: Callable[[float], float], df: Callable[[float], float], 
                     initial_guess: float, tolerance: float = 1e-6, 
                     max_iterations: int = 100) -> Optional[float]:
        """
        Finds a root of a function using Newton's method
        
        Parameters:
            f: Function to find root of
            df: Derivative of the function
            initial_guess: Starting guess
            tolerance: Convergence tolerance
            max_iterations: Maximum iterations
            
        Returns:
            Root or None if not converged
            
        Formula: x_{n+1} = x_n - f(x_n) / f'(x_n)
        """
        x = initial_guess
        
        for _ in range(max_iterations):
            fx = f(x)
            
            if abs(fx) < tolerance:
                return x
                
            dfx = df(x)
            
            if dfx == 0:
                # Derivative is zero, can't continue
                return None
                
            x = x - fx / dfx
            
        # Did not converge
        return None
    
    @staticmethod
    def taylor_series(f: Callable[[float], float], df_list: List[Callable[[float], float]], 
                     a: float, x: float, n: int) -> float:
        """
        Evaluates the Taylor series of a function at a point
        
        Parameters:
            f: Function to expand
            df_list: List of derivatives [f', f'', ..., f^(n)]
            a: Point around which to expand
            x: Point at which to evaluate
            n: Number of terms
            
        Returns:
            Taylor series approximation
            
        Formula: f(x) ≈ f(a) + f'(a)(x-a) + f''(a)(x-a)²/2! + ... + f^(n)(a)(x-a)^n/n!
        """
        result = f(a)
        
        for i in range(1, n + 1):
            derivative = df_list[i - 1]
            result += (derivative(a) * ((x - a) ** i)) / math.factorial(i)
            
        return result
    
    @staticmethod
    def laplace_transform(f: Callable[[float], float], s: float, t_max: float = 100, 
                        n: int = 1000) -> float:
        """
        Numerically computes the Laplace transform of a function
        
        Parameters:
            f: Function to transform
            s: Transform parameter
            t_max: Upper integration limit
            n: Number of intervals
            
        Returns:
            Laplace transform value
            
        Formula: L{f(t)}(s) = ∫(0,∞) e^(-st) f(t) dt
        """
        def integrand(t):
            return math.exp(-s * t) * f(t)
            
        return MathAlgorithmsReference.numerical_integration(integrand, 0, t_max, n)
    
    # ======== SPECIAL ALGORITHMS ========
    
    @staticmethod
    def fft(signal: List[complex]) -> List[complex]:
        """
        Fast Fourier Transform implementation
        
        Parameters:
            signal: Complex signal to transform
            
        Returns:
            Frequency domain representation
        """
        # Use NumPy's FFT
        signal_np = np.array(signal, dtype=complex)
        fft_result = np.fft.fft(signal_np)
        return fft_result.tolist()
    
    @staticmethod
    def eigenvalues(A: List[List[float]]) -> List[float]:
        """
        Calculates eigenvalues of a matrix
        
        Parameters:
            A: Input matrix
            
        Returns:
            List of eigenvalues
        """
        A_np = np.array(A, dtype=float)
        eigenvalues = np.linalg.eigvals(A_np)
        return eigenvalues.tolist()
    
    @staticmethod
    def svd_decomposition(A: List[List[float]]) -> Tuple[List[List[float]], List[float], List[List[float]]]:
        """
        Performs Singular Value Decomposition (SVD)
        
        Parameters:
            A: Input matrix
            
        Returns:
            Tuple of (U, S, V) matrices
            
        Formula: A = U · Σ · V^T
        """
        A_np = np.array(A, dtype=float)
        U, S, Vt = np.linalg.svd(A_np)
        return U.tolist(), S.tolist(), Vt.tolist()
    
    @staticmethod
    def pca(data: List[List[float]], n_components: int) -> Tuple[List[List[float]], List[List[float]]]:
        """
        Performs Principal Component Analysis (PCA)
        
        Parameters:
            data: Input data matrix (each row is a sample)
            n_components: Number of principal components to retain
            
        Returns:
            Tuple of (transformed data, principal components)
        """
        data_np = np.array(data, dtype=float)
        
        # Standardize the data
        data_mean = np.mean(data_np, axis=0)
        data_std = np.std(data_np, axis=0)
        data_standardized = (data_np - data_mean) / data_std
        
        # Compute covariance matrix
        cov_matrix = np.cov(data_standardized, rowvar=False)
        
        # Compute eigenvectors and eigenvalues
        eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
        
        # Sort by eigenvalues in descending order
        idx = np.argsort(eigenvalues)[::-1]
        eigenvectors = eigenvectors[:, idx]
        
        # Select top n_components eigenvectors
        components = eigenvectors[:, :n_components]
        
        # Transform the data
        transformed_data = np.dot(data_standardized, components)
        
        return transformed_data.tolist(), components.tolist()


def demonstrate_algebra():
    """Demonstrate algebra algorithms"""
    
    calc = MathAlgorithmsReference()
    
    print("=== ALGEBRA ALGORITHMS ===\n")
    
    # Demonstrate quadratic formula
    a, b, c = 1, -3, 2
    x1, x2 = calc.quadratic_formula(a, b, c)
    print(f"Quadratic Equation: {a}x² + {b}x + {c} = 0")
    print(f"Solutions: x₁ = {x1}, x₂ = {x2}\n")
    
    # Demonstrate linear system solver
    A = [[3, 2], [1, -1]]
    b = [5, -1]
    solution = calc.linear_system_solver(A, b)
    print(f"Linear System: 3x + 2y = 5, x - y = -1")
    print(f"Solution: {solution}\n")
    
    # Demonstrate matrix operations
    A = [[1, 2], [3, 4]]
    B = [[5, 6], [7, 8]]
    print(f"Matrix A: {A}")
    print(f"Matrix B: {B}")
    
    result = calc.matrix_operations(A, B, 'add')
    print(f"A + B = {result}")
    
    result = calc.matrix_operations(A, B, 'multiply')
    print(f"A × B = {result}")
    
    det = calc.matrix_determinant(A)
    print(f"Determinant of A: {det}\n")


def demonstrate_calculus():
    """Demonstrate calculus algorithms"""
    
    calc = MathAlgorithmsReference()
    
    print("=== CALCULUS ALGORITHMS ===\n")
    
    # Demonstrate differentiation
    def f(x):
        return x**2
        
    def df(x):
        return 2*x
    
    x_point = 3.0
    numerical_derivative = calc.numerical_differentiation(f, x_point)
    actual_derivative = df(x_point)
    
    print(f"Function: f(x) = x²")
    print(f"Point: x = {x_point}")
    print(f"Numerical Derivative: {numerical_derivative}")
    print(f"Actual Derivative: {actual_derivative}\n")
    
    # Demonstrate integration
    a, b = 0, 1
    integral = calc.numerical_integration(f, a, b)
    actual_integral = (b**3 - a**3) / 3
    
    print(f"Integral of f(x) = x² from {a} to {b}")
    print(f"Numerical Integration: {integral}")
    print(f"Actual Integral: {actual_integral}\n")
    
    # Demonstrate Newton's Method
    def g(x):
        return x**2 - 4
        
    def dg(x):
        return 2*x
    
    root = calc.newton_method(g, dg, 3.0)
    print(f"Finding root of g(x) = x² - 4")
    print(f"Newton's Method Result: {root}")
    print(f"Verification: g({root}) = {g(root)}\n")


def main():
    """Demonstrate math algorithms"""
    
    print("=== MATH ALGORITHMS CHEAT SHEET DEMONSTRATION ===\n")
    
    demonstrate_algebra()
    demonstrate_calculus()
    
    print("\nAdditional algorithms available in the MathAlgorithmsReference class:")
    print("  - Polynomial evaluation using Horner's method")
    print("  - Function composition and inverse calculation")
    print("  - Gradient descent optimization")
    print("  - Taylor series expansion")
    print("  - Fast Fourier Transform (FFT)")
    print("  - Singular Value Decomposition (SVD)")
    print("  - Principal Component Analysis (PCA)")


if __name__ == "__main__":
    main()
