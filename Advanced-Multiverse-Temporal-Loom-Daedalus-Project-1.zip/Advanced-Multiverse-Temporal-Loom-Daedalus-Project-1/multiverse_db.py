
import sqlite3
import json
import os
from typing import Dict, List, Any, Optional, Tuple

class MultiverseDatabase:
    def __init__(self, db_path="multiverse.db"):
        """Initialize the multiverse database."""
        self.db_path = db_path
        self.initialize_db()

    def initialize_db(self):
        """Create database tables if they don't exist."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create timelines table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS timelines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                stability REAL NOT NULL,
                worldline_integrity REAL NOT NULL,
                reality_coefficient REAL NOT NULL,
                timewave_influence REAL NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            
            # Create quantum_states table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS quantum_states (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timeline_id INTEGER NOT NULL,
                entanglement_level REAL NOT NULL,
                superposition BOOLEAN NOT NULL,
                observation_count INTEGER NOT NULL,
                wave_function_collapse BOOLEAN NOT NULL,
                quantum_field_energy REAL NOT NULL,
                spin REAL NOT NULL,
                quantum_coherence REAL NOT NULL,
                FOREIGN KEY (timeline_id) REFERENCES timelines (id) ON DELETE CASCADE
            )
            ''')
            
            # Create events table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timeline_id INTEGER NOT NULL,
                year INTEGER NOT NULL,
                description TEXT NOT NULL,
                event_type TEXT,
                significance REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (timeline_id) REFERENCES timelines (id) ON DELETE CASCADE
            )
            ''')
            
            # Create wormholes table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS wormholes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                origin_timeline_id INTEGER NOT NULL,
                destination_timeline_id INTEGER NOT NULL,
                stability REAL NOT NULL,
                year_shift INTEGER NOT NULL,
                quantum_shielding REAL NOT NULL,
                activation_count INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (origin_timeline_id) REFERENCES timelines (id) ON DELETE CASCADE,
                FOREIGN KEY (destination_timeline_id) REFERENCES timelines (id) ON DELETE CASCADE
            )
            ''')
            
            # Create timeline_connections table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS timeline_connections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timeline1_id INTEGER NOT NULL,
                timeline2_id INTEGER NOT NULL,
                is_quantum_entangled BOOLEAN NOT NULL DEFAULT 0,
                entanglement_strength REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (timeline1_id) REFERENCES timelines (id) ON DELETE CASCADE,
                FOREIGN KEY (timeline2_id) REFERENCES timelines (id) ON DELETE CASCADE,
                UNIQUE(timeline1_id, timeline2_id)
            )
            ''')
            
            # Create paradoxes table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS paradoxes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timeline_id INTEGER NOT NULL,
                year INTEGER NOT NULL,
                paradox_type TEXT NOT NULL,
                description TEXT NOT NULL,
                resolved BOOLEAN NOT NULL DEFAULT 0,
                resolution_method TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (timeline_id) REFERENCES timelines (id) ON DELETE CASCADE
            )
            ''')
            
            # Create timewaves table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS timewaves (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                origin_timeline_id INTEGER NOT NULL,
                year INTEGER NOT NULL,
                strength REAL NOT NULL,
                description TEXT NOT NULL,
                current_strength REAL NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (origin_timeline_id) REFERENCES timelines (id) ON DELETE CASCADE
            )
            ''')
            
            # Create cosmic_strings table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS cosmic_strings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timeline_id INTEGER NOT NULL,
                strength REAL NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (timeline_id) REFERENCES timelines (id) ON DELETE CASCADE
            )
            ''')
            
            conn.commit()
            print(f"Initialized multiverse database at {self.db_path}")

    # Timeline methods
    def save_timeline(self, timeline) -> int:
        """Save a timeline to the database and return its ID."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Insert timeline
            cursor.execute('''
            INSERT INTO timelines (name, stability, worldline_integrity, reality_coefficient, timewave_influence)
            VALUES (?, ?, ?, ?, ?)
            ''', (
                timeline.name,
                timeline.stability,
                timeline.worldline_integrity,
                timeline.reality_coefficient,
                timeline.timewave_influence
            ))
            
            timeline_id = cursor.lastrowid
            
            # Insert quantum state
            cursor.execute('''
            INSERT INTO quantum_states (
                timeline_id, entanglement_level, superposition, observation_count,
                wave_function_collapse, quantum_field_energy, spin, quantum_coherence
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                timeline_id,
                timeline.quantum_state.entanglement_level,
                1 if timeline.quantum_state.superposition else 0,
                timeline.quantum_state.observation_count,
                1 if timeline.quantum_state.wave_function_collapse else 0,
                timeline.quantum_state.quantum_field_energy,
                timeline.quantum_state.spin,
                timeline.quantum_state.quantum_coherence
            ))
            
            # Insert events
            for year, event in timeline.events:
                cursor.execute('''
                INSERT INTO events (timeline_id, year, description)
                VALUES (?, ?, ?)
                ''', (timeline_id, year, event))
            
            conn.commit()
            return timeline_id
            
    def update_timeline(self, timeline):
        """Update an existing timeline in the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline ID
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timeline.name,))
            result = cursor.fetchone()
            
            if not result:
                return self.save_timeline(timeline)
                
            timeline_id = result[0]
            
            # Update timeline
            cursor.execute('''
            UPDATE timelines 
            SET stability = ?, worldline_integrity = ?, reality_coefficient = ?, timewave_influence = ?
            WHERE id = ?
            ''', (
                timeline.stability,
                timeline.worldline_integrity,
                timeline.reality_coefficient,
                timeline.timewave_influence,
                timeline_id
            ))
            
            # Update quantum state
            cursor.execute('''
            UPDATE quantum_states 
            SET entanglement_level = ?, superposition = ?, observation_count = ?,
                wave_function_collapse = ?, quantum_field_energy = ?, spin = ?, quantum_coherence = ?
            WHERE timeline_id = ?
            ''', (
                timeline.quantum_state.entanglement_level,
                1 if timeline.quantum_state.superposition else 0,
                timeline.quantum_state.observation_count,
                1 if timeline.quantum_state.wave_function_collapse else 0,
                timeline.quantum_state.quantum_field_energy,
                timeline.quantum_state.spin,
                timeline.quantum_state.quantum_coherence,
                timeline_id
            ))
            
            conn.commit()
            return timeline_id
    
    def load_timeline(self, timeline_name) -> Optional[Dict]:
        """Load a timeline from the database by name."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get timeline
            cursor.execute('''
            SELECT t.*, qs.entanglement_level, qs.superposition, qs.observation_count,
                   qs.wave_function_collapse, qs.quantum_field_energy, qs.spin, qs.quantum_coherence
            FROM timelines t
            JOIN quantum_states qs ON t.id = qs.timeline_id
            WHERE t.name = ?
            ''', (timeline_name,))
            
            timeline_data = cursor.fetchone()
            if not timeline_data:
                return None
                
            timeline_dict = dict(timeline_data)
            
            # Get events
            cursor.execute('''
            SELECT year, description FROM events
            WHERE timeline_id = ?
            ORDER BY year
            ''', (timeline_data['id'],))
            
            events = [(row['year'], row['description']) for row in cursor.fetchall()]
            timeline_dict['events'] = events
            
            return timeline_dict
    
    def delete_timeline(self, timeline_name) -> bool:
        """Delete a timeline from the database by name."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM timelines WHERE name = ?", (timeline_name,))
            conn.commit()
            return cursor.rowcount > 0
    
    def get_all_timelines(self) -> List[str]:
        """Get a list of all timeline names."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM timelines ORDER BY name")
            return [row[0] for row in cursor.fetchall()]
    
    # Wormhole methods
    def save_wormhole(self, wormhole) -> int:
        """Save a wormhole to the database and return its ID."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline IDs
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (wormhole.origin.name,))
            origin_id = cursor.fetchone()[0]
            
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (wormhole.destination.name,))
            destination_id = cursor.fetchone()[0]
            
            # Insert wormhole
            cursor.execute('''
            INSERT INTO wormholes (
                origin_timeline_id, destination_timeline_id, stability,
                year_shift, quantum_shielding, activation_count
            )
            VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                origin_id,
                destination_id,
                wormhole.stability,
                wormhole.year_shift,
                wormhole.quantum_shielding,
                wormhole.activation_count
            ))
            
            wormhole_id = cursor.lastrowid
            conn.commit()
            return wormhole_id
    
    def update_wormhole(self, wormhole):
        """Update an existing wormhole in the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline IDs
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (wormhole.origin.name,))
            origin_id = cursor.fetchone()[0]
            
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (wormhole.destination.name,))
            destination_id = cursor.fetchone()[0]
            
            # Find wormhole ID
            cursor.execute('''
            SELECT id FROM wormholes
            WHERE origin_timeline_id = ? AND destination_timeline_id = ?
            ''', (origin_id, destination_id))
            
            result = cursor.fetchone()
            if not result:
                return self.save_wormhole(wormhole)
                
            wormhole_id = result[0]
            
            # Update wormhole
            cursor.execute('''
            UPDATE wormholes
            SET stability = ?, year_shift = ?, quantum_shielding = ?, activation_count = ?
            WHERE id = ?
            ''', (
                wormhole.stability,
                wormhole.year_shift,
                wormhole.quantum_shielding,
                wormhole.activation_count,
                wormhole_id
            ))
            
            conn.commit()
            return wormhole_id
    
    # Event methods
    def add_event(self, timeline_name, year, description, event_type=None, significance=None):
        """Add an event to a timeline."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline ID
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timeline_name,))
            result = cursor.fetchone()
            
            if not result:
                return False
                
            timeline_id = result[0]
            
            # Insert event
            cursor.execute('''
            INSERT INTO events (timeline_id, year, description, event_type, significance)
            VALUES (?, ?, ?, ?, ?)
            ''', (timeline_id, year, description, event_type, significance))
            
            conn.commit()
            return cursor.lastrowid
    
    # Paradox methods
    def record_paradox(self, timeline_name, year, paradox_type, description, resolved=False, resolution_method=None):
        """Record a paradox in the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline ID
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timeline_name,))
            result = cursor.fetchone()
            
            if not result:
                return False
                
            timeline_id = result[0]
            
            # Insert paradox
            cursor.execute('''
            INSERT INTO paradoxes (
                timeline_id, year, paradox_type, description, resolved, resolution_method
            )
            VALUES (?, ?, ?, ?, ?, ?)
            ''', (timeline_id, year, paradox_type, description, 1 if resolved else 0, resolution_method))
            
            conn.commit()
            return cursor.lastrowid
    
    # Connection methods
    def save_timeline_connection(self, timeline1_name, timeline2_name, is_quantum_entangled=False, entanglement_strength=None):
        """Save a connection between two timelines."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline IDs
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timeline1_name,))
            result1 = cursor.fetchone()
            
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timeline2_name,))
            result2 = cursor.fetchone()
            
            if not result1 or not result2:
                return False
                
            timeline1_id = result1[0]
            timeline2_id = result2[0]
            
            # Ensure the connection is stored with the lower ID first for consistency
            if timeline1_id > timeline2_id:
                timeline1_id, timeline2_id = timeline2_id, timeline1_id
            
            # Check if connection already exists
            cursor.execute('''
            SELECT id FROM timeline_connections
            WHERE timeline1_id = ? AND timeline2_id = ?
            ''', (timeline1_id, timeline2_id))
            
            result = cursor.fetchone()
            
            if result:
                # Update existing connection
                cursor.execute('''
                UPDATE timeline_connections
                SET is_quantum_entangled = ?, entanglement_strength = ?
                WHERE timeline1_id = ? AND timeline2_id = ?
                ''', (1 if is_quantum_entangled else 0, entanglement_strength, timeline1_id, timeline2_id))
            else:
                # Insert new connection
                cursor.execute('''
                INSERT INTO timeline_connections (
                    timeline1_id, timeline2_id, is_quantum_entangled, entanglement_strength
                )
                VALUES (?, ?, ?, ?)
                ''', (timeline1_id, timeline2_id, 1 if is_quantum_entangled else 0, entanglement_strength))
            
            conn.commit()
            return True
    
    # Timewave methods
    def save_timewave(self, timewave):
        """Save a timewave to the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline ID
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timewave.origin.name,))
            result = cursor.fetchone()
            
            if not result:
                return False
                
            timeline_id = result[0]
            
            # Insert timewave
            cursor.execute('''
            INSERT INTO timewaves (
                origin_timeline_id, year, strength, description, current_strength
            )
            VALUES (?, ?, ?, ?, ?)
            ''', (timeline_id, timewave.year, timewave.strength, timewave.description, timewave.strength))
            
            conn.commit()
            return cursor.lastrowid
    
    def update_timewave_strength(self, timewave_id, current_strength):
        """Update the current strength of a timewave."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
            UPDATE timewaves
            SET current_strength = ?
            WHERE id = ?
            ''', (current_strength, timewave_id))
            conn.commit()
            return cursor.rowcount > 0
    
    # Query methods
    def get_unstable_timelines(self, stability_threshold=0.4):
        """Get all timelines with stability below the threshold."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
            SELECT name, stability, worldline_integrity
            FROM timelines
            WHERE stability < ?
            ORDER BY stability
            ''', (stability_threshold,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_quantum_anomalies(self):
        """Get all timelines with quantum anomalies."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
            SELECT t.name, qs.wave_function_collapse, qs.entanglement_level, qs.superposition
            FROM timelines t
            JOIN quantum_states qs ON t.id = qs.timeline_id
            WHERE qs.wave_function_collapse = 1 
               OR (qs.entanglement_level > 0.8 AND t.stability < 0.6)
               OR qs.superposition = 1
            ''')
            return [dict(row) for row in cursor.fetchall()]
    
    def get_paradox_statistics(self):
        """Get statistics about paradoxes by type."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
            SELECT paradox_type, COUNT(*) as count, 
                   SUM(CASE WHEN resolved = 1 THEN 1 ELSE 0 END) as resolved_count
            FROM paradoxes
            GROUP BY paradox_type
            ORDER BY count DESC
            ''')
            return [{"type": row[0], "count": row[1], "resolved": row[2]} for row in cursor.fetchall()]
    
    def export_multiverse_state(self, file_path="multiverse_export.json"):
        """Export the entire multiverse state to a JSON file."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get all timelines with their quantum states
            cursor.execute('''
            SELECT t.*, qs.* 
            FROM timelines t
            JOIN quantum_states qs ON t.id = qs.timeline_id
            ''')
            timelines = [dict(row) for row in cursor.fetchall()]
            
            # Get events for each timeline
            for timeline in timelines:
                cursor.execute('''
                SELECT year, description FROM events
                WHERE timeline_id = ?
                ORDER BY year
                ''', (timeline['id'],))
                timeline['events'] = [{"year": row[0], "description": row[1]} for row in cursor.fetchall()]
            
            # Get wormholes
            cursor.execute('''
            SELECT w.*, t1.name as origin_name, t2.name as destination_name
            FROM wormholes w
            JOIN timelines t1 ON w.origin_timeline_id = t1.id
            JOIN timelines t2 ON w.destination_timeline_id = t2.id
            ''')
            wormholes = [dict(row) for row in cursor.fetchall()]
            
            # Get connections
            cursor.execute('''
            SELECT c.*, t1.name as timeline1_name, t2.name as timeline2_name
            FROM timeline_connections c
            JOIN timelines t1 ON c.timeline1_id = t1.id
            JOIN timelines t2 ON c.timeline2_id = t2.id
            ''')
            connections = [dict(row) for row in cursor.fetchall()]
            
            # Get paradoxes
            cursor.execute('''
            SELECT p.*, t.name as timeline_name
            FROM paradoxes p
            JOIN timelines t ON p.timeline_id = t.id
            ''')
            paradoxes = [dict(row) for row in cursor.fetchall()]
            
            # Get timewaves
            cursor.execute('''
            SELECT tw.*, t.name as origin_name
            FROM timewaves tw
            JOIN timelines t ON tw.origin_timeline_id = t.id
            ''')
            timewaves = [dict(row) for row in cursor.fetchall()]
            
            # Get cosmic strings
            cursor.execute('''
            SELECT cs.*, t.name as timeline_name
            FROM cosmic_strings cs
            JOIN timelines t ON cs.timeline_id = t.id
            ''')
            cosmic_strings = [dict(row) for row in cursor.fetchall()]
            
            # Assemble the export data
            export_data = {
                "timelines": timelines,
                "wormholes": wormholes,
                "connections": connections,
                "paradoxes": paradoxes,
                "timewaves": timewaves,
                "cosmic_strings": cosmic_strings,
                "export_timestamp": "CURRENT_TIMESTAMP"
            }
            
            # Write to file
            with open(file_path, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            return file_path
    
    def save_cosmic_string(self, timeline_name, strength):
        """Save a cosmic string to the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get timeline ID
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (timeline_name,))
            result = cursor.fetchone()
            
            if not result:
                return False
                
            timeline_id = result[0]
            
            # Insert cosmic string
            cursor.execute('''
            INSERT INTO cosmic_strings (timeline_id, strength)
            VALUES (?, ?)
            ''', (timeline_id, strength))
            
            conn.commit()
            return cursor.lastrowid
    
    def import_multiverse_state(self, file_path="multiverse_export.json"):
        """Import a multiverse state from a JSON file."""
        if not os.path.exists(file_path):
            return False
            
        try:
            with open(file_path, 'r') as f:
                import_data = json.load(f)
                
            # Clear existing database
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                tables = [
                    "timeline_connections", "events", "paradoxes", 
                    "timewaves", "cosmic_strings", "wormholes", 
                    "quantum_states", "timelines"
                ]
                
                for table in tables:
                    cursor.execute(f"DELETE FROM {table}")
                
                # Reset sequences
                cursor.execute("DELETE FROM sqlite_sequence")
                
                # For each table, we need to reconstruct the right relationships
                # ... Implementation depends on the structure of import_data
                # This would be a complex set of SQL operations
                
                conn.commit()
                
            return True
        except Exception as e:
            print(f"Error importing multiverse state: {e}")
            return False
        
    def search_events(self, query):
        """Search for events containing the query string."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
            SELECT e.*, t.name as timeline_name
            FROM events e
            JOIN timelines t ON e.timeline_id = t.id
            WHERE e.description LIKE ?
            ORDER BY e.year
            ''', (f'%{query}%',))
            return [dict(row) for row in cursor.fetchall()]
    
    def find_connected_timelines(self, timeline_name):
        """Find all timelines connected to the given timeline."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
            SELECT t2.name 
            FROM timeline_connections c
            JOIN timelines t1 ON c.timeline1_id = t1.id
            JOIN timelines t2 ON c.timeline2_id = t2.id
            WHERE t1.name = ?
            UNION
            SELECT t1.name 
            FROM timeline_connections c
            JOIN timelines t1 ON c.timeline1_id = t1.id
            JOIN timelines t2 ON c.timeline2_id = t2.id
            WHERE t2.name = ?
            ''', (timeline_name, timeline_name))
            return [row[0] for row in cursor.fetchall()]
            
    # Coordinate system methods
    def initialize_coordinate_tables(self):
        """Create tables for the coordinate system."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create spatial_coordinates table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS spatial_coordinates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                x REAL NOT NULL,
                y REAL NOT NULL,
                z REAL NOT NULL,
                uncertainty REAL NOT NULL,
                reference_system TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            
            # Create temporal_coordinates table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS temporal_coordinates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                day INTEGER NOT NULL,
                hour INTEGER NOT NULL,
                minute INTEGER NOT NULL,
                second INTEGER NOT NULL,
                uncertainty_days REAL NOT NULL,
                calendar_system TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            
            # Create spacetime_coordinates table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS spacetime_coordinates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                spatial_id INTEGER NOT NULL,
                temporal_id INTEGER NOT NULL,
                timeline_id INTEGER NOT NULL,
                quantum_signature REAL NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (spatial_id) REFERENCES spatial_coordinates (id),
                FOREIGN KEY (temporal_id) REFERENCES temporal_coordinates (id),
                FOREIGN KEY (timeline_id) REFERENCES timelines (id)
            )
            ''')
            
            # Create named_coordinates table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS named_coordinates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                coordinate_id INTEGER NOT NULL,
                is_historical_event BOOLEAN NOT NULL DEFAULT 0,
                is_fixed_point BOOLEAN NOT NULL DEFAULT 0,
                is_divergence_point BOOLEAN NOT NULL DEFAULT 0,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (coordinate_id) REFERENCES spacetime_coordinates (id)
            )
            ''')
            
            conn.commit()
            
    def save_coordinate(self, coordinate, name=None, is_historical=False, 
                       is_fixed_point=False, is_divergence=False, description=None):
        """Save a SpaceTimeCoordinate to the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # First, save the spatial coordinate
            cursor.execute('''
            INSERT INTO spatial_coordinates (
                x, y, z, uncertainty, reference_system
            ) VALUES (?, ?, ?, ?, ?)
            ''', (
                coordinate.spatial.x,
                coordinate.spatial.y,
                coordinate.spatial.z,
                coordinate.spatial.uncertainty,
                coordinate.spatial.reference_system
            ))
            spatial_id = cursor.lastrowid
            
            # Next, save the temporal coordinate
            cursor.execute('''
            INSERT INTO temporal_coordinates (
                year, month, day, hour, minute, second, uncertainty_days, calendar_system
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                coordinate.temporal.year,
                coordinate.temporal.month,
                coordinate.temporal.day,
                coordinate.temporal.hour,
                coordinate.temporal.minute,
                coordinate.temporal.second,
                coordinate.temporal.uncertainty_days,
                coordinate.temporal.calendar_system
            ))
            temporal_id = cursor.lastrowid
            
            # Get timeline ID
            cursor.execute("SELECT id FROM timelines WHERE name = ?", (coordinate.timeline_name,))
            timeline_id_result = cursor.fetchone()
            if not timeline_id_result:
                return None
            timeline_id = timeline_id_result[0]
            
            # Save the spacetime coordinate
            cursor.execute('''
            INSERT INTO spacetime_coordinates (
                spatial_id, temporal_id, timeline_id, quantum_signature
            ) VALUES (?, ?, ?, ?)
            ''', (
                spatial_id,
                temporal_id,
                timeline_id,
                coordinate.quantum_signature
            ))
            coordinate_id = cursor.lastrowid
            
            # If a name is provided, save as a named coordinate
            if name:
                cursor.execute('''
                INSERT INTO named_coordinates (
                    name, coordinate_id, is_historical_event, 
                    is_fixed_point, is_divergence_point, description
                ) VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    name,
                    coordinate_id,
                    1 if is_historical else 0,
                    1 if is_fixed_point else 0,
                    1 if is_divergence else 0,
                    description
                ))
            
            conn.commit()
            return coordinate_id
            
    def load_coordinate(self, coordinate_id=None, name=None):
        """Load a SpaceTimeCoordinate from the database by ID or name."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if name:
                # Look up by name
                cursor.execute('''
                SELECT c.id FROM named_coordinates nc
                JOIN spacetime_coordinates c ON nc.coordinate_id = c.id
                WHERE nc.name = ?
                ''', (name,))
                result = cursor.fetchone()
                if not result:
                    return None
                coordinate_id = result['id']
            
            if not coordinate_id:
                return None
                
            # Get the full coordinate data
            cursor.execute('''
            SELECT 
                c.id, c.quantum_signature,
                s.x, s.y, s.z, s.uncertainty, s.reference_system,
                t.year, t.month, t.day, t.hour, t.minute, t.second, 
                t.uncertainty_days, t.calendar_system,
                tl.name as timeline_name
            FROM spacetime_coordinates c
            JOIN spatial_coordinates s ON c.spatial_id = s.id
            JOIN temporal_coordinates t ON c.temporal_id = t.id
            JOIN timelines tl ON c.timeline_id = tl.id
            WHERE c.id = ?
            ''', (coordinate_id,))
            
            row = cursor.fetchone()
            if not row:
                return None
                
            # Convert to a SpaceTimeCoordinate object
            from temporal_coordinates import SpatialCoordinate, TemporalCoordinate, SpaceTimeCoordinate
            
            spatial = SpatialCoordinate(
                row['x'], row['y'], row['z'],
                row['uncertainty'], row['reference_system']
            )
            
            temporal = TemporalCoordinate(
                row['year'], row['month'], row['day'],
                row['hour'], row['minute'], row['second'],
                row['uncertainty_days'], row['calendar_system']
            )
            
            return SpaceTimeCoordinate(
                spatial, temporal, row['timeline_name'], row['quantum_signature']
            )
            
    def get_all_named_coordinates(self, filter_type=None):
        """Get all named coordinates, optionally filtered by type."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = '''
            SELECT nc.name, nc.description, nc.is_historical_event, 
                   nc.is_fixed_point, nc.is_divergence_point,
                   t.year, tl.name as timeline_name
            FROM named_coordinates nc
            JOIN spacetime_coordinates c ON nc.coordinate_id = c.id
            JOIN temporal_coordinates t ON c.temporal_id = t.id
            JOIN timelines tl ON c.timeline_id = tl.id
            '''
            
            params = []
            
            if filter_type == 'historical':
                query += ' WHERE nc.is_historical_event = 1'
            elif filter_type == 'fixed':
                query += ' WHERE nc.is_fixed_point = 1'
            elif filter_type == 'divergence':
                query += ' WHERE nc.is_divergence_point = 1'
                
            query += ' ORDER BY t.year'
            
            cursor.execute(query)
            return [dict(row) for row in cursor.fetchall()]
