import random
import time
import math
from typing import List, Dict, Tuple, Optional, Set, Any, Union
import numpy as np  # For quantum field calculations

class QuantumState:
    def __init__(self):
        self.entanglement_level = 0.0  # 0.0 to 1.0
        self.superposition = False
        self.observation_count = 0
        self.wave_function_collapse = False
        self.quantum_field_energy = 0.0
        self.spin = random.choice([-0.5, 0.5])  # Quantum spin (up or down)
        self.quantum_coherence = 1.0  # Starts fully coherent

    def observe(self) -> bool:
        """Observe quantum state, potentially causing wave function collapse"""
        self.observation_count += 1

        # Apply quantum decoherence - repeated observations decrease coherence
        self.quantum_coherence *= max(0.1, 1 - (0.1 * self.observation_count))

        # More observations increase chance of wave function collapse
        # Modified by quantum coherence level
        collapse_probability = min(0.9, self.observation_count * 0.1) * (1 - self.quantum_coherence)

        if not self.wave_function_collapse and random.random() < collapse_probability:
            self.wave_function_collapse = True
            return True
        return False

    def entangle(self, other: 'QuantumState', strength: float = 0.5):
        """Entangle this quantum state with another using quantum field theory principles"""
        # Conservation of total entanglement energy in the system
        avg_entanglement = (self.entanglement_level + other.entanglement_level) / 2
        interaction_factor = math.sin((self.quantum_field_energy - other.quantum_field_energy) * math.pi)

        # Quantum field interaction affects entanglement strength
        effective_strength = strength * (1 + 0.5 * interaction_factor)

        self.entanglement_level = min(1.0, avg_entanglement + effective_strength)
        other.entanglement_level = self.entanglement_level

        # Quantum spins align in opposite directions when entangled (conservation of angular momentum)
        if random.random() < self.entanglement_level:
            other.spin = -self.spin

    def enter_superposition(self):
        """Enter quantum superposition state with multiple probability amplitudes"""
        self.superposition = True

    def exit_superposition(self):
        """Exit quantum superposition state, collapsing to a single eigenstate"""
        self.superposition = False

    def update_quantum_field(self, energy_delta: float):
        """Update the quantum field energy associated with this state"""
        self.quantum_field_energy += energy_delta
        # Normalized between 0 and 5 (arbitrary upper limit for simulation)
        self.quantum_field_energy = max(0, min(5, self.quantum_field_energy))

class ParadoxResolver:
    """Class for detecting and resolving time paradoxes using quantum algorithms"""

    PARADOX_TYPES = {
        "grandfather": "Causality violation where an effect prevents its own cause",
        "bootstrap": "Information or object with no origin",
        "predestination": "Attempts to change past result in causing known events",
        "consistency": "Timeline modifications causing contradictions",
        "quantum": "Quantum measurement causing timeline branching"
    }

    def __init__(self):
        self.novikov_consistency_principle = True  # If True, enforces self-consistency
        self.many_worlds_interpretation = True  # If True, allows timeline branching
        self.detected_paradoxes: Dict[str, List[str]] = {ptype: [] for ptype in self.PARADOX_TYPES}
        self.resolution_attempts = 0

    def detect_paradox(self, timeline: 'Timeline', event_year: int, 
                       traveler: str, action: str) -> Tuple[bool, Optional[str]]:
        """
        Detect if a time travel event would cause a paradox
        Returns (paradox_detected, paradox_type)
        """
        # Check for potential paradoxes by analyzing existing events
        for year, event in timeline.events:
            # Check for grandfather paradox - events that would prevent traveler's existence/time travel
            if year < event_year and traveler in event and "prevented" in action.lower():
                return True, "grandfather"

            # Check for consistency paradoxes - direct contradictions
            if year == event_year and event.startswith(f"PARADOX RESOLVED:"):
                # We've already resolved a paradox here, high risk of consistency issues
                return True, "consistency"

            # Check for quantum paradoxes in quantum timelines
            if timeline.quantum_state.superposition and "observed" in action.lower():
                return True, "quantum"

        # Lower probability checks based on timeline stability
        paradox_probability = (1 - timeline.stability) * 0.8

        if random.random() < paradox_probability:
            # Determine type of paradox
            weights = [0.3, 0.2, 0.2, 0.2, 0.1]  # Weights for each paradox type
            paradox_type = random.choices(list(self.PARADOX_TYPES.keys()), weights=weights)[0]
            return True, paradox_type

        return False, None

    def resolve_paradox(self, multiverse: 'Multiverse', timeline: 'Timeline', 
                       event_year: int, traveler: str, paradox_type: str) -> Tuple[bool, str]:
        """
        Attempt to resolve a paradox using quantum algorithms
        Returns (success, resolution_method)
        """
        self.resolution_attempts += 1
        self.detected_paradoxes[paradox_type].append(f"{timeline.name} - {event_year}")

        # Higher timeline stability increases resolution chance
        base_success_chance = timeline.stability * 0.7

        # Quantum states affect resolution probabilities
        if timeline.quantum_state.superposition:
            base_success_chance *= 1.3  # Superposition helps resolve paradoxes

        if timeline.quantum_state.entanglement_level > 0.7:
            base_success_chance *= 0.8  # High entanglement makes resolution harder

        # Apply Novikov self-consistency principle if enabled
        if self.novikov_consistency_principle:
            base_success_chance += 0.2  # Novikov principle helps enforce consistency

        resolution_methods = {
            "grandfather": [
                "Quantum causality protection", 
                "Timeline bifurcation",
                "Causal loop reinforcement"
            ],
            "bootstrap": [
                "Temporal information loop stabilization",
                "Quantum information duplication",
                "Self-causation anchoring"
            ],
            "predestination": [
                "Fate-lock mechanism",
                "Temporal determinism enforcement",
                "Quantum predetermination"
            ],
            "consistency": [
                "Reality-wave harmonization",
                "Quantum superposition collapse",
                "Temporal consistency field"
            ],
            "quantum": [
                "Quantum decoherence mitigation",
                "Many-worlds branch separation",
                "Quantum observer effect isolation"
            ]
        }

        # Attempt resolution
        success = random.random() < base_success_chance

        if success:
            # Pick a resolution method based on paradox type
            resolution = random.choice(resolution_methods.get(paradox_type, 
                                     resolution_methods["consistency"]))

            # If many-worlds interpretation is enabled, create branch timeline on severe paradoxes
            if self.many_worlds_interpretation and paradox_type in ["grandfather", "consistency"]:
                # 40% chance to create a branch timeline instead of resolving in-place
                if random.random() < 0.4:
                    branch_name = f"{timeline.name}-Branch-{self.resolution_attempts}"
                    branch = multiverse.create_timeline(branch_name, timeline.stability * 0.85)

                    # Copy events up to the paradox
                    for year, event in timeline.events:
                        if year <= event_year:
                            branch.add_event(event, year)

                    # Add branching event
                    branch.add_event(f"TIMELINE BRANCH: Created due to {paradox_type} paradox", event_year)
                    timeline.add_event(f"TIMELINE BRANCH: Spawned {branch_name} due to {paradox_type} paradox", event_year)

                    # Connect timelines
                    multiverse.connect_timelines(timeline.name, branch_name)

                    return success, f"Many-worlds branch creation: {branch_name}"

            return success, resolution
        else:
            # Failed resolution consequences
            timeline.stability = max(0.1, timeline.stability - 0.15)

            # Critical failure may cause quantum state collapse
            if random.random() < 0.3:
                timeline.quantum_state.wave_function_collapse = True

            return success, "Failed - paradox remains unresolved"

class Timeline:
    def __init__(self, name: str, stability: float):
        self.name = name
        self.stability = stability  # 0.0 to 1.0
        self.events = []
        self.connected_timelines = []
        self.quantum_state = QuantumState()
        self.worldline_integrity = 1.0  # Measure of how intact the timeline's causality is
        self.reality_coefficient = random.uniform(0.8, 1.2)  # Unique "physics constant" for this timeline
        self.timewave_influence = 0.0

    def add_event(self, event: str, year: int):
        self.events.append((year, event))
        self.events.sort(key=lambda x: x[0])  # Sort by year

        # Update quantum field energy based on event significance
        event_significance = len(event) / 100  # Simple heuristic
        self.quantum_state.update_quantum_field(event_significance * random.uniform(0.1, 0.3))

        # Major events with certain keywords affect worldline integrity
        lower_event = event.lower()
        if "paradox" in lower_event:
            self.worldline_integrity -= 0.1
        elif "collapse" in lower_event:
            self.worldline_integrity -= 0.05
        elif "stabilized" in lower_event:
            self.worldline_integrity += 0.05

        # Keep worldline integrity in valid range
        self.worldline_integrity = max(0.1, min(1.0, self.worldline_integrity))

    def calculate_quantum_fluctuation(self) -> float:
        """Calculate the quantum fluctuation at a given point in the timeline using QFT principles"""
        base_fluctuation = math.sin(self.quantum_state.quantum_field_energy * math.pi / 5) * 0.5

        # Apply quantum uncertainty principle - less stable timelines have higher fluctuations
        uncertainty_factor = (1 - self.stability) * 0.5

        # Entanglement amplifies fluctuations
        entanglement_factor = self.quantum_state.entanglement_level * 0.3

        return base_fluctuation + uncertainty_factor + entanglement_factor

    def display(self):
        quantum_status = []
        if self.quantum_state.superposition:
            quantum_status.append("SUPERPOSITION")
        if self.quantum_state.entanglement_level > 0:
            quantum_status.append(f"ENTANGLED({self.quantum_state.entanglement_level:.2f})")
        if self.quantum_state.wave_function_collapse:
            quantum_status.append("COLLAPSED")

        # Add new quantum field theory metrics
        qft_info = f" | QField: {self.quantum_state.quantum_field_energy:.2f} | Spin: {self.quantum_state.spin}"
        coherence_info = f" | Coherence: {self.quantum_state.quantum_coherence:.2f}"
        worldline_info = f" | Worldline: {self.worldline_integrity:.2f}"
        timewave_info = f" | Timewave: {self.timewave_influence:.2f}"

        quantum_info = f" | Quantum: {', '.join(quantum_status)}" if quantum_status else ""

        print(f"\n=== Timeline: {self.name} (Stability: {self.stability:.2f}{quantum_info}{qft_info}{coherence_info}{worldline_info}{timewave_info}) ===")
        for year, event in self.events:
            print(f"{year}: {event}")

        if self.connected_timelines:
            print("Connected to timelines:", ", ".join([t.name for t in self.connected_timelines]))

class QuantumWormhole:
    """Represents a stable spacetime tunnel for time travel using quantum field stabilization"""

    def __init__(self, origin: 'Timeline', destination: 'Timeline', 
                stability: float = 0.7, year_shift: int = 0):
        self.origin = origin
        self.destination = destination
        self.stability = stability  # How stable the connection is
        self.year_shift = year_shift  # Time difference between ends (0 = same year)
        self.quantum_shielding = 0.5  # Protection from paradox effects
        self.activation_count = 0

        # Connect the timelines
        if destination not in origin.connected_timelines:
            origin.connected_timelines.append(destination)
        if origin not in destination.connected_timelines:
            destination.connected_timelines.append(origin)

        # Quantum entangle the timelines
        origin.quantum_state.entangle(destination.quantum_state, 0.3)

    def activate(self, traveler: str, origin_year: int) -> Tuple[bool, int]:
        """
        Activate the wormhole for time travel
        Returns (success, destination_year)
        """
        self.activation_count += 1

        # Calculate success probability based on wormhole stability
        # and quantum fluctuations in origin and destination
        origin_fluctuation = self.origin.calculate_quantum_fluctuation()
        dest_fluctuation = self.destination.calculate_quantum_fluctuation()

        success_probability = self.stability * (1 - (origin_fluctuation + dest_fluctuation) / 2)

        # Repeated use makes wormhole more stable up to a point
        experience_bonus = min(0.2, self.activation_count * 0.05)
        success_probability += experience_bonus

        # But excessive use can cause instability
        if self.activation_count > 5:
            stress_penalty = (self.activation_count - 5) * 0.03
            success_probability -= stress_penalty

        # Calculate destination year with quantum uncertainty
        base_destination_year = origin_year + self.year_shift

        # Apply quantum uncertainty principle - temporal uncertainty
        max_uncertainty = round(10 * (1 - self.stability))
        year_uncertainty = random.randint(-max_uncertainty, max_uncertainty)
        actual_destination_year = base_destination_year + year_uncertainty

        # Activate the wormhole
        success = random.random() < success_probability

        if success:
            # Record the event in both timelines
            uncertainty_info = f" with {abs(year_uncertainty)} year{'s' if abs(year_uncertainty) != 1 else ''} temporal shift" if year_uncertainty != 0 else ""
            self.origin.add_event(f"{traveler} entered quantum wormhole to {self.destination.name}{uncertainty_info}", origin_year)
            self.destination.add_event(f"{traveler} emerged from quantum wormhole from {self.origin.name}{uncertainty_info}", actual_destination_year)

            # Each use slightly decreases stability
            self.stability = max(0.2, self.stability - 0.02)

            return True, actual_destination_year
        else:
            # Failed activation
            self.origin.add_event(f"{traveler} attempted to use quantum wormhole but failed", origin_year)

            # Failed activation significantly decreases stability
            self.stability = max(0.1, self.stability - 0.1)

            # Catastrophic failure can break the connection
            if self.stability < 0.2 and random.random() < 0.5:
                self.origin.connected_timelines.remove(self.destination)
                self.destination.connected_timelines.remove(self.origin)
                self.origin.add_event(f"Quantum wormhole to {self.destination.name} collapsed", origin_year)
                self.destination.add_event(f"Quantum wormhole from {self.origin.name} collapsed", actual_destination_year)

            return False, origin_year

class Multiverse:
    def __init__(self):
        self.timelines: Dict[str, Timeline] = {}
        self.current_timeline = None
        self.wormholes: List[QuantumWormhole] = []
        self.paradox_resolver = ParadoxResolver()
        self.cosmic_strings: Dict[str, float] = {}  # Topological defects in spacetime
        self.reality_constant = random.uniform(0.9, 1.1)  # Universal constant for this multiverse
        self.timewaves = []

    def create_timeline(self, name: str, stability: float = 0.8) -> Timeline:
        timeline = Timeline(name, stability)
        self.timelines[name] = timeline

        # Create cosmic string with 30% probability for new timelines
        if random.random() < 0.3:
            string_strength = random.uniform(0.3, 0.7)
            self.cosmic_strings[name] = string_strength
            print(f"Cosmic string detected in timeline {name} (strength: {string_strength:.2f})")

        if not self.current_timeline:
            self.current_timeline = timeline

        return timeline

    def connect_timelines(self, timeline1_name: str, timeline2_name: str, quantum_entangle: bool = False):
        if timeline1_name in self.timelines and timeline2_name in self.timelines:
            timeline1 = self.timelines[timeline1_name]
            timeline2 = self.timelines[timeline2_name]

            if timeline2 not in timeline1.connected_timelines:
                timeline1.connected_timelines.append(timeline2)

            if timeline1 not in timeline2.connected_timelines:
                timeline2.connected_timelines.append(timeline1)

            connection_type = "Connected"
            if quantum_entangle:
                # Quantum entangle the timelines
                timeline1.quantum_state.entangle(timeline2.quantum_state)
                connection_type = "Quantum entangled"

            print(f"{connection_type} timeline '{timeline1_name}' to '{timeline2_name}'")
        else:
            print("One or both timelines don't exist")

    def create_quantum_wormhole(self, origin_name: str, destination_name: str, 
                              year_shift: int = 0) -> Optional[QuantumWormhole]:
        """Create a stabilized quantum wormhole between timelines for reliable time travel"""
        if origin_name not in self.timelines or destination_name not in self.timelines:
            print(f"Cannot create wormhole: one or both timelines don't exist")
            return None

        origin = self.timelines[origin_name]
        destination = self.timelines[destination_name]

        # Calculate initial stability based on involved timelines
        initial_stability = (origin.stability + destination.stability) / 2

        # Year shifts reduce stability (larger shifts = less stable)
        if year_shift != 0:
            stability_penalty = min(0.3, abs(year_shift) / 100)
            initial_stability -= stability_penalty

        # Cosmic strings can enhance stability
        if origin_name in self.cosmic_strings or destination_name in self.cosmic_strings:
            string_bonus = 0.0
            if origin_name in self.cosmic_strings:
                string_bonus += self.cosmic_strings[origin_name] * 0.2
            if destination_name in self.cosmic_strings:
                string_bonus += self.cosmic_strings[destination_name] * 0.2

            initial_stability += string_bonus
            print(f"Cosmic string(s) enhancing wormhole stability: +{string_bonus:.2f}")

        # Create the wormhole
        wormhole = QuantumWormhole(origin, destination, initial_stability, year_shift)
        self.wormholes.append(wormhole)

        # Add events to both timelines
        origin.add_event(f"Quantum wormhole established to {destination_name}" + 
                        (f" with {year_shift} year shift" if year_shift != 0 else ""), 
                        2030)  # Arbitrary year for wormhole creation

        destination.add_event(f"Quantum wormhole established from {origin_name}" + 
                             (f" with {-year_shift} year shift" if year_shift != 0 else ""), 
                             2030 + year_shift)  # Matching year in destination timeline

        print(f"Created quantum wormhole from {origin_name} to {destination_name}" +
             (f" with {year_shift} year shift" if year_shift != 0 else "") +
             f" (stability: {initial_stability:.2f})")

        return wormhole

    def create_quantum_superposition(self, timeline_name: str) -> Optional[Timeline]:
        """Create a superposition of a timeline, existing in multiple states at once"""
        if timeline_name not in self.timelines:
            print(f"Timeline {timeline_name} doesn't exist")
            return None

        source = self.timelines[timeline_name]

        # Create a new timeline as the superposition of the original
        superposition_name = f"{timeline_name}-Superposition"
        superposition = self.create_timeline(superposition_name, source.stability * 0.8)

        # Copy events
        for year, event in source.events:
            superposition.add_event(event, year)

        # Mark as being in superposition
        source.quantum_state.enter_superposition()
        superposition.quantum_state.enter_superposition()

        # Entangle the timelines
        source.quantum_state.entangle(superposition.quantum_state, 0.9)

        # Connect the timelines
        self.connect_timelines(timeline_name, superposition_name, True)

        print(f"Created quantum superposition of {timeline_name}")
        return superposition

    def perform_quantum_wormhole_travel(self, wormhole_index: int, traveler: str, origin_year: int) -> bool:
        """Perform time travel through an established quantum wormhole"""
        if wormhole_index < 0 or wormhole_index >= len(self.wormholes):
            print(f"Invalid wormhole index: {wormhole_index}")
            return False

        wormhole = self.wormholes[wormhole_index]

        print(f"Attempting quantum wormhole travel for {traveler}...")
        success, destination_year = wormhole.activate(traveler, origin_year)

        if success:
            print(f"Success! {traveler} traveled from {wormhole.origin.name} year {origin_year} " +
                 f"to {wormhole.destination.name} year {destination_year}")

            # Check for paradoxes
            is_paradox, paradox_type = self.paradox_resolver.detect_paradox(
                wormhole.destination, destination_year, traveler, "arrived through quantum wormhole"
            )

            if is_paradox:
                print(f"WARNING: {paradox_type.title()} paradox detected in timeline {wormhole.destination.name}!")

                # Attempt to resolve the paradox
                resolved, method = self.paradox_resolver.resolve_paradox(
                    self, wormhole.destination, destination_year, traveler, paradox_type
                )

                if resolved:
                    print(f"Paradox successfully resolved using {method}")
                    wormhole.destination.add_event(
                        f"PARADOX RESOLVED: {paradox_type} paradox from {traveler}'s arrival resolved via {method}", 
                        destination_year
                    )
                else:
                    print(f"Failed to resolve paradox: {method}")
                    wormhole.destination.add_event(
                        f"UNRESOLVED PARADOX: {paradox_type} paradox from {traveler}'s arrival", 
                        destination_year
                    )
                    wormhole.destination.stability -= 0.1

            self.current_timeline = wormhole.destination
            return True
        else:
            print(f"Travel failed. {traveler} remains in {wormhole.origin.name} year {origin_year}")
            return False

    def time_travel(self, origin_timeline: str, destination_timeline: str, traveler: str, year: int, 
               quantum_tunneling: bool = False):
        if origin_timeline in self.timelines and destination_timeline in self.timelines:
            origin = self.timelines[origin_timeline]
            destination = self.timelines[destination_timeline]

            # Check if timelines are connected (unless using quantum tunneling)
            if not quantum_tunneling and destination not in origin.connected_timelines:
                print(f"Error: Cannot travel from {origin_timeline} to {destination_timeline} - no direct connection")
                return False

            # Calculate paradox risk based on timeline stability, quantum states
            paradox_risk = (1 - destination.stability) * random.random()

            # Apply quantum effects
            quantum_effects = []

            # Quantum Tunneling - can bypass normal timeline connections but increases risk
            if quantum_tunneling:
                quantum_effects.append("Quantum Tunneling")
                paradox_risk *= 1.5  # Higher risk when tunneling

            # Quantum Entanglement - affects both timelines
            if origin.quantum_state.entanglement_level > 0.5:
                quantum_effects.append("Quantum Entanglement")

                # Observe the quantum state, potentially causing collapse
                if origin.quantum_state.observe():
                    origin.add_event(f"QUANTUM EVENT: Wave function collapse triggered by {traveler}", year)
                    quantum_effects.append("Wave Function Collapse")
                    paradox_risk *= 2.0  # Dramatic increase in risk

                # Entangled timelines share effects
                for timeline in self.timelines.values():
                    if timeline.quantum_state.entanglement_level > 0.7 and random.random() < 0.5:
                        timeline.add_event(f"QUANTUM ECHO: Entanglement effect from {traveler}'s time travel", year)

            # Quantum Superposition
            if destination.quantum_state.superposition:
                quantum_effects.append("Superposition")

                # 50% chance to exit superposition on travel
                if random.random() < 0.5:
                    destination.quantum_state.exit_superposition()
                    destination.add_event(f"QUANTUM EVENT: Superposition collapsed by {traveler}'s arrival", year)

                    # Superposition collapse can actually stabilize a timeline
                    destination.stability = min(1.0, destination.stability + 0.15)

            # Calculate quantum uncertainty factor
            uncertainty = math.sin(origin.quantum_state.entanglement_level * math.pi) * 0.5

            # Apply QFT spin interactions
            if abs(origin.quantum_state.spin - destination.quantum_state.spin) < 0.1:
                quantum_effects.append("Spin Alignment")
                uncertainty *= 0.7  # Aligned spins reduce uncertainty
            else:
                quantum_effects.append("Spin Opposition")
                uncertainty *= 1.3  # Opposed spins increase uncertainty

            # Quantum uncertainty can cause random arrival year shifts
            actual_year = year
            if uncertainty > 0.1:
                # The higher the uncertainty, the greater the possible year shift
                max_shift = round(uncertainty * 10)
                year_shift = random.randint(-max_shift, max_shift)
                actual_year = year + year_shift

                if year_shift != 0:
                    quantum_effects.append(f"Temporal Shift ({year_shift} years)")

            # Add the time travel event to both timelines
            quantum_info = f" using {', '.join(quantum_effects)}" if quantum_effects else ""
            origin.add_event(f"{traveler} traveled to timeline {destination_timeline}{quantum_info}", year)
            destination.add_event(f"{traveler} arrived from timeline {origin_timeline}{quantum_info}", actual_year)

            # Check if a paradox occurs
            is_paradox, paradox_type = self.paradox_resolver.detect_paradox(
                destination, actual_year, traveler, "arrived from another timeline"
            )

            if is_paradox:
                # Attempt to resolve the paradox
                resolved, method = self.paradox_resolver.resolve_paradox(
                    self, destination, actual_year, traveler, paradox_type
                )

                if resolved:
                    print(f"Paradox successfully resolved using {method}")
                    destination.add_event(
                        f"PARADOX RESOLVED: {paradox_type} paradox resolved via {method}", 
                        actual_year
                    )
                else:
                    print(f"Failed to resolve paradox: {method}")
                    destination.add_event(f"UNRESOLVED PARADOX: {paradox_type} paradox", actual_year)
                    destination.stability -= 0.1  # Decrease stability due to paradox

                # Prevent stability from going negative
                destination.stability = max(0.1, destination.stability)

                if destination.stability < 0.3:
                    print(f"CRITICAL: Timeline {destination_timeline} becoming unstable!")

                    # Quantum entanglement propagates instability
                    if destination.quantum_state.entanglement_level > 0.7:
                        for timeline in destination.connected_timelines:
                            if timeline.quantum_state.entanglement_level > 0.6:
                                timeline.stability = max(0.2, timeline.stability - 0.05)
                                print(f"QUANTUM EFFECT: Entangled timeline {timeline.name} affected by paradox")

            self.current_timeline = destination
            return True
        else:
            print("One or both timelines don't exist")
            return False

    def display_all_timelines(self):
        print("\n==== MULTIVERSE MAP ====")
        for name, timeline in self.timelines.items():
            timeline.display()

        if self.wormholes:
            print("\n==== QUANTUM WORMHOLES ====")
            for i, wormhole in enumerate(self.wormholes):
                print(f"Wormhole {i}: {wormhole.origin.name} <-> {wormhole.destination.name} " +
                     f"(stability: {wormhole.stability:.2f}, year shift: {wormhole.year_shift}, " +
                     f"activations: {wormhole.activation_count})")

        if self.cosmic_strings:
            print("\n==== COSMIC STRINGS ====")
            for timeline_name, strength in self.cosmic_strings.items():
                print(f"Cosmic string in {timeline_name} - strength: {strength:.2f}")

        if self.paradox_resolver.resolution_attempts > 0:
            print("\n==== PARADOX STATISTICS ====")
            for ptype, instances in self.paradox_resolver.detected_paradoxes.items():
                if instances:
                    print(f"{ptype.title()} paradoxes: {len(instances)}")
                    for instance in instances[:3]:  # Show first 3 instances
                        print(f"  - {instance}")
                    if len(instances) > 3:
                        print(f"  - ... and {len(instances) - 3} more")

        if self.timewaves:
            print("\n==== TIMEWAVES ====")
            for wave in self.timewaves:
                print(f"Timewave: Origin={wave.origin}, Year={wave.year}, Strength={wave.strength:.2f}, Description={wave.description}")

    def create_timewave(self, origin_name: str, year: int, strength: float, description: str) -> Tuple[bool, Any]:
        if origin_name not in self.timelines:
            print(f"Error: Timeline '{origin_name}' not found.")
            return False, None

        origin = self.timelines[origin_name]
        wave = Timewave(origin, year, strength, description)
        self.timewaves.append(wave)
        origin.add_event(f"Timewave Originated: {description}", year)
        print(f"Timewave created in '{origin_name}' at {year} with strength {strength:.2f}: {description}")
        return True, wave

    def propagate_timewaves(self):
        # Simulate timewave propagation, affecting timeline stability and events
        removed_waves = []
        for wave in self.timewaves:
            if wave.strength <= 0:
                removed_waves.append(wave)
                continue

            # Randomly select a timeline to affect
            affected_timeline = random.choice(list(self.timelines.values()))
            influence = wave.strength * random.uniform(0.05, 0.2)

            # Timewave influence changes timeline stability, quantum field
            affected_timeline.stability = min(1.0, max(0.0, affected_timeline.stability + random.uniform(-influence, influence)))
            affected_timeline.quantum_state.update_quantum_field(influence * random.uniform(-0.5, 0.5))
            affected_timeline.timewave_influence += influence

            # Add event to affected timeline
            affected_timeline.add_event(f"Timewave Influence: {wave.description} ({influence:.2f})", wave.year)
            wave.strength -= random.uniform(0.05, 0.15)

        # Remove waves that have dissipated
        for wave in removed_waves:
            self.timewaves.remove(wave)
            
    def get_quantum_anomalies(self):
        """Return a list of timelines that exhibit quantum anomalies"""
        anomalies = []
        for timeline in self.timelines.values():
            # Check for quantum anomalies
            if (timeline.quantum_state.wave_function_collapse or 
                (timeline.quantum_state.entanglement_level > 0.8 and timeline.stability < 0.6) or
                (timeline.quantum_state.superposition and timeline.quantum_state.quantum_field_energy > 0.7)):
                anomalies.append(timeline)
        return anomalies

class Timewave:
    def __init__(self, origin: Timeline, year: int, strength: float, description: str):
        self.origin = origin
        self.year = year
        self.strength = strength
        self.description = description

def run_simulation():
    print("=== Advanced Multiverse Paradox Quantum Field Theory Simulation ===")
    print("Initializing timelines with quantum field properties...")

    multiverse = Multiverse()

    # Create several timelines
    alpha = multiverse.create_timeline("Alpha Prime", 0.9)
    beta = multiverse.create_timeline("Beta Variant", 0.75)
    gamma = multiverse.create_timeline("Gamma Nexus", 0.6)
    delta = multiverse.create_timeline("Delta Flux", 0.5)
    omega = multiverse.create_timeline("Omega Point", 0.85)

    # Add historical events to each timeline
    alpha.add_event("Timeline origin point", 2000)
    alpha.add_event("Quantum computing breakthrough", 2025)
    alpha.add_event("First contact with extradimensional beings", 2042)

    beta.add_event("Timeline origin point - diverged from Alpha", 2010)
    beta.add_event("Global climate catastrophe", 2028)
    beta.add_event("Underground civilization established", 2035)

    gamma.add_event("Timeline origin - artificial creation", 1980)
    gamma.add_event("Robotic revolution", 2015)
    gamma.add_event("Human consciousness uploaded to quantum network", 2038)

    delta.add_event("Timeline origin - natural quantum fluctuation", 1995)
    delta.add_event("Dimensional barrier discovery", 2022)
    delta.add_event("Time strand manipulation technology invented", 2030)

    omega.add_event("Timeline origin - future recursion point", 2090)
    omega.add_event("Temporal mechanics breakthrough", 2065)
    omega.add_event("Quantum field unification theory completed", 2078)

    # Connect timelines in the multiverse
    multiverse.connect_timelines("Alpha Prime", "Beta Variant")
    multiverse.connect_timelines("Alpha Prime", "Gamma Nexus", quantum_entangle=True)  # Quantum entangled
    multiverse.connect_timelines("Beta Variant", "Delta Flux")
    multiverse.connect_timelines("Gamma Nexus", "Delta Flux")
    multiverse.connect_timelines("Omega Point", "Alpha Prime", quantum_entangle=True)

    # Create quantum superposition of Delta timeline
    quantum_delta = multiverse.create_quantum_superposition("Delta Flux")
    if quantum_delta:
        quantum_delta.add_event("Quantum state observed leading to alternative history", 2035)
        quantum_delta.add_event("Schrödinger's civilization: both thriving and extinct", 2040)

    # Create stable quantum wormholes
    multiverse.create_quantum_wormhole("Alpha Prime", "Omega Point", year_shift=30)  # 30 year difference
    multiverse.create_quantum_wormhole("Beta Variant", "Gamma Nexus", year_shift=-10)  # -10 year difference

    # Display the initial state
    multiverse.display_all_timelines()

    # Simulate time travel events
    print("\n\n==== SIMULATING TIME TRAVEL EVENTS WITH QUANTUM FIELD ALGORITHMS ====")

    time_travelers = [
        "Dr. Eliza Chen", "Quantum Agent Smith", "Professor Paradox", 
        "Traveler X", "Dr. Schrödinger", "Temporal Engineer Novikov",
        "Quantum Field Specialist Zhang", "Paradox Resolver Kim"
    ]

    # First try some quantum wormhole travel
    for i in range(3):
        print(f"\n--- Quantum Wormhole Travel Event {i+1} ---")

        # Select random time traveler and wormhole
        traveler = random.choice(time_travelers)
        wormhole_index = random.randint(0, len(multiverse.wormholes) - 1)
        origin_timeline = multiverse.wormholes[wormhole_index].origin

        # Random year for time travel between 2030 and 2060
        year = random.randint(2030, 2060)

        print(f"Attempting: {traveler} traveling via quantum wormhole from {origin_timeline.name} in year {year}")
        multiverse.perform_quantum_wormhole_travel(wormhole_index, traveler, year)

        time.sleep(0.5)  # Pause for effect

    # Then try regular time travel with quantum tunneling
    for i in range(5):
        print(f"\n--- Quantum Field Time Travel Event {i+1} ---")

        # Select random time traveler and timelines
        traveler = random.choice(time_travelers)
        timeline_names = list(multiverse.timelines.keys())
        origin_name = random.choice(timeline_names)

        # Use quantum tunneling with varying probability
        quantum_tunneling = random.random() < 0.4

        if quantum_tunneling:
            # With quantum tunneling, can go to any timeline regardless of connection
            destination_name = random.choice([t for t in timeline_names if t != origin_name])
            print(f"{traveler} attempting QUANTUM TUNNELING from {origin_name} to {destination_name}")
        else:
            # Find connected timeline for destination
            origin_timeline = multiverse.timelines[origin_name]
            if not origin_timeline.connected_timelines:
                print(f"No connected timelines available from {origin_name}")
                continue

            destination_timeline = random.choice(origin_timeline.connected_timelines)
            destination_name = destination_timeline.name

        # Random year for time travel between 2000 and 2070
        year = random.randint(2000, 2070)

        print(f"Attempting: {traveler} traveling from {origin_name} to {destination_name} in year {year}")
        success = multiverse.time_travel(origin_name, destination_name, traveler, year, quantum_tunneling)

        if success:
            print(f"Time travel completed. Current timeline: {multiverse.current_timeline.name}")

            # Periodically create quantum superpositions
            if i == 2:  # On the third event
                source_name = random.choice(timeline_names)
                print(f"\nCreating quantum superposition of {source_name}...")
                multiverse.create_quantum_superposition(source_name)

            time.sleep(0.5)  # Pause for effect

    # Create some timewaves and observe their propagation
    print("\n\n==== CREATING TEMPORAL WAVES ====")

    # Create a major temporal wave from a significant event
    wave1 = multiverse.create_timewave("Alpha Prime", 2040, 1.2, 
                                      "Quantum singularity experiment")

    # Create another wave from a different timeline
    wave2 = multiverse.create_timewave("Beta Variant", 2030, 0.8,
                                      "Temporal resonance cascade")

    # Propagate the waves through the multiverse
    for i in range(3):
        print(f"\n--- Timewave Propagation Cycle {i+1} ---")
        multiverse.propagate_timewaves()
        time.sleep(0.3)

    # Display final state
    print("\n\n==== FINAL MULTIVERSE STATE WITH QUANTUM FIELD ANALYSIS ====")
    multiverse.display_all_timelines()

    # Check for unstable timelines and quantum anomalies
    unstable_timelines = [t.name for t in multiverse.timelines.values() if t.stability < 0.4]
    quantum_anomalies = [t.name for t in multiverse.timelines.values() 
                         if t.quantum_state.wave_function_collapse or 
                            (t.quantum_state.entanglement_level > 0.8 and t.stability < 0.6)]

    if unstable_timelines:
        print("\n⚠️ WARNING: The following timelines are dangerously unstable:")
        for name in unstable_timelines:
            print(f"  - {name} (Stability: {multiverse.timelines[name].stability:.2f})")
        print("\nMultiverse collapse possible if stability continues to decrease!")

    if quantum_anomalies:
        print("\n⚠️ QUANTUM ALERT: The following timelines show quantum anomalies:")
        for name in quantum_anomalies:
            timeline = multiverse.timelines[name]
            anomaly_type = []
            if timeline.quantum_state.wave_function_collapse:
                anomaly_type.append("wave function collapse")
            if timeline.quantum_state.entanglement_level > 0.8:
                anomaly_type.append("critical entanglement")
            if timeline.quantum_state.superposition:
                anomaly_type.append("sustained superposition")

            print(f"  - {name} (Anomalies: {', '.join(anomaly_type)})")
        print("\nQuantum decoherence across multiverse fabric detected!")

    if not unstable_timelines and not quantum_anomalies:
        print("\nAll timelines maintaining relative stability. Multiverse remains intact.")

    # Determine most quantum-affected timeline
    most_quantum = max(multiverse.timelines.values(), 
                      key=lambda t: t.quantum_state.entanglement_level + 
                                   (0.5 if t.quantum_state.superposition else 0) +
                                   (0.5 if t.quantum_state.wave_function_collapse else 0))

    print(f"\nTimeline most affected by quantum mechanics: {most_quantum.name}")
    print(f"Quantum entanglement level: {most_quantum.quantum_state.entanglement_level:.2f}")
    print(f"Quantum field energy: {most_quantum.quantum_state.quantum_field_energy:.2f}")
    print(f"Quantum coherence: {most_quantum.quantum_state.quantum_coherence:.2f}")
    if most_quantum.quantum_state.superposition:
        print("Timeline exists in quantum superposition")
    if most_quantum.quantum_state.wave_function_collapse:
        print("Timeline has experienced wave function collapse")

    # Paradox statistics
    resolved_count = sum(1 for ptype, instances in multiverse.paradox_resolver.detected_paradoxes.items() 
                       for _ in instances)

    if resolved_count > 0:
        print(f"\nTotal paradoxes detected: {resolved_count}")
        print(f"Most common paradox type: {max(multiverse.paradox_resolver.detected_paradoxes.items(), key=lambda x: len(x[1]))[0]}")

        # Novikov consistency evaluation
        if multiverse.paradox_resolver.novikov_consistency_principle:
            print("\nNovikov self-consistency principle evaluation: Generally maintained")
            print("Timeline causality remains mostly coherent despite temporal interventions")

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

class MultiverseSimulatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Multiverse Paradox Quantum Field Simulator")
        self.root.geometry("1000x700")
        self.root.configure(bg='#1e1e2e')

        self.multiverse = None
        self.setup_ui()

    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Set up title
        title_label = ttk.Label(main_frame, text="Advanced Multiverse Paradox Quantum Field Theory Simulator", 
                              font=('Arial', 16, 'bold'))
        title_label.pack(pady=10)

        # Create notebook for tabs
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill=tk.BOTH, expand=True, pady=5)

        # Simulation tab
        sim_frame = ttk.Frame(notebook)
        notebook.add(sim_frame, text="Simulation")

        # Control panel frame
        control_frame = ttk.LabelFrame(sim_frame, text="Control Panel")
        control_frame.pack(fill=tk.X, padx=5, pady=5)

        # Initialize button
        init_button = ttk.Button(control_frame, text="Initialize Multiverse", command=self.initialize_multiverse)
        init_button.grid(row=0, column=0, padx=5, pady=5)

        # Run simulation button
        run_button = ttk.Button(control_frame, text="Run Time Travel Simulation", command=self.run_time_travel)
        run_button.grid(row=0, column=1, padx=5, pady=5)

        # Display state button
        display_button = ttk.Button(control_frame, text="Display Multiverse State", command=self.display_state)
        display_button.grid(row=0, column=2, padx=5, pady=5)

        # Create wormhole button
        wormhole_button = ttk.Button(control_frame, text="Create Wormhole", command=self.create_wormhole)
        wormhole_button.grid(row=0, column=3, padx=5, pady=5)

        # Create superposition button
        superpos_button = ttk.Button(control_frame, text="Create Superposition", command=self.create_superposition)
        superpos_button.grid(row=0, column=4, padx=5, pady=5)

        # Timeline travel panel
        travel_frame = ttk.LabelFrame(sim_frame, text="Manual Time Travel")
        travel_frame.pack(fill=tk.X, padx=5, pady=5)

        # Origin timeline selection
        ttk.Label(travel_frame, text="Origin Timeline:").grid(row=0, column=0, padx=5, pady=5)
        self.origin_var = tk.StringVar()
        self.origin_combo = ttk.Combobox(travel_frame, textvariable=self.origin_var, state="readonly")
        self.origin_combo.grid(row=0, column=1, padx=5, pady=5)

        # Destination timeline selection
        ttk.Label(travel_frame, text="Destination Timeline:").grid(row=0, column=2, padx=5, pady=5)
        self.dest_var = tk.StringVar()
        self.dest_combo = ttk.Combobox(travel_frame, textvariable=self.dest_var, state="readonly")
        self.dest_combo.grid(row=0, column=3, padx=5, pady=5)

        # Year entry
        ttk.Label(travel_frame, text="Year:").grid(row=0, column=4, padx=5, pady=5)
        self.year_var = tk.StringVar(value="2030")
        year_entry = ttk.Entry(travel_frame, textvariable=self.year_var, width=6)
        year_entry.grid(row=0, column=5, padx=5, pady=5)

        # Traveler name
        ttk.Label(travel_frame, text="Traveler:").grid(row=1, column=0, padx=5, pady=5)
        self.traveler_var = tk.StringVar(value="Dr. Eliza Chen")
        traveler_entry = ttk.Entry(travel_frame, textvariable=self.traveler_var, width=20)
        traveler_entry.grid(row=1, column=1, padx=5, pady=5)

        # Quantum tunneling checkbox
        self.tunneling_var = tk.BooleanVar(value=False)
        tunneling_check = ttk.Checkbutton(travel_frame, text="Use Quantum Tunneling", 
                                         variable=self.tunneling_var)
        tunneling_check.grid(row=1, column=2, padx=5, pady=5)

        # Time travel button
        travel_button = ttk.Button(travel_frame, text="Execute Time Travel", command=self.execute_time_travel)
        travel_button.grid(row=1, column=3, padx=5, pady=5)

        # Output console
        console_frame = ttk.LabelFrame(sim_frame, text="Simulation Output")
        console_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.console = scrolledtext.ScrolledText(console_frame, wrap=tk.WORD, font=('Courier', 10))
        self.console.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Timeline visualization tab
        viz_frame = ttk.Frame(notebook)
        notebook.add(viz_frame, text="Timeline Visualization")

        # Timeline stats
        stats_frame = ttk.LabelFrame(viz_frame, text="Quantum Statistics")
        stats_frame.pack(fill=tk.X, padx=5, pady=5)

        self.stats_text = scrolledtext.ScrolledText(stats_frame, wrap=tk.WORD, height=5, font=('Courier', 10))
        self.stats_text.pack(fill=tk.X, expand=True, padx=5, pady=5)

        # Timeline visualization
        timeline_frame = ttk.LabelFrame(viz_frame, text="Timelines")
        timeline_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.timeline_canvas = tk.Canvas(timeline_frame, bg="#232338", highlightthickness=0)
        self.timeline_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Redirect standard output to the console
        import sys
        self.original_stdout = sys.stdout
        sys.stdout = self

    def write(self, text):
        # This method is called by print statements
        self.console.insert(tk.END, text)
        self.console.see(tk.END)
        self.root.update_idletasks()

    def flush(self):
        # Required for file-like objects
        pass

    def initialize_multiverse(self):
        self.console.delete(1.0, tk.END)  # Clear console
        print("Initializing Multiverse with Quantum Field Properties...")
        self.multiverse = Multiverse()

        # Create timelines
        self.multiverse.create_timeline("Alpha Prime", 0.9)
        self.multiverse.create_timeline("Beta Variant", 0.75)
        self.multiverse.create_timeline("Gamma Nexus", 0.6)
        self.multiverse.create_timeline("Delta Flux", 0.5)
        self.multiverse.create_timeline("Omega Point", 0.85)

        # Add historical events to each timeline
        self.multiverse.timelines["Alpha Prime"].add_event("Timeline origin point", 2000)
        self.multiverse.timelines["Alpha Prime"].add_event("Quantum computing breakthrough", 2025)
        self.multiverse.timelines["Alpha Prime"].add_event("First contact with extradimensional beings", 2042)

        self.multiverse.timelines["Beta Variant"].add_event("Timeline origin point - diverged from Alpha", 2010)
        self.multiverse.timelines["Beta Variant"].add_event("Global climate catastrophe", 2028)
        self.multiverse.timelines["Beta Variant"].add_event("Underground civilization established", 2035)

        self.multiverse.timelines["Gamma Nexus"].add_event("Timeline origin - artificial creation", 1980)
        self.multiverse.timelines["Gamma Nexus"].add_event("Robotic revolution", 2015)
        self.multiverse.timelines["Gamma Nexus"].add_event("Human consciousness uploaded to quantum network", 2038)

        self.multiverse.timelines["Delta Flux"].add_event("Timeline origin - natural quantum fluctuation", 1995)
        self.multiverse.timelines["Delta Flux"].add_event("Dimensional barrier discovery", 2022)
        self.multiverse.timelines["Delta Flux"].add_event("Time strand manipulation technology invented", 2030)

        self.multiverse.timelines["Omega Point"].add_event("Timeline origin - future recursion point", 2090)
        self.multiverse.timelines["Omega Point"].add_event("Temporal mechanics breakthrough", 2065)
        self.multiverse.timelines["Omega Point"].add_event("Quantum field unification theory completed", 2078)

        # Connect timelines
        self.multiverse.connect_timelines("Alpha Prime", "Beta Variant")
        self.multiverse.connect_timelines("Alpha Prime", "Gamma Nexus", quantum_entangle=True)
        self.multiverse.connect_timelines("Beta Variant", "Delta Flux")
        self.multiverse.connect_timelines("Gamma Nexus", "Delta Flux")
        self.multiverse.connect_timelines("Omega Point", "Alpha Prime", quantum_entangle=True)

        # Update the timeline selector dropdowns
        self.update_timeline_selectors()

        # Display the initial state
        self.multiverse.display_all_timelines()

        # Draw the timelines
        self.draw_timelines()

    def run_time_travel(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        print("\n\n==== SIMULATING TIME TRAVEL EVENTS WITH QUANTUM FIELD ALGORITHMS ====")

        time_travelers = [
            "Dr. Eliza Chen", "Quantum Agent Smith", "Professor Paradox", 
            "Traveler X", "Dr. Schrödinger", "Temporal Engineer Novikov",
            "Quantum Field Specialist Zhang", "Paradox Resolver Kim"
        ]

        # Simulate time travel events
        for i in range(3):
            print(f"\n--- Quantum Wormhole Travel Event {i+1} ---")

            # Select random time traveler and wormhole
            traveler = random.choice(time_travelers)
            if not self.multiverse.wormholes:
                print("No wormholes available. Creating wormhole...")
                self.multiverse.create_quantum_wormhole("Alpha Prime", "Beta Variant", random.randint(-20, 20))

            wormhole_index = random.randint(0, len(self.multiverse.wormholes) - 1)
            origin_timeline = self.multiverse.wormholes[wormhole_index].origin

            # Random year for time travel
            year = random.randint(2030, 2060)

            print(f"Attempting: {traveler} traveling via quantum wormhole from {origin_timeline.name} in year {year}")
            self.multiverse.perform_quantum_wormhole_travel(wormhole_index, traveler, year)

            # Update UI after each event
            self.root.update()

        # Regular time travel with quantum tunneling
        for i in range(3):
            print(f"\n--- Quantum Field Time Travel Event {i+1} ---")

            # Select random time traveler and timelines
            traveler = random.choice(time_travelers)
            timeline_names = list(self.multiverse.timelines.keys())
            origin_name = random.choice(timeline_names)

            # Use quantum tunneling with varying probability
            quantum_tunneling = random.random() < 0.4

            if quantum_tunneling:
                # With quantum tunneling, can go to any timeline regardless of connection
                dest_options = [t for t in timeline_names if t != origin_name]
                if dest_options:
                    destination_name = random.choice(dest_options)
                    print(f"{traveler} attempting QUANTUM TUNNELING from {origin_name} to {destination_name}")
                else:
                    print(f"No destination timelines available for {origin_name}")
                    continue
            else:
                # Find connected timeline for destination
                origin_timeline = self.multiverse.timelines[origin_name]
                if not origin_timeline.connected_timelines:
                    print(f"No connected timelines available from {origin_name}")
                    continue

                destination_timeline = random.choice(origin_timeline.connected_timelines)
                destination_name = destination_timeline.name

            # Random year for time travel
            year = random.randint(2000, 2070)

            print(f"Attempting: {traveler} traveling from {origin_name} to {destination_name} in year {year}")
            self.multiverse.time_travel(origin_name, destination_name, traveler, year, quantum_tunneling)

            # Update UI after each event
            self.root.update()

        # Draw updated timelines
        self.draw_timelines()

        # Display final stats
        self.update_stats()

    def display_state(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        print("\n\n==== CURRENT MULTIVERSE STATE WITH QUANTUM FIELD ANALYSIS ====")
        self.multiverse.display_all_timelines()
        self.draw_timelines()
        self.update_stats()

    def create_wormhole(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        # Create a dialog for wormhole parameters
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Quantum Wormhole")
        dialog.geometry("400x200")
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(dialog, text="Origin Timeline:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        origin_var = tk.StringVar()
        origin_combo = ttk.Combobox(dialog, textvariable=origin_var, state="readonly",
                                   values=list(self.multiverse.timelines.keys()))
        origin_combo.grid(row=0, column=1, padx=5, pady=5)
        if list(self.multiverse.timelines.keys()):
            origin_combo.current(0)

        ttk.Label(dialog, text="Destination Timeline:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
        dest_var = tk.StringVar()
        dest_combo = ttk.Combobox(dialog, textvariable=dest_var, state="readonly",
                                 values=list(self.multiverse.timelines.keys()))
        dest_combo.grid(row=1, column=1, padx=5, pady=5)
        if len(list(self.multiverse.timelines.keys())) > 1:
            dest_combo.current(1)

        ttk.Label(dialog, text="Year Shift:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
        year_shift_var = tk.StringVar(value="0")
        year_shift_entry = ttk.Entry(dialog, textvariable=year_shift_var, width=10)
        year_shift_entry.grid(row=2, column=1, padx=5, pady=5, sticky='w')

        def create():
            try:
                origin = origin_var.get()
                dest = dest_var.get()
                year_shift = int(year_shift_var.get())

                if origin == dest:
                    messagebox.showerror("Error", "Origin and destination must be different timelines.")
                    return

                self.multiverse.create_quantum_wormhole(origin, dest, year_shift)
                dialog.destroy()
                self.draw_timelines()
            except ValueError:
                messagebox.showerror("Error", "Year shift must be an integer.")

        ttk.Button(dialog, text="Create Wormhole", command=create).grid(row=3, column=0, columnspan=2, pady=20)

    def create_superposition(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        # Create a dialog for superposition parameters
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Quantum Superposition")
        dialog.geometry("400x120")
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(dialog, text="Source Timeline:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        source_var = tk.StringVar()
        source_combo = ttk.Combobox(dialog, textvariable=source_var, state="readonly", 
                                   values=list(self.multiverse.timelines.keys()))
        source_combo.grid(row=0, column=1, padx=5, pady=5)
        if list(self.multiverse.timelines.keys()):
            source_combo.current(0)

        def create():
            source = source_var.get()
            if not source:
                messagebox.showerror("Error", "Please select a source timeline.")
                return

            self.multiverse.create_quantum_superposition(source)
            dialog.destroy()

            # Update the UI
            self.update_timeline_selectors()
            self.draw_timelines()

        ttk.Button(dialog, text="Create Superposition", command=create).grid(row=1, column=0, columnspan=2, pady=20)

    def execute_time_travel(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        origin = self.origin_var.get()
        dest = self.dest_var.get()

        if not origin or not dest:
            messagebox.showerror("Error", "Please select origin and destination timelines.")
            return

        try:
            year = int(self.year_var.get())
        except ValueError:
            messagebox.showerror("Error", "Year must be an integer.")
            return

        traveler = self.traveler_var.get() or "Unnamed Traveler"
        tunneling = self.tunneling_var.get()

        print(f"\n--- Manual Time Travel Event ---")
        print(f"Attempting: {traveler} traveling from {origin} to {dest} in year {year}" +
             (" using QUANTUM TUNNELING" if tunneling else ""))

        self.multiverse.time_travel(origin, dest, traveler, year, tunneling)

        # Update the visualization
        self.draw_timelines()
        self.update_stats()

    def update_timeline_selectors(self):
        # Update the origin and destination timeline selectors
        timeline_names = list(self.multiverse.timelines.keys())

        self.origin_combo['values'] = timeline_names
        self.dest_combo['values'] = timeline_names

        if timeline_names:
            self.origin_combo.current(0)
            if len(timeline_names) > 1:
                self.dest_combo.current(1)
            else:
                self.dest_combo.current(0)

    def draw_timelines(self):
        if not self.multiverse:
            return

        # Clear the canvas
        self.timeline_canvas.delete("all")

        # Get canvas dimensions
        canvas_width = self.timeline_canvas.winfo_width()
        canvas_height = self.timeline_canvas.winfo_height()

        # Ensure minimum size
        canvas_width = max(canvas_width, 600)
        canvas_height = max(canvas_height, 400)

        # Calculate timeline positions
        timelines = list(self.multiverse.timelines.values())
        num_timelines = len(timelines)

        if num_timelines == 0:
            return

        # Vertical spacing
        margin = 40
        spacing = min(80, (canvas_height - 2 * margin) / max(1, num_timelines - 1))

        # Track timeline positions
        timeline_positions = {}

        # Draw each timeline
        for i, timeline in enumerate(timelines):
            y_pos = margin + i * spacing if num_timelines > 1 else canvas_height // 2

            # Determine color based on stability
            r = min(255, int(255 * (1 - timeline.stability)))
            g = min(255, int(180 * timeline.stability))
            b = min(255, int(100 + 155 * timeline.worldline_integrity))
            color = f"#{r:02x}{g:02x}{b:02x}"

            # Draw timeline
            line_width = 3 if timeline == self.multiverse.current_timeline else 2
            line = self.timeline_canvas.create_line(
                50, y_pos, canvas_width - 50, y_pos, 
                fill=color, width=line_width, smooth=True
            )

            # Add timeline name
            name_text = self.timeline_canvas.create_text(
                30, y_pos, text=timeline.name, 
                fill="white", anchor="e"
            )

            # Add stability info
            stats = f"S:{timeline.stability:.2f} QF:{timeline.quantum_state.quantum_field_energy:.2f}"
            if timeline.quantum_state.superposition:
                stats += " [SUPER]"
            if timeline.quantum_state.wave_function_collapse:
                stats += " [COLLAPSE]"

            stats_text = self.timeline_canvas.create_text(
                canvas_width - 30, y_pos, text=stats,
                fill="light gray", anchor="w", font=("Arial", 8)
            )

            # Track position
            timeline_positions[timeline.name] = (50, y_pos, canvas_width - 50, y_pos)

        # Draw connections between timelines
        for timeline in timelines:
            start_x, start_y, end_x, end_y = timeline_positions[timeline.name]
            mid_x = (start_x + end_x) / 2

            for connected in timeline.connected_timelines:
                if connected.name in timeline_positions:
                    c_start_x, cstart_y, c_end_x, c_end_y = timeline_positions[connected.name]
                    c_mid_x = (c_start_x + c_end_x) / 2

                    # Determine if quantum entangled
                    is_entangled = timeline.quantum_state.entanglement_level > 0.5 and \
                                connected.quantum_state.entanglement_level > 0.5

                    # Connection color
                    if is_entangled:
                        conn_color = "#ff00ff"  # Magenta for quantum entanglement
                        dash = (5, 2)
                    else:
                        conn_color = "#4080ff"  # Blue for normal connections
                        dash = None

                    # Draw curved connection
                    self.timeline_canvas.create_line(
                        mid_x, start_y, (mid_x + c_mid_x)/2, (start_y + c_start_y)/2, c_mid_x, c_start_y,
                        fill=conn_color, width=1, smooth=True, dash=dash,
                        arrow="last", arrowshape=(8, 10, 3)
                    )

        # Draw wormholes
        for i, wormhole in enumerate(self.multiverse.wormholes):
            if wormhole.origin.name in timeline_positions and wormhole.destination.name in timeline_positions:
                o_start_x, o_start_y, o_end_x, o_end_y = timeline_positions[wormhole.origin.name]
                d_start_x, d_start_y, d_end_x, d_end_y = timeline_positions[wormhole.destination.name]

                # Position wormholes along the timeline based on index
                wh_x1 = o_start_x + (o_end_x - o_start_x) * (0.3 + i * 0.1)
                wh_x2 = d_start_x + (d_end_x - d_start_x) * (0.7 - i * 0.1)

                # Wormhole color based on stability
                r = min(255, int(255 * (1 - wormhole.stability)))
                g = min(255, int(220 * wormhole.stability))
                b = 255
                wh_color = f"#{r:02x}{g:02x}{b:02x}"

                # Draw wormhole representation
                self.timeline_canvas.create_line(
                    wh_x1, o_start_y, wh_x2, d_start_y,
                    fill=wh_color, width=3, smooth=True,
                    dash=(10, 4), arrow="both", arrowshape=(10, 12, 5)
                )

                # Add wormhole info
                info = f"±{wormhole.year_shift}y"
                self.timeline_canvas.create_text(
                    (wh_x1 + wh_x2)/2, (o_start_y + d_start_y)/2,
                    text=info, fill="yellow", font=("Arial", 8)
                )

    def update_stats(self):
        if not self.multiverse:
            return

        self.stats_text.delete(1.0, tk.END)

        # Count unstable timelines
        unstable = [t.name for t in self.multiverse.timelines.values() if t.stability < 0.4]

        # Count quantum anomalies
        anomalies = [t.name for t in self.multiverse.timelines.values() 
                   if t.quantum_state.wave_function_collapse or 
                      (t.quantum_state.entanglement_level > 0.8 and t.stability < 0.6)]

        # Find most quantum-affected timeline
        if self.multiverse.timelines:
            most_quantum = max(self.multiverse.timelines.values(), 
                              key=lambda t: t.quantum_state.entanglement_level + 
                                           (0.5 if t.quantum_state.superposition else 0) +
                                           (0.5 if t.quantum_state.wave_function_collapse else 0))

            self.stats_text.insert(tk.END, f"Multiverse Statistics:\n")
            self.stats_text.insert(tk.END, f"Total Timelines: {len(self.multiverse.timelines)}\n")
            self.stats_text.insert(tk.END, f"Unstable Timelines: {len(unstable)}\n")
            self.stats_text.insert(tk.END, f"Quantum Anomalies: {len(anomalies)}\n")
            self.stats_text.insert(tk.END, f"Most Quantum-Affected: {most_quantum.name} " +
                                 f"(QE: {most_quantum.quantum_state.entanglement_level:.2f})")

def run_simulation():
    print("=== Advanced Multiverse Paradox Quantum Field Theory Simulation ===")
    print("Initializing timelines with quantum field properties...")

    multiverse = Multiverse()

    # Create several timelines
    alpha = multiverse.create_timeline("Alpha Prime", 0.9)
    beta = multiverse.create_timeline("Beta Variant", 0.75)
    gamma = multiverse.create_timeline("Gamma Nexus", 0.6)
    delta = multiverse.create_timeline("Delta Flux", 0.5)
    omega = multiverse.create_timeline("Omega Point", 0.85)

    # Add historical events to each timeline
    alpha.add_event("Timeline origin point", 2000)
    alpha.add_event("Quantum computing breakthrough", 2025)
    alpha.add_event("First contact with extradimensional beings", 2042)

    beta.add_event("Timeline origin point - diverged from Alpha", 2010)
    beta.add_event("Global climate catastrophe", 2028)
    beta.add_event("Underground civilization established", 2035)

    gamma.add_event("Timeline origin - artificial creation", 1980)
    gamma.add_event("Robotic revolution", 2015)
    gamma.add_event("Human consciousness uploaded to quantum network", 2038)

    delta.add_event("Timeline origin - natural quantum fluctuation", 1995)
    delta.add_event("Dimensional barrier discovery", 2022)
    delta.add_event("Time strand manipulation technology invented", 2030)

    omega.add_event("Timeline origin - future recursion point", 2090)
    omega.add_event("Temporal mechanics breakthrough", 2065)
    omega.add_event("Quantum field unification theory completed", 2078)

    # Connect timelines in the multiverse
    multiverse.connect_timelines("Alpha Prime", "Beta Variant")
    multiverse.connect_timelines("Alpha Prime", "Gamma Nexus", quantum_entangle=True)  # Quantum entangled
    multiverse.connect_timelines("Beta Variant", "Delta Flux")
    multiverse.connect_timelines("Gamma Nexus", "Delta Flux")
    multiverse.connect_timelines("Omega Point", "Alpha Prime", quantum_entangle=True)

    # Create quantum superposition of Delta timeline
    quantum_delta = multiverse.create_quantum_superposition("Delta Flux")
    if quantum_delta:
        quantum_delta.add_event("Quantum state observed leading to alternative history", 2035)
        quantum_delta.add_event("Schrödinger's civilization: both thriving and extinct", 2040)

    # Create stable quantum wormholes
    multiverse.create_quantum_wormhole("Alpha Prime", "Omega Point", year_shift=30)  # 30 year difference
    multiverse.create_quantum_wormhole("Beta Variant", "Gamma Nexus", year_shift=-10)  # -10 year difference

    # Display the initial state
    multiverse.display_all_timelines()

    # Simulate time travel events
    print("\n\n==== SIMULATING TIME TRAVEL EVENTS WITH QUANTUM FIELD ALGORITHMS ====")

    time_travelers = [
        "Dr. Eliza Chen", "Quantum Agent Smith", "Professor Paradox", 
        "Traveler X", "Dr. Schrödinger", "Temporal Engineer Novikov",
        "Quantum Field Specialist Zhang", "Paradox Resolver Kim"
    ]

    # First try some quantum wormhole travel
    for i in range(3):
        print(f"\n--- Quantum Wormhole Travel Event {i+1} ---")

        # Select random time traveler and wormhole
        traveler = random.choice(time_travelers)
        wormhole_index = random.randint(0, len(multiverse.wormholes) - 1)
        origin_timeline = multiverse.wormholes[wormhole_index].origin

        # Random year for time travel between 2030 and 2060
        year = random.randint(2030, 2060)

        print(f"Attempting: {traveler} traveling via quantum wormhole from {origin_timeline.name} in year {year}")
        multiverse.perform_quantum_wormhole_travel(wormhole_index, traveler, year)

        time.sleep(0.5)  # Pause for effect

    # Then try regular time travel with quantum tunneling
    for i in range(5):
        print(f"\n--- Quantum Field Time Travel Event {i+1} ---")

        # Select random time traveler and timelines
        traveler = random.choice(time_travelers)
        timeline_names = list(multiverse.timelines.keys())
        origin_name = random.choice(timeline_names)

        # Use quantum tunneling with varying probability
        quantum_tunneling = random.random() < 0.4

        if quantum_tunneling:
            # With quantum tunneling, can go to any timeline regardless of connection
            destination_name = random.choice([t for t in timeline_names if t != origin_name])
            print(f"{traveler} attempting QUANTUM TUNNELING from {origin_name} to {destination_name}")
        else:
            # Find connected timeline for destination
            origin_timeline = multiverse.timelines[origin_name]
            if not origin_timeline.connected_timelines:
                print(f"No connected timelines available from {origin_name}")
                continue

            destination_timeline = random.choice(origin_timeline.connected_timelines)
            destination_name = destination_timeline.name

        # Random year for time travel between 2000 and 2070
        year = random.randint(2000, 2070)

        print(f"Attempting: {traveler} traveling from {origin_name} to {destination_name} in year {year}")
        success = multiverse.time_travel(origin_name, destination_name, traveler, year, quantum_tunneling)

        if success:
            print(f"Time travel completed. Current timeline: {multiverse.current_timeline.name}")

            # Periodically create quantum superpositions
            if i == 2:  # On the third event
                source_name = random.choice(timeline_names)
                print(f"\nCreating quantum superposition of {source_name}...")
                multiverse.create_quantum_superposition(source_name)

            time.sleep(0.5)  # Pause for effect

    # Create some timewaves and observe their propagation
    print("\n\n==== CREATING TEMPORAL WAVES ====")

    # Create a major temporal wave from a significant event
    wave1 = multiverse.create_timewave("Alpha Prime", 2040, 1.2, 
                                      "Quantum singularity experiment")

    # Create another wave from a different timeline
    wave2 = multiverse.create_timewave("Beta Variant", 2030, 0.8,
                                      "Temporal resonance cascade")

    # Propagate the waves through the multiverse
    for i in range(3):
        print(f"\n--- Timewave Propagation Cycle {i+1} ---")
        multiverse.propagate_timewaves()
        time.sleep(0.3)

    # Display final state
    print("\n\n==== FINAL MULTIVERSE STATE WITH QUANTUM FIELD ANALYSIS ====")
    multiverse.display_all_timelines()

    # Check for unstable timelines and quantum anomalies
    unstable_timelines = [t.name for t in multiverse.timelines.values() if t.stability < 0.4]
    quantum_anomalies = [t.name for t in multiverse.timelines.values() 
                         if t.quantum_state.wave_function_collapse or 
                            (t.quantum_state.entanglement_level > 0.8 and t.stability < 0.6)]

    if unstable_timelines:
        print("\n⚠️ WARNING: The following timelines are dangerously unstable:")
        for name in unstable_timelines:
            print(f"  - {name} (Stability: {multiverse.timelines[name].stability:.2f})")
        print("\nMultiverse collapse possible if stability continues to decrease!")

    if quantum_anomalies:
        print("\n⚠️ QUANTUM ALERT: The following timelines show quantum anomalies:")
        for name in quantum_anomalies:
            timeline = multiverse.timelines[name]
            anomaly_type = []
            if timeline.quantum_state.wave_function_collapse:
                anomaly_type.append("wave function collapse")
            if timeline.quantum_state.entanglement_level > 0.8:
                anomaly_type.append("critical entanglement")
            if timeline.quantum_state.superposition:
                anomaly_type.append("sustained superposition")

            print(f"  - {name} (Anomalies: {', '.join(anomaly_type)})")
        print("\nQuantum decoherence across multiverse fabric detected!")

    if not unstable_timelines and not quantum_anomalies:
        print("\nAll timelines maintaining relative stability. Multiverse remains intact.")

    # Determine most quantum-affected timeline
    most_quantum = max(multiverse.timelines.values(), 
                      key=lambda t: t.quantum_state.entanglement_level + 
                                   (0.5 if t.quantum_state.superposition else 0) +
                                   (0.5 if t.quantum_state.wave_function_collapse else 0))

    print(f"\nTimeline most affected by quantum mechanics: {most_quantum.name}")
    print(f"Quantum entanglement level: {most_quantum.quantum_state.entanglement_level:.2f}")
    print(f"Quantum field energy: {most_quantum.quantum_state.quantum_field_energy:.2f}")
    print(f"Quantum coherence: {most_quantum.quantum_state.quantum_coherence:.2f}")
    if most_quantum.quantum_state.superposition:
        print("Timeline exists in quantum superposition")
    if most_quantum.quantum_state.wave_function_collapse:
        print("Timeline has experienced wave function collapse")

    # Paradox statistics
    resolved_count = sum(1 for ptype, instances in multiverse.paradox_resolver.detected_paradoxes.items() 
                       for _ in instances)

    if resolved_count > 0:
        print(f"\nTotal paradoxes detected: {resolved_count}")
        print(f"Most common paradox type: {max(multiverse.paradox_resolver.detected_paradoxes.items(), key=lambda x: len(x[1]))[0]}")

        # Novikov consistency evaluation
        if multiverse.paradox_resolver.novikov_consistency_principle:
            print("\nNovikov self-consistency principle evaluation: Generally maintained")
            print("Timeline causality remains mostly coherent despite temporal interventions")

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

class MultiverseSimulatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Multiverse Paradox Quantum Field Simulator")
        self.root.geometry("1000x700")
        self.root.configure(bg='#1e1e2e')

        self.multiverse = None
        self.setup_ui()

    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Set up title
        title_label = ttk.Label(main_frame, text="Advanced Multiverse Paradox Quantum Field Theory Simulator", 
                              font=('Arial', 16, 'bold'))
        title_label.pack(pady=10)

        # Create notebook for tabs
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill=tk.BOTH, expand=True, pady=5)

        # Simulation tab
        sim_frame = ttk.Frame(notebook)
        notebook.add(sim_frame, text="Simulation")

        # Control panel frame
        control_frame = ttk.LabelFrame(sim_frame, text="Control Panel")
        control_frame.pack(fill=tk.X, padx=5, pady=5)

        # Initialize button
        init_button = ttk.Button(control_frame, text="Initialize Multiverse", command=self.initialize_multiverse)
        init_button.grid(row=0, column=0, padx=5, pady=5)

        # Run simulation button
        run_button = ttk.Button(control_frame, text="Run Time Travel Simulation", command=self.run_time_travel)
        run_button.grid(row=0, column=1, padx=5, pady=5)

        # Display state button
        display_button = ttk.Button(control_frame, text="Display Multiverse State", command=self.display_state)
        display_button.grid(row=0, column=2, padx=5, pady=5)

        # Create wormhole button
        wormhole_button = ttk.Button(control_frame, text="Create Wormhole", command=self.create_wormhole)
        wormhole_button.grid(row=0, column=3, padx=5, pady=5)

        # Create superposition button
        superpos_button = ttk.Button(control_frame, text="Create Superposition", command=self.create_superposition)
        superpos_button.grid(row=0, column=4, padx=5, pady=5)

        # Timeline travel panel
        travel_frame = ttk.LabelFrame(sim_frame, text="Manual Time Travel")
        travel_frame.pack(fill=tk.X, padx=5, pady=5)

        # Origin timeline selection
        ttk.Label(travel_frame, text="Origin Timeline:").grid(row=0, column=0, padx=5, pady=5)
        self.origin_var = tk.StringVar()
        self.origin_combo = ttk.Combobox(travel_frame, textvariable=self.origin_var, state="readonly")
        self.origin_combo.grid(row=0, column=1, padx=5, pady=5)

        # Destination timeline selection
        ttk.Label(travel_frame, text="Destination Timeline:").grid(row=0, column=2, padx=5, pady=5)
        self.dest_var = tk.StringVar()
        self.dest_combo = ttk.Combobox(travel_frame, textvariable=self.dest_var, state="readonly")
        self.dest_combo.grid(row=0, column=3, padx=5, pady=5)

        # Year entry
        ttk.Label(travel_frame, text="Year:").grid(row=0, column=4, padx=5, pady=5)
        self.year_var = tk.StringVar(value="2030")
        year_entry = ttk.Entry(travel_frame, textvariable=self.year_var, width=6)
        year_entry.grid(row=0, column=5, padx=5, pady=5)

        # Traveler name
        ttk.Label(travel_frame, text="Traveler:").grid(row=1, column=0, padx=5, pady=5)
        self.traveler_var = tk.StringVar(value="Dr. Eliza Chen")
        traveler_entry = ttk.Entry(travel_frame, textvariable=self.traveler_var, width=20)
        traveler_entry.grid(row=1, column=1, padx=5, pady=5)

        # Quantum tunneling checkbox
        self.tunneling_var = tk.BooleanVar(value=False)
        tunneling_check = ttk.Checkbutton(travel_frame, text="Use Quantum Tunneling", 
                                         variable=self.tunneling_var)
        tunneling_check.grid(row=1, column=2, padx=5, pady=5)

        # Time travel button
        travel_button = ttk.Button(travel_frame, text="Execute Time Travel", command=self.execute_time_travel)
        travel_button.grid(row=1, column=3, padx=5, pady=5)

        # Output console
        console_frame = ttk.LabelFrame(sim_frame, text="Simulation Output")
        console_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.console = scrolledtext.ScrolledText(console_frame, wrap=tk.WORD, font=('Courier', 10))
        self.console.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Timeline visualization tab
        viz_frame = ttk.Frame(notebook)
        notebook.add(viz_frame, text="Timeline Visualization")

        # Timeline stats
        stats_frame = ttk.LabelFrame(viz_frame, text="Quantum Statistics")
        stats_frame.pack(fill=tk.X, padx=5, pady=5)

        self.stats_text = scrolledtext.ScrolledText(stats_frame, wrap=tk.WORD, height=5, font=('Courier', 10))
        self.stats_text.pack(fill=tk.X, expand=True, padx=5, pady=5)

        # Timeline visualization
        timeline_frame = ttk.LabelFrame(viz_frame, text="Timelines")
        timeline_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.timeline_canvas = tk.Canvas(timeline_frame, bg="#232338", highlightthickness=0)
        self.timeline_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Redirect standard output to the console
        import sys
        self.original_stdout = sys.stdout
        sys.stdout = self

    def write(self, text):
        # This method is called by print statements
        self.console.insert(tk.END, text)
        self.console.see(tk.END)
        self.root.update_idletasks()

    def flush(self):
        # Required for file-like objects
        pass

    def initialize_multiverse(self):
        self.console.delete(1.0, tk.END)  # Clear console
        print("Initializing Multiverse with Quantum Field Properties...")
        self.multiverse = Multiverse()

        # Create timelines
        self.multiverse.create_timeline("Alpha Prime", 0.9)
        self.multiverse.create_timeline("Beta Variant", 0.75)
        self.multiverse.create_timeline("Gamma Nexus", 0.6)
        self.multiverse.create_timeline("Delta Flux", 0.5)
        self.multiverse.create_timeline("Omega Point", 0.85)

        # Add historical events to each timeline
        self.multiverse.timelines["Alpha Prime"].add_event("Timeline origin point", 2000)
        self.multiverse.timelines["Alpha Prime"].add_event("Quantum computing breakthrough", 2025)
        self.multiverse.timelines["Alpha Prime"].add_event("First contact with extradimensional beings", 2042)

        self.multiverse.timelines["Beta Variant"].add_event("Timeline origin point - diverged from Alpha", 2010)
        self.multiverse.timelines["Beta Variant"].add_event("Global climate catastrophe", 2028)
        self.multiverse.timelines["Beta Variant"].add_event("Underground civilization established", 2035)

        self.multiverse.timelines["Gamma Nexus"].add_event("Timeline origin - artificial creation", 1980)
        self.multiverse.timelines["Gamma Nexus"].add_event("Robotic revolution", 2015)
        self.multiverse.timelines["Gamma Nexus"].add_event("Human consciousness uploaded to quantum network", 2038)

        self.multiverse.timelines["Delta Flux"].add_event("Timeline origin - natural quantum fluctuation", 1995)
        self.multiverse.timelines["Delta Flux"].add_event("Dimensional barrier discovery", 2022)
        self.multiverse.timelines["Delta Flux"].add_event("Time strand manipulation technology invented", 2030)

        self.multiverse.timelines["Omega Point"].add_event("Timeline origin - future recursion point", 2090)
        self.multiverse.timelines["Omega Point"].add_event("Temporal mechanics breakthrough", 2065)
        self.multiverse.timelines["Omega Point"].add_event("Quantum field unification theory completed", 2078)

        # Connect timelines
        self.multiverse.connect_timelines("Alpha Prime", "Beta Variant")
        self.multiverse.connect_timelines("Alpha Prime", "Gamma Nexus", quantum_entangle=True)
        self.multiverse.connect_timelines("Beta Variant", "Delta Flux")
        self.multiverse.connect_timelines("Gamma Nexus", "Delta Flux")
        self.multiverse.connect_timelines("Omega Point", "Alpha Prime", quantum_entangle=True)

        # Update the timeline selector dropdowns
        self.update_timeline_selectors()

        # Display the initial state
        self.multiverse.display_all_timelines()

        # Draw the timelines
        self.draw_timelines()

    def run_time_travel(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        print("\n\n==== SIMULATING TIME TRAVEL EVENTS WITH QUANTUM FIELD ALGORITHMS ====")

        time_travelers = [
            "Dr. Eliza Chen", "Quantum Agent Smith", "Professor Paradox", 
            "Traveler X", "Dr. Schrödinger", "Temporal Engineer Novikov",
            "Quantum Field Specialist Zhang", "Paradox Resolver Kim"
        ]

        # Simulate time travel events
        for i in range(3):
            print(f"\n--- Quantum Wormhole Travel Event {i+1} ---")

            # Select random time traveler and wormhole
            traveler = random.choice(time_travelers)
            if not self.multiverse.wormholes:
                print("No wormholes available. Creating wormhole...")
                self.multiverse.create_quantum_wormhole("Alpha Prime", "Beta Variant", random.randint(-20, 20))

            wormhole_index = random.randint(0, len(self.multiverse.wormholes) - 1)
            origin_timeline = self.multiverse.wormholes[wormhole_index].origin

            # Random year for time travel
            year = random.randint(2030, 2060)

            print(f"Attempting: {traveler} traveling via quantum wormhole from {origin_timeline.name} in year {year}")
            self.multiverse.perform_quantum_wormhole_travel(wormhole_index, traveler, year)

            # Update UI after each event
            self.root.update()

        # Regular time travel with quantum tunneling
        for i in range(3):
            print(f"\n--- Quantum Field Time Travel Event {i+1} ---")

            # Select random time traveler and timelines
            traveler = random.choice(time_travelers)
            timeline_names = list(self.multiverse.timelines.keys())
            origin_name = random.choice(timeline_names)

            # Use quantum tunneling with varying probability
            quantum_tunneling = random.random() < 0.4

            if quantum_tunneling:
                # With quantum tunneling, can go to any timeline regardless of connection
                dest_options = [t for t in timeline_names if t != origin_name]
                if dest_options:
                    destination_name = random.choice(dest_options)
                    print(f"{traveler} attempting QUANTUM TUNNELING from {origin_name} to {destination_name}")
                else:
                    print(f"No destination timelines available for {origin_name}")
                    continue
            else:
                # Find connected timeline for destination
                origin_timeline = self.multiverse.timelines[origin_name]
                if not origin_timeline.connected_timelines:
                    print(f"No connected timelines available from {origin_name}")
                    continue

                destination_timeline = random.choice(origin_timeline.connected_timelines)
                destination_name = destination_timeline.name

            # Random year for time travel
            year = random.randint(2000, 2070)

            print(f"Attempting: {traveler} traveling from {origin_name} to {destination_name} in year {year}")
            self.multiverse.time_travel(origin_name, destination_name, traveler, year, quantum_tunneling)

            # Update UI after each event
            self.root.update()

        # Draw updated timelines
        self.draw_timelines()

        # Display final stats
        self.update_stats()

    def display_state(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        print("\n\n==== CURRENT MULTIVERSE STATE WITH QUANTUM FIELD ANALYSIS ====")
        self.multiverse.display_all_timelines()
        self.draw_timelines()
        self.update_stats()

    def create_wormhole(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        # Create a dialog for wormhole parameters
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Quantum Wormhole")
        dialog.geometry("400x200")
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(dialog, text="Origin Timeline:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        origin_var = tk.StringVar()
        origin_combo = ttk.Combobox(dialog, textvariable=origin_var, state="readonly",
                                   values=list(self.multiverse.timelines.keys()))
        origin_combo.grid(row=0, column=1, padx=5, pady=5)
        if list(self.multiverse.timelines.keys()):
            origin_combo.current(0)

        ttk.Label(dialog, text="Destination Timeline:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
        dest_var = tk.StringVar()
        dest_combo = ttk.Combobox(dialog, textvariable=dest_var, state="readonly",
                                 values=list(self.multiverse.timelines.keys()))
        dest_combo.grid(row=1, column=1, padx=5, pady=5)
        if len(list(self.multiverse.timelines.keys())) > 1:
            dest_combo.current(1)

        ttk.Label(dialog, text="Year Shift:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
        year_shift_var = tk.StringVar(value="0")
        year_shift_entry = ttk.Entry(dialog, textvariable=year_shift_var, width=10)
        year_shift_entry.grid(row=2, column=1, padx=5, pady=5, sticky='w')

        def create():
            try:
                origin = origin_var.get()
                dest = dest_var.get()
                year_shift = int(year_shift_var.get())

                if origin == dest:
                    messagebox.showerror("Error", "Origin and destination must be different timelines.")
                    return

                self.multiverse.create_quantum_wormhole(origin, dest, year_shift)
                dialog.destroy()
                self.draw_timelines()
            except ValueError:
                messagebox.showerror("Error", "Year shift must be an integer.")

        ttk.Button(dialog, text="Create Wormhole", command=create).grid(row=3, column=0, columnspan=2, pady=20)

    def create_superposition(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        # Create a dialog for superposition parameters
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Quantum Superposition")
        dialog.geometry("400x120")
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(dialog, text="Source Timeline:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        source_var = tk.StringVar()
        source_combo = ttk.Combobox(dialog, textvariable=source_var, state="readonly", 
                                   values=list(self.multiverse.timelines.keys()))
        source_combo.grid(row=0, column=1, padx=5, pady=5)
        if list(self.multiverse.timelines.keys()):
            source_combo.current(0)

        def create():
            source = source_var.get()
            if not source:
                messagebox.showerror("Error", "Please select a source timeline.")
                return

            self.multiverse.create_quantum_superposition(source)
            dialog.destroy()

            # Update the UI
            self.update_timeline_selectors()
            self.draw_timelines()

        ttk.Button(dialog, text="Create Superposition", command=create).grid(row=1, column=0, columnspan=2, pady=20)

    def execute_time_travel(self):
        if not self.multiverse:
            messagebox.showerror("Error", "Please initialize the multiverse first.")
            return

        origin = self.origin_var.get()
        dest = self.dest_var.get()

        if not origin or not dest:
            messagebox.showerror("Error", "Please select origin and destination timelines.")
            return

        try:
            year = int(self.year_var.get())
        except ValueError:
            messagebox.showerror("Error", "Year must be an integer.")
            return

        traveler = self.traveler_var.get() or "Unnamed Traveler"
        tunneling = self.tunneling_var.get()

        print(f"\n--- Manual Time Travel Event ---")
        print(f"Attempting: {traveler} traveling from {origin} to {dest} in year {year}" +
             (" using QUANTUM TUNNELING" if tunneling else ""))

        self.multiverse.time_travel(origin, dest, traveler, year, tunneling)

        # Update the visualization
        self.draw_timelines()
        self.update_stats()

    def update_timeline_selectors(self):
        # Update the origin and destination timeline selectors
        timeline_names = list(self.multiverse.timelines.keys())

        self.origin_combo['values'] = timeline_names
        self.dest_combo['values'] = timeline_names

        if timeline_names:
            self.origin_combo.current(0)
            if len(timeline_names) > 1:
                self.dest_combo.current(1)
            else:
                self.dest_combo.current(0)

    def draw_timelines(self):
        if not self.multiverse:
            return

        # Clear the canvas
        self.timeline_canvas.delete("all")

        # Get canvas dimensions
        canvas_width = self.timeline_canvas.winfo_width()
        canvas_height = self.timeline_canvas.winfo_height()

        # Ensure minimum size
        canvas_width = max(canvas_width, 600)
        canvas_height = max(canvas_height, 400)

        # Calculate timeline positions
        timelines = list(self.multiverse.timelines.values())
        num_timelines = len(timelines)

        if num_timelines == 0:
            return

        # Vertical spacing
        margin = 40
        spacing = min(80, (canvas_height - 2 * margin) / max(1, num_timelines - 1))

        # Track timeline positions
        timeline_positions = {}

        # Draw each timeline
        for i, timeline in enumerate(timelines):
            y_pos = margin + i * spacing if num_timelines > 1 else canvas_height // 2

            # Determine color based on stability
            r = min(255, int(255 * (1 - timeline.stability)))
            g = min(255, int(180 * timeline.stability))
            b = min(255, int(100 + 155 * timeline.worldline_integrity))
            color = f"#{r:02x}{g:02x}{b:02x}"

            # Draw timeline
            line_width = 3 if timeline == self.multiverse.current_timeline else 2
            line = self.timeline_canvas.create_line(
                50, y_pos, canvas_width - 50, y_pos, 
                fill=color, width=line_width, smooth=True
            )

            # Add timeline name
            name_text = self.timeline_canvas.create_text(
                30, y_pos, text=timeline.name, 
                fill="white", anchor="e"
            )

            # Add stability info
            stats = f"S:{timeline.stability:.2f} QF:{timeline.quantum_state.quantum_field_energy:.2f}"
            if timeline.quantum_state.superposition:
                stats += " [SUPER]"
            if timeline.quantum_state.wave_function_collapse:
                stats += " [COLLAPSE]"

            stats_text = self.timeline_canvas.create_text(
                canvas_width - 30, y_pos, text=stats,
                fill="light gray", anchor="w", font=("Arial", 8)
            )

            # Track position
            timeline_positions[timeline.name] = (50, y_pos, canvas_width - 50, y_pos)

        # Draw connections between timelines
        for timeline in timelines:
            start_x, start_y, end_x, end_y = timeline_positions[timeline.name]
            mid_x = (start_x + end_x) / 2

            for connected in timeline.connected_timelines:
                if connected.name in timeline_positions:
                    c_start_x, c_start_y, c_end_x, c_end_y = timeline_positions[connected.name]
                    c_mid_x = (c_start_x + c_end_x) / 2

                    # Determine if quantum entangled
                    is_entangled = timeline.quantum_state.entanglement_level > 0.5 and \
                                connected.quantum_state.entanglement_level > 0.5

                    # Connection color
                    if is_entangled:
                        conn_color = "#ff00ff"  # Magenta for quantum entanglement
                        dash = (5, 2)
                    else:
                        conn_color = "#4080ff"  # Blue for normal connections
                        dash = None

                    # Draw curved connection
                    self.timeline_canvas.create_line(
                        mid_x, start_y, (mid_x + c_mid_x)/2, (start_y + c_start_y)/2, c_mid_x, c_start_y,
                        fill=conn_color, width=1, smooth=True, dash=dash,
                        arrow="last", arrowshape=(8, 10, 3)
                    )

        # Draw wormholes
        for i, wormhole in enumerate(self.multiverse.wormholes):
            if wormhole.origin.name in timeline_positions and wormhole.destination.name in timeline_positions:
                o_start_x, o_start_y, o_end_x, o_end_y = timeline_positions[wormhole.origin.name]
                d_start_x, d_start_y, d_end_x, d_end_y = timeline_positions[wormhole.destination.name]

                # Position wormholes along the timeline based on index
                wh_x1 = o_start_x + (o_end_x - o_start_x) * (0.3 + i * 0.1)
                wh_x2 = d_start_x + (d_end_x - d_start_x) * (0.7 - i * 0.1)

                # Wormhole color based on stability
                r = min(255, int(255 * (1 - wormhole.stability)))
                g = min(255, int(220 * wormhole.stability))
                b = 255
                wh_color = f"#{r:02x}{g:02x}{b:02x}"

                # Draw wormhole representation
                self.timeline_canvas.create_line(
                    wh_x1, o_start_y, wh_x2, d_start_y,
                    fill=wh_color, width=3, smooth=True,
                    dash=(10, 4), arrow="both", arrowshape=(10, 12, 5)
                )

                # Add wormhole info
                info = f"±{wormhole.year_shift}y"
                self.timeline_canvas.create_text(
                    (wh_x1 + wh_x2)/2, (o_start_y + d_start_y)/2,
                    text=info, fill="yellow", font=("Arial", 8)
                )

    def update_stats(self):
        if not self.multiverse:
            return

        self.stats_text.delete(1.0, tk.END)

        # Count unstable timelines
        unstable = [t.name for t in self.multiverse.timelines.values() if t.stability < 0.4]

        # Count quantum anomalies
        anomalies = [t.name for t in self.multiverse.timelines.values() 
                   if t.quantum_state.wave_function_collapse or 
                      (t.quantum_state.entanglement_level > 0.8 and t.stability < 0.6)]

        # Find most quantum-affected timeline
        if self.multiverse.timelines:
            most_quantum = max(self.multiverse.timelines.values(), 
                              key=lambda t: t.quantum_state.entanglement_level + 
                                           (0.5 if t.quantum_state.superposition else 0) +
                                           (0.5 if t.quantum_state.wave_function_collapse else 0))

            self.stats_text.insert(tk.END, f"Multiverse Statistics:\n")
            self.stats_text.insert(tk.END, f"Total Timelines: {len(self.multiverse.timelines)}\n")
            self.stats_text.insert(tk.END, f"Unstable Timelines: {len(unstable)}\n")
            self.stats_text.insert(tk.END, f"Quantum Anomalies: {len(anomalies)}\n")
            self.stats_text.insert(tk.END, f"Most Quantum-Affected: {most_quantum.name} " +
                                 f"(QE: {most_quantum.quantum_state.entanglement_level:.2f})")

def run_simulation():
    print("=== Advanced Multiverse Paradox Quantum Field Theory Simulation ===")
    print("Initializing timelines with quantum field properties...")

    multiverse = Multiverse()

    # Create several timelines
    alpha = multiverse.create_timeline("Alpha Prime", 0.9)
    beta = multiverse.create_timeline("Beta Variant", 0.75)
    gamma = multiverse.create_timeline("Gamma Nexus", 0.6)
    delta = multiverse.create_timeline("Delta Flux", 0.5)
    omega = multiverse.create_timeline("Omega Point", 0.85)

    # Add historical events to each timeline
    alpha.add_event("Timeline origin point", 2000)
    alpha.add_event("Quantum computing breakthrough", 2025)
    alpha.add_event("First contact with extradimensional beings", 2042)

    beta.add_event("Timeline origin point - diverged from Alpha", 2010)
    beta.add_event("Global climate catastrophe", 2028)
    beta.add_event("Underground civilization established", 2035)

    gamma.add_event("Timeline origin - artificial creation", 1980)
    gamma.add_event("Robotic revolution", 2015)
    gamma.add_event("Human consciousness uploaded to quantum network", 2038)

    delta.add_event("Timeline origin - natural quantum fluctuation", 1995)
    delta.add_event("Dimensional barrier discovery", 2022)
    delta.add_event("Time strand manipulation technology invented", 2030)

    omega.add_event("Timeline origin - future recursion point", 2090)
    omega.add_event("Temporal mechanics breakthrough", 2065)
    omega.add_event("Quantum field unification theory completed", 2078)

    # Connect timelines in the multiverse
    multiverse.connect_timelines("Alpha Prime", "Beta Variant")
    multiverse.connect_timelines("Alpha Prime", "Gamma Nexus", quantum_entangle=True)  # Quantum entangled
    multiverse.connect_timelines("Beta Variant", "Delta Flux")
    multiverse.connect_timelines("Gamma Nexus", "Delta Flux")
    multiverse.connect_timelines("Omega Point", "Alpha Prime", quantum_entangle=True)

    # Create quantum superposition of Delta timeline
    quantum_delta = multiverse.create_quantum_superposition("Delta Flux")
    if quantum_delta:
        quantum_delta.add_event("Quantum state observed leading to alternative history", 2035)
        quantum_delta.add_event("Schrödinger's civilization: both thriving and extinct", 2040)

    # Create stable quantum wormholes
    multiverse.create_quantum_wormhole("Alpha Prime", "Omega Point", year_shift=30)  # 30 year difference
    multiverse.create_quantum_wormhole("Beta Variant", "Gamma Nexus", year_shift=-10)  # -10 year difference

    # Display the initial state
    multiverse.display_all_timelines()

    # Simulate time travel events
    print("\n\n==== SIMULATING TIME TRAVEL EVENTS WITH QUANTUM FIELD ALGORITHMS ====")

    time_travelers = [
        "Dr. Eliza Chen", "Quantum Agent Smith", "Professor Paradox", 
        "Traveler X", "Dr. Schrödinger", "Temporal Engineer Novikov",
        "Quantum Field Specialist Zhang", "Paradox Resolver Kim"
    ]

    # First try some quantum wormhole travel
    for i in range(3):
        print(f"\n--- Quantum Wormhole Travel Event {i+1} ---")

        # Select random time traveler and wormhole
        traveler = random.choice(time_travelers)
        wormhole_index = random.randint(0, len(multiverse.wormholes) - 1)
        origin_timeline = multiverse.wormholes[wormhole_index].origin

        # Random year for time travel between 2030 and 2060
        year = random.randint(2030, 2060)

        print(f"Attempting: {traveler} traveling via quantum wormhole from {origin_timeline.name} in year {year}")
        multiverse.perform_quantum_wormhole_travel(wormhole_index, traveler, year)

        time.sleep(0.5)  # Pause for effect

    # Then try regular time travel with quantum tunneling
    for i in range(5):
        print(f"\n--- Quantum Field Time Travel Event {i+1} ---")

        # Select random time traveler and timelines
        traveler = random.choice(time_travelers)
        timeline_names = list(multiverse.timelines.keys())
        origin_name = random.choice(timeline_names)

        # Use quantum tunneling with varying probability
        quantum_tunneling = random.random() < 0.4

        if quantum_tunneling:
            # With quantum tunneling, can go to any timeline regardless of connection
            destination_name = random.choice([t for t in timeline_names if t != origin_name])
            print(f"{traveler} attempting QUANTUM TUNNELING from {origin_name} to {destination_name}")
        else:
            # Find connected timeline for destination
            origin_timeline = multiverse.timelines[origin_name]
            if not origin_timeline.connected_timelines:
                print(f"No connected timelines available from {origin_name}")
                continue

            destination_timeline = random.choice(origin_timeline.connected_timelines)
            destination_name = destination_timeline.name

        # Random year for time travel between 2000 and 2070
        year = random.randint(2000, 2070)

        print(f"Attempting: {traveler} traveling from {origin_name} to {destination_name} in year {year}")
        success = multiverse.time_travel(origin_name, destination_name, traveler, year, quantum_tunneling)

        if success:
            print(f"Time travel completed. Current timeline: {multiverse.current_timeline.name}")

            # Periodically create quantum superpositions
            if i == 2:  # On the third event
                source_name = random.choice(timeline_names)
                print(f"\nCreating quantum superposition of {source_name}...")
                multiverse.create_quantum_superposition(source_name)

            time.sleep(0.5)  # Pause for effect

    # Create some timewaves and observe their propagation
    print("\n\n==== CREATING TEMPORAL WAVES ====")

    # Create a major temporal wave from a significant event
    wave1 = multiverse.create_timewave("Alpha Prime", 2040, 1.2, 
                                      "Quantum singularity experiment")

    # Create another wave from a different timeline
    wave2 = multiverse.create_timewave("Beta Variant", 2030, 0.8,
                                      "Temporal resonance cascade")

    # Propagate the waves through the multiverse
    for i in range(3):
        print(f"\n--- Timewave Propagation Cycle {i+1} ---")
        multiverse.propagate_timewaves()
        time.sleep(0.3)

    # Display final state
    print("\n\n==== FINAL MULTIVERSE STATE WITH QUANTUM FIELD ANALYSIS ====")
    multiverse.display_all_timelines()

    # Check for unstable timelines and quantum anomalies
    unstable_timelines = [t.name for t in multiverse.timelines.values() if t.stability < 0.4]
    quantum_anomalies = [t.name for t in multiverse.timelines.values() 
                         if t.quantum_state.wave_function_collapse or 
                            (t.quantum_state.entanglement_level > 0.8 and t.stability < 0.6)]

    if unstable_timelines:
        print("\n⚠️ WARNING: The following timelines are dangerously unstable:")
        for name in unstable_timelines:
            print(f"  - {name} (Stability: {multiverse.timelines[name].stability:.2f})")
        print("\nMultiverse collapse possible if stability continues to decrease!")

    if quantum_anomalies:
        print("\n⚠️ QUANTUM ALERT: The following timelines show quantum anomalies:")
        for name in quantum_anomalies:
            timeline = multiverse.timelines[name]
            anomaly_type = []
            if timeline.quantum_state.wave_function_collapse:
                anomaly_type.append("wave function collapse")
            if timeline.quantum_state.entanglement_level > 0.8:
                anomaly_type.append("critical entanglement")
            if timeline.quantum_state.superposition:
                anomaly_type.append("sustained superposition")

            print(f"  - {name} (Anomalies: {', '.join(anomaly_type)})")
        print("\nQuantum decoherence across multiverse fabric detected!")

    if not unstable_timelines and not quantum_anomalies:
        print("\nAll timelines maintaining relative stability. Multiverse remains intact.")

    # Determine most quantum-affected timeline
    most_quantum = max(multiverse.timelines.values(), 
                      key=lambda t: t.quantum_state.entanglement_level + 
                                   (0.5 if t.quantum_state.superposition else 0) +
                                   (0.5 if t.quantum_state.wave_function_collapse else 0))

    print(f"\nTimeline most affected by quantum mechanics: {most_quantum.name}")
    print(f"Quantum entanglement level: {most_quantum.quantum_state.entanglement_level:.2f}")
    print(f"Quantum field energy: {most_quantum.quantum_state.quantum_field_energy:.2f}")
    print(f"Quantum coherence: {most_quantum.quantum_state.quantum_coherence:.2f}")
    if most_quantum.quantum_state.superposition:
        print("Timeline exists in quantum superposition")
    if most_quantum.quantum_state.wave_function_collapse:
        print("Timeline has experienced wave function collapse")

    # Paradox statistics
    resolved_count = sum(1 for ptype, instances in multiverse.paradox_resolver.detected_paradoxes.items() 
                       for _ in instances)

    if resolved_count > 0:
        print(f"\nTotal paradoxes detected: {resolved_count}")
        print(f"Most common paradox type: {max(multiverse.paradox_resolver.detected_paradoxes.items(), key=lambda x: len(x[1]))[0]}")

        # Novikov consistency evaluation
        if multiverse.paradox_resolver.novikov_consistency_principle:
            print("\nNovikov self-consistency principle evaluation: Generally maintained")
            print("Timeline causality remains mostly coherent despite temporal interventions")

def run_demo_menu():
    """Run a menu of different demonstration options"""
    print("\n=== Multiverse Simulation Demonstrations ===")
    print("1. Run Quantum Multiverse Simulation")
    print("2. Run Fusion Reactor Demonstration")
    print("3. Run Quantum Mechanics Visualization")
    print("4. Run Timeline Paradox Analysis")
    print("5. Run Timeline Integration Demo")
    print("6. Back to main menu")
    
    choice = input("\nSelect a demonstration (1-6): ")
    
    if choice == "1":
        run_simulation()
    elif choice == "2":
        try:
            from fusion_demo import run_advanced_fusion_demo
            run_advanced_fusion_demo()
        except ImportError:
            print("Fusion demo module not available.")
    elif choice == "3":
        try:
            from quantum_physics import quantum_mechanics
            principles = quantum_mechanics.get_principles_list()
            print("\n=== Quantum Mechanics Principles ===")
            for i, principle in enumerate(principles, 1):
                print(f"{i}. {principle.name}")
            
            principle_num = input("\nSelect a principle to learn about (1-8): ")
            try:
                idx = int(principle_num) - 1
                if 0 <= idx < len(principles):
                    print("\n" + quantum_mechanics.get_principle_description(principles[idx].name))
                else:
                    print("Invalid selection.")
            except ValueError:
                print("Invalid input.")
        except ImportError:
            print("Quantum physics module not available.")
    elif choice == "4":
        try:
            # Run a paradox demonstration
            print("\nInitializing paradox analysis...")
            multiverse = Multiverse()
            multiverse.create_timeline("Alpha", 0.9)
            multiverse.create_timeline("Beta", 0.7)
            
            print("\nCreating paradox situation...")
            multiverse.time_travel("Alpha", "Beta", "Dr. Time", 2030, True)
            multiverse.time_travel("Beta", "Alpha", "Dr. Time", 2020, True)
            
            print("\nAnalyzing paradox resolution...")
            multiverse.display_all_timelines()
        except Exception as e:
            print(f"Error in paradox demonstration: {e}")
    elif choice == "5":
        try:
            from timeline_integration import run_timeline_integration_demo
            run_timeline_integration_demo()
        except ImportError:
            print("Timeline integration module not available.")
    
    input("\nPress Enter to continue...")

if __name__ == "__main__":
    # Adding numpy to requirements
    try:
        import numpy
    except ImportError:
        print("Installing numpy for quantum field calculations...")
        import subprocess
        subprocess.check_call(["pip", "install", "numpy"])

    # Check if running in GUI mode or console mode
    import sys
    if len(sys.argv) > 1:
        if sys.argv[1] == "--console":
            # Run in console mode
            run_simulation()
        elif sys.argv[1] == "--demo":
            # Run the demo menu
            run_demo_menu()
        elif sys.argv[1] == "--fusion":
            # Run just the fusion demo
            from fusion_demo import run_advanced_fusion_demo
            run_advanced_fusion_demo()
    else:
        # Default to GUI mode
        root = tk.Tk()
        app = MultiverseSimulatorGUI(root)
        root.mainloop()