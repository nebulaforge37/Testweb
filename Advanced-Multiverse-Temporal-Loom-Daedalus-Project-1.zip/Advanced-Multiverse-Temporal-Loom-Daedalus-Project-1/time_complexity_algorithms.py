
"""
Time Complexity Algorithms Module
This module provides time complexity analysis tools and classes for algorithms
used in the multiverse simulation system.
"""

import math
import random
from typing import List, Dict, Tuple, Optional, Any, Callable, Union
from algorithm_system import AlgorithmSystem

class TimeComplexityAnalyzer:
    """Class for analyzing and categorizing algorithm complexity"""
    
    def __init__(self, algorithm_system: Optional[AlgorithmSystem] = None):
        """Initialize the time complexity analyzer"""
        self.algorithm_system = algorithm_system or AlgorithmSystem()
        self.complexity_categories = {
            "O(1)": "Constant time - execution time stays the same regardless of input size",
            "O(log n)": "Logarithmic time - execution time increases logarithmically with input size",
            "O(n)": "Linear time - execution time increases linearly with input size",
            "O(n log n)": "Linearithmic time - slightly worse than linear time",
            "O(n²)": "Quadratic time - execution time is proportional to square of input size",
            "O(n³)": "Cubic time - execution time is proportional to cube of input size",
            "O(2^n)": "Exponential time - execution time doubles with each addition to input size",
            "O(n!)": "Factorial time - execution time grows factorially with input size"
        }
        
        # Mapping of algorithms to their complexity
        self.algorithm_complexity_map = self._initialize_complexity_map()
        
    def _initialize_complexity_map(self) -> Dict[str, Dict[str, str]]:
        """Create mapping of algorithms to their time complexity"""
        complexity_map = {}
        
        # Dynamic Programming Algorithms
        complexity_map["dynamic_programming"] = {
            "optimal_path": "O(n²)",
            "paradox_resolution": "O(n)",
            "timeline_stability": "O(n*m)",
            "quantum_energy_distribution": "O(n*e)"
        }
        
        # Greedy Algorithms
        complexity_map["greedy"] = {
            "timeline_stabilization": "O(n log n)",
            "resource_allocation": "O(n log n)",
            "wormhole_routing": "O(n log n)",
            "reality_pruning": "O(n log n)"
        }
        
        # Searching Algorithms
        complexity_map["searching"] = {
            "timeline_traversal_dfs": "O(V + E)",
            "timeline_traversal_bfs": "O(V + E)",
            "find_stable_path": "O(E log V)",
            "quantum_dimension_search": "O(n)"
        }
        
        # Backtracking Algorithms
        complexity_map["backtracking"] = {
            "paradox_resolution": "O(2ⁿ)",
            "timeline_reconstruction": "O(n!)",
            "reality_stabilization": "O(2ⁿ)",
            "event_sequencing": "O(n!)"
        }
        
        # Binary Search Algorithms
        complexity_map["binary_search"] = {
            "timeline_event_search": "O(log n)",
            "quantum_coordinate_lookup": "O(n log n)",
            "stability_threshold": "O(log n)",
            "paradox_probability": "O(log n)"
        }
        
        # Brute Force Algorithms
        complexity_map["brute_force"] = {
            "timeline_permutation": "O(n!)",
            "quantum_state_search": "O(mⁿ)",
            "paradox_combination_test": "O(2ⁿ)",
            "reality_merge_evaluation": "O(n²)"
        }
        
        # Machine Learning Algorithms
        complexity_map["machine_learning"] = {
            "timeline_stability_prediction": "O(n*d)",
            "paradox_risk_classification": "O(n)",
            "quantum_pattern_recognition": "O(k*n*i)",
            "reality_convergence_prediction": "O(n*t)"
        }
        
        # Logistic Regression Algorithms
        complexity_map["logistic_regression"] = {
            "timeline_stability_probability": "O(f)",
            "wormhole_success_probability": "O(f)",
            "paradox_occurrence_probability": "O(f)",
            "wavefunction_collapse": "O(f)"
        }
        
        return complexity_map
    
    def get_algorithm_complexity(self, category: str, algorithm_name: str) -> Optional[str]:
        """Get the time complexity of a specific algorithm"""
        if category in self.algorithm_complexity_map and algorithm_name in self.algorithm_complexity_map[category]:
            return self.algorithm_complexity_map[category][algorithm_name]
        return None
    
    def explain_complexity(self, complexity: str) -> str:
        """Get an explanation of a complexity class"""
        return self.complexity_categories.get(complexity, "Unknown complexity classification")
    
    def estimate_runtime(self, complexity: str, input_size: int, base_time: float = 1.0) -> float:
        """
        Estimate runtime based on complexity class and input size
        
        Args:
            complexity: Big O notation as string
            input_size: Size of the input
            base_time: Base time unit (e.g., milliseconds for one operation)
            
        Returns:
            Estimated runtime in the same units as base_time
        """
        if complexity == "O(1)":
            return base_time
        elif complexity == "O(log n)":
            return base_time * math.log2(input_size)
        elif complexity == "O(n)":
            return base_time * input_size
        elif complexity == "O(n log n)":
            return base_time * input_size * math.log2(input_size)
        elif complexity == "O(n²)":
            return base_time * (input_size ** 2)
        elif complexity == "O(n³)":
            return base_time * (input_size ** 3)
        elif complexity == "O(2^n)":
            return base_time * (2 ** input_size)
        elif complexity == "O(n!)":
            # Use Stirling's approximation for large n
            if input_size > 20:
                # log(n!) ≈ n*log(n) - n
                log_factorial = input_size * math.log(input_size) - input_size
                return base_time * math.exp(log_factorial)
            else:
                # Calculate directly for small n
                factorial = 1
                for i in range(1, input_size + 1):
                    factorial *= i
                return base_time * factorial
        else:
            return float('inf')  # Unknown complexity
    
    def compare_algorithms(self, algorithms: List[Tuple[str, str]], input_size: int) -> Dict[str, Dict[str, Any]]:
        """
        Compare estimated runtime performance of multiple algorithms
        
        Args:
            algorithms: List of (category, name) tuples
            input_size: Size of the input
            
        Returns:
            Dictionary with algorithm names as keys and performance metrics as values
        """
        results = {}
        
        for category, name in algorithms:
            complexity = self.get_algorithm_complexity(category, name)
            if complexity:
                estimated_time = self.estimate_runtime(complexity, input_size)
                
                results[f"{category}.{name}"] = {
                    "complexity": complexity,
                    "estimated_time": estimated_time,
                    "explanation": self.explain_complexity(complexity)
                }
        
        # Sort by estimated time
        return dict(sorted(results.items(), key=lambda x: x[1]["estimated_time"]))
    
    def generate_complexity_report(self) -> Dict[str, Dict[str, Dict[str, str]]]:
        """Generate a comprehensive complexity report for all algorithms"""
        report = {}
        
        for category, algorithms in self.algorithm_complexity_map.items():
            report[category] = {}
            
            for algorithm, complexity in algorithms.items():
                report[category][algorithm] = {
                    "complexity": complexity,
                    "explanation": self.explain_complexity(complexity),
                    "description": self._get_algorithm_description(category, algorithm)
                }
                
        return report
    
    def _get_algorithm_description(self, category: str, algorithm: str) -> str:
        """Get a description of what an algorithm does"""
        descriptions = {
            "dynamic_programming.optimal_path": "Finds optimal path through timelines using DP",
            "dynamic_programming.paradox_resolution": "Resolves multiple paradoxes in optimal order",
            "dynamic_programming.timeline_stability": "Maximizes timeline stability by selecting optimal events to modify",
            "dynamic_programming.quantum_energy_distribution": "Optimizes quantum energy distribution across dimensions",
            
            "greedy.timeline_stabilization": "Quickly stabilizes a timeline by modifying events in order of efficiency",
            "greedy.resource_allocation": "Allocates resources to timelines based on need and stability",
            "greedy.wormhole_routing": "Creates optimal wormhole routes from origin to other timelines",
            "greedy.reality_pruning": "Prunes realities to target count by removing least important ones",
            
            "searching.timeline_traversal_dfs": "Traverses connected timelines using depth-first search",
            "searching.timeline_traversal_bfs": "Traverses connected timelines using breadth-first search",
            "searching.find_stable_path": "Finds the most stable path between two timelines using A* search",
            "searching.quantum_dimension_search": "Searches for quantum dimensions matching criteria",
            
            "backtracking.paradox_resolution": "Resolves a paradox by trying different options and backtracking if needed",
            "backtracking.timeline_reconstruction": "Reconstructs a damaged timeline using available evidence and constraints",
            "backtracking.reality_stabilization": "Finds optimal interventions to stabilize a reality",
            "backtracking.event_sequencing": "Finds a valid sequence of events that satisfies all temporal constraints",
            
            "binary_search.timeline_event_search": "Binary search for events near a target year",
            "binary_search.quantum_coordinate_lookup": "Binary search for quantum coordinates within tolerance",
            "binary_search.stability_threshold": "Binary search to find the threshold where stability changes",
            "binary_search.paradox_probability": "Binary search to find the probability of paradox for a given event",
            
            "brute_force.timeline_permutation": "Finds optimal permutation of elements by brute force",
            "brute_force.quantum_state_search": "Brute force search for quantum state transition path",
            "brute_force.paradox_combination_test": "Tests all combinations of events to find those causing paradoxes",
            "brute_force.reality_merge_evaluation": "Evaluates all possible reality merge pairs",
            
            "machine_learning.timeline_stability_prediction": "Predicts timeline stability using k-nearest neighbors",
            "machine_learning.paradox_risk_classification": "Classifies events into paradox risk categories",
            "machine_learning.quantum_pattern_recognition": "Recognizes patterns in quantum field data using clustering",
            "machine_learning.reality_convergence_prediction": "Predicts future convergence of realities",
            
            "logistic_regression.timeline_stability_probability": "Estimates probability of timeline stability",
            "logistic_regression.wormhole_success_probability": "Estimates probability of successful wormhole travel",
            "logistic_regression.paradox_occurrence_probability": "Estimates probability of paradox occurrence from an event",
            "logistic_regression.wavefunction_collapse": "Estimates probability of quantum wavefunction collapse"
        }
        
        key = f"{category}.{algorithm}"
        return descriptions.get(key, "No description available")

class TimeComplexityVisualizer:
    """Visualizes time complexity growth for different algorithm classes"""
    
    def __init__(self, analyzer: TimeComplexityAnalyzer):
        """Initialize the time complexity visualizer"""
        self.analyzer = analyzer
        
    def generate_comparison_data(self, input_sizes: List[int]) -> Dict[str, List[float]]:
        """
        Generate data points for various complexity classes
        
        Args:
            input_sizes: List of input sizes to calculate for
            
        Returns:
            Dictionary with complexity classes as keys and runtime lists as values
        """
        complexities = ["O(1)", "O(log n)", "O(n)", "O(n log n)", "O(n²)", "O(n³)", "O(2^n)", "O(n!)"]
        data = {complexity: [] for complexity in complexities}
        
        for size in input_sizes:
            for complexity in complexities:
                # Skip extreme values for exponential and factorial
                if complexity == "O(2^n)" and size > 30:
                    data[complexity].append(float('inf'))
                elif complexity == "O(n!)" and size > 20:
                    data[complexity].append(float('inf'))
                else:
                    runtime = self.analyzer.estimate_runtime(complexity, size)
                    data[complexity].append(runtime)
        
        return data
    
    def generate_algorithm_comparison(self, 
                                   categories: List[str], 
                                   input_size: int) -> Dict[str, Dict[str, Any]]:
        """
        Compare all algorithms from specified categories
        
        Args:
            categories: List of algorithm categories to include
            input_size: Input size for comparison
            
        Returns:
            Dictionary with algorithms as keys and performance data as values
        """
        algorithms = []
        
        for category in categories:
            if category in self.analyzer.algorithm_complexity_map:
                for algorithm in self.analyzer.algorithm_complexity_map[category]:
                    algorithms.append((category, algorithm))
        
        return self.analyzer.compare_algorithms(algorithms, input_size)
    
    def print_comparison_table(self, comparison_data: Dict[str, Dict[str, Any]]) -> None:
        """Print a formatted comparison table of algorithm performance"""
        print("\n=== Algorithm Complexity Comparison ===")
        print(f"{'Algorithm':<40} {'Complexity':<12} {'Est. Runtime':<20} {'Category'}")
        print("-" * 90)
        
        for algorithm, data in comparison_data.items():
            runtime = data["estimated_time"]
            if runtime > 1e10:
                runtime_str = "INFEASIBLE"
            elif runtime > 1e6:
                runtime_str = f"{runtime:.2e} units"
            else:
                runtime_str = f"{runtime:.2f} units"
                
            category = algorithm.split('.')[0]
            print(f"{algorithm:<40} {data['complexity']:<12} {runtime_str:<20} {category}")

class BigONotationReference:
    """Reference class for Big O notation and algorithm complexity"""
    
    def __init__(self):
        """Initialize the Big O notation reference"""
        self.common_operations = {
            "Array/List": {
                "Access": "O(1)",
                "Search (unsorted)": "O(n)",
                "Search (sorted)": "O(log n)",
                "Insert/Delete (end)": "O(1)",
                "Insert/Delete (arbitrary)": "O(n)"
            },
            "LinkedList": {
                "Access": "O(n)",
                "Search": "O(n)",
                "Insert/Delete (beginning)": "O(1)",
                "Insert/Delete (end, with tail)": "O(1)",
                "Insert/Delete (arbitrary)": "O(n)"
            },
            "Hash Table": {
                "Search/Insert/Delete (average)": "O(1)",
                "Search/Insert/Delete (worst)": "O(n)"
            },
            "Binary Search Tree": {
                "Search/Insert/Delete (average)": "O(log n)",
                "Search/Insert/Delete (worst)": "O(n)"
            },
            "Heap": {
                "FindMax/FindMin": "O(1)",
                "Insert": "O(log n)",
                "Delete": "O(log n)",
                "Heapify": "O(n)"
            },
            "Graph": {
                "BFS/DFS": "O(V+E)",
                "Dijkstra": "O(V^2) or O(E+V log V)",
                "Bellman-Ford": "O(V*E)",
                "Floyd-Warshall": "O(V^3)"
            }
        }
        
        self.sorting_algorithms = {
            "Bubble Sort": {
                "Best": "O(n)",
                "Average": "O(n²)",
                "Worst": "O(n²)",
                "Space": "O(1)"
            },
            "Selection Sort": {
                "Best": "O(n²)",
                "Average": "O(n²)",
                "Worst": "O(n²)",
                "Space": "O(1)"
            },
            "Insertion Sort": {
                "Best": "O(n)",
                "Average": "O(n²)",
                "Worst": "O(n²)",
                "Space": "O(1)"
            },
            "Merge Sort": {
                "Best": "O(n log n)",
                "Average": "O(n log n)",
                "Worst": "O(n log n)",
                "Space": "O(n)"
            },
            "Quick Sort": {
                "Best": "O(n log n)",
                "Average": "O(n log n)",
                "Worst": "O(n²)",
                "Space": "O(log n)"
            },
            "Heap Sort": {
                "Best": "O(n log n)",
                "Average": "O(n log n)",
                "Worst": "O(n log n)",
                "Space": "O(1)"
            },
            "Counting Sort": {
                "Time": "O(n + k)",
                "Space": "O(n + k)"
            },
            "Radix Sort": {
                "Time": "O(d * (n + k))",
                "Space": "O(n + k)"
            },
            "Bucket Sort": {
                "Best": "O(n + k)",
                "Average": "O(n + k)",
                "Worst": "O(n²)",
                "Space": "O(n * k)"
            }
        }
        
    def get_complexity_hierarchy(self) -> List[str]:
        """Returns a list of complexity classes from most to least efficient"""
        return [
            "O(1)", "O(log n)", "O(n)", "O(n log n)", 
            "O(n²)", "O(n³)", "O(2^n)", "O(n!)"
        ]
    
    def explain_notation(self) -> str:
        """Returns an explanation of Big O notation"""
        return """
Big O notation describes the upper bound of an algorithm's time complexity 
in terms of the input size n. It answers the question: "How does the running 
time or space requirements scale as the input grows?"

Key concepts:
- We focus on the dominant terms and ignore constants
- O(1) is constant time - operations that take the same amount of time regardless of input size
- O(log n) is logarithmic time - typically found in algorithms that divide the problem in half each time
- O(n) is linear time - execution time grows directly with input size
- O(n log n) is linearithmic time - common in efficient sorting algorithms
- O(n²) is quadratic time - often found in nested loops
- O(n³) is cubic time - often found in triple nested loops
- O(2^n) is exponential time - typically found in algorithms that solve problems by trying all subsets
- O(n!) is factorial time - typically found in algorithms that generate all permutations
"""
    
    def print_sorting_comparison(self) -> None:
        """Print a comparison of sorting algorithms"""
        print("\n=== Sorting Algorithm Complexity Comparison ===")
        print(f"{'Algorithm':<15} {'Best':<10} {'Average':<10} {'Worst':<10} {'Space':<10}")
        print("-" * 60)
        
        for algorithm, complexities in self.sorting_algorithms.items():
            if "Best" in complexities:
                print(f"{algorithm:<15} {complexities.get('Best', 'N/A'):<10} "
                      f"{complexities.get('Average', 'N/A'):<10} {complexities.get('Worst', 'N/A'):<10} "
                      f"{complexities.get('Space', 'N/A'):<10}")
            else:
                # For counting/radix sort which have different categorization
                print(f"{algorithm:<15} {'N/A':<10} {complexities.get('Time', 'N/A'):<10} "
                      f"{'N/A':<10} {complexities.get('Space', 'N/A'):<10}")
    
    def print_data_structure_operations(self) -> None:
        """Print complexity of common data structure operations"""
        print("\n=== Data Structure Operation Complexities ===")
        
        for structure, operations in self.common_operations.items():
            print(f"\n{structure}:")
            print("-" * 40)
            for operation, complexity in operations.items():
                print(f"{operation:<30} {complexity}")

def demonstrate_time_complexity():
    """Demonstrate the time complexity analyzer and visualizer"""
    # Create instances
    analyzer = TimeComplexityAnalyzer()
    visualizer = TimeComplexityVisualizer(analyzer)
    reference = BigONotationReference()
    
    print("=== Time Complexity Analysis System Demo ===")
    print("This system analyzes and compares algorithm complexities in the multiverse simulation.")
    
    # Show specific algorithm complexity
    category = "dynamic_programming"
    algorithm = "optimal_path"
    complexity = analyzer.get_algorithm_complexity(category, algorithm)
    
    print(f"\nAlgorithm: {category}.{algorithm}")
    print(f"Time Complexity: {complexity}")
    print(f"Explanation: {analyzer.explain_complexity(complexity)}")
    
    # Compare algorithms from different categories
    print("\n=== Algorithm Comparison ===")
    comparison = visualizer.generate_algorithm_comparison(
        ["dynamic_programming", "greedy", "searching"], 1000
    )
    visualizer.print_comparison_table(comparison)
    
    # Show data structure operation complexities
    reference.print_data_structure_operations()
    
    # Show sorting algorithm comparison
    reference.print_sorting_comparison()
    
    # Show Big O notation explanation
    print(reference.explain_notation())

if __name__ == "__main__":
    demonstrate_time_complexity()
