
"""
Timeline Merging System
This module enables the merging of divergent timelines into a new stable timeline.
"""

import random
import time
from typing import List, Dict, Tuple, Optional, Set
from main import Timeline, Multiverse

class MergeConflict:
    """Represents a conflict between events in two timelines"""
    
    def __init__(self, year: int, event1: str, event2: str, timeline1: str, timeline2: str):
        self.year = year
        self.event1 = event1
        self.event2 = event2
        self.timeline1 = timeline1
        self.timeline2 = timeline2
        self.resolution = None
        self.resolution_method = None
        
    def resolve_automatically(self) -> bool:
        """Attempt to automatically resolve the conflict"""
        # Default resolution strategies
        methods = ["select_first", "select_second", "combine", "create_new"]
        self.resolution_method = random.choice(methods)
        
        if self.resolution_method == "select_first":
            self.resolution = self.event1
        elif self.resolution_method == "select_second":
            self.resolution = self.event2
        elif self.resolution_method == "combine":
            self.resolution = f"MERGED: {self.event1} AND {self.event2}"
        else:  # create_new
            variations = [
                f"CONSENSUS: Hybrid event derived from conflicting histories",
                f"RECONCILED: Alternative outcome to conflicting events",
                f"SYNTHESIS: New event emerging from timeline variance"
            ]
            self.resolution = random.choice(variations)
            
        return True
        
    def resolve_manually(self, choice: str) -> bool:
        """Manually resolve the conflict"""
        if choice == "first":
            self.resolution = self.event1
            self.resolution_method = "select_first"
        elif choice == "second":
            self.resolution = self.event2
            self.resolution_method = "select_second"
        elif choice == "combine":
            self.resolution = f"MERGED: {self.event1} AND {self.event2}"
            self.resolution_method = "combine"
        elif choice.startswith("custom:"):
            self.resolution = choice[7:]  # Remove "custom:" prefix
            self.resolution_method = "custom"
        else:
            return False
            
        return True
        
    def __str__(self) -> str:
        return (f"CONFLICT at {self.year}:\n"
                f"  {self.timeline1}: {self.event1}\n"
                f"  {self.timeline2}: {self.event2}\n"
                f"  Resolution: {self.resolution if self.resolution else 'UNRESOLVED'}")


class TimelineMerger:
    """Handles the process of merging timelines"""
    
    def __init__(self, multiverse: Multiverse):
        self.multiverse = multiverse
        self.conflicts = []
        self.merge_stability = 1.0  # Start with perfect stability
        
    def analyze_merge_compatibility(self, timeline1_name: str, timeline2_name: str) -> Dict:
        """Analyze how compatible two timelines are for merging"""
        if timeline1_name not in self.multiverse.timelines or timeline2_name not in self.multiverse.timelines:
            return {"compatible": False, "reason": "One or both timelines don't exist"}
            
        timeline1 = self.multiverse.timelines[timeline1_name]
        timeline2 = self.multiverse.timelines[timeline2_name]
        
        # Check if timelines are connected
        if timeline2 not in timeline1.connected_timelines:
            return {"compatible": False, "reason": "Timelines are not connected"}
            
        # Find conflicts
        self.conflicts = self._identify_conflicts(timeline1, timeline2)
        
        # Calculate compatibility score
        total_events = len(timeline1.events) + len(timeline2.events)
        conflict_ratio = len(self.conflicts) / total_events if total_events > 0 else 0
        
        # Check quantum state compatibility
        quantum_compatibility = 1.0
        if hasattr(timeline1, 'quantum_state') and hasattr(timeline2, 'quantum_state'):
            # Different entanglement levels reduce compatibility
            entanglement_diff = abs(timeline1.quantum_state.entanglement_level - 
                                   timeline2.quantum_state.entanglement_level)
            quantum_compatibility -= entanglement_diff * 0.5
            
            # Superposition states are harder to merge
            if timeline1.quantum_state.superposition or timeline2.quantum_state.superposition:
                quantum_compatibility *= 0.7
                
            # Wave function collapse makes merging even harder
            if timeline1.quantum_state.wave_function_collapse or timeline2.quantum_state.wave_function_collapse:
                quantum_compatibility *= 0.5
        
        # Calculate overall compatibility
        compatibility_score = (1.0 - conflict_ratio) * quantum_compatibility
        
        return {
            "compatible": compatibility_score > 0.3,  # Arbitrary threshold
            "compatibility_score": compatibility_score,
            "conflict_count": len(self.conflicts),
            "quantum_compatibility": quantum_compatibility,
            "conflicts": self.conflicts
        }
        
    def _identify_conflicts(self, timeline1: Timeline, timeline2: Timeline) -> List[MergeConflict]:
        """Identify conflicts between two timelines"""
        conflicts = []
        
        # Create dictionaries of events by year for easy comparison
        timeline1_events = {}
        for year, event in timeline1.events:
            if year not in timeline1_events:
                timeline1_events[year] = []
            timeline1_events[year].append(event)
            
        timeline2_events = {}
        for year, event in timeline2.events:
            if year not in timeline2_events:
                timeline2_events[year] = []
            timeline2_events[year].append(event)
            
        # Find years that exist in both timelines
        common_years = set(timeline1_events.keys()) & set(timeline2_events.keys())
        
        # Check for conflicts in those years
        for year in common_years:
            for event1 in timeline1_events[year]:
                for event2 in timeline2_events[year]:
                    # Skip if events are identical
                    if event1 == event2:
                        continue
                        
                    # Check if events might be conflicting
                    # This is a simple heuristic - in reality, you'd need 
                    # more sophisticated conflict detection
                    if self._events_conflict(event1, event2):
                        conflicts.append(MergeConflict(
                            year, event1, event2, timeline1.name, timeline2.name
                        ))
        
        return conflicts
        
    def _events_conflict(self, event1: str, event2: str) -> bool:
        """Determine if two events conflict with each other"""
        # Skip comparison if one is a PARADOX and one isn't
        if "PARADOX" in event1 and "PARADOX" not in event2:
            return False
        if "PARADOX" in event2 and "PARADOX" not in event1:
            return False
            
        # Skip if one is clearly a metadata event
        if event1.startswith("Timeline") or event1.startswith("QUANTUM"):
            return False
        if event2.startswith("Timeline") or event2.startswith("QUANTUM"):
            return False
            
        # Check for key conflict indicators
        conflict_indicators = [
            ("established", "destroyed"),
            ("created", "prevented"),
            ("discovered", "remained hidden"),
            ("succeeded", "failed"),
            ("resolved", "unresolved"),
            ("peace", "war"),
            ("alive", "dead")
        ]
        
        for indicator1, indicator2 in conflict_indicators:
            if (indicator1 in event1.lower() and indicator2 in event2.lower()) or \
               (indicator2 in event1.lower() and indicator1 in event2.lower()):
                return True
                
        # Simple word overlap check - if they're too different, they might conflict
        words1 = set(event1.lower().split())
        words2 = set(event2.lower().split())
        overlap = len(words1 & words2)
        
        # If they share words but aren't identical, they might be conflicting versions
        # of the same event
        if 0 < overlap < min(len(words1), len(words2)) * 0.8:
            return True
            
        return False
        
    def resolve_conflicts_automatically(self) -> List[MergeConflict]:
        """Automatically resolve all conflicts"""
        for conflict in self.conflicts:
            success = conflict.resolve_automatically()
            if not success:
                self.merge_stability *= 0.9  # Reduce stability for each unresolved conflict
                
        return self.conflicts
        
    def resolve_conflict_manually(self, conflict_index: int, choice: str) -> bool:
        """Manually resolve a specific conflict"""
        if 0 <= conflict_index < len(self.conflicts):
            conflict = self.conflicts[conflict_index]
            success = conflict.resolve_manually(choice)
            if not success:
                self.merge_stability *= 0.9
            return success
        return False
        
    def merge_timelines(self, timeline1_name: str, timeline2_name: str, 
                       new_timeline_name: str) -> Optional[Timeline]:
        """
        Merge two timelines into a new one, applying conflict resolutions
        """
        # Verify the timelines exist
        if timeline1_name not in self.multiverse.timelines or timeline2_name not in self.multiverse.timelines:
            return None
            
        timeline1 = self.multiverse.timelines[timeline1_name]
        timeline2 = self.multiverse.timelines[timeline2_name]
        
        # Check if we've analyzed these timelines
        if not self.conflicts:
            analysis = self.analyze_merge_compatibility(timeline1_name, timeline2_name)
            if not analysis["compatible"]:
                return None
        
        # Check if all conflicts are resolved
        unresolved = [c for c in self.conflicts if c.resolution is None]
        if unresolved:
            # Auto-resolve remaining conflicts
            self.resolve_conflicts_automatically()
        
        # Calculate the stability of the merged timeline
        # Base it on component timeline stability and merge stability
        base_stability = (timeline1.stability + timeline2.stability) / 2
        new_stability = base_stability * self.merge_stability
        
        # Constrain to valid range
        new_stability = max(0.1, min(1.0, new_stability))
        
        # Create the new timeline
        merged_timeline = self.multiverse.create_timeline(new_timeline_name, new_stability)
        
        # Combine events from both timelines, using conflict resolutions where needed
        event_map = {}  # year -> event
        
        # Add all non-conflicting events
        for year, event in timeline1.events:
            event_map.setdefault(year, set()).add(event)
            
        for year, event in timeline2.events:
            event_map.setdefault(year, set()).add(event)
            
        # Replace conflicting events with resolutions
        for conflict in self.conflicts:
            year = conflict.year
            event_map[year].discard(conflict.event1)
            event_map[year].discard(conflict.event2)
            event_map[year].add(conflict.resolution)
        
        # Add a merge event
        merge_year = max(max(y for y, _ in timeline1.events), max(y for y, _ in timeline2.events)) + 1
        event_map.setdefault(merge_year, set()).add(
            f"TIMELINE MERGE: Created from {timeline1_name} and {timeline2_name}"
        )
        
        # Add all events to the merged timeline
        for year, events in sorted(event_map.items()):
            for event in events:
                merged_timeline.add_event(event, year)
        
        # Handle quantum state if available
        if hasattr(timeline1, 'quantum_state') and hasattr(merged_timeline, 'quantum_state'):
            # Average the quantum field energy
            merged_timeline.quantum_state.quantum_field_energy = (
                timeline1.quantum_state.quantum_field_energy + 
                timeline2.quantum_state.quantum_field_energy
            ) / 2
            
            # Average the entanglement level
            merged_timeline.quantum_state.entanglement_level = (
                timeline1.quantum_state.entanglement_level + 
                timeline2.quantum_state.entanglement_level
            ) / 2
            
            # Combine superposition states
            merged_timeline.quantum_state.superposition = (
                timeline1.quantum_state.superposition or 
                timeline2.quantum_state.superposition
            )
            
            # Update other quantum properties as needed
            
        # Connect the merged timeline to both parent timelines
        self.multiverse.connect_timelines(new_timeline_name, timeline1_name)
        self.multiverse.connect_timelines(new_timeline_name, timeline2_name)
        
        # Also connect to any other timelines connected to both parents
        common_connections = set(timeline1.connected_timelines) & set(timeline2.connected_timelines)
        for connected_timeline in common_connections:
            if connected_timeline.name != merged_timeline.name:
                self.multiverse.connect_timelines(new_timeline_name, connected_timeline.name)
        
        return merged_timeline


def run_merge_demonstration(multiverse):
    """Run a demonstration of the timeline merging functionality"""
    print("=== Timeline Merging Demonstration ===")
    
    # Check if we have timelines to merge
    if len(multiverse.timelines) < 2:
        print("Need at least two timelines for merging. Creating sample timelines...")
        
        # Create some sample timelines if needed
        alpha = multiverse.create_timeline("Alpha Demo", 0.9)
        beta = multiverse.create_timeline("Beta Demo", 0.8)
        
        # Add events to Alpha
        alpha.add_event("Timeline origin point", 2000)
        alpha.add_event("Clean energy revolution begins", 2025)
        alpha.add_event("Global peace treaty signed", 2035)
        alpha.add_event("Mars colony established", 2042)
        alpha.add_event("Quantum computing breakthrough", 2050)
        
        # Add events to Beta (some conflicting, some complementary)
        beta.add_event("Timeline origin point", 2000)
        beta.add_event("Fusion power breakthrough", 2025)  # Different but not conflicting
        beta.add_event("Third World War begins", 2035)  # Conflicts with Alpha's peace treaty
        beta.add_event("Mars colony established", 2042)  # Same as Alpha
        beta.add_event("Quantum computing fails to materialize", 2050)  # Conflicts with Alpha
        
        # Connect the timelines
        multiverse.connect_timelines("Alpha Demo", "Beta Demo")
    
    # Get timeline names for demonstration
    timeline_names = list(multiverse.timelines.keys())
    
    # Let user select timelines or use defaults
    print(f"\nAvailable timelines: {', '.join(timeline_names)}")
    timeline1_name = input(f"Select first timeline [{timeline_names[0]}]: ") or timeline_names[0]
    
    other_timelines = [name for name in timeline_names if name != timeline1_name]
    default_timeline2 = other_timelines[0] if other_timelines else timeline_names[1] if len(timeline_names) > 1 else None
    
    if not default_timeline2:
        print("Need a second distinct timeline for merging.")
        return
        
    timeline2_name = input(f"Select second timeline [{default_timeline2}]: ") or default_timeline2
    
    # Create merger
    merger = TimelineMerger(multiverse)
    
    # Analyze compatibility
    print(f"\nAnalyzing merge compatibility between {timeline1_name} and {timeline2_name}...")
    analysis = merger.analyze_merge_compatibility(timeline1_name, timeline2_name)
    
    if not analysis["compatible"]:
        print(f"Cannot merge timelines: {analysis.get('reason', 'Unknown reason')}")
        return
        
    print(f"Merge compatibility score: {analysis['compatibility_score']:.2f}")
    print(f"Quantum compatibility: {analysis['quantum_compatibility']:.2f}")
    print(f"Identified {analysis['conflict_count']} conflicts")
    
    # Show conflicts
    if analysis["conflicts"]:
        print("\nConflicts identified:")
        for i, conflict in enumerate(analysis["conflicts"]):
            print(f"{i+1}. Year {conflict.year}:")
            print(f"   {conflict.timeline1}: {conflict.event1}")
            print(f"   {conflict.timeline2}: {conflict.event2}")
    
    # Choose resolution method
    print("\nHow would you like to resolve conflicts?")
    print("1. Automatically")
    print("2. Manually (one by one)")
    
    resolution_choice = input("Select option [1]: ") or "1"
    
    if resolution_choice == "1":
        print("\nResolving conflicts automatically...")
        resolved = merger.resolve_conflicts_automatically()
        
        print("Resolutions:")
        for i, conflict in enumerate(resolved):
            print(f"{i+1}. Year {conflict.year}: {conflict.resolution} (Method: {conflict.resolution_method})")
    else:
        print("\nManual conflict resolution:")
        for i, conflict in enumerate(analysis["conflicts"]):
            print(f"\nConflict {i+1}/{len(analysis['conflicts'])}")
            print(f"Year {conflict.year}:")
            print(f"   {conflict.timeline1}: {conflict.event1}")
            print(f"   {conflict.timeline2}: {conflict.event2}")
            
            print("\nResolution options:")
            print(f"1. Keep event from {conflict.timeline1}")
            print(f"2. Keep event from {conflict.timeline2}")
            print("3. Combine both events")
            print("4. Create custom resolution")
            
            choice = input("Select option [1]: ") or "1"
            
            if choice == "1":
                merger.resolve_conflict_manually(i, "first")
            elif choice == "2":
                merger.resolve_conflict_manually(i, "second")
            elif choice == "3":
                merger.resolve_conflict_manually(i, "combine")
            elif choice == "4":
                custom = input("Enter custom resolution: ")
                merger.resolve_conflict_manually(i, f"custom:{custom}")
            else:
                print("Invalid choice, using first event as default.")
                merger.resolve_conflict_manually(i, "first")
    
    # Create the merged timeline
    new_name = f"Merged-{timeline1_name[:3]}-{timeline2_name[:3]}"
    new_name_input = input(f"Name for merged timeline [{new_name}]: ") or new_name
    
    print(f"\nCreating merged timeline '{new_name_input}'...")
    merged_timeline = merger.merge_timelines(timeline1_name, timeline2_name, new_name_input)
    
    if merged_timeline:
        print(f"Successfully created merged timeline with stability: {merged_timeline.stability:.2f}")
        print("\nEvents in merged timeline:")
        
        for year, event in sorted(merged_timeline.events):
            print(f"{year}: {event}")
            
        print(f"\nThe merged timeline is connected to {len(merged_timeline.connected_timelines)} other timelines")
    else:
        print("Failed to create merged timeline.")
    
    return merged_timeline


if __name__ == "__main__":
    # For standalone testing
    from main import Multiverse
    multiverse = Multiverse()
    run_merge_demonstration(multiverse)
