
"""
Machine Learning Algorithms Demonstration
This module provides demonstrations of different machine learning and algorithmic techniques
implemented in the machine_learning_system.py module.
"""

import random
import numpy as np
import math
import time
from typing import List, Dict, Tuple, Any
from machine_learning_system import MachineLearningSystem
from algorithm_system import AlgorithmSystem
from main import Multiverse, Timeline

def run_ml_algorithms_demo():
    """Run a demonstration of the different machine learning algorithms"""
    print("=== Machine Learning Algorithms Demonstration ===")
    print("Initializing machine learning system...")
    
    # Initialize both algorithm systems
    alg_system = AlgorithmSystem()
    ml_system = MachineLearningSystem(alg_system)
    
    # Show available algorithms
    categories = ml_system.list_algorithms()
    print("\nAvailable Algorithm Categories:")
    for category, algorithms in categories.items():
        print(f"- {category} ({len(algorithms)} algorithms)")
    
    # Prepare mock data for demonstrations
    mock_data = create_mock_data()
    
    # Run selected algorithm demonstrations
    demo_classification_algorithms(ml_system, mock_data)
    demo_regression_algorithms(ml_system, mock_data)
    demo_clustering_algorithms(ml_system, mock_data)
    demo_ensemble_algorithms(ml_system, mock_data)
    demo_search_algorithms(ml_system, mock_data)
    demo_optimization_algorithms(ml_system, mock_data)
    
    print("\n=== Machine Learning Algorithms Demonstration Complete ===")

def create_mock_data() -> Dict[str, Any]:
    """Create mock data for algorithm demonstrations"""
    # Create a multiverse simulation with timelines
    multiverse = Multiverse()
    
    # Create 5 timelines with various properties
    for i in range(5):
        stability = 0.4 + random.random() * 0.5  # Random stability between 0.4 and 0.9
        timeline = Timeline(f"Timeline-{chr(65+i)}", stability)
        
        # Add some events
        for j in range(5):
            year = 2000 + j * 5 + random.randint(-2, 2)
            timeline.add_event(f"Event {j} in timeline {chr(65+i)}", year)
        
        # Add quantum field energy
        timeline.quantum_state.update_quantum_field(random.uniform(0.5, 2.5))
        
        # Add to multiverse
        multiverse.timelines[timeline.name] = timeline
    
    # Create classification data
    X_class = []
    y_class = []
    
    # Generate 100 data points with 5 features
    for i in range(100):
        # Generate features
        features = [random.uniform(0, 10) for _ in range(5)]
        X_class.append(features)
        
        # Generate class label (0, 1, or 2)
        if features[0] + features[1] > 12:
            label = 2
        elif features[2] - features[3] > 2:
            label = 1
        else:
            label = 0
        
        y_class.append(label)
    
    # Create regression data
    X_reg = X_class.copy()  # Use same features
    y_reg = []
    
    for features in X_reg:
        # Target is a nonlinear function of features
        target = 2 * features[0] + 0.5 * features[1]**2 - 3 * features[2] + 0.1 * features[3] * features[4] + random.uniform(-1, 1)
        y_reg.append(target)
    
    # Create clustering data
    X_cluster = []
    # Generate 3 clusters
    for _ in range(30):
        X_cluster.append([random.uniform(0, 3), random.uniform(0, 3)])
    for _ in range(30):
        X_cluster.append([random.uniform(7, 10), random.uniform(0, 3)])
    for _ in range(30):
        X_cluster.append([random.uniform(3, 7), random.uniform(7, 10)])
    
    # Create graph for search algorithms
    graph = {
        0: {1: 4, 2: 1, 3: 2},
        1: {0: 4, 4: 3},
        2: {0: 1, 3: 5, 5: 6},
        3: {0: 2, 2: 5, 4: 2, 6: 3},
        4: {1: 3, 3: 2, 6: 4},
        5: {2: 6, 6: 1},
        6: {3: 3, 4: 4, 5: 1}
    }
    
    # Gather it all together
    return {
        "multiverse": multiverse,
        "X_class": X_class,
        "y_class": y_class,
        "X_reg": X_reg,
        "y_reg": y_reg,
        "X_cluster": X_cluster,
        "graph": graph
    }

def demo_classification_algorithms(ml_system: MachineLearningSystem, mock_data: Dict[str, Any]):
    """Demonstrate classification algorithms"""
    print("\n=== Classification Algorithms ===")
    
    # Get data
    X = mock_data["X_class"]
    y = mock_data["y_class"]
    
    # Split into train and test
    split_idx = int(len(X) * 0.8)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    print(f"Training data: {len(X_train)} samples, Test data: {len(X_test)} samples")
    
    # Decision Tree
    print("\n1. Decision Tree Classifier")
    start_time = time.time()
    predictions = ml_system.get_algorithm("classification", "decision_tree")(
        X_train, y_train, X_test, max_depth=5
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, y_test) if pred == true) / len(y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # KNN
    print("\n2. K-Nearest Neighbors")
    start_time = time.time()
    predictions = ml_system.get_algorithm("classification", "knn")(
        X_train, y_train, X_test, k=3
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, y_test) if pred == true) / len(y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Convert to binary classification for SVM and Logistic Regression
    binary_y_train = [1 if y == 2 else 0 for y in y_train]
    binary_y_test = [1 if y == 2 else 0 for y in y_test]
    
    # SVM
    print("\n3. Support Vector Machine (Binary classification)")
    start_time = time.time()
    predictions = ml_system.get_algorithm("classification", "svm")(
        X_train, binary_y_train, X_test
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, binary_y_test) if pred == true) / len(binary_y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Logistic Regression
    print("\n4. Logistic Regression (Binary classification)")
    start_time = time.time()
    predictions = ml_system.get_algorithm("classification", "logistic_regression")(
        X_train, binary_y_train, X_test
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, binary_y_test) if pred == true) / len(binary_y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Naive Bayes
    print("\n5. Naive Bayes")
    start_time = time.time()
    predictions = ml_system.get_algorithm("classification", "naive_bayes")(
        X_train, y_train, X_test
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, y_test) if pred == true) / len(y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")

def demo_regression_algorithms(ml_system: MachineLearningSystem, mock_data: Dict[str, Any]):
    """Demonstrate regression algorithms"""
    print("\n=== Regression Algorithms ===")
    
    # Get data
    X = mock_data["X_reg"]
    y = mock_data["y_reg"]
    
    # Split into train and test
    split_idx = int(len(X) * 0.8)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    print(f"Training data: {len(X_train)} samples, Test data: {len(X_test)} samples")
    
    # Linear Regression
    print("\n1. Linear Regression")
    start_time = time.time()
    predictions = ml_system.get_algorithm("regression", "linear_regression")(
        X_train, y_train, X_test
    )
    elapsed = time.time() - start_time
    
    mse = sum((pred - true) ** 2 for pred, true in zip(predictions, y_test)) / len(y_test)
    print(f"  Mean Squared Error: {mse:.4f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Polynomial Regression
    print("\n2. Polynomial Regression")
    start_time = time.time()
    predictions = ml_system.get_algorithm("regression", "polynomial_regression")(
        X_train, y_train, X_test, degree=2
    )
    elapsed = time.time() - start_time
    
    mse = sum((pred - true) ** 2 for pred, true in zip(predictions, y_test)) / len(y_test)
    print(f"  Mean Squared Error: {mse:.4f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Ridge Regression
    print("\n3. Ridge Regression")
    start_time = time.time()
    predictions = ml_system.get_algorithm("regression", "ridge_regression")(
        X_train, y_train, X_test, alpha=1.0
    )
    elapsed = time.time() - start_time
    
    mse = sum((pred - true) ** 2 for pred, true in zip(predictions, y_test)) / len(y_test)
    print(f"  Mean Squared Error: {mse:.4f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Decision Tree Regressor
    print("\n4. Decision Tree Regressor")
    start_time = time.time()
    predictions = ml_system.get_algorithm("regression", "decision_tree_regressor")(
        X_train, y_train, X_test, max_depth=5
    )
    elapsed = time.time() - start_time
    
    mse = sum((pred - true) ** 2 for pred, true in zip(predictions, y_test)) / len(y_test)
    print(f"  Mean Squared Error: {mse:.4f}")
    print(f"  Time: {elapsed:.4f} seconds")

def demo_clustering_algorithms(ml_system: MachineLearningSystem, mock_data: Dict[str, Any]):
    """Demonstrate clustering algorithms"""
    print("\n=== Clustering Algorithms ===")
    
    # Get data
    X = mock_data["X_cluster"]
    
    print(f"Clustering data: {len(X)} samples")
    
    # K-means
    print("\n1. K-means Clustering")
    start_time = time.time()
    clusters = ml_system.get_algorithm("clustering", "k_means")(
        X, k=3
    )
    elapsed = time.time() - start_time
    
    cluster_counts = {}
    for cluster in clusters:
        if cluster not in cluster_counts:
            cluster_counts[cluster] = 0
        cluster_counts[cluster] += 1
    
    print(f"  Cluster distribution: {cluster_counts}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Hierarchical Clustering
    print("\n2. Hierarchical Clustering")
    start_time = time.time()
    clusters = ml_system.get_algorithm("clustering", "hierarchical_clustering")(
        X, k=3
    )
    elapsed = time.time() - start_time
    
    cluster_counts = {}
    for cluster in clusters:
        if cluster not in cluster_counts:
            cluster_counts[cluster] = 0
        cluster_counts[cluster] += 1
    
    print(f"  Cluster distribution: {cluster_counts}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # DBSCAN
    print("\n3. DBSCAN Clustering")
    start_time = time.time()
    clusters = ml_system.get_algorithm("clustering", "dbscan")(
        X, eps=3.0, min_samples=5
    )
    elapsed = time.time() - start_time
    
    cluster_counts = {}
    for cluster in clusters:
        if cluster not in cluster_counts:
            cluster_counts[cluster] = 0
        cluster_counts[cluster] += 1
    
    print(f"  Cluster distribution: {cluster_counts}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Gaussian Mixture Model
    print("\n4. Gaussian Mixture Model")
    start_time = time.time()
    clusters = ml_system.get_algorithm("clustering", "gaussian_mixture")(
        X, k=3
    )
    elapsed = time.time() - start_time
    
    cluster_counts = {}
    for cluster in clusters:
        if cluster not in cluster_counts:
            cluster_counts[cluster] = 0
        cluster_counts[cluster] += 1
    
    print(f"  Cluster distribution: {cluster_counts}")
    print(f"  Time: {elapsed:.4f} seconds")

def demo_ensemble_algorithms(ml_system: MachineLearningSystem, mock_data: Dict[str, Any]):
    """Demonstrate ensemble algorithms"""
    print("\n=== Ensemble Algorithms ===")
    
    # Get data
    X = mock_data["X_class"]
    y = mock_data["y_class"]
    
    # Convert to binary classification for simpler demonstration
    y = [1 if label == 2 else 0 for label in y]
    
    # Split into train and test
    split_idx = int(len(X) * 0.8)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    print(f"Training data: {len(X_train)} samples, Test data: {len(X_test)} samples")
    
    # Random Forest
    print("\n1. Random Forest Classifier")
    start_time = time.time()
    predictions = ml_system.get_algorithm("ensemble", "random_forest")(
        X_train, y_train, X_test, n_trees=10, max_depth=5
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, y_test) if pred == true) / len(y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # AdaBoost
    print("\n2. AdaBoost Classifier")
    start_time = time.time()
    predictions = ml_system.get_algorithm("ensemble", "adaboost")(
        X_train, y_train, X_test, n_estimators=10
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, y_test) if pred == true) / len(y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Bagging
    print("\n3. Bagging Classifier")
    start_time = time.time()
    predictions = ml_system.get_algorithm("ensemble", "bagging")(
        X_train, y_train, X_test, n_estimators=10, max_depth=5
    )
    elapsed = time.time() - start_time
    
    accuracy = sum(1 for pred, true in zip(predictions, y_test) if pred == true) / len(y_test)
    print(f"  Accuracy: {accuracy:.2f}")
    print(f"  Time: {elapsed:.4f} seconds")
    
    # Gradient Boosting (for regression)
    # Use regression data
    X_reg = mock_data["X_reg"]
    y_reg = mock_data["y_reg"]
    
    # Split into train and test
    split_idx = int(len(X_reg) * 0.8)
    X_train_reg, X_test_reg = X_reg[:split_idx], X_reg[split_idx:]
    y_train_reg, y_test_reg = y_reg[:split_idx], y_reg[split_idx:]
    
    print("\n4. Gradient Boosting Regressor")
    start_time = time.time()
    predictions = ml_system.get_algorithm("ensemble", "gradient_boosting")(
        X_train_reg, y_train_reg, X_test_reg, n_estimators=10, learning_rate=0.1
    )
    elapsed = time.time() - start_time
    
    mse = sum((pred - true) ** 2 for pred, true in zip(predictions, y_test_reg)) / len(y_test_reg)
    print(f"  Mean Squared Error: {mse:.4f}")
    print(f"  Time: {elapsed:.4f} seconds")

def demo_search_algorithms(ml_system: MachineLearningSystem, mock_data: Dict[str, Any]):
    """Demonstrate search algorithms"""
    print("\n=== Search Algorithms ===")
    
    # Get data
    graph = mock_data["graph"]
    
    # Binary Search
    print("\n1. Binary Search")
    sorted_array = list(range(0, 100, 2))  # Even numbers from 0 to 98
    target = 64
    
    start_time = time.time()
    index = ml_system.get_algorithm("search", "binary_search")(
        sorted_array, target
    )
    elapsed = time.time() - start_time
    
    print(f"  Searching for {target} in array with {len(sorted_array)} elements")
    print(f"  Result: {index}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Depth-First Search
    print("\n2. Depth-First Search")
    start, target = 0, 6
    
    start_time = time.time()
    path = ml_system.get_algorithm("search", "depth_first_search")(
        graph, start, target
    )
    elapsed = time.time() - start_time
    
    print(f"  Finding path from node {start} to node {target}")
    print(f"  Path: {path}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Breadth-First Search
    print("\n3. Breadth-First Search")
    
    start_time = time.time()
    path = ml_system.get_algorithm("search", "breadth_first_search")(
        graph, start, target
    )
    elapsed = time.time() - start_time
    
    print(f"  Finding shortest path from node {start} to node {target}")
    print(f"  Path: {path}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # A* Search
    print("\n4. A* Search")
    
    # Simple heuristic function (Manhattan distance assuming nodes are points in a 2D grid)
    node_positions = {
        0: (0, 0), 1: (4, 0), 2: (1, 2), 3: (3, 2),
        4: (6, 3), 5: (2, 5), 6: (5, 5)
    }
    
    def heuristic(node):
        return abs(node_positions[node][0] - node_positions[target][0]) + \
               abs(node_positions[node][1] - node_positions[target][1])
    
    start_time = time.time()
    path = ml_system.get_algorithm("search", "a_star_search")(
        graph, start, target, heuristic
    )
    elapsed = time.time() - start_time
    
    print(f"  Finding optimal path from node {start} to node {target}")
    print(f"  Path: {path}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Backtracking Search
    print("\n5. Backtracking Search")
    
    # N-Queens problem (4x4)
    def is_valid(state):
        """Check if queens can attack each other"""
        for i in range(len(state)):
            for j in range(i + 1, len(state)):
                # Same column
                if state[i] == state[j]:
                    return False
                # Same diagonal
                if abs(state[i] - state[j]) == abs(i - j):
                    return False
        return True
    
    def is_complete(state):
        """Check if all queens are placed"""
        return len(state) == 4
    
    start_time = time.time()
    solution = ml_system.get_algorithm("search", "backtracking")(
        [], [is_valid], is_complete
    )
    elapsed = time.time() - start_time
    
    print(f"  Solving 4-Queens problem using backtracking")
    print(f"  Solution: {solution}")
    print(f"  Time: {elapsed:.6f} seconds")

def demo_optimization_algorithms(ml_system: MachineLearningSystem, mock_data: Dict[str, Any]):
    """Demonstrate optimization algorithms"""
    print("\n=== Optimization Algorithms ===")
    
    # Dynamic Programming (Knapsack problem)
    print("\n1. Dynamic Programming (Knapsack)")
    weights = [3, 2, 1, 4, 5]
    values = [6, 4, 5, 7, 10]
    capacity = 8
    
    start_time = time.time()
    max_value = ml_system.get_algorithm("optimization", "dynamic_programming")(
        weights, values, capacity
    )
    elapsed = time.time() - start_time
    
    print(f"  Maximizing value within weight capacity {capacity}")
    print(f"  Max value: {max_value}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Greedy Optimization
    print("\n2. Greedy Optimization")
    items = [
        {"name": "Item 1", "value": 6, "weight": 3},
        {"name": "Item 2", "value": 4, "weight": 2},
        {"name": "Item 3", "value": 5, "weight": 1},
        {"name": "Item 4", "value": 7, "weight": 4},
        {"name": "Item 5", "value": 10, "weight": 5}
    ]
    
    start_time = time.time()
    selected = ml_system.get_algorithm("optimization", "greedy")(
        items, capacity
    )
    elapsed = time.time() - start_time
    
    total_value = sum(item["value"] for item in selected)
    total_weight = sum(item["weight"] for item in selected)
    
    print(f"  Selecting items within weight capacity {capacity}")
    print(f"  Selected items: {[item['name'] for item in selected]}")
    print(f"  Total value: {total_value}, Total weight: {total_weight}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Genetic Algorithm
    print("\n3. Genetic Algorithm")
    
    # Maximize function f(x) = sum(x_i) where x_i is in {0, 1}
    def fitness_function(individual):
        return sum(individual)
    
    gene_length = 10
    
    start_time = time.time()
    solution = ml_system.get_algorithm("optimization", "genetic_algorithm")(
        fitness_function, gene_length, population_size=50, generations=20
    )
    elapsed = time.time() - start_time
    
    print(f"  Maximizing sum of bits using genetic algorithm")
    print(f"  Solution: {solution}")
    print(f"  Fitness: {fitness_function(solution)}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Hill Climbing
    print("\n4. Hill Climbing")
    
    # Start with a random state
    initial_state = [random.randint(0, 1) for _ in range(gene_length)]
    
    start_time = time.time()
    solution = ml_system.get_algorithm("optimization", "hill_climbing")(
        fitness_function, initial_state, max_iterations=100
    )
    elapsed = time.time() - start_time
    
    print(f"  Maximizing sum of bits using hill climbing")
    print(f"  Initial state: {initial_state}")
    print(f"  Solution: {solution}")
    print(f"  Fitness: {fitness_function(solution)}")
    print(f"  Time: {elapsed:.6f} seconds")
    
    # Simulated Annealing
    print("\n5. Simulated Annealing")
    
    start_time = time.time()
    solution = ml_system.get_algorithm("optimization", "simulated_annealing")(
        fitness_function, initial_state, max_iterations=100
    )
    elapsed = time.time() - start_time
    
    print(f"  Maximizing sum of bits using simulated annealing")
    print(f"  Initial state: {initial_state}")
    print(f"  Solution: {solution}")
    print(f"  Fitness: {fitness_function(solution)}")
    print(f"  Time: {elapsed:.6f} seconds")

if __name__ == "__main__":
    run_ml_algorithms_demo()
