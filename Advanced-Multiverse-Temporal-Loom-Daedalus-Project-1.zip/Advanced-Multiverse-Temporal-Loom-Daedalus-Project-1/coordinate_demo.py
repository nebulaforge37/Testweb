
#!/usr/bin/env python3
"""
Time Travel Coordinates System Demo
This script demonstrates the space-time coordinate system for precise time travel targeting.
"""

import time
import random
from multiverse_coordinates import CoordinateEnhancedMultiverse
from temporal_coordinates import SpatialCoordinate, TemporalCoordinate, SpaceTimeCoordinate

def run_coordinate_demo():
    """Run a demonstration of the coordinate system functionality."""
    print("=== Time Travel Coordinates System Demo ===")
    print("Initializing enhanced multiverse...")
    
    # Create a coordinate-enhanced multiverse
    multiverse = CoordinateEnhancedMultiverse(use_database=False)
    
    # Create several timelines
    print("\nCreating timelines...")
    alpha = multiverse.create_timeline("Alpha Prime", 0.9)
    beta = multiverse.create_timeline("Beta Variant", 0.75)
    gamma = multiverse.create_timeline("Gamma Nexus", 0.6)
    delta = multiverse.create_timeline("Delta Flux", 0.5)
    omega = multiverse.create_timeline("Omega Point", 0.85)
    
    # Add events with coordinates
    print("\nAdding historical events with coordinates...")
    alpha.add_event("Timeline origin point", 2000)
    alpha.add_landmark("Alpha Origin", 2000, 0, 0, 0, "The point where Alpha timeline began")
    alpha.add_landmark("Quantum Lab", 2025, 4000, 2000, 0, "Location of quantum computing breakthrough")
    alpha.add_landmark("First Contact Site", 2042, -3000, 5000, 1000, "First contact with extradimensional beings")

    beta.add_event("Timeline diverged from Alpha Prime", 2010)
    beta.add_landmark("Beta Divergence", 2010, 0, 0, 0, "Point where Beta diverged from Alpha")
    beta.add_landmark("Climate Disaster Ground Zero", 2028, 2000, 3000, 0, "Epicenter of climate catastrophe")
    
    gamma.add_event("Timeline artificially created", 1980)
    gamma.add_landmark("Creation Point", 1980, 0, 0, 0, "Artificial creation point of Gamma timeline")
    gamma.add_landmark("Robot Revolution HQ", 2015, -1000, -2000, 0, "Headquarters of the robotic revolution")
    
    # Create fixed points (events that exist across timelines)
    print("\nCreating fixed points in spacetime...")
    multiverse.create_fixed_point("Alpha Prime", "Moon Landing", 1969, 3474/2, 0, 0, "The first human landing on Earth's Moon")
    multiverse.create_fixed_point("Alpha Prime", "Quantum Singularity", 2075, 0, 0, 0, "A quantum singularity that exists in all timelines")
    
    # Create divergence points
    print("\nEstablishing timeline divergence points...")
    multiverse.add_divergence_point("Alpha Prime", "Beta Variant", 2010, "Climate policy disagreement")
    multiverse.add_divergence_point("Alpha Prime", "Gamma Nexus", 1980, "AI experiment creates new timeline")
    multiverse.add_divergence_point("Beta Variant", "Delta Flux", 2030, "Quantum experiment gone wrong")
    
    # Define some specific coordinates for travel
    print("\nDefining specific space-time coordinates...")
    
    # Apollo 11 moon landing
    moon_landing = SpaceTimeCoordinate(
        SpatialCoordinate(3474/2, 0, 0, 0.01, "Moon-Centered"), 
        TemporalCoordinate(1969, 7, 20, 20, 17, 0, 0),
        "Alpha Prime"
    )
    multiverse.coordinate_registry.add_historical_event("Apollo 11 Landing", moon_landing)
    
    # Ancient Rome
    ancient_rome = SpaceTimeCoordinate(
        SpatialCoordinate(1500, 1200, 0, 0.2, "Earth-Centered"),
        TemporalCoordinate(44, 3, 15, 12, 0, 0, 0, "Julian"),
        "Alpha Prime"
    )
    multiverse.coordinate_registry.add_historical_event("Caesar Assassination", ancient_rome)
    
    # Future Mars colony
    mars_colony = SpaceTimeCoordinate(
        SpatialCoordinate(0, 0, 0, 0.05, "Mars-Centered"),
        TemporalCoordinate(2050, 5, 15),
        "Beta Variant"
    )
    multiverse.coordinate_registry.add_historical_event("Mars Colony Founding", mars_colony)
    
    # Print out the coordinate information
    print("\n=== Coordinate System Information ===")
    print("\nFixed Points (stable across timelines):")
    fixed_points = [coord for name, coord in multiverse.coordinate_registry.historical_events.items() 
                   if name.startswith("FixedPoint:")]
    for i, coord in enumerate(fixed_points):
        print(f"{i+1}. Timeline: {coord.timeline_name}, "
              f"Time: {coord.temporal.year}, "
              f"Location: ({coord.spatial.x:.1f}, {coord.spatial.y:.1f}, {coord.spatial.z:.1f})")
    
    print("\nHistorical Events with Coordinates:")
    historical = [item for item in multiverse.coordinate_registry.historical_events.items() 
                 if not item[0].startswith("FixedPoint:") and not item[0].startswith("Divergence:")]
    for name, coord in historical:
        print(f"- {name}: {coord.temporal.year} in {coord.timeline_name}")
    
    # Simulate some time travel with coordinates
    print("\n=== Simulating Time Travel with Precise Coordinates ===")
    
    travelers = ["Dr. Elena Silva", "Quantum Explorer Jackson", "Professor Paradox"]
    
    # First trip: Modern day to Moon Landing
    print("\nTravel 1: Modern day to witness the Moon Landing")
    origin = SpaceTimeCoordinate(
        SpatialCoordinate(0, 0, 0, 0.1, "Earth-Centered"),
        TemporalCoordinate(2023, 5, 15),
        "Alpha Prime"
    )
    success, message = multiverse.time_travel_with_coordinates(
        origin, moon_landing, travelers[0]
    )
    print(message)
    
    # Second trip: Moon Landing to Ancient Rome (high risk!)
    print("\nTravel 2: Moon Landing to Ancient Rome (high risk!)")
    success, message = multiverse.time_travel_with_coordinates(
        moon_landing, ancient_rome, travelers[1]
    )
    print(message)
    
    # Third trip: Modern day to Mars Colony in alternate timeline
    print("\nTravel 3: Cross-timeline travel to Mars Colony")
    origin = SpaceTimeCoordinate(
        SpatialCoordinate(0, 0, 0, 0.1, "Earth-Centered"),
        TemporalCoordinate(2023, 5, 15),
        "Alpha Prime"
    )
    success, message = multiverse.time_travel_with_coordinates(
        origin, mars_colony, travelers[2]
    )
    print(message)
    
    # Find stable routes
    print("\n=== Finding Stable Travel Routes ===")
    print("\nLooking for stable route from 2023 Alpha Prime to 44 BCE Rome...")
    
    routes = multiverse.find_stable_route("Alpha Prime", "Alpha Prime", 2023, 44)
    
    if routes:
        print(f"Found {len(routes)} potential routes:")
        for i, route in enumerate(routes):
            print(f"\nRoute {i+1}:")
            for j, (name, coord) in enumerate(route):
                print(f"  Jump {j+1}: {name} - {coord.timeline_name} year {coord.temporal.year}")
    else:
        print("No stable routes found.")
    
    print("\nCoordinate system demo completed!")

if __name__ == "__main__":
    run_coordinate_demo()
