
"""
Algorithm System Demonstration
This module provides demonstrations of the different algorithm types
implemented in the algorithm_system.py module.
"""

import random
import math
import time
from typing import List, Dict, Tuple, Any
from algorithm_system import AlgorithmSystem
from main import Multiverse, Timeline

def run_algorithm_demo():
    """Run a demonstration of the different algorithm types"""
    print("=== Algorithm System Demonstration ===")
    print("Initializing algorithm system...")
    
    alg_system = AlgorithmSystem()
    
    # Show available algorithms
    categories = alg_system.list_algorithms()
    print("\nAvailable Algorithm Categories:")
    for category, algorithms in categories.items():
        print(f"- {category} ({len(algorithms)} algorithms)")
    
    # Prepare mock data for demonstrations
    mock_multiverse = create_mock_multiverse()
    
    # Run selected algorithm demonstrations
    demo_dynamic_programming(alg_system, mock_multiverse)
    demo_greedy_algorithms(alg_system, mock_multiverse)
    demo_searching(alg_system, mock_multiverse)
    demo_backtracking(alg_system, mock_multiverse)
    demo_binary_search(alg_system, mock_multiverse)
    demo_machine_learning(alg_system, mock_multiverse)
    demo_logistic_regression(alg_system, mock_multiverse)
    
    print("\n=== Algorithm Demonstration Complete ===")

def create_mock_multiverse() -> Dict[str, Any]:
    """Create mock data for algorithm demonstrations"""
    # Create timelines with various properties
    timelines = []
    for i in range(5):
        stability = random.uniform(0.3, 0.9)
        timeline = Timeline(f"Timeline-{chr(65+i)}", stability)
        
        # Add some events
        for j in range(5):
            year = 2000 + j * 5 + random.randint(-2, 2)
            timeline.add_event(f"Event {j} in timeline {chr(65+i)}", year)
        
        # Add quantum field energy
        timeline.quantum_state.update_quantum_field(random.uniform(0.5, 2.5))
        
        # Add to list
        timelines.append(timeline)
    
    # Create connections between timelines
    for i in range(len(timelines)):
        for j in range(i+1, len(timelines)):
            if random.random() < 0.6:  # 60% chance of connection
                if timelines[j] not in timelines[i].connected_timelines:
                    timelines[i].connected_timelines.append(timelines[j])
                if timelines[i] not in timelines[j].connected_timelines:
                    timelines[j].connected_timelines.append(timelines[i])
    
    # Create events with various properties
    events = []
    for i in range(10):
        event = {
            "id": i,
            "year": 2030 + random.randint(-10, 10),
            "description": f"Test Event {i}",
            "impact": random.uniform(0.2, 0.9),
            "stability_gain": random.uniform(-0.2, 0.3),
            "cost": random.uniform(0.1, 0.5),
            "involves_time_travel": random.random() < 0.3,
            "causality_effect": random.uniform(0, 0.8)
        }
        events.append(event)
    
    # Create paradoxes
    paradoxes = []
    for i in range(3):
        paradox_types = ["bootstrap", "grandfather", "consistency", "predestination"]
        paradox = {
            "id": i,
            "type": random.choice(paradox_types),
            "severity": random.uniform(0.4, 0.9),
            "year": 2040 + random.randint(-5, 5),
            "description": f"Paradox {i}"
        }
        paradoxes.append(paradox)
    
    # Create quantum data for pattern recognition
    quantum_data = []
    for i in range(20):
        # Generate 4-dimensional quantum field measurements
        data_point = [random.uniform(0, 5) for _ in range(4)]
        quantum_data.append(data_point)
    
    return {
        "timelines": timelines,
        "events": events,
        "paradoxes": paradoxes,
        "quantum_data": quantum_data
    }

def demo_dynamic_programming(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate dynamic programming algorithms"""
    print("\n=== Dynamic Programming Algorithms ===")
    
    # Demonstrate optimal path finding
    timelines = mock_data["timelines"]
    print("\n1. Finding optimal path between timelines...")
    
    # Cost function based on stability
    def cost_fn(t1, t2):
        # Higher cost for less stable timelines
        if t2 in t1.connected_timelines:
            return 1.0 - t2.stability
        else:
            return float('inf')  # Not directly connected
    
    # Find path from first to last timeline
    optimal_path = alg_system.get_algorithm("dynamic_programming", "optimal_path")(
        timelines, 0, len(timelines) - 1, cost_fn
    )
    
    if optimal_path:
        print(f"Optimal path found with {len(optimal_path)} steps:")
        for i, idx in enumerate(optimal_path):
            print(f"  Step {i+1}: {timelines[idx].name} (stability: {timelines[idx].stability:.2f})")
    else:
        print("No path found between timelines.")
    
    # Demonstrate paradox resolution
    print("\n2. Resolving multiple paradoxes optimally...")
    paradoxes = mock_data["paradoxes"]
    timeline = timelines[0]
    
    resolution_steps = alg_system.get_algorithm("dynamic_programming", "paradox_resolution")(
        timeline, paradoxes
    )
    
    print(f"Optimal resolution plan for {len(paradoxes)} paradoxes:")
    for step in resolution_steps:
        paradox_id = step["paradox_id"]
        print(f"  - Resolve paradox {paradoxes[paradox_id]['type']} using {step['action']}")
        print(f"    Cost: {step['cost']:.2f}")

def demo_greedy_algorithms(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate greedy algorithms"""
    print("\n=== Greedy Algorithms ===")
    
    # Demonstrate timeline stabilization
    events = mock_data["events"]
    timeline = mock_data["timelines"][0]
    print("\n1. Stabilizing timeline using greedy approach...")
    
    selected_events = alg_system.get_algorithm("greedy", "timeline_stabilization")(
        timeline, events, 1.0  # Budget of 1.0
    )
    
    print(f"Selected {len(selected_events)} events for modification:")
    for event in selected_events:
        print(f"  - Event {event['id']}: stability gain = {event['stability_gain']:.2f}, cost = {event['cost']:.2f}")
    
    # Demonstrate resource allocation
    print("\n2. Allocating resources to timelines...")
    timelines = mock_data["timelines"]
    
    allocations = alg_system.get_algorithm("greedy", "resource_allocation")(
        timelines, 100.0  # 100 units of resources
    )
    
    print("Resource allocation:")
    for timeline_name, amount in allocations.items():
        print(f"  - {timeline_name}: {amount:.2f} units")
    
    # Demonstrate wormhole routing
    print("\n3. Planning optimal wormhole routes...")
    origin = timelines[0]
    
    wormholes = alg_system.get_algorithm("greedy", "wormhole_routing")(
        origin, timelines, 3  # Max 3 wormholes
    )
    
    print(f"Planned {len(wormholes)} wormholes from {origin.name}:")
    for wh in wormholes:
        print(f"  - To: {wh['destination']}, Year shift: {wh['year_shift']}, Stability: {wh['stability']:.2f}")

def demo_searching(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate searching algorithms"""
    print("\n=== Searching Algorithms ===")
    
    # Demonstrate depth-first search
    timelines = mock_data["timelines"]
    print("\n1. Timeline traversal using DFS...")
    
    # Define a visitor function that looks for a specific stability
    target_stability = 0.7
    def find_stable_timeline(timeline):
        found = abs(timeline.stability - target_stability) < 0.1
        if found:
            print(f"  Found timeline with stability ~{target_stability}: {timeline.name}")
        return found
    
    visited = alg_system.get_algorithm("searching", "timeline_traversal_dfs")(
        timelines[0], find_stable_timeline
    )
    
    print(f"Visited {len(visited)} timelines in DFS traversal")
    print("  Path: " + " -> ".join(t.name for t in visited))
    
    # Demonstrate breadth-first search
    print("\n2. Timeline traversal using BFS...")
    visited = alg_system.get_algorithm("searching", "timeline_traversal_bfs")(
        timelines[0], find_stable_timeline
    )
    
    print(f"Visited {len(visited)} timelines in BFS traversal")
    print("  Path: " + " -> ".join(t.name for t in visited))
    
    # Demonstrate A* search for stable path
    print("\n3. Finding stable path between timelines...")
    if len(timelines) >= 2:
        start = timelines[0]
        end = timelines[-1]
        
        path = alg_system.get_algorithm("searching", "find_stable_path")(start, end)
        
        if path:
            print(f"Found path with {len(path)} steps from {start.name} to {end.name}:")
            for i, timeline in enumerate(path):
                print(f"  Step {i+1}: {timeline.name} (stability: {timeline.stability:.2f})")
        else:
            print(f"No path found from {start.name} to {end.name}")

def demo_backtracking(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate backtracking algorithms"""
    print("\n=== Backtracking Algorithms ===")
    
    # Demonstrate paradox resolution with backtracking
    print("\n1. Resolving paradox with backtracking...")
    timeline = mock_data["timelines"][0]
    paradox = mock_data["paradoxes"][0]
    
    # Create resolution options
    options = [
        {"name": "Temporal reinforcement", "stability_impact": -0.05},
        {"name": "Causal loop isolation", "stability_impact": -0.1},
        {"name": "Quantum state adjustment", "stability_impact": -0.15},
        {"name": "Reality anchoring", "stability_impact": -0.08},
        {"name": "Timeline bifurcation", "stability_impact": -0.2}
    ]
    
    steps = alg_system.get_algorithm("backtracking", "paradox_resolution")(
        timeline, paradox, options
    )
    
    if steps:
        print(f"Found solution with {len(steps)} steps:")
        for i, step in enumerate(steps):
            print(f"  Step {i+1}: {step['name']} (impact: {step['stability_impact']:.2f})")
    else:
        print("No viable resolution found that maintains timeline stability")
    
    # Demonstrate timeline reconstruction
    print("\n2. Reconstructing damaged timeline...")
    
    # Evidence fragments
    evidence = [
        {"year": 2030, "description": "Quantum breakthrough", "confidence": 0.8},
        {"year": 2025, "description": "First contact event", "confidence": 0.7},
        {"year": 2035, "description": "Timeline bifurcation", "confidence": 0.6},
        {"year": 2028, "description": "Paradox event", "confidence": 0.5},
        {"year": 2032, "description": "Stability crisis", "confidence": 0.9}
    ]
    
    # Constraints for valid reconstruction
    def temporal_order_valid(events):
        # Events should generally be in ascending year order
        years = [e["year"] for e in events]
        return all(years[i] <= years[i+1] for i in range(len(years)-1))
    
    def causality_valid(events):
        # "Paradox event" must occur before "Stability crisis"
        paradox_idx = next((i for i, e in enumerate(events) 
                          if "paradox" in e["description"].lower()), -1)
        crisis_idx = next((i for i, e in enumerate(events) 
                         if "crisis" in e["description"].lower()), -1)
        
        if paradox_idx >= 0 and crisis_idx >= 0:
            return paradox_idx < crisis_idx
        return True
    
    reconstruction = alg_system.get_algorithm("backtracking", "timeline_reconstruction")(
        evidence, [temporal_order_valid, causality_valid]
    )
    
    if reconstruction:
        print("Successfully reconstructed timeline:")
        for event in reconstruction:
            print(f"  {event['year']}: {event['description']} (confidence: {event['confidence']:.2f})")
    else:
        print("Failed to reconstruct timeline with given constraints")

def demo_binary_search(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate binary search algorithms"""
    print("\n=== Binary Search Algorithms ===")
    
    # Demonstrate timeline event search
    print("\n1. Searching for events by year...")
    timeline = mock_data["timelines"][0]
    
    target_year = 2010
    event = alg_system.get_algorithm("binary_search", "timeline_event_search")(
        timeline, target_year
    )
    
    if event:
        print(f"Found event closest to year {target_year}:")
        print(f"  {event['year']}: {event['description']}")
    else:
        print(f"No events found in timeline")
    
    # Demonstrate stability threshold search
    print("\n2. Finding stability threshold...")
    
    # Function that tests if a given stability is sufficient
    def test_stability(stability):
        # Simulate 10 runs with this stability
        successes = 0
        for _ in range(10):
            # More stable timelines have higher success rates
            if random.random() < stability * 1.2:
                successes += 1
        # Need at least 7 successes to be considered "sufficient"
        return successes >= 7
    
    threshold = alg_system.get_algorithm("binary_search", "stability_threshold_search")(
        test_stability, 0.0, 1.0, 0.01
    )
    
    print(f"Minimum stability threshold for success: {threshold:.2f}")
    
    # Demonstrate paradox probability search
    print("\n3. Calculating paradox probability...")
    timeline = mock_data["timelines"][0]
    event = mock_data["events"][0]
    
    probability = alg_system.get_algorithm("binary_search", "paradox_probability_search")(
        timeline, event
    )
    
    print(f"Paradox probability for event '{event['description']}': {probability:.2f}")
    if probability > 0.7:
        print("  HIGH RISK - Consider canceling this event")
    elif probability > 0.4:
        print("  MEDIUM RISK - Monitor carefully")
    else:
        print("  LOW RISK - Proceed normally")

def demo_machine_learning(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate machine learning algorithms"""
    print("\n=== Machine Learning Algorithms ===")
    
    # Demonstrate timeline stability prediction
    print("\n1. Predicting timeline stability...")
    timelines = mock_data["timelines"]
    
    # Create a new timeline to predict
    new_timeline = timelines[0].__class__(f"New-Timeline", 0.5)
    new_timeline.quantum_state.update_quantum_field(1.8)
    new_timeline.quantum_state.entanglement_level = 0.4
    
    # Use existing timelines to predict stability
    predicted_stability = alg_system.get_algorithm("machine_learning", "timeline_stability_prediction")(
        timelines[:-1], ["stability", "quantum_field_energy", "entanglement_level"], new_timeline
    )
    
    print(f"Predicted stability for new timeline: {predicted_stability:.2f}")
    print("  Timeline features:")
    print(f"  - Quantum field energy: {new_timeline.quantum_state.quantum_field_energy:.2f}")
    print(f"  - Entanglement level: {new_timeline.quantum_state.entanglement_level:.2f}")
    
    # Demonstrate paradox risk classification
    print("\n2. Classifying events by paradox risk...")
    events = mock_data["events"]
    
    # Add specific features for classification demo
    for event in events:
        event["causality_violation"] = random.uniform(0, 1)
        event["timeline_impact"] = random.uniform(0, 1)
        event["quantum_disruption"] = random.uniform(0, 1)
        event["stability_effect"] = random.uniform(-1, 0.5)
        event["scale"] = random.uniform(0, 1)
    
    risk_categories = alg_system.get_algorithm("machine_learning", "paradox_risk_classification")(
        events[:5], ["causality_violation", "timeline_impact", "quantum_disruption", 
                    "stability_effect", "involves_time_travel", "scale"]
    )
    
    print("Paradox risk classification:")
    for i, risk in enumerate(risk_categories):
        print(f"  Event {events[i]['id']}: {risk.upper()} RISK")
        if risk == "high":
            print(f"    WARNING: High-risk event detected!")
    
    # Demonstrate quantum pattern recognition
    print("\n3. Recognizing quantum field patterns...")
    quantum_data = mock_data["quantum_data"]
    
    clusters = alg_system.get_algorithm("machine_learning", "quantum_pattern_recognition")(
        quantum_data, 3  # 3 clusters
    )
    
    # Count the number of points in each cluster
    cluster_counts = [0, 0, 0]
    for cluster in clusters:
        cluster_counts[cluster] += 1
    
    print("Quantum field pattern analysis:")
    print(f"  Found {len(set(clusters))} distinct patterns in the data")
    for i, count in enumerate(cluster_counts):
        print(f"  Pattern {i+1}: {count} data points")
    
    if max(cluster_counts) > len(quantum_data) * 0.6:
        print("  Dominant pattern detected - possible timeline convergence")

def demo_logistic_regression(alg_system: AlgorithmSystem, mock_data: Dict[str, Any]):
    """Demonstrate logistic regression algorithms"""
    print("\n=== Logistic Regression Algorithms ===")
    
    # Demonstrate timeline stability probability
    print("\n1. Estimating timeline stability probability...")
    timeline = mock_data["timelines"][0]
    
    features = {
        "paradox_count": random.randint(0, 3),
        "age": random.uniform(0.2, 0.8)
    }
    
    probability = alg_system.get_algorithm("logistic_regression", "timeline_stability_probability")(
        timeline, features
    )
    
    print(f"Probability of {timeline.name} remaining stable: {probability:.2f}")
    print(f"  Features: {features}")
    
    # Demonstrate wormhole success probability
    print("\n2. Estimating wormhole travel success probability...")
    
    # Create mock wormhole
    wormhole = type('Wormhole', (), {
        "stability": 0.75,
        "activation_count": 3,
        "year_shift": 20,
        "origin": mock_data["timelines"][0],
        "destination": mock_data["timelines"][1]
    })()
    
    success_prob = alg_system.get_algorithm("logistic_regression", "wormhole_success_probability")(
        wormhole, {"experience": 0.8}
    )
    
    print(f"Wormhole travel success probability: {success_prob:.2f}")
    if success_prob > 0.8:
        print("  SAFE - Travel recommended")
    elif success_prob > 0.5:
        print("  CAUTION - Travel acceptable with precautions")
    else:
        print("  DANGER - Travel not recommended")
    
    # Demonstrate paradox occurrence probability
    print("\n3. Estimating paradox occurrence probability...")
    timeline = mock_data["timelines"][0]
    event = mock_data["events"][0]
    
    paradox_prob = alg_system.get_algorithm("logistic_regression", "paradox_occurrence_probability")(
        timeline, event
    )
    
    print(f"Probability of paradox from event '{event['description']}': {paradox_prob:.2f}")
    
    # Demonstrate quantum wavefunction collapse
    print("\n4. Estimating quantum wavefunction collapse probability...")
    quantum_state = timeline.quantum_state
    
    collapse_prob = alg_system.get_algorithm("logistic_regression", "quantum_wavefunction_collapse")(
        quantum_state, {"technology_level": 0.7, "timeline_stability": timeline.stability}
    )
    
    print(f"Probability of wavefunction collapse upon observation: {collapse_prob:.2f}")

if __name__ == "__main__":
    run_algorithm_demo()
