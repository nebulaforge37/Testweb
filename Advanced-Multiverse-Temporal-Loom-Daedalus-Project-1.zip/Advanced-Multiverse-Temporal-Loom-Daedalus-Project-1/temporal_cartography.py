
"""
Temporal Cartography System
This module provides tools for mapping and visualizing the multiverse structure.
"""

import random
import math
import time
from typing import Dict, List, Tuple, Any, Optional
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

class TemporalCartographer:
    """
    The Temporal Cartographer creates navigable maps of the multiverse structure,
    showing relationships between timelines, dimensions, and navigation routes.
    """
    
    def __init__(self, multiverse=None):
        """Initialize the Temporal Cartographer"""
        self.multiverse = multiverse
        self.map_resolution = 100
        self.stability_threshold = 0.4
        self.last_update = time.time()
        self.coordinate_cache = {}
        self.route_cache = {}
        self.timeline_coordinates = {}
        self.dimension_boundaries = {}
        self.stability_zones = []
        self.navigation_routes = []
        
    def generate_multiverse_map(self, dimensions: int = 3) -> Dict[str, Any]:
        """
        Generate a map of the current multiverse structure.
        
        Args:
            dimensions: Number of dimensions to map (2 or 3)
            
        Returns:
            Dictionary containing map data
        """
        if not self.multiverse:
            print("No multiverse data available. Creating simulated map...")
            return self._generate_simulated_map(dimensions)
            
        print(f"Generating {dimensions}D multiverse map...")
        
        # Reset mapping data
        self.timeline_coordinates = {}
        self.dimension_boundaries = {}
        self.stability_zones = []
        self.navigation_routes = []
        
        # Calculate coordinates for each timeline
        for name, timeline in self.multiverse.timelines.items():
            # Calculate a position based on timeline properties
            # More stable timelines are placed toward the center
            if dimensions == 2:
                coordinates = self._calculate_timeline_coordinates_2d(timeline)
            else:
                coordinates = self._calculate_timeline_coordinates_3d(timeline)
                
            self.timeline_coordinates[name] = coordinates
            
            # Calculate timeline stability zone
            stability = getattr(timeline, 'stability', 0.5)
            zone_radius = max(0.1, stability) * 0.5
            
            self.stability_zones.append({
                'center': coordinates,
                'radius': zone_radius,
                'stability': stability,
                'timeline': name
            })
        
        # Calculate navigation routes between connected timelines
        for name, timeline in self.multiverse.timelines.items():
            connected_timelines = getattr(timeline, 'connected_timelines', [])
            
            for connected in connected_timelines:
                connected_name = getattr(connected, 'name', str(connected))
                
                if connected_name in self.timeline_coordinates:
                    start = self.timeline_coordinates[name]
                    end = self.timeline_coordinates[connected_name]
                    
                    # Determine if quantum entangled
                    entangled = False
                    if hasattr(timeline, 'quantum_state') and hasattr(connected, 'quantum_state'):
                        entanglement1 = getattr(timeline.quantum_state, 'entanglement_level', 0)
                        entanglement2 = getattr(connected.quantum_state, 'entanglement_level', 0)
                        entangled = entanglement1 > 0.6 and entanglement2 > 0.6
                    
                    self.navigation_routes.append({
                        'start': start,
                        'end': end,
                        'start_timeline': name,
                        'end_timeline': connected_name,
                        'quantum_entangled': entangled
                    })
        
        # Add quantum wormholes if available
        if hasattr(self.multiverse, 'wormholes'):
            for i, wormhole in enumerate(self.multiverse.wormholes):
                origin_name = getattr(wormhole.origin, 'name', f"Origin-{i}")
                target_name = getattr(wormhole.target, 'name', f"Target-{i}")
                
                if origin_name in self.timeline_coordinates and target_name in self.timeline_coordinates:
                    start = self.timeline_coordinates[origin_name]
                    end = self.timeline_coordinates[target_name]
                    
                    self.navigation_routes.append({
                        'start': start,
                        'end': end,
                        'start_timeline': origin_name,
                        'end_timeline': target_name,
                        'is_wormhole': True,
                        'wormhole_stability': getattr(wormhole, 'stability', 0.7)
                    })
        
        # Calculate dimension boundaries
        self._calculate_dimension_boundaries(dimensions)
        
        return {
            'dimensions': dimensions,
            'timelines': self.timeline_coordinates,
            'stability_zones': self.stability_zones,
            'routes': self.navigation_routes,
            'dimension_boundaries': self.dimension_boundaries
        }
    
    def _calculate_timeline_coordinates_2d(self, timeline) -> Tuple[float, float]:
        """Calculate 2D coordinates for a timeline based on its properties"""
        # Get timeline properties with defaults
        stability = getattr(timeline, 'stability', 0.5)
        temporal_position = getattr(timeline, 'temporal_position', random.random())
        
        # Additional properties if available
        entropy = getattr(timeline, 'entropy', random.random())
        quantum_state = getattr(timeline, 'quantum_state', None)
        
        # Calculate angle based on temporal position (0 to 2π)
        angle = temporal_position * 2 * math.pi
        
        # Calculate distance from center based on stability (more stable = closer to center)
        # More stable timelines are closer to the center
        distance = 1.0 - stability
        
        # Apply quantum effects if available
        if quantum_state:
            entanglement = getattr(quantum_state, 'entanglement_level', 0)
            superposition = getattr(quantum_state, 'superposition', False)
            
            # Entangled timelines get pulled toward the center
            distance *= max(0.5, 1.0 - entanglement)
            
            # Superposition causes position uncertainty
            if superposition:
                angle += random.uniform(-0.2, 0.2)
                distance += random.uniform(-0.1, 0.1)
        
        # Calculate position
        x = distance * math.cos(angle)
        y = distance * math.sin(angle)
        
        return (x, y)
    
    def _calculate_timeline_coordinates_3d(self, timeline) -> Tuple[float, float, float]:
        """Calculate 3D coordinates for a timeline based on its properties"""
        # Get timeline properties with defaults
        stability = getattr(timeline, 'stability', 0.5)
        temporal_position = getattr(timeline, 'temporal_position', random.random())
        
        # Additional properties if available
        entropy = getattr(timeline, 'entropy', random.random())
        quantum_state = getattr(timeline, 'quantum_state', None)
        
        # Calculate spherical coordinates
        # Phi: azimuthal angle in x-y plane (0 to 2π)
        phi = temporal_position * 2 * math.pi
        
        # Theta: polar angle from z-axis (0 to π)
        theta = entropy * math.pi
        
        # Calculate distance from center based on stability
        # More stable timelines are closer to the center
        distance = 1.0 - stability
        
        # Apply quantum effects if available
        if quantum_state:
            entanglement = getattr(quantum_state, 'entanglement_level', 0)
            superposition = getattr(quantum_state, 'superposition', False)
            
            # Entangled timelines get pulled toward the center
            distance *= max(0.5, 1.0 - entanglement)
            
            # Superposition causes position uncertainty
            if superposition:
                phi += random.uniform(-0.2, 0.2)
                theta += random.uniform(-0.2, 0.2)
                distance += random.uniform(-0.1, 0.1)
        
        # Convert spherical to Cartesian coordinates
        x = distance * math.sin(theta) * math.cos(phi)
        y = distance * math.sin(theta) * math.sin(phi)
        z = distance * math.cos(theta)
        
        return (x, y, z)
    
    def _calculate_dimension_boundaries(self, dimensions: int):
        """Calculate boundaries between quantum dimensions"""
        # For now, use a simple approach to create dimension regions
        # In a real implementation, this would use more advanced dimensional analysis
        
        # Group timelines by quantum dimension properties
        dimension_groups = {}
        
        for name, coords in self.timeline_coordinates.items():
            # In a full implementation, we would extract actual dimension data
            # For now, simulate dimensions based on timeline name prefixes
            if name.startswith("Alpha"):
                dim_id = "Alpha Dimension"
            elif name.startswith("Beta"):
                dim_id = "Beta Dimension"
            elif name.startswith("Gamma"):
                dim_id = "Gamma Dimension"
            elif name.startswith("Delta"):
                dim_id = "Delta Dimension"
            elif name.startswith("Omega"):
                dim_id = "Omega Dimension"
            else:
                dim_id = "Primary Dimension"
            
            if dim_id not in dimension_groups:
                dimension_groups[dim_id] = []
                
            dimension_groups[dim_id].append(coords)
        
        # Create boundary definitions for each dimension
        for dim_id, coord_list in dimension_groups.items():
            if not coord_list:
                continue
                
            # Convert to numpy for easier calculations
            points = np.array(coord_list)
            
            # Find center and extent of dimension
            center = points.mean(axis=0)
            
            # Calculate radius to encompass all points with some margin
            if points.shape[0] > 1:
                distances = np.sqrt(np.sum((points - center) ** 2, axis=1))
                radius = np.max(distances) * 1.2  # 20% margin
            else:
                radius = 0.3  # Default for single point
            
            self.dimension_boundaries[dim_id] = {
                'center': tuple(center),
                'radius': radius,
                'points': len(coord_list)
            }
    
    def _generate_simulated_map(self, dimensions: int) -> Dict[str, Any]:
        """Generate a simulated map when no multiverse data is available"""
        # Create simulated timelines
        simulated_timelines = [
            "Alpha Prime", "Alpha Secondary", "Alpha Tertiary",
            "Beta Prime", "Beta Variant", 
            "Gamma Nexus", "Gamma Flux",
            "Delta Horizon", "Delta Paradox",
            "Omega Point"
        ]
        
        self.timeline_coordinates = {}
        self.stability_zones = []
        
        # Generate random coordinates and properties
        for timeline in simulated_timelines:
            if dimensions == 2:
                coords = (random.uniform(-1, 1), random.uniform(-1, 1))
            else:
                coords = (random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1))
                
            self.timeline_coordinates[timeline] = coords
            
            # Generate random stability
            stability = random.uniform(0.3, 0.9)
            zone_radius = max(0.1, stability) * 0.5
            
            self.stability_zones.append({
                'center': coords,
                'radius': zone_radius,
                'stability': stability,
                'timeline': timeline
            })
        
        # Generate random connections
        self.navigation_routes = []
        for i in range(len(simulated_timelines)):
            timeline = simulated_timelines[i]
            
            # Create 1-3 connections to other timelines
            num_connections = random.randint(1, 3)
            for _ in range(num_connections):
                # Choose another random timeline
                other_idx = random.randint(0, len(simulated_timelines) - 1)
                if other_idx == i:
                    continue
                    
                other = simulated_timelines[other_idx]
                
                # Add route
                start = self.timeline_coordinates[timeline]
                end = self.timeline_coordinates[other]
                
                # Randomly make some quantum entangled
                entangled = random.random() < 0.3
                is_wormhole = random.random() < 0.2
                
                self.navigation_routes.append({
                    'start': start,
                    'end': end,
                    'start_timeline': timeline,
                    'end_timeline': other,
                    'quantum_entangled': entangled,
                    'is_wormhole': is_wormhole,
                    'wormhole_stability': random.uniform(0.5, 0.9) if is_wormhole else 0
                })
        
        # Calculate dimension boundaries
        dimension_groups = {
            "Alpha Dimension": [t for t in simulated_timelines if t.startswith("Alpha")],
            "Beta Dimension": [t for t in simulated_timelines if t.startswith("Beta")],
            "Gamma Dimension": [t for t in simulated_timelines if t.startswith("Gamma")],
            "Delta Dimension": [t for t in simulated_timelines if t.startswith("Delta")],
            "Omega Dimension": [t for t in simulated_timelines if t.startswith("Omega")]
        }
        
        self.dimension_boundaries = {}
        for dim_id, timeline_list in dimension_groups.items():
            if not timeline_list:
                continue
                
            coord_list = [self.timeline_coordinates[t] for t in timeline_list]
            points = np.array(coord_list)
            
            # Find center and extent of dimension
            center = points.mean(axis=0)
            
            # Calculate radius to encompass all points with some margin
            if points.shape[0] > 1:
                distances = np.sqrt(np.sum((points - center) ** 2, axis=1))
                radius = np.max(distances) * 1.2  # 20% margin
            else:
                radius = 0.3  # Default for single point
            
            self.dimension_boundaries[dim_id] = {
                'center': tuple(center),
                'radius': radius,
                'points': len(coord_list)
            }
            
        return {
            'dimensions': dimensions,
            'timelines': self.timeline_coordinates,
            'stability_zones': self.stability_zones,
            'routes': self.navigation_routes,
            'dimension_boundaries': self.dimension_boundaries
        }
    
    def visualize_map(self, map_data: Dict[str, Any] = None) -> None:
        """Visualize the multiverse map"""
        if not map_data:
            map_data = self.generate_multiverse_map()
            
        dimensions = map_data.get('dimensions', 3)
        timelines = map_data.get('timelines', {})
        routes = map_data.get('routes', [])
        stability_zones = map_data.get('stability_zones', [])
        dimension_boundaries = map_data.get('dimension_boundaries', {})
        
        # Create appropriate plot based on dimensions
        if dimensions == 2:
            self._visualize_2d_map(timelines, routes, stability_zones, dimension_boundaries)
        else:
            self._visualize_3d_map(timelines, routes, stability_zones, dimension_boundaries)
    
    def _visualize_2d_map(self, timelines, routes, stability_zones, dimension_boundaries):
        """Visualize a 2D multiverse map"""
        plt.figure(figsize=(12, 10))
        
        # Plot dimension boundaries first (as background)
        for dim_id, boundary in dimension_boundaries.items():
            center = boundary['center']
            radius = boundary['radius']
            
            # Create a circle for the dimension
            dimension_circle = plt.Circle(
                center, radius, alpha=0.1, 
                edgecolor='black', facecolor=self._get_dimension_color(dim_id),
                linewidth=1, linestyle='--'
            )
            plt.gca().add_patch(dimension_circle)
            
            # Add dimension label
            plt.annotate(
                dim_id, xy=center, ha='center', va='center', 
                fontsize=8, alpha=0.7
            )
        
        # Plot stability zones (as semi-transparent circles)
        for zone in stability_zones:
            # Color based on stability (green = stable, red = unstable)
            stability = zone['stability']
            color = (1 - stability, stability, 0.2)
            
            zone_circle = plt.Circle(
                zone['center'], zone['radius'], alpha=0.3, 
                edgecolor='none', facecolor=color
            )
            plt.gca().add_patch(zone_circle)
        
        # Plot connections between timelines
        for route in routes:
            start = route['start']
            end = route['end']
            
            # Determine line style and color based on connection type
            if route.get('is_wormhole', False):
                linestyle = ':'
                color = 'purple'
                linewidth = 2
            elif route.get('quantum_entangled', False):
                linestyle = '-'
                color = 'blue'
                linewidth = 1.5
            else:
                linestyle = '--'
                color = 'gray'
                linewidth = 1
            
            plt.plot(
                [start[0], end[0]], [start[1], end[1]], 
                linestyle=linestyle, color=color, linewidth=linewidth, alpha=0.7
            )
        
        # Plot timeline points
        x_coords = []
        y_coords = []
        labels = []
        colors = []
        sizes = []
        
        for name, coords in timelines.items():
            x_coords.append(coords[0])
            y_coords.append(coords[1])
            labels.append(name)
            
            # Determine point color and size
            if name.startswith("Alpha"):
                colors.append('green')
            elif name.startswith("Beta"):
                colors.append('blue')
            elif name.startswith("Gamma"):
                colors.append('orange')
            elif name.startswith("Delta"):
                colors.append('red')
            elif name.startswith("Omega"):
                colors.append('purple')
            else:
                colors.append('gray')
                
            # Size based on significance in the system
            for zone in stability_zones:
                if zone['timeline'] == name:
                    # Make more stable timelines bigger
                    sizes.append(50 + zone['stability'] * 100)
                    break
            else:
                sizes.append(50)
        
        # Plot the timeline points
        plt.scatter(x_coords, y_coords, c=colors, s=sizes, alpha=0.7, edgecolors='black')
        
        # Add timeline labels
        for i, txt in enumerate(labels):
            plt.annotate(
                txt, (x_coords[i], y_coords[i]), 
                xytext=(5, 5), textcoords='offset points',
                fontsize=8
            )
        
        # Set equal aspect and limits
        plt.axis('equal')
        plt.grid(True, linestyle='--', alpha=0.3)
        plt.title('Multiverse Map (2D Projection)')
        
        # Create legend for connection types
        from matplotlib.lines import Line2D
        legend_elements = [
            Line2D([0], [0], color='gray', linestyle='--', label='Standard Connection'),
            Line2D([0], [0], color='blue', linestyle='-', label='Quantum Entangled'),
            Line2D([0], [0], color='purple', linestyle=':', label='Quantum Wormhole')
        ]
        plt.legend(handles=legend_elements, loc='upper right')
        
        plt.tight_layout()
        plt.show()
    
    def _visualize_3d_map(self, timelines, routes, stability_zones, dimension_boundaries):
        """Visualize a 3D multiverse map"""
        fig = plt.figure(figsize=(12, 10))
        ax = fig.add_subplot(111, projection='3d')
        
        # Plot connections between timelines first
        for route in routes:
            start = route['start']
            end = route['end']
            
            # Determine line style and color based on connection type
            if route.get('is_wormhole', False):
                linestyle = ':'
                color = 'purple'
                linewidth = 2
            elif route.get('quantum_entangled', False):
                linestyle = '-'
                color = 'blue'
                linewidth = 1.5
            else:
                linestyle = '--'
                color = 'gray'
                linewidth = 1
            
            ax.plot(
                [start[0], end[0]], [start[1], end[1]], [start[2], end[2]],
                linestyle=linestyle, color=color, linewidth=linewidth, alpha=0.7
            )
        
        # Plot timeline points
        x_coords = []
        y_coords = []
        z_coords = []
        labels = []
        colors = []
        sizes = []
        
        for name, coords in timelines.items():
            x_coords.append(coords[0])
            y_coords.append(coords[1])
            z_coords.append(coords[2])
            labels.append(name)
            
            # Determine point color
            if name.startswith("Alpha"):
                colors.append('green')
            elif name.startswith("Beta"):
                colors.append('blue')
            elif name.startswith("Gamma"):
                colors.append('orange')
            elif name.startswith("Delta"):
                colors.append('red')
            elif name.startswith("Omega"):
                colors.append('purple')
            else:
                colors.append('gray')
                
            # Size based on significance in the system
            for zone in stability_zones:
                if zone['timeline'] == name:
                    # Base size on stability
                    sizes.append(20 + zone['stability'] * 80)
                    break
            else:
                sizes.append(20)
        
        # Plot the timeline points
        ax.scatter(x_coords, y_coords, z_coords, c=colors, s=sizes, alpha=0.7, edgecolors='black')
        
        # Add timeline labels
        for i, txt in enumerate(labels):
            ax.text(
                x_coords[i], y_coords[i], z_coords[i], txt,
                fontsize=8
            )
        
        # Try to visualize dimension boundaries as transparent spheres
        # (not all matplotlib installations support this)
        try:
            from matplotlib.patches import FancyArrowPatch
            from mpl_toolkits.mplot3d import proj3d
            
            # Create wireframe spheres for dimensions
            for dim_id, boundary in dimension_boundaries.items():
                center = boundary['center']
                radius = boundary['radius']
                
                # Create a wireframe sphere
                u, v = np.mgrid[0:2*np.pi:20j, 0:np.pi:10j]
                x = center[0] + radius * np.cos(u) * np.sin(v)
                y = center[1] + radius * np.sin(u) * np.sin(v)
                z = center[2] + radius * np.cos(v)
                
                # Color varies by dimension
                color = self._get_dimension_color(dim_id)
                
                ax.plot_wireframe(
                    x, y, z, color=color, alpha=0.1,
                    linewidth=0.5
                )
                
                # Add dimension label at center
                ax.text(
                    center[0], center[1], center[2], dim_id,
                    fontsize=10, ha='center', va='center', alpha=0.7
                )
        except Exception as e:
            print(f"Could not render dimension spheres: {e}")
        
        # Set labels and title
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('Multiverse Map (3D)')
        
        # Create legend for connection types
        from matplotlib.lines import Line2D
        legend_elements = [
            Line2D([0], [0], color='gray', linestyle='--', label='Standard Connection'),
            Line2D([0], [0], color='blue', linestyle='-', label='Quantum Entangled'),
            Line2D([0], [0], color='purple', linestyle=':', label='Quantum Wormhole')
        ]
        ax.legend(handles=legend_elements, loc='upper right')
        
        # Set equal aspect ratio
        max_range = max([
            max(x_coords) - min(x_coords),
            max(y_coords) - min(y_coords),
            max(z_coords) - min(z_coords)
        ])
        
        mid_x = (max(x_coords) + min(x_coords)) / 2
        mid_y = (max(y_coords) + min(y_coords)) / 2
        mid_z = (max(z_coords) + min(z_coords)) / 2
        
        ax.set_xlim(mid_x - max_range/2, mid_x + max_range/2)
        ax.set_ylim(mid_y - max_range/2, mid_y + max_range/2)
        ax.set_zlim(mid_z - max_range/2, mid_z + max_range/2)
        
        plt.tight_layout()
        plt.show()
    
    def _get_dimension_color(self, dimension_id: str) -> Tuple[float, float, float, float]:
        """Get a color for a dimension based on its ID"""
        if "Alpha" in dimension_id:
            return (0.0, 0.8, 0.2, 0.2)  # Green
        elif "Beta" in dimension_id:
            return (0.2, 0.2, 0.8, 0.2)  # Blue
        elif "Gamma" in dimension_id:
            return (1.0, 0.6, 0.0, 0.2)  # Orange
        elif "Delta" in dimension_id:
            return (0.8, 0.2, 0.2, 0.2)  # Red
        elif "Omega" in dimension_id:
            return (0.6, 0.0, 0.8, 0.2)  # Purple
        else:
            return (0.5, 0.5, 0.5, 0.2)  # Gray
    
    def find_optimal_route(self, origin: str, destination: str) -> List[Dict[str, Any]]:
        """
        Find the optimal route between two timelines.
        
        Args:
            origin: Name of origin timeline
            destination: Name of destination timeline
            
        Returns:
            List of route segments forming the optimal path
        """
        if origin == destination:
            return []
            
        # Check cache first
        cache_key = f"{origin}|{destination}"
        if cache_key in self.route_cache:
            return self.route_cache[cache_key]
            
        # Ensure we have the multiverse map
        if not self.timeline_coordinates:
            self.generate_multiverse_map()
            
        # Check if origin and destination exist
        if origin not in self.timeline_coordinates or destination not in self.timeline_coordinates:
            return []
            
        # Build a graph of connections
        graph = {}
        for route in self.navigation_routes:
            start = route['start_timeline']
            end = route['end_timeline']
            
            # Determine edge weight based on connection type
            weight = 1.0
            if route.get('is_wormhole', False):
                # Wormholes are faster but may be less stable
                weight = 0.5 / max(0.1, route.get('wormhole_stability', 0.5))
            elif route.get('quantum_entangled', False):
                # Quantum entangled connections are more efficient
                weight = 0.7
                
            # Add to graph (bidirectional)
            if start not in graph:
                graph[start] = []
            if end not in graph:
                graph[end] = []
                
            graph[start].append((end, weight, route))
            graph[end].append((start, weight, route))
        
        # Use Dijkstra's algorithm to find shortest path
        import heapq
        
        # Priority queue for Dijkstra's algorithm
        queue = [(0, origin, [])]  # (cost, current, path)
        visited = set()
        
        while queue:
            cost, current, path = heapq.heappop(queue)
            
            if current in visited:
                continue
                
            visited.add(current)
            
            if current == destination:
                # We found the destination, return the path
                self.route_cache[cache_key] = path
                return path
                
            if current not in graph:
                continue
                
            for neighbor, weight, route_data in graph[current]:
                if neighbor not in visited:
                    new_path = path + [route_data]
                    heapq.heappush(queue, (cost + weight, neighbor, new_path))
        
        # No path found
        self.route_cache[cache_key] = []
        return []
    
    def run_cartography_demo(self):
        """Run a demonstration of the temporal cartography system"""
        print("=== Temporal Cartography System Demonstration ===")
        
        print("\nGenerating multiverse map...")
        map_data_2d = self.generate_multiverse_map(dimensions=2)
        
        print(f"\nMap generated with {len(map_data_2d['timelines'])} timelines and {len(map_data_2d['routes'])} connections.")
        print(f"Found {len(map_data_2d['dimension_boundaries'])} quantum dimensions:\n")
        
        for dim_id, data in map_data_2d['dimension_boundaries'].items():
            print(f"  • {dim_id}: {data['points']} timelines, center at {data['center'][:2]}")
        
        # Find route between two timelines
        available_timelines = list(map_data_2d['timelines'].keys())
        if len(available_timelines) > 1:
            origin = available_timelines[0]
            destination = available_timelines[-1]
            
            print(f"\nFinding optimal route from {origin} to {destination}...")
            route = self.find_optimal_route(origin, destination)
            
            if route:
                print(f"Found route with {len(route)} segments:")
                for i, segment in enumerate(route, 1):
                    start = segment['start_timeline']
                    end = segment['end_timeline']
                    
                    route_type = "standard connection"
                    if segment.get('is_wormhole', False):
                        route_type = "quantum wormhole"
                    elif segment.get('quantum_entangled', False):
                        route_type = "quantum entangled link"
                        
                    print(f"  {i}. {start} → {end} via {route_type}")
            else:
                print(f"No route found between {origin} and {destination}")
        
        print("\nPreparing visualization...")
        print("(Close the plot window to continue with the demo)\n")
        
        # Visualize 2D map
        self.visualize_map(map_data_2d)
        
        # Generate and visualize 3D map if desired
        print("\nGenerating 3D multiverse map...")
        map_data_3d = self.generate_multiverse_map(dimensions=3)
        
        print("\nPreparing 3D visualization...")
        print("(Close the plot window to end the demo)\n")
        
        self.visualize_map(map_data_3d)
        
        return {
            "timelines": len(map_data_3d['timelines']),
            "routes": len(map_data_3d['routes']),
            "dimensions": len(map_data_3d['dimension_boundaries'])
        }


def run_temporal_cartography_demo():
    """Run a demonstration of the temporal cartography system"""
    cartographer = TemporalCartographer()
    results = cartographer.run_cartography_demo()
    return cartographer


if __name__ == "__main__":
    run_temporal_cartography_demo()
