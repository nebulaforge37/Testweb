
"""
Missing Modules Handler
This utility helps manage missing module imports in the multiverse simulation system.
"""

import sys
import importlib
from typing import Dict, Any, List, Optional, Callable

# Track missing modules
missing_modules = set()
substituted_modules = {}

class ModuleSubstitute:
    """A substitute class that can be used in place of a missing module"""
    
    def __init__(self, module_name: str):
        self.module_name = module_name
        
    def __getattr__(self, name):
        # Return a placeholder function or value
        if name.startswith('__'):
            raise AttributeError(f"'{self.module_name}' substitute has no attribute '{name}'")
        
        # Return a placeholder class for any attribute
        return PlaceholderClass(f"{self.module_name}.{name}")

class PlaceholderClass:
    """A placeholder class that can be instantiated but does nothing"""
    
    def __init__(self, name: str, *args, **kwargs):
        self.name = name
        self.args = args
        self.kwargs = kwargs
        
    def __getattr__(self, name):
        # Make all attributes callable
        if name.startswith('__'):
            raise AttributeError(f"'{self.name}' placeholder has no attribute '{name}'")
        
        return lambda *args, **kwargs: None
        
    def __call__(self, *args, **kwargs):
        # Make the class callable
        return self

def safe_import(module_name: str, substitute: Any = None) -> Any:
    """
    Safely import a module, returning a substitute if it doesn't exist
    
    Args:
        module_name: The name of the module to import
        substitute: A specific substitute to use if the module is missing
        
    Returns:
        The imported module or a substitute
    """
    try:
        return importlib.import_module(module_name)
    except ImportError:
        global missing_modules
        missing_modules.add(module_name)
        
        if substitute is None:
            substitute = ModuleSubstitute(module_name)
            
        substituted_modules[module_name] = substitute
        return substitute

def report_missing_modules() -> bool:
    """
    Report any modules that failed to import
    
    Returns:
        True if any modules were missing, False otherwise
    """
    if missing_modules:
        modules_list = ", ".join(missing_modules)
        print(f"Some modules could not be imported. Some features may be unavailable.")
        print(f"Missing modules: {modules_list}")
        return True
    return False

def get_missing_modules() -> List[str]:
    """Get the list of missing modules"""
    return list(missing_modules)

def clear_missing_modules():
    """Clear the list of missing modules"""
    global missing_modules
    missing_modules = set()
