
#!/usr/bin/env python3
"""
Quantum Fusion Demo
This script demonstrates the quantum fusion system and mechanics principles
in the context of the multiverse and quantum dimensions.
"""

import random
import time
from quantum_dimensions import DimensionalRegistry
from quantum_physics import run_fusion_demo, QuantumFusionRegistry, QuantumMechanicsRegistry
from alternate_realities import RealityManager

def run_advanced_fusion_demo():
    """Run a more advanced demonstration of quantum fusion in the multiverse"""
    print("=== Advanced Quantum Fusion and Mechanics Demo ===")
    
    # Set up the dimensional registry and reality manager
    registry = DimensionalRegistry()
    dimensions = registry.initialize_dimensions(count=20, max_id=10000)
    reality_manager = RealityManager(registry)
    
    # Create fusion and mechanics registries
    fusion_registry = QuantumFusionRegistry()
    mechanics_registry = QuantumMechanicsRegistry()
    
    # Display information about dimensions
    print(f"\nInitialized {len(dimensions)} quantum dimensions")
    print("Sample dimensions and their properties:")
    for i, dimension in enumerate(dimensions[:3]):
        print(f"\n{i+1}. {dimension}")
        print(f"   Physical laws: {dimension.physical_laws_description()}")
        
        # Show best fusion type for this dimension
        best_type, efficiency = fusion_registry.get_most_efficient_fusion(dimension)
        print(f"   Best fusion type: {best_type.name} (Efficiency: {efficiency:.2f})")
    
    # Create several fusion reactors in different dimensions
    print("\n=== Establishing Quantum Fusion Network ===")
    reactors = []
    
    # Create 3 reactors in different dimensions
    for i in range(3):
        # Use a different dimension for each reactor
        dimension = dimensions[i]
        
        # Create reactor with varying parameters
        reactor_name = f"Reactor {chr(65+i)}-{dimension.dimension_id}"
        base_power = random.uniform(1.0, 3.0)
        stability = random.uniform(0.6, 0.9)
        
        from quantum_physics import QuantumFusionReactor
        reactor = QuantumFusionReactor(reactor_name, dimension.dimension_id, base_power, stability)
        
        # Connect to a few other dimensions
        connection_count = random.randint(2, 4)
        for _ in range(connection_count):
            target_dim = random.choice(dimensions)
            if target_dim.dimension_id != dimension.dimension_id:
                strength = random.uniform(0.4, 0.8)
                reactor.connect_dimension(target_dim.dimension_id, strength)
        
        reactors.append(reactor)
        print(f"Created {reactor_name} in dimension {dimension.dimension_id}")
        print(f"Connected to {connection_count} other dimensions")
    
    # Activate each reactor with its optimal fusion type
    print("\n=== Activating Fusion Reactors ===")
    
    for reactor in reactors:
        dimension = registry.get_dimension(reactor.base_dimension_id)
        best_type, _ = fusion_registry.get_most_efficient_fusion(dimension)
        
        print(f"\nActivating {reactor.name} with {best_type.name}...")
        success = reactor.activate_fusion(fusion_registry, registry, best_type.name.split()[0].lower())
        
        if success:
            print(f"Activation successful! Power output: {reactor.calculate_power_output():.2f} units")
        else:
            print("Activation failed! Attempting alternative fusion type...")
            # Try another fusion type
            alt_type = random.choice(fusion_registry.get_all_fusion_types())
            while alt_type.name == best_type.name:
                alt_type = random.choice(fusion_registry.get_all_fusion_types())
                
            success = reactor.activate_fusion(fusion_registry, registry, alt_type.name.split()[0].lower())
            if success:
                print(f"Alternative activation successful! Power output: {reactor.calculate_power_output():.2f} units")
            else:
                print("All activation attempts failed!")
    
    # Show the effect of quantum mechanics principles on realities
    print("\n=== Quantum Mechanics Effects on Multiverse ===")
    
    # Create some realities to work with
    test_realities = []
    for i in range(3):
        dimension = random.choice(dimensions)
        reality = registry.create_reality(dimension.dimension_id)
        test_realities.append(reality)
        print(f"Created test reality: {reality}")
    
    # Apply different principles to different realities
    for i, reality in enumerate(test_realities):
        principle_name = list(mechanics_registry.principles.keys())[i % 4]
        principle = mechanics_registry.get_principle(principle_name)
        
        print(f"\nApplying {principle.name} to {reality.name}...")
        effects = principle.apply_to_reality(reality)
        
        for effect in effects:
            print(f"- {effect}")
    
    # Create some reality breaches using fusion energy
    print("\n=== Creating Fusion-Powered Reality Breaches ===")
    
    for i, reactor in enumerate(reactors):
        if reactor.active_fusion_type:  # Only use active reactors
            # Source and destination realities
            if len(test_realities) >= 2:
                source_reality = test_realities[i % len(test_realities)]
                dest_reality = test_realities[(i+1) % len(test_realities)]
                
                # Create coordinates
                from alternate_realities import RealityCoordinate
                source_coord = RealityCoordinate.from_dimension(
                    source_reality.dimension_id, source_reality.reality_id, 2045)
                dest_coord = RealityCoordinate.from_dimension(
                    dest_reality.dimension_id, dest_reality.reality_id, 2045)
                
                # Fusion-powered breaches are more stable
                stability_boost = min(0.3, reactor.calculate_power_output() / 20)
                breach_stability = 0.6 + stability_boost
                
                print(f"\nCreating fusion-powered breach using {reactor.name}...")
                print(f"Source: {source_coord}")
                print(f"Destination: {dest_coord}")
                
                stability = reality_manager.create_reality_breach(
                    source_coord, dest_coord, breach_stability)
                
                print(f"Breach created with stability: {stability:.2f}")
                print(f"Fusion power contribution: +{stability_boost:.2f} stability")
            else:
                print("Not enough test realities created for breaches")
    
    # Simulate a quantum traveler using the fusion-powered breaches
    print("\n=== Quantum Traveler Using Fusion-Powered Breaches ===")
    
    traveler_name = "Dr. Quantum Fusion"
    source_reality = test_realities[0]
    
    # Register the traveler in the source reality
    traveler = reality_manager.register_traveler(
        traveler_name, source_reality.dimension_id, source_reality.reality_id)
    
    print(f"Registered traveler: {traveler}")
    
    # Travel through the breaches
    for i in range(min(len(reactors), len(test_realities)-1)):
        if reactors[i].active_fusion_type:
            dest_reality = test_realities[i+1]
            
            print(f"\nTravel attempt {i+1}: To D{dest_reality.dimension_id}:R{dest_reality.reality_id}")
            event = reality_manager.perform_reality_travel(
                traveler_name, dest_reality.dimension_id, dest_reality.reality_id, use_breach=True)
            
            print(event.generate_report())
    
    # Show final state of reactors
    print("\n=== Final Reactor Status ===")
    for reactor in reactors:
        print("\n" + reactor.get_status_report())
    
    print("\nAdvanced quantum fusion and mechanics demo completed!")

if __name__ == "__main__":
    # Run the basic fusion demo
    run_fusion_demo()
    
    print("\n" + "="*60 + "\n")
    
    # Then run the advanced demo
    run_advanced_fusion_demo()
"""
Advanced Fusion Demonstration Module
This module provides a visual simulation of quantum fusion processes
in the multiverse simulator.
"""

import time
import random
import math

class FusionReactor:
    """Simulates a quantum fusion reactor"""
    
    def __init__(self, reactor_type="tokamak", initial_temp=15000000):
        self.reactor_type = reactor_type
        self.temperature = initial_temp  # Kelvin
        self.containment_field = 1.0     # 0-1 stability
        self.plasma_density = 0.5        # 0-1 scale
        self.fusion_rate = 0.0           # 0-1 scale
        self.energy_output = 0.0         # Megawatts
        self.runtime = 0                 # seconds
        self.quantum_stabilizers = True  # Using quantum stabilization
        
    def initialize(self):
        """Initialize the fusion reactor"""
        print(f"Initializing {self.reactor_type.upper()} fusion reactor...")
        
        # Visual reactor startup sequence
        for i in range(5):
            progress = "■" * i + "□" * (4-i)
            print(f"\rReactor initialization: [{progress}] {(i+1)*20}%", end="")
            time.sleep(0.3)
        
        print("\nReactor initialization complete!")
        self.containment_field = random.uniform(0.85, 0.95)
        
    def heat_plasma(self, target_temp):
        """Heat the plasma to target temperature"""
        print(f"\nBeginning plasma heating sequence...")
        current = self.temperature
        
        # Visual heating progress
        steps = 6
        for i in range(steps):
            progress = i / (steps - 1)
            self.temperature = current + (target_temp - current) * progress
            heat_bar = "█" * int(progress * 20) + "▒" * (20 - int(progress * 20))
            print(f"\rPlasma heating: [{heat_bar}] {self.temperature/1000000:.1f} million K", end="")
            time.sleep(0.4)
            
        print("\nPlasma heating complete!")
        
    def engage_quantum_field(self):
        """Engage quantum field stabilizers"""
        if self.quantum_stabilizers:
            print("\nEngaging quantum field stabilizers...")
            
            for i in range(4):
                print(f"\rQuantum field: {'◢◤' * i}", end="")
                time.sleep(0.3)
                
            print("\rQuantum field stabilizers engaged: ◢◤◢◤◢◤◢◤")
            self.containment_field = min(1.0, self.containment_field + random.uniform(0.05, 0.15))
        else:
            print("\nWARNING: Quantum field stabilizers disabled")
            
    def run_fusion_cycle(self, duration=10):
        """Run a fusion cycle for the specified duration"""
        print(f"\nBeginning fusion cycle ({duration} time units)...")
        self.plasma_density = min(1.0, self.plasma_density + random.uniform(0.1, 0.3))
        
        # Calculate base fusion rate
        self.fusion_rate = (self.temperature / 100000000) * self.plasma_density * self.containment_field
        self.fusion_rate = min(0.95, max(0.1, self.fusion_rate))
        
        # Run the cycle
        instability = False
        for i in range(duration):
            self.runtime += 1
            
            # Random fluctuations in containment field
            field_fluctuation = random.uniform(-0.08, 0.05)
            self.containment_field = max(0.1, min(1.0, self.containment_field + field_fluctuation))
            
            # Calculate energy output based on fusion rate and containment
            self.energy_output = 500 * self.fusion_rate * self.containment_field
            
            # Quantum effects - random spikes or drops in fusion rate
            if random.random() < 0.2:
                quantum_effect = random.uniform(-0.2, 0.3)
                self.fusion_rate = max(0.05, min(0.99, self.fusion_rate + quantum_effect))
                effect_type = "surge" if quantum_effect > 0 else "drop"
                print(f"  Quantum {effect_type} detected! Fusion rate: {self.fusion_rate:.2f}")
            
            # Visualization
            energy_bar = "█" * int(self.energy_output / 50)
            containment_indicator = "!" if self.containment_field < 0.6 else "="
            
            print(f"\rCycle {i+1}/{duration}: [{energy_bar:<10}] {self.energy_output:.1f} MW | " + 
                  f"Containment: {self.containment_field:.2f} {containment_indicator*int(5*(1-self.containment_field))}", end="")
            
            # Check for instabilities
            if self.containment_field < 0.3 and random.random() < 0.7:
                instability = True
                print("\n\nWARNING: Containment field critical! Aborting fusion cycle.")
                break
                
            time.sleep(0.5)
            
        if not instability:
            print("\nFusion cycle completed successfully!")
        
        return not instability
        
    def generate_report(self):
        """Generate a report of reactor performance"""
        efficiency = (self.energy_output / 500) * 100
        
        print("\n\n===== FUSION REACTOR REPORT =====")
        print(f"Reactor Type:      {self.reactor_type.upper()}")
        print(f"Runtime:           {self.runtime} seconds")
        print(f"Core Temperature:  {self.temperature/1000000:.2f} million K")
        print(f"Plasma Density:    {self.plasma_density:.2f}")
        print(f"Containment Field: {self.containment_field:.2f}")
        print(f"Fusion Rate:       {self.fusion_rate:.2f}")
        print(f"Energy Output:     {self.energy_output:.1f} MW")
        print(f"Efficiency:        {efficiency:.1f}%")
        print(f"Quantum Fields:    {'Enabled' if self.quantum_stabilizers else 'Disabled'}")
        
        status = "STABLE"
        if self.containment_field < 0.5:
            status = "UNSTABLE"
        elif self.containment_field < 0.7:
            status = "DEGRADING"
            
        print(f"Reactor Status:    {status}")
        print("================================")

def run_advanced_fusion_demo():
    """Run a comprehensive fusion reactor demonstration"""
    print("=" * 60)
    print(" ADVANCED QUANTUM FUSION REACTOR DEMONSTRATION ".center(60, '='))
    print("=" * 60)
    print("\nThis demonstration simulates a fusion reactor with quantum stabilization")
    print("techniques derived from the multiverse field theories.\n")
    
    # Create reactor
    reactor_types = ["tokamak", "stellarator", "inertial confinement", "quantum pinch"]
    selected_type = reactor_types[random.randint(0, len(reactor_types)-1)]
    
    reactor = FusionReactor(selected_type)
    
    # Initialize the system
    reactor.initialize()
    time.sleep(0.5)
    
    # Heat the plasma
    target_temp = random.uniform(50000000, 150000000)
    reactor.heat_plasma(target_temp)
    time.sleep(0.5)
    
    # Engage quantum field
    reactor.engage_quantum_field()
    time.sleep(0.5)
    
    # Run multiple fusion cycles
    total_cycles = random.randint(2, 4)
    successful_cycles = 0
    
    for cycle in range(total_cycles):
        print(f"\n--- Fusion Cycle {cycle+1}/{total_cycles} ---")
        cycle_duration = random.randint(8, 12)
        if reactor.run_fusion_cycle(cycle_duration):
            successful_cycles += 1
        
        # Adjust containment between cycles
        if reactor.containment_field < 0.6:
            print("\nPerforming emergency containment field recalibration...")
            reactor.containment_field = min(0.85, reactor.containment_field + random.uniform(0.2, 0.4))
            time.sleep(0.5)
    
    # Generate final report
    reactor.generate_report()
    
    # Conclusion
    success_rate = (successful_cycles / total_cycles) * 100
    print(f"\nDemonstration complete. Cycle success rate: {success_rate:.1f}%")
    
    if success_rate > 75:
        print("Assessment: Fusion demonstration successful with high stability")
    elif success_rate > 50:
        print("Assessment: Fusion demonstration successful with acceptable stability")
    else:
        print("Assessment: Fusion demonstration requires containment field optimization")
        
    print("\nPress Enter to return to the menu...")

if __name__ == "__main__":
    run_advanced_fusion_demo()
