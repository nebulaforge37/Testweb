
"""
Quantum Reality Merging Module
This module provides functionality for merging multiple quantum realities
to create hybrid realities with combined properties.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any, Set
from quantum_dimensions import QuantumDimension, QuantumReality, DimensionalRegistry

class RealityMergeType:
    """Represents different methods of merging quantum realities"""
    
    def __init__(self, name: str, description: str, stability_impact: float, complexity: float):
        """
        Initialize a merger type
        
        Args:
            name: Name of the merger process
            description: Description of how it works
            stability_impact: Impact on resulting reality stability (-1.0 to 1.0)
            complexity: How complex the merger is (0.0-1.0)
        """
        self.name = name
        self.description = description
        self.stability_impact = stability_impact
        self.complexity = complexity
        
    def __str__(self) -> str:
        return f"{self.name}: {self.description} (Stability Impact: {self.stability_impact:+.2f})"


class RealityMerger:
    """Handles the merging of quantum realities"""
    
    def __init__(self, dimensional_registry: DimensionalRegistry):
        """Initialize the reality merger with a dimensional registry"""
        self.registry = dimensional_registry
        self.merge_types = self._initialize_merge_types()
        self.merge_history: List[Dict[str, Any]] = []
        
    def _initialize_merge_types(self) -> Dict[str, RealityMergeType]:
        """Initialize available merger types"""
        return {
            "harmonic": RealityMergeType(
                "Harmonic Fusion",
                "Gentle merger that preserves most original properties with minimal disruption",
                stability_impact=0.2,
                complexity=0.3
            ),
            "quantum_overlay": RealityMergeType(
                "Quantum Overlay",
                "One reality's quantum properties are superimposed onto another's physical framework",
                stability_impact=0.0,
                complexity=0.5
            ),
            "temporal_splice": RealityMergeType(
                "Temporal Splice",
                "Combines realities along temporal boundaries, creating time-sector divisions",
                stability_impact=-0.1,
                complexity=0.7
            ),
            "dimensional_fusion": RealityMergeType(
                "Dimensional Fusion",
                "Deep integration that fully combines all aspects of both realities",
                stability_impact=-0.3,
                complexity=0.8
            ),
            "resonance_collapse": RealityMergeType(
                "Resonance Collapse",
                "Forced merger through quantum resonance collapse - highly unstable but powerful",
                stability_impact=-0.5,
                complexity=0.9
            )
        }
        
    def get_merge_type(self, type_name: str) -> Optional[RealityMergeType]:
        """Get a merge type by name"""
        return self.merge_types.get(type_name.lower())
    
    def get_all_merge_types(self) -> List[RealityMergeType]:
        """Get all available merge types"""
        return list(self.merge_types.values())
    
    def calculate_compatibility(self, reality1: QuantumReality, reality2: QuantumReality) -> float:
        """
        Calculate the compatibility between two realities
        
        Returns:
            Compatibility score (0.0 to 1.0)
        """
        # Base compatibility on similarity of quantum properties
        property_diff = abs(reality1.consistency - reality2.consistency)
        
        # Calculate event compatibility based on shared or similar events
        event_compatibility = 0.0
        if reality1.events and reality2.events:
            # Check for similarities in events
            r1_events = set(e.lower() for e in reality1.events)
            r2_events = set(e.lower() for e in reality2.events)
            
            # Calculate Jaccard similarity
            intersection = len(r1_events.intersection(r2_events))
            union = len(r1_events.union(r2_events))
            if union > 0:
                event_compatibility = intersection / union
        
        # Compatibility is higher for realities in the same dimension
        dimension_compatibility = 1.0 if reality1.dimension_id == reality2.dimension_id else 0.6
        
        # Combine factors
        compatibility = (
            (1.0 - property_diff) * 0.4 +
            event_compatibility * 0.3 +
            dimension_compatibility * 0.3
        )
        
        return max(0.1, min(0.95, compatibility))
    
    def merge_realities(self, 
                      reality1_id: int, 
                      reality2_id: int, 
                      merge_type_name: str,
                      new_name: str = None,
                      target_dimension_id: int = None) -> Optional[QuantumReality]:
        """
        Merge two realities using the specified merge type
        
        Args:
            reality1_id: ID of first reality
            reality2_id: ID of second reality
            merge_type_name: Name of merge type to use
            new_name: Name for the new reality (optional)
            target_dimension_id: ID of dimension for the new reality (optional)
                                If None, places in the same dimension as reality1
        
        Returns:
            The newly created reality, or None if merger failed
        """
        # Get the realities
        reality1 = self.registry.get_reality(reality1_id)
        reality2 = self.registry.get_reality(reality2_id)
        
        if not reality1 or not reality2:
            print(f"One or both realities not found: {reality1_id}, {reality2_id}")
            return None
            
        # Get the merge type
        merge_type = self.get_merge_type(merge_type_name)
        if not merge_type:
            print(f"Unknown merge type: {merge_type_name}")
            return None
            
        # Calculate compatibility
        compatibility = self.calculate_compatibility(reality1, reality2)
        
        # Calculate success probability based on compatibility and merge complexity
        success_probability = compatibility * (1.0 - merge_type.complexity * 0.5)
        
        # Determine target dimension
        if target_dimension_id is None:
            target_dimension_id = reality1.dimension_id
            
        target_dimension = self.registry.get_dimension(target_dimension_id)
        if not target_dimension:
            print(f"Target dimension not found: {target_dimension_id}")
            return None
            
        # Attempt the merge
        print(f"Attempting to merge realities {reality1_id} and {reality2_id} " + 
             f"using {merge_type.name} (compatibility: {compatibility:.2f})")
             
        success = random.random() < success_probability
        
        if not success:
            print(f"Merger failed! Incompatible quantum signatures or unstable dimensional boundary.")
            
            # Record the failed attempt
            self.merge_history.append({
                "reality1_id": reality1_id, 
                "reality2_id": reality2_id,
                "merge_type": merge_type.name,
                "success": False,
                "compatibility": compatibility,
                "reason": "Quantum incompatibility"
            })
            
            return None
            
        # Merge successful - create new reality
        # Calculate merged properties
        merged_consistency = (reality1.consistency + reality2.consistency) / 2
        merged_name = new_name or f"Merged-{reality1.name[:4]}-{reality2.name[:4]}"
        
        # Apply stability impact from merge type
        merged_stability = min(1.0, max(0.1, (
            (reality1.stability + reality2.stability) / 2 + 
            merge_type.stability_impact
        )))
        
        # Create the new reality
        new_reality = self.registry.create_reality(
            target_dimension_id,
            name=merged_name,
            consistency=merged_consistency
        )
        
        if not new_reality:
            print("Failed to create new reality")
            return None
            
        # Set stability manually (not part of creation parameters)
        new_reality.stability = merged_stability
        
        # Merge the events from both realities
        self._merge_events(new_reality, reality1, reality2)
        
        # Record success
        self.merge_history.append({
            "reality1_id": reality1_id, 
            "reality2_id": reality2_id,
            "merge_type": merge_type.name,
            "success": True,
            "compatibility": compatibility,
            "new_reality_id": new_reality.reality_id,
            "new_dimension_id": new_reality.dimension_id
        })
        
        # Report result
        print(f"Successfully created merged reality {new_reality.reality_id}: {new_reality.name} " +
             f"in dimension {target_dimension_id} with stability {new_reality.stability:.2f}")
             
        return new_reality
    
    def _merge_events(self, new_reality: QuantumReality, 
                     reality1: QuantumReality, reality2: QuantumReality):
        """Merge the events from two realities into the new one"""
        # Add events from both realities, with some logic to handle duplicates and contradictions
        all_events = {}  # event text -> counter
        
        # Count occurrences of each event
        for event in reality1.events:
            event_lower = event.lower()
            all_events[event_lower] = all_events.get(event_lower, 0) + 1
            
        for event in reality2.events:
            event_lower = event.lower()
            all_events[event_lower] = all_events.get(event_lower, 0) + 1
        
        # Add events that appear in both realities
        for event_text, count in all_events.items():
            if count > 1:
                # This event appears in both - it's consistent across realities
                new_reality.add_event(f"CONSISTENT: {event_text}")
            else:
                # This event is unique to one reality
                # Add with probability based on new reality's consistency
                if random.random() < new_reality.consistency:
                    new_reality.add_event(f"VARIANT: {event_text}")
        
        # Add a merger event
        new_reality.add_event(
            f"REALITY MERGER: Created from realities {reality1.reality_id} and {reality2.reality_id}"
        )
    
    def find_compatible_realities(self, reality_id: int, threshold: float = 0.6) -> List[Tuple[QuantumReality, float]]:
        """
        Find realities compatible with the specified reality
        
        Args:
            reality_id: ID of the reality to find matches for
            threshold: Minimum compatibility threshold (0.0-1.0)
            
        Returns:
            List of (reality, compatibility_score) tuples, sorted by compatibility
        """
        target_reality = self.registry.get_reality(reality_id)
        if not target_reality:
            return []
            
        compatible = []
        
        # Check all realities
        for reality in self.registry.realities.values():
            # Skip the same reality
            if reality.reality_id == reality_id:
                continue
                
            compatibility = self.calculate_compatibility(target_reality, reality)
            if compatibility >= threshold:
                compatible.append((reality, compatibility))
                
        # Sort by compatibility (highest first)
        compatible.sort(key=lambda x: x[1], reverse=True)
        
        return compatible
    
    def generate_merge_report(self, merged_reality_id: int = None) -> str:
        """Generate a report on reality merges"""
        if not self.merge_history:
            return "No reality merges have been performed."
            
        report = ["=== REALITY MERGER REPORT ==="]
        
        successful = [m for m in self.merge_history if m["success"]]
        failed = [m for m in self.merge_history if not m["success"]]
        
        report.append(f"Total merger attempts: {len(self.merge_history)}")
        report.append(f"Successful mergers: {len(successful)}")
        report.append(f"Failed mergers: {len(failed)}")
        
        if merged_reality_id:
            # Find specific information about a merged reality
            for merge in successful:
                if merge.get("new_reality_id") == merged_reality_id:
                    report.append(f"\nDetailed information about Reality {merged_reality_id}:")
                    report.append(f"Parent realities: {merge['reality1_id']} and {merge['reality2_id']}")
                    report.append(f"Merger type: {merge['merge_type']}")
                    report.append(f"Compatibility score: {merge['compatibility']:.2f}")
                    
                    new_reality = self.registry.get_reality(merged_reality_id)
                    if new_reality:
                        report.append(f"Current stability: {new_reality.stability:.2f}")
                        report.append(f"Events: {len(new_reality.events)}")
        
        return "\n".join(report)


def run_merger_demo(dimensional_registry: DimensionalRegistry = None):
    """Run a demonstration of quantum reality merging"""
    print("=== Quantum Reality Merger Demonstration ===")
    
    # Create registry if not provided
    if not dimensional_registry:
        dimensional_registry = DimensionalRegistry()
        dimensions = dimensional_registry.initialize_dimensions(count=3)
    
    # Create a reality merger
    merger = RealityMerger(dimensional_registry)
    
    # Show available merge types
    print("\nAvailable Reality Merger Types:")
    for merge_type in merger.get_all_merge_types():
        print(f"- {merge_type}")
    
    # Create some test realities if needed
    realities = list(dimensional_registry.realities.values())
    if len(realities) < 4:
        print("\nCreating test realities...")
        dimension = list(dimensional_registry.dimensions.values())[0]
        
        # Reality with high stability
        reality1 = dimensional_registry.create_reality(
            dimension.dimension_id, name="Stable-Alpha", consistency=0.9
        )
        reality1.add_event("Peaceful global unification")
        reality1.add_event("Clean energy breakthrough")
        
        # Another stable reality with similar events
        reality2 = dimensional_registry.create_reality(
            dimension.dimension_id, name="Stable-Beta", consistency=0.85
        )
        reality2.add_event("Peaceful continental unification")
        reality2.add_event("Fusion energy breakthrough")
        
        # Unstable reality with different events
        reality3 = dimensional_registry.create_reality(
            dimension.dimension_id, name="Chaotic-Gamma", consistency=0.4
        )
        reality3.add_event("Global conflict eruption")
        reality3.add_event("Resource depletion crisis")
        
        realities = [reality1, reality2, reality3] + realities
    
    # Show the realities
    print("\nAvailable Realities:")
    for i, reality in enumerate(realities[:6]):  # Show up to 6 realities
        print(f"{i+1}. ID: {reality.reality_id}, Name: {reality.name}, " +
             f"Consistency: {reality.consistency:.2f}, Events: {len(reality.events)}")
    
    # Find compatible realities
    target_reality = realities[0]
    print(f"\nFinding realities compatible with {target_reality.name} (ID: {target_reality.reality_id})...")
    
    compatible = merger.find_compatible_realities(target_reality.reality_id, threshold=0.4)
    
    if compatible:
        print(f"Found {len(compatible)} compatible realities:")
        for reality, score in compatible:
            print(f"- {reality.name} (ID: {reality.reality_id}), Compatibility: {score:.2f}")
            
        # Perform merge with most compatible reality
        best_match, score = compatible[0]
        print(f"\nAttempting to merge {target_reality.name} with {best_match.name}...")
        
        # Try different merge types
        for merge_type_name in ["harmonic", "quantum_overlay", "resonance_collapse"]:
            merge_type = merger.get_merge_type(merge_type_name)
            print(f"\nAttempting {merge_type.name} merger...")
            
            result = merger.merge_realities(
                target_reality.reality_id,
                best_match.reality_id,
                merge_type_name
            )
            
            if result:
                # Show the new reality's properties
                print(f"New reality created: {result.name} (ID: {result.reality_id})")
                print(f"Events in new reality:")
                for event in result.events:
                    print(f"  - {event}")
    else:
        print("No compatible realities found.")
    
    # Generate report
    print("\n" + merger.generate_merge_report())
    
    return merger


if __name__ == "__main__":
    run_merger_demo()
