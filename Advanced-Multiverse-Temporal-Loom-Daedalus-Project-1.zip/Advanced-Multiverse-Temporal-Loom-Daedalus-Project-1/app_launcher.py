
"""
Multiverse Simulation System Launcher
This module serves as the main entry point for the application,
integrating the boot loader and launching the interface.
"""

import os
import sys
import time
from boot_loader import BootSequence
from menu_system import MenuSystem, SimulationSettings

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_welcome():
    """Display welcome message and application banner"""
    clear_screen()
    print("\n" + "=" * 70)
    print("               MULTIVERSE SIMULATION SYSTEM")
    print("     Temporal Physics and Quantum Field Theory Simulator")
    print("=" * 70)
    print("\nInitializing systems. Please wait...")

def launch_application():
    """Launch the complete application with boot sequence"""
    display_welcome()
    
    # Initialize the boot sequence
    boot = BootSequence()
    success = boot.boot(verbose=True)
    
    if not success:
        print("\nError: Boot sequence failed. System cannot start.")
        print(f"Boot status: {boot.status}")
        sys.exit(1)
    
    # Get the multiverse instance from boot sequence
    multiverse = boot.get_system("multiverse")
    if not multiverse:
        print("\nError: Multiverse system not initialized properly.")
        sys.exit(1)
    
    print("\nSystem initialized successfully. Launching user interface...")
    time.sleep(1)
    
    # Initialize settings
    settings = SimulationSettings()
    
    # Start the menu system with initialized components
    menu = MenuSystem(settings)
    menu.multiverse = multiverse  # Set the multiverse instance
    
    # Launch the main menu
    menu.main_menu()
    
    print("\nShutdown sequence initiated...")
    print("Multiverse Simulation System terminated.")

if __name__ == "__main__":
    try:
        launch_application()
    except KeyboardInterrupt:
        print("\n\nUser interrupted. Shutting down safely...")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        print("System terminated abnormally.")
