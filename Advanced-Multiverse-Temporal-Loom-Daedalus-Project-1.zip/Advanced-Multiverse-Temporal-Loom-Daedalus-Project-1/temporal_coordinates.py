
"""
Temporal Coordinates System
This module provides classes and utilities for handling space-time coordinates
in the multiverse, allowing precise targeting of time travel events.
"""

import datetime
from typing import List, Dict, Optional, Tuple, Any, Union
import random
import math

class SpatialCoordinate:
    """Represent a location in 3D space with uncertainty factors"""
    
    def __init__(self, x: float = 0.0, y: float = 0.0, z: float = 0.0, 
                 uncertainty: float = 0.0, reference_system: str = "Earth-Centered"):
        """
        Initialize spatial coordinates
        
        Args:
            x, y, z: Cartesian coordinates (in kilometers)
            uncertainty: Coordinate uncertainty factor (0.0 to 1.0)
            reference_system: The reference system for these coordinates
        """
        self.x = x
        self.y = y
        self.z = z
        self.uncertainty = min(1.0, max(0.0, uncertainty))
        self.reference_system = reference_system
    
    def distance_to(self, other: 'SpatialCoordinate') -> float:
        """Calculate Euclidean distance to another coordinate"""
        if self.reference_system != other.reference_system:
            return float('inf')  # Cannot compare different reference systems directly
            
        return math.sqrt((self.x - other.x)**2 + 
                         (self.y - other.y)**2 + 
                         (self.z - other.z)**2)
    
    def apply_uncertainty(self) -> 'SpatialCoordinate':
        """Return coordinates with random deviation based on uncertainty"""
        if self.uncertainty == 0:
            return SpatialCoordinate(self.x, self.y, self.z, 0, self.reference_system)
            
        # Deviation increases with uncertainty
        max_deviation = 100 * self.uncertainty  # km
        dx = random.uniform(-max_deviation, max_deviation)
        dy = random.uniform(-max_deviation, max_deviation)
        dz = random.uniform(-max_deviation, max_deviation)
        
        return SpatialCoordinate(
            self.x + dx,
            self.y + dy,
            self.z + dz,
            self.uncertainty,
            self.reference_system
        )
    
    def __str__(self) -> str:
        return f"({self.x:.2f}, {self.y:.2f}, {self.z:.2f}) ±{self.uncertainty:.2f} [{self.reference_system}]"


class TemporalCoordinate:
    """Represent a point in time with uncertainty factors"""
    
    def __init__(self, 
                 year: int, 
                 month: int = 1, 
                 day: int = 1, 
                 hour: int = 0, 
                 minute: int = 0, 
                 second: int = 0,
                 uncertainty_days: float = 0.0,
                 calendar_system: str = "Gregorian"):
        """
        Initialize temporal coordinates
        
        Args:
            year, month, day, hour, minute, second: Date and time components
            uncertainty_days: Temporal uncertainty in days
            calendar_system: The calendar system used
        """
        # Ensure valid date values before creating
        self.validate_date(year, month, day, hour, minute, second)
        
        self.year = year
        self.month = month
        self.day = day
        self.hour = hour
        self.minute = minute
        self.second = second
        self.uncertainty_days = max(0.0, uncertainty_days)
        self.calendar_system = calendar_system
        
        # Create datetime object (for Gregorian calendar only)
        if self.calendar_system == "Gregorian":
            try:
                self._datetime = datetime.datetime(
                    year, month, day, hour, minute, second)
            except ValueError:
                # Fall back to January 1st of the year if date is invalid
                self._datetime = datetime.datetime(year, 1, 1)
                self.month, self.day = 1, 1
                self.hour, self.minute, self.second = 0, 0, 0
        else:
            self._datetime = None
    
    @staticmethod
    def validate_date(year, month, day, hour, minute, second):
        """Validate date components and raise error if invalid"""
        if month < 1 or month > 12:
            raise ValueError(f"Invalid month: {month}")
        if day < 1 or day > 31:
            raise ValueError(f"Invalid day: {day}")
        if hour < 0 or hour > 23:
            raise ValueError(f"Invalid hour: {hour}")
        if minute < 0 or minute > 59:
            raise ValueError(f"Invalid minute: {minute}")
        if second < 0 or second > 59:
            raise ValueError(f"Invalid second: {second}")
    
    @classmethod
    def from_datetime(cls, dt: datetime.datetime, 
                     uncertainty_days: float = 0.0) -> 'TemporalCoordinate':
        """Create a TemporalCoordinate from a Python datetime object"""
        return cls(
            dt.year, dt.month, dt.day,
            dt.hour, dt.minute, dt.second,
            uncertainty_days, "Gregorian"
        )
    
    @classmethod
    def from_year(cls, year: int, 
                 uncertainty_days: float = 0.0) -> 'TemporalCoordinate':
        """Create a TemporalCoordinate with just the year"""
        return cls(year, 1, 1, 0, 0, 0, uncertainty_days, "Gregorian")
    
    def to_datetime(self) -> Optional[datetime.datetime]:
        """Convert to Python datetime if possible"""
        return self._datetime if self.calendar_system == "Gregorian" else None
    
    def days_between(self, other: 'TemporalCoordinate') -> Optional[float]:
        """Calculate days between two temporal coordinates"""
        if self.calendar_system != other.calendar_system:
            return None  # Cannot compare different calendar systems directly
            
        if self.calendar_system == "Gregorian" and other.calendar_system == "Gregorian":
            delta = other.to_datetime() - self.to_datetime()
            return delta.total_seconds() / (24 * 3600)  # Convert to days
            
        # Simplified calculation for non-Gregorian or mixed calendars
        # This is approximate and doesn't account for leap years etc.
        year_diff = other.year - self.year
        month_diff = other.month - self.month
        day_diff = other.day - self.day
        
        # Very approximate, just for relative comparisons
        return year_diff * 365 + month_diff * 30 + day_diff
    
    def apply_uncertainty(self) -> 'TemporalCoordinate':
        """Return date with random deviation based on uncertainty"""
        if self.uncertainty_days == 0 or self.calendar_system != "Gregorian":
            return self
            
        # Create a timedelta with random days within uncertainty range
        delta_days = random.uniform(-self.uncertainty_days, self.uncertainty_days)
        
        if self._datetime:
            new_datetime = self._datetime + datetime.timedelta(days=delta_days)
            return TemporalCoordinate.from_datetime(
                new_datetime, self.uncertainty_days)
        
        return self
    
    def __str__(self) -> str:
        time_str = f"{self.hour:02d}:{self.minute:02d}:{self.second:02d}" if any([self.hour, self.minute, self.second]) else ""
        date_str = f"{self.year}-{self.month:02d}-{self.day:02d}"
        uncertainty = f" ±{self.uncertainty_days:.1f} days" if self.uncertainty_days > 0 else ""
        return f"{date_str} {time_str} [{self.calendar_system}]{uncertainty}"


class SpaceTimeCoordinate:
    """
    Combined space and time coordinates for precise multiversal positioning
    """
    
    def __init__(self, 
                 spatial: SpatialCoordinate, 
                 temporal: TemporalCoordinate,
                 timeline_name: str,
                 quantum_signature: float = 0.0):
        """
        Initialize with spatial and temporal coordinates
        
        Args:
            spatial: The spatial coordinate
            temporal: The temporal coordinate
            timeline_name: The timeline this coordinate exists in
            quantum_signature: Quantum signature for identifying coordinates across timelines
        """
        self.spatial = spatial
        self.temporal = temporal
        self.timeline_name = timeline_name
        self.quantum_signature = quantum_signature
    
    @classmethod
    def random_earth_coordinate(cls, 
                               year_range: Tuple[int, int] = (1900, 2100),
                               timeline_name: str = "Alpha Prime") -> 'SpaceTimeCoordinate':
        """Generate a random coordinate on Earth in the given year range"""
        # Earth's radius is approximately 6371 km
        # Generate a random point on the sphere
        radius = 6371.0
        
        # Random angles
        theta = random.uniform(0, 2 * math.pi)  # longitude angle
        phi = random.uniform(0, math.pi)        # latitude angle
        
        # Convert to Cartesian coordinates
        x = radius * math.sin(phi) * math.cos(theta)
        y = radius * math.sin(phi) * math.sin(theta)
        z = radius * math.cos(phi)
        
        # Generate a random date in the year range
        year = random.randint(year_range[0], year_range[1])
        month = random.randint(1, 12)
        day = random.randint(1, 28)  # Simplified to avoid month length issues
        
        spatial = SpatialCoordinate(x, y, z, random.uniform(0, 0.2), "Earth-Centered")
        temporal = TemporalCoordinate(year, month, day, 
                                     random.randint(0, 23),
                                     random.randint(0, 59),
                                     random.randint(0, 59),
                                     random.uniform(0, 5))
        
        return cls(spatial, temporal, timeline_name, random.random())
    
    def calculate_transit_energy(self, destination: 'SpaceTimeCoordinate') -> float:
        """
        Calculate energy required to travel from this coordinate to another
        
        Returns a relative value where higher means more energy required
        """
        # Spatial distance component
        try:
            spatial_distance = self.spatial.distance_to(destination.spatial)
        except:
            spatial_distance = 1000  # Default if incompatible
        
        # Temporal distance component
        try:
            days_diff = abs(self.temporal.days_between(destination.temporal) or 365*10)
        except:
            days_diff = 365 * 10  # Default to 10 years if calculation fails
        
        # Timeline difference component (crossing timelines costs extra energy)
        timeline_factor = 1.0 if self.timeline_name == destination.timeline_name else 2.5
        
        # Combine factors - this is a simplified model
        base_energy = math.sqrt(spatial_distance) + (days_diff / 365)
        return base_energy * timeline_factor
    
    def stability_risk(self, destination: 'SpaceTimeCoordinate') -> float:
        """
        Calculate the stability risk of travel between coordinates
        
        Returns a value from 0.0 to 1.0, where higher is riskier
        """
        # Factors that increase risk:
        # 1. High uncertainty in either coordinate
        spatial_uncertainty = self.spatial.uncertainty + destination.spatial.uncertainty
        temporal_uncertainty = (self.temporal.uncertainty_days + 
                               destination.temporal.uncertainty_days) / 30  # Normalize to ~0-1
        
        # 2. Quantum signature difference
        quantum_diff = abs(self.quantum_signature - destination.quantum_signature)
        
        # 3. Very distant time travel
        time_factor = 0
        days = self.temporal.days_between(destination.temporal)
        if days:
            years_diff = abs(days) / 365
            time_factor = min(1.0, years_diff / 1000)  # Normalize with 1000 years as max
        
        # Combine all factors
        raw_risk = (0.3 * spatial_uncertainty + 
                   0.3 * temporal_uncertainty +
                   0.2 * quantum_diff +
                   0.2 * time_factor)
                   
        # Return normalized 0-1 risk
        return min(1.0, max(0.0, raw_risk))
    
    def __str__(self) -> str:
        return (f"Timeline: {self.timeline_name}\n"
                f"Space: {self.spatial}\n"
                f"Time: {self.temporal}\n"
                f"Quantum Signature: {self.quantum_signature:.4f}")


class CoordinateRegistry:
    """Registry of important space-time coordinates across the multiverse"""
    
    def __init__(self):
        self.coordinates = {}
        self.historical_events = {}
    
    def add_coordinate(self, name: str, coordinate: SpaceTimeCoordinate):
        """Register a named coordinate"""
        self.coordinates[name] = coordinate
    
    def get_coordinate(self, name: str) -> Optional[SpaceTimeCoordinate]:
        """Retrieve a coordinate by name"""
        return self.coordinates.get(name)
    
    def add_historical_event(self, event_name: str, coordinate: SpaceTimeCoordinate):
        """Register a coordinate for a historical event"""
        self.historical_events[event_name] = coordinate
    
    def get_historical_event(self, event_name: str) -> Optional[SpaceTimeCoordinate]:
        """Get coordinate for a historical event"""
        return self.historical_events.get(event_name)
    
    def find_nearest_coordinates(self, 
                                target: SpaceTimeCoordinate, 
                                max_results: int = 5,
                                same_timeline_only: bool = False) -> List[Tuple[str, SpaceTimeCoordinate, float]]:
        """
        Find the nearest registered coordinates to the target
        Returns list of (name, coordinate, energy_cost) tuples
        """
        results = []
        
        for name, coord in {**self.coordinates, **self.historical_events}.items():
            if same_timeline_only and coord.timeline_name != target.timeline_name:
                continue
                
            energy = target.calculate_transit_energy(coord)
            results.append((name, coord, energy))
        
        # Sort by energy cost
        results.sort(key=lambda x: x[2])
        return results[:max_results]
    
    def find_stable_routes(self, 
                          origin: SpaceTimeCoordinate, 
                          destination: SpaceTimeCoordinate,
                          max_jumps: int = 3) -> List[List[Tuple[str, SpaceTimeCoordinate]]]:
        """
        Find stable routes between two coordinates using registered waypoints
        Returns list of possible routes, each a list of (name, coordinate) tuples
        """
        if max_jumps <= 0:
            return []
            
        # Direct route
        direct_energy = origin.calculate_transit_energy(destination)
        direct_risk = origin.stability_risk(destination)
        
        routes = []
        
        # If direct route is reasonably safe, include it
        if direct_risk < 0.7:
            routes.append([("Direct", destination)])
        
        # Only look for indirect routes if we can do multiple jumps
        if max_jumps > 1:
            # Find potential waypoints
            all_points = list(self.coordinates.items()) + list(self.historical_events.items())
            
            for name, waypoint in all_points:
                # Skip if waypoint is too risky from origin
                if origin.stability_risk(waypoint) >= 0.8:
                    continue
                    
                # Recursively find routes from waypoint to destination
                sub_routes = self.find_stable_routes(waypoint, destination, max_jumps - 1)
                
                # Add this waypoint to the front of each route
                for route in sub_routes:
                    full_route = [(name, waypoint)] + route
                    routes.append(full_route)
        
        return routes[:5]  # Limit to top 5 routes
