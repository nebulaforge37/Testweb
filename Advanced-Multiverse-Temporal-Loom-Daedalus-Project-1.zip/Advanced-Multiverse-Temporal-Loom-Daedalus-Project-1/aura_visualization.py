
"""
Temporal Aura Visualization Tool
This module provides simple text-based visualization for temporal auras.
"""

import math
import random
import time
from temporal_aura import TemporalAura, AuraDetector


def visualize_aura_text(aura: TemporalAura, width: int = 40, height: int = 15) -> str:
    """
    Generate a simple text-based visualization of a temporal aura
    
    Args:
        aura: The temporal aura to visualize
        width: Width of the visualization
        height: Height of the visualization
        
    Returns:
        String containing the text visualization
    """
    # Characters for different intensity levels (from low to high)
    chars = ' .·•○●★'
    
    # Map colors to ANSI color codes
    color_codes = {
        "red": 91,
        "orange": 33,
        "yellow": 93,
        "green": 92,
        "blue": 94,
        "indigo": 95,
        "violet": 35,
        "ultraviolet": 96,
        "infrared": 31
    }
    
    # Create the canvas
    canvas = [[' ' for _ in range(width)] for _ in range(height)]
    
    # Calculate center
    center_x = width // 2
    center_y = height // 2
    
    # Aura radius is proportional to strength
    max_radius = min(width, height) // 2 - 1
    aura_radius = int(max_radius * (0.5 + aura.strength * 0.5))
    
    # Function to get color at a specific angle based on color spectrum
    def get_color_at_angle(angle_degrees):
        # Normalize angle to 0-360
        angle_degrees = angle_degrees % 360
        
        # Map angle to colors in the spectrum (simple mapping)
        color_map = {
            "red": (0, 30),
            "orange": (30, 60),
            "yellow": (60, 120),
            "green": (120, 180),
            "blue": (180, 240),
            "indigo": (240, 270),
            "violet": (270, 330),
            "infrared": (330, 345),
            "ultraviolet": (345, 360)
        }
        
        # Find which color range the angle falls into
        for color, (start, end) in color_map.items():
            if start <= angle_degrees < end:
                return color
        
        return "red"  # Default
    
    # Fill the canvas with aura
    for y in range(height):
        for x in range(width):
            # Calculate distance from center
            dx = x - center_x
            dy = y - center_y
            distance = math.sqrt(dx*dx + dy*dy)
            
            if distance <= aura_radius:
                # Calculate angle for this point
                angle = math.degrees(math.atan2(dy, dx)) + 180
                color = get_color_at_angle(angle)
                
                # Calculate intensity based on distance from center and aura properties
                # More stable auras have smoother falloff
                if aura.stability > 0.7:
                    intensity = 1.0 - (distance / aura_radius) ** 1.5
                else:
                    # Less stable auras have more variance
                    noise = random.uniform(-0.2, 0.2) * (1.0 - aura.stability)
                    intensity = 1.0 - (distance / aura_radius) + noise
                
                # Add complexity-based variation
                if aura.complexity > 0.5:
                    # Higher complexity creates patterns
                    variation = 0.2 * math.sin(distance * aura.complexity * 0.5) * math.sin(angle * 0.05)
                    intensity += variation
                
                # Constrain intensity
                intensity = max(0.0, min(1.0, intensity * aura.strength))
                
                # Map intensity to character
                char_index = min(len(chars) - 1, int(intensity * (len(chars) - 1)))
                
                # Add the character to the canvas
                canvas[y][x] = f"\033[{color_codes.get(color, 37)}m{chars[char_index]}\033[0m"
    
    # Add past shadows
    for shadow in range(aura.past_shadows):
        # Past shadows appear behind (to the left of) the main aura
        shadow_x = max(0, center_x - aura_radius - shadow - 2)
        shadow_y = center_y
        
        if 0 <= shadow_x < width and 0 <= shadow_y < height:
            canvas[shadow_y][shadow_x] = f"\033[90m◐\033[0m"  # Gray half-circle
    
    # Add future echoes
    for echo in range(aura.future_echoes):
        # Future echoes appear ahead (to the right of) the main aura
        echo_x = min(width - 1, center_x + aura_radius + echo + 2)
        echo_y = center_y
        
        if 0 <= echo_x < width and 0 <= echo_y < height:
            canvas[echo_y][echo_x] = f"\033[97m◑\033[0m"  # White half-circle
    
    # Add entity name at the bottom
    name = aura.entity_name
    if len(name) > width:
        name = name[:width-3] + "..."
        
    name_start = center_x - len(name) // 2
    name_start = max(0, min(width - len(name), name_start))
    
    for i, char in enumerate(name):
        if name_start + i < width:
            canvas[height - 1][name_start + i] = char
    
    # Convert canvas to string
    result = ""
    for row in canvas:
        result += ''.join(row) + "\n"
    
    # Add aura information
    result += f"\nStrength: {aura.strength:.2f} | Stability: {aura.stability:.2f} | " \
             f"Complexity: {aura.complexity:.2f}\n"
    result += f"Dominant Color: {aura.get_dominant_color()} | " \
             f"Past Shadows: {aura.past_shadows} | Future Echoes: {aura.future_echoes}\n"
    
    return result


def visualize_aura_interference(aura: TemporalAura, interference_field: 'AuraInterferenceField',
                               width: int = 40, height: int = 15) -> str:
    """
    Visualize an aura with and without interference for comparison
    
    Args:
        aura: The original aura
        interference_field: The interference field
        width: Width of each visualization
        height: Height of each visualization
        
    Returns:
        String containing both visualizations side by side
    """
    from temporal_aura import AuraInterferenceField
    
    # Get the original aura visualization
    original_viz = visualize_aura_text(aura, width, height).split('\n')
    
    # Apply interference and get the modified aura
    modified_aura = interference_field.apply_to_aura(aura)
    modified_viz = visualize_aura_text(modified_aura, width, height).split('\n')
    
    # Combine visualizations side by side
    combined = []
    max_lines = max(len(original_viz), len(modified_viz))
    
    combined.append(f"{'Original Aura':<{width}} | {'Aura with Interference':<{width}}")
    combined.append('-' * (width * 2 + 3))
    
    for i in range(max_lines):
        orig_line = original_viz[i] if i < len(original_viz) else ' ' * width
        mod_line = modified_viz[i] if i < len(modified_viz) else ' ' * width
        combined.append(f"{orig_line} | {mod_line}")
    
    # Add information about the interference field
    combined.append('')
    combined.append(f"Interference Field: {interference_field.field_mode.capitalize()} mode, " 
                   f"Strength: {interference_field.field_strength:.2f}")
    
    return '\n'.join(combined)


def visualize_aura_comparison(aura1: TemporalAura, aura2: TemporalAura, 
                             detector: AuraDetector = None, width: int = 30, 
                             height: int = 12) -> str:
    """
    Visualize a comparison between two auras
    
    Args:
        aura1: First aura
        aura2: Second aura
        detector: Optional detector to provide similarity analysis
        width: Width of each visualization
        height: Height of each visualization
        
    Returns:
        String containing both visualizations and comparison info
    """
    # Get individual visualizations
    viz1 = visualize_aura_text(aura1, width, height).split('\n')
    viz2 = visualize_aura_text(aura2, width, height).split('\n')
    
    # Combine visualizations side by side
    combined = []
    max_lines = max(len(viz1), len(viz2))
    
    combined.append(f"{aura1.entity_name:<{width}} | {aura2.entity_name:<{width}}")
    combined.append('-' * (width * 2 + 3))
    
    for i in range(max_lines):
        line1 = viz1[i] if i < len(viz1) else ' ' * width
        line2 = viz2[i] if i < len(viz2) else ' ' * width
        combined.append(f"{line1} | {line2}")
    
    # Add comparison information
    if detector:
        comparison = detector.compare_auras(aura1.entity_name, aura2.entity_name)
        combined.append('')
        combined.append(f"Similarity: {comparison['similarity_score']:.2f} - {comparison['relationship_assessment']}")
        combined.append(f"Same Timeline Probability: {comparison['same_timeline_probability']:.2f}")
        
        # Add details of comparison
        details = comparison['details']
        combined.append(f"Strength Difference: {details['strength_difference']:.2f}, "
                       f"Stability Difference: {details['stability_difference']:.2f}")
        combined.append(f"Color Similarity: {details['color_similarity']:.2f}, "
                       f"Temporal Similarity: {details['temporal_similarity']:.2f}")
    else:
        # Basic comparison without detector
        combined.append('')
        combined.append("Timeline Comparison:")
        combined.append(f"Same Timeline: {'Yes' if aura1.timeline_name == aura2.timeline_name else 'No'}")
        
        # Simple metrics
        strength_diff = abs(aura1.strength - aura2.strength)
        stability_diff = abs(aura1.stability - aura2.stability)
        complexity_diff = abs(aura1.complexity - aura2.complexity)
        
        combined.append(f"Strength Difference: {strength_diff:.2f}, "
                       f"Stability Difference: {stability_diff:.2f}, "
                       f"Complexity Difference: {complexity_diff:.2f}")
    
    return '\n'.join(combined)


def visualize_merged_aura(aura1: TemporalAura, aura2: TemporalAura,
                         width: int = 40, height: int = 15) -> str:
    """
    Visualize the merging of two auras
    
    Args:
        aura1: First aura
        aura2: Second aura
        width: Width of visualization
        height: Height of visualization
        
    Returns:
        String containing the visualization of the merger process
    """
    # Get individual visualizations
    viz1 = visualize_aura_text(aura1, width, height).split('\n')
    viz2 = visualize_aura_text(aura2, width, height).split('\n')
    
    # Create merged aura
    merged_aura = aura1.merge_with_aura(aura2)
    viz_merged = visualize_aura_text(merged_aura, width, height).split('\n')
    
    # Setup output
    combined = []
    combined.append("=== Aura Merger Visualization ===")
    combined.append('')
    
    # First row: Original auras side by side
    combined.append(f"{aura1.entity_name:<{width}} | {aura2.entity_name:<{width}}")
    combined.append('-' * (width * 2 + 3))
    
    max_lines = max(len(viz1), len(viz2))
    for i in range(max_lines):
        line1 = viz1[i] if i < len(viz1) else ' ' * width
        line2 = viz2[i] if i < len(viz2) else ' ' * width
        combined.append(f"{line1} | {line2}")
    
    # Divider
    combined.append('')
    combined.append('↓' * width + '   ' + '↓' * width)
    combined.append('')
    
    # Second row: Merged aura
    combined.append(f"{merged_aura.entity_name:^{width*2+3}}")
    combined.append('-' * (width * 2 + 3))
    
    # Center the merged visualization
    padding = ' ' * ((width * 2 + 3 - width) // 2)
    for i in range(len(viz_merged)):
        combined.append(f"{padding}{viz_merged[i]}")
    
    # Summary
    combined.append('')
    combined.append(f"Merger Results:")
    combined.append(f"Strength: {aura1.strength:.2f} + {aura2.strength:.2f} → {merged_aura.strength:.2f}")
    combined.append(f"Stability: {aura1.stability:.2f} + {aura2.stability:.2f} → {merged_aura.stability:.2f}")
    combined.append(f"Complexity: {aura1.complexity:.2f} + {aura2.complexity:.2f} → {merged_aura.complexity:.2f}")
    combined.append(f"Timeline: {merged_aura.timeline_name}")
    
    return '\n'.join(combined)


def demo_aura_visualization():
    """Run a demonstration of the aura visualization capabilities"""
    from temporal_aura import TemporalAura, AuraDetector, AuraInterferenceField
    
    print("=== Temporal Aura Visualization Demo ===\n")
    
    # Create sample auras
    stable_aura = TemporalAura("Stable Entity", "Prime Timeline", 0.8, 0.5, 0.9)
    unstable_aura = TemporalAura("Unstable Entity", "Fractured Timeline", 0.7, 0.8, 0.3)
    
    # Create a detector and interference field
    detector = AuraDetector(0.9, 0.9)
    interference = AuraInterferenceField(0.6, 5.0)
    
    # Visualize individual auras
    print(visualize_aura_text(stable_aura))
    print("\n" + "="*50 + "\n")
    
    print(visualize_aura_text(unstable_aura))
    print("\n" + "="*50 + "\n")
    
    # Visualize with interference
    print(visualize_aura_interference(stable_aura, interference))
    print("\n" + "="*50 + "\n")
    
    # Visualize comparison
    print(visualize_aura_comparison(stable_aura, unstable_aura, detector))
    print("\n" + "="*50 + "\n")
    
    # Visualize merger
    print(visualize_merged_aura(stable_aura, unstable_aura))


if __name__ == "__main__":
    demo_aura_visualization()



class TemporalAuraVisualizer:
    """Graphical visualizer for temporal auras using tkinter"""
    
    def __init__(self, parent, width=800, height=600):
        """Initialize the visualizer"""
        import tkinter as tk
        
        self.parent = parent
        self.width = width
        self.height = height
        
        # Create canvas for visualization
        self.canvas = tk.Canvas(parent, width=width, height=height, bg="#0A1128")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Store visualization state
        self.auras = {}
        self.connections = []
        self.animation_id = None
        self.animation_frame = 0
        
        # Start animation
        self.animate()
    
    def add_aura(self, entity_name, strength=0.7, stability=0.8, complexity=0.5):
        """Add an aura to the visualization"""
        from temporal_aura import TemporalAura
        
        if entity_name not in self.auras:
            timeline_name = f"Timeline-{len(self.auras) + 1}"
            aura = TemporalAura(entity_name, timeline_name, strength, complexity, stability)
            
            # Random position in the canvas
            import random
            x = random.randint(100, self.width - 100)
            y = random.randint(100, self.height - 100)
            
            self.auras[entity_name] = {
                "aura": aura,
                "x": x,
                "y": y,
                "pulse": 0,
                "pulse_direction": 1
            }
            
            return True
        return False
    
    def remove_aura(self, entity_name):
        """Remove an aura from the visualization"""
        if entity_name in self.auras:
            del self.auras[entity_name]
            
            # Remove any connections involving this aura
            self.connections = [c for c in self.connections 
                              if c[0] != entity_name and c[1] != entity_name]
            return True
        return False
    
    def connect_auras(self, entity1, entity2, strength=0.5):
        """Create a connection between two auras"""
        if entity1 in self.auras and entity2 in self.auras:
            self.connections.append((entity1, entity2, strength))
            return True
        return False
    
    def animate(self):
        """Animation loop for the visualization"""
        import tkinter as tk
        
        self.canvas.delete("all")
        self.animation_frame += 1
        
        # Draw connections first (so they're behind the auras)
        for entity1, entity2, strength in self.connections:
            if entity1 in self.auras and entity2 in self.auras:
                x1 = self.auras[entity1]["x"]
                y1 = self.auras[entity1]["y"]
                x2 = self.auras[entity2]["x"]
                y2 = self.auras[entity2]["y"]
                
                # Connection color based on strength
                import colorsys
                hue = 0.6 + (strength * 0.4)  # Blue to purple
                r, g, b = colorsys.hsv_to_rgb(hue, 0.8, 0.9)
                color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
                
                # Draw connection line with animated dash pattern
                dash_offset = (self.animation_frame % 20) * (1 if strength > 0.5 else -1)
                self.canvas.create_line(
                    x1, y1, x2, y2, fill=color, width=2 + int(strength * 3),
                    dash=(5, 5), dashoffset=dash_offset
                )
        
        # Draw each aura
        for entity_name, data in self.auras.items():
            aura = data["aura"]
            x = data["x"]
            y = data["y"]
            
            # Update pulse animation
            data["pulse"] += 0.05 * data["pulse_direction"]
            if data["pulse"] >= 1.0:
                data["pulse"] = 1.0
                data["pulse_direction"] = -1
            elif data["pulse"] <= 0.0:
                data["pulse"] = 0.0
                data["pulse_direction"] = 1
            
            pulse = data["pulse"]
            
            # Draw multiple aura layers
            for i in range(5):
                # Size based on aura strength and layer
                size = 20 + (80 * aura.strength) - (i * 10)
                size += pulse * 10  # Add pulse animation
                
                # Color based on aura properties
                import math
                
                # Hue based on stability (red=unstable, green=stable)
                hue = aura.stability * 0.3  # 0.0-0.3 (red to green-yellow)
                
                # Saturation based on complexity
                sat = 0.5 + (aura.complexity * 0.5)
                
                # Value darkens for outer rings
                val = 0.9 - (i * 0.15)
                
                r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
                
                # Alpha depends on layer and pulse
                alpha = int((0.8 - (i * 0.15) + (pulse * 0.2)) * 255)
                
                color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}{alpha:02x}"
                
                # Draw aura layer
                self.canvas.create_oval(
                    x - size, y - size, x + size, y + size,
                    fill=color, outline=""
                )
            
            # Draw center
            center_size = 15
            self.canvas.create_oval(
                x - center_size, y - center_size, x + center_size, y + center_size,
                fill="#FFFFFF", outline="#80C0FF", width=2
            )
            
            # Draw name
            self.canvas.create_text(
                x, y + center_size + 20, text=entity_name, fill="white",
                font=("Arial", 10, "bold")
            )
            
            # Draw timeline name
            self.canvas.create_text(
                x, y + center_size + 35, text=aura.timeline_name, fill="#AAAAFF",
                font=("Arial", 8)
            )
            
            # Draw stability indicator
            if aura.stability < 0.5:
                if self.animation_frame % 20 < 10:
                    self.canvas.create_text(
                        x, y - center_size - 20, text="⚠ Unstable", fill="#FF6060",
                        font=("Arial", 9, "bold")
                    )
        
        # Schedule next animation frame
        self.animation_id = self.canvas.after(50, self.animate)
    
    def stop_animation(self):
        """Stop the animation loop"""
        if self.animation_id:
            self.canvas.after_cancel(self.animation_id)
            self.animation_id = None
    
    def clear(self):
        """Clear all auras and connections"""
        self.auras = {}
        self.connections = []
        self.canvas.delete("all")

