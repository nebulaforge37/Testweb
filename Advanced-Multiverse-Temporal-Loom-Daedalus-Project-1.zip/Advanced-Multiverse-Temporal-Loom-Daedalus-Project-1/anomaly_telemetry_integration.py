
"""
Anomaly Telemetry Integration
Integrates the Timewave system with the Telemetry Anomaly Tracker
to provide comprehensive temporal anomaly monitoring.
"""

import random
import time
from typing import List, Dict, Any, Optional
from timewave import Timewave, TimewaveManager
from telemetry_anomaly_tracker import TelemetryAnomalyTracker, TemporalAnomaly
from multiverse_telemetry import MultiverseTelemetry, TelemetrySignal, SpaceTimeCoordinate
from temporal_coordinates import TemporalCoordinate, SpatialCoordinate

class AnomalyWave:
    """Represents an anomaly that generates timewaves"""
    
    def __init__(self, anomaly: TemporalAnomaly, wave_manager: TimewaveManager):
        """
        Initialize an anomaly-generated wave
        
        Args:
            anomaly: The source anomaly
            wave_manager: The timewave manager to use
        """
        self.anomaly = anomaly
        self.wave_manager = wave_manager
        self.generated_waves = []
        self.last_generation = 0
        self.generation_interval = random.uniform(5, 15)  # Seconds between waves
        self.stability_impact = 0.0
        
    def update(self) -> Optional[Timewave]:
        """
        Update the anomaly wave and possibly generate new timewaves
        
        Returns:
            Newly generated timewave, if any
        """
        # Skip if anomaly is contained or resolved
        if self.anomaly.containment_level > 0.8 or not self.anomaly.is_active():
            return None
            
        current_time = time.time()
        
        # Check if it's time to generate a new wave
        if current_time - self.last_generation < self.generation_interval:
            return None
            
        # Generate a new timewave based on the anomaly
        current_magnitude = self.anomaly.get_current_magnitude()
        
        # Stronger anomalies generate stronger waves
        wave_strength = current_magnitude * random.uniform(0.8, 1.2)
        
        # Description based on anomaly type
        description = f"Anomaly-induced wave from {self.anomaly.type} #{self.anomaly.anomaly_id}"
        
        # Create the wave using the manager
        success, wave = self.wave_manager.create_timewave(
            self.anomaly.timeline_name,
            self.anomaly.year,
            wave_strength,
            description
        )
        
        if success and wave:
            self.generated_waves.append(wave)
            self.last_generation = current_time
            
            # Calculate stability impact
            self.stability_impact += current_magnitude * 0.05
            
            return wave
            
        return None
        
    def get_current_status(self) -> Dict[str, Any]:
        """Get current status of this anomaly wave"""
        return {
            "anomaly_id": self.anomaly.anomaly_id,
            "anomaly_type": self.anomaly.type,
            "timeline": self.anomaly.timeline_name,
            "year": self.anomaly.year,
            "current_magnitude": self.anomaly.get_current_magnitude(),
            "containment_level": self.anomaly.containment_level,
            "waves_generated": len(self.generated_waves),
            "cumulative_impact": self.stability_impact
        }


class TimeWaveAnomalyIntegrator:
    """Integrates timewave and anomaly functionality"""
    
    def __init__(self, 
                wave_manager: TimewaveManager = None,
                anomaly_tracker: TelemetryAnomalyTracker = None,
                telemetry: MultiverseTelemetry = None):
        """
        Initialize the integrator
        
        Args:
            wave_manager: TimewaveManager instance
            anomaly_tracker: TelemetryAnomalyTracker instance
            telemetry: MultiverseTelemetry instance
        """
        self.wave_manager = wave_manager or TimewaveManager()
        self.anomaly_tracker = anomaly_tracker or TelemetryAnomalyTracker()
        self.telemetry = telemetry or MultiverseTelemetry()
        
        self.anomaly_waves = {}  # Dict of anomaly_id: AnomalyWave
        self.wave_induced_anomalies = {}  # Dict of wave_id: anomaly_id
        self.last_update = time.time()
        self.update_interval = 1.0  # Seconds between updates
        
    def link_anomaly_to_waves(self, anomaly_id: int) -> Optional[AnomalyWave]:
        """
        Create a link between an anomaly and timewave generation
        
        Args:
            anomaly_id: ID of the anomaly to link
            
        Returns:
            AnomalyWave object if successful, None otherwise
        """
        anomaly = self.anomaly_tracker.get_anomaly(anomaly_id)
        
        if not anomaly or not anomaly.is_active():
            return None
            
        # Create anomaly wave
        anomaly_wave = AnomalyWave(anomaly, self.wave_manager)
        self.anomaly_waves[anomaly_id] = anomaly_wave
        
        return anomaly_wave
        
    def detect_wave_anomalies(self) -> List[TemporalAnomaly]:
        """
        Detect anomalies caused by timewaves
        
        Returns:
            List of newly created anomalies
        """
        new_anomalies = []
        
        # Skip if no wave manager
        if not self.wave_manager:
            return []
            
        # Check active waves that might cause anomalies
        active_waves = self.wave_manager.get_active_waves()
        
        for wave in active_waves:
            # Skip if already linked to an anomaly
            wave_id = id(wave)
            if wave_id in self.wave_induced_anomalies:
                continue
                
            # Stronger waves have higher chance of causing anomalies
            chance = wave.strength * 0.3
            
            if random.random() < chance:
                # Create a new anomaly from this wave
                description = f"Timewave-induced anomaly from {wave.description}"
                
                # Create in one of the affected timelines
                if wave.affected_timelines:
                    # Choose a random affected timeline
                    effect = random.choice(wave.affected_timelines)
                    timeline_name = effect['timeline_name']
                    
                    # Create the anomaly
                    anomaly = self.anomaly_tracker.create_anomaly(
                        timeline_name,
                        wave.year,
                        magnitude=wave.strength * random.uniform(0.6, 0.9),
                        description=description
                    )
                    
                    # Link them
                    self.wave_induced_anomalies[wave_id] = anomaly.anomaly_id
                    
                    new_anomalies.append(anomaly)
        
        return new_anomalies
        
    def generate_telemetry_for_anomalies(self) -> List[TelemetrySignal]:
        """
        Generate telemetry signals for anomalies
        
        Returns:
            List of generated telemetry signals
        """
        generated_signals = []
        
        # Skip if no telemetry system
        if not self.telemetry:
            return []
            
        # Get active anomalies
        active_anomalies = self.anomaly_tracker.get_active_anomalies()
        
        for anomaly in active_anomalies:
            # Skip low magnitude anomalies
            if anomaly.get_current_magnitude() < 0.3:
                continue
                
            # Create a unique entity ID for this anomaly
            entity_id = f"Anomaly-{anomaly.anomaly_id}"
            
            # Register if not already registered
            self.telemetry.register_entity(entity_id, {
                "type": "temporal_anomaly",
                "anomaly_type": anomaly.type,
                "description": anomaly.description
            })
            
            # Create spatial coordinates (can be random if none provided)
            if anomaly.coordinates:
                spatial = anomaly.coordinates
            else:
                # Random coordinates
                spatial = SpatialCoordinate(
                    random.uniform(-10000, 10000),
                    random.uniform(-10000, 10000),
                    random.uniform(-1000, 1000),
                    uncertainty=anomaly.get_current_magnitude() * 100,
                    reference_system="Earth-Centered"
                )
                
            # Create temporal coordinates
            temporal = TemporalCoordinate(
                anomaly.year,
                random.randint(1, 12),
                random.randint(1, 28)
            )
            
            # Create space-time coordinate
            coordinate = SpaceTimeCoordinate(
                spatial, temporal, anomaly.timeline_name,
                quantum_signature=random.random()
            )
            
            # Create telemetry signal
            signal = TelemetrySignal(
                entity_id,
                coordinate,
                signal_strength=anomaly.get_current_magnitude(),
                metadata={
                    "anomaly_id": anomaly.anomaly_id,
                    "anomaly_type": anomaly.type,
                    "magnitude": anomaly.get_current_magnitude(),
                    "containment": anomaly.containment_level
                }
            )
            
            # Record the signal
            self.telemetry.record_signal(signal)
            
            # Add signal to anomaly's telemetry
            anomaly.add_telemetry_signal(signal)
            
            generated_signals.append(signal)
        
        return generated_signals
        
    def update(self) -> Dict[str, Any]:
        """
        Update the integrator, processing waves and anomalies
        
        Returns:
            Dictionary with update statistics
        """
        current_time = time.time()
        
        # Only update at the specified interval
        if current_time - self.last_update < self.update_interval:
            return {
                "skipped": True,
                "time_to_next": self.update_interval - (current_time - self.last_update)
            }
            
        self.last_update = current_time
        
        # Update stats
        stats = {
            "new_anomalies": 0,
            "new_waves": 0,
            "signals_generated": 0,
            "active_anomalies": 0,
            "active_waves": 0
        }
        
        # Process anomaly-induced waves
        new_waves = []
        for anomaly_id, anomaly_wave in list(self.anomaly_waves.items()):
            wave = anomaly_wave.update()
            if wave:
                new_waves.append(wave)
                stats["new_waves"] += 1
                
        # Detect wave-induced anomalies
        new_anomalies = self.detect_wave_anomalies()
        stats["new_anomalies"] = len(new_anomalies)
        
        # For newly detected anomalies, create anomaly waves
        for anomaly in new_anomalies:
            self.link_anomaly_to_waves(anomaly.anomaly_id)
            
        # Generate telemetry signals for anomalies
        signals = self.generate_telemetry_for_anomalies()
        stats["signals_generated"] = len(signals)
        
        # Scan for new anomalies in telemetry
        telemetry_anomalies = self.anomaly_tracker.scan_for_anomalies()
        stats["new_anomalies"] += len(telemetry_anomalies)
        
        # Link new telemetry anomalies to waves
        for anomaly in telemetry_anomalies:
            self.link_anomaly_to_waves(anomaly.anomaly_id)
            
        # Update counts
        if self.wave_manager:
            stats["active_waves"] = len(self.wave_manager.get_active_waves())
            
        if self.anomaly_tracker:
            stats["active_anomalies"] = len(self.anomaly_tracker.get_active_anomalies())
            
        return stats
        
    def get_integration_report(self) -> str:
        """Generate a report on the integration status"""
        anomaly_count = len(self.anomaly_tracker.get_active_anomalies()) if self.anomaly_tracker else 0
        wave_count = len(self.wave_manager.get_active_waves()) if self.wave_manager else 0
        anomaly_wave_count = len(self.anomaly_waves)
        wave_induced_count = len(self.wave_induced_anomalies)
        
        report = ["=== TIMEWAVE-ANOMALY INTEGRATION REPORT ==="]
        report.append(f"Active Anomalies: {anomaly_count}")
        report.append(f"Active Timewaves: {wave_count}")
        report.append(f"Anomaly-Wave Links: {anomaly_wave_count}")
        report.append(f"Wave-Induced Anomalies: {wave_induced_count}")
        
        # Add anomaly-wave details
        if self.anomaly_waves:
            report.append("\nAnomaly-Generated Waves:")
            
            for anomaly_id, anomaly_wave in self.anomaly_waves.items():
                status = anomaly_wave.get_current_status()
                report.append(f"- Anomaly #{status['anomaly_id']} ({status['anomaly_type']})")
                report.append(f"  Timeline: {status['timeline']}, Year: {status['year']}")
                report.append(f"  Generated {status['waves_generated']} waves (Impact: {status['cumulative_impact']:.2f})")
        
        # Add wave-induced anomaly details
        if self.wave_induced_anomalies:
            report.append("\nWave-Induced Anomalies:")
            
            for wave_id, anomaly_id in list(self.wave_induced_anomalies.items())[:5]:  # Show top 5
                anomaly = self.anomaly_tracker.get_anomaly(anomaly_id)
                if anomaly:
                    report.append(f"- Anomaly #{anomaly_id} ({anomaly.type})")
                    report.append(f"  Timeline: {anomaly.timeline_name}, Magnitude: {anomaly.get_current_magnitude():.2f}")
                    
        # Add timeline risk summary
        if self.anomaly_tracker and hasattr(self.anomaly_tracker, 'timeline_risk_levels'):
            report.append("\nTimeline Risk Summary:")
            
            for timeline, risk in self.anomaly_tracker.timeline_risk_levels.items():
                report.append(f"- {timeline}: {risk.get('level', 'Unknown')} risk (Score: {risk.get('score', 0):.1f})")
        
        return "\n".join(report)


def run_integration_demo(multiverse = None):
    """Run a demonstration of the timewave-anomaly integration"""
    from sacred_timeline import SacredTimeline
    import time
    
    print("=== Timewave-Anomaly Integration Demonstration ===")
    
    # Create mock timelines if multiverse not provided
    if not multiverse:
        timelines = {
            "Alpha": SacredTimeline("Alpha", 0.8),
            "Beta": SacredTimeline("Beta", 0.7),
            "Gamma": SacredTimeline("Gamma", 0.9),
            "Delta": SacredTimeline("Delta", 0.6)
        }
        
        # Add some events to the timelines
        timelines["Alpha"].add_nexus_point(2020, "Quantum Revolution", 0.8)
        timelines["Beta"].add_nexus_point(2025, "Temporal Disruption", 0.7)
        timelines["Gamma"].add_nexus_point(2030, "Dimensional Shift", 0.9)
        
        # Create a mock multiverse with these timelines
        class MockMultiverse:
            def __init__(self, timelines):
                self.timelines = timelines
        
        multiverse = MockMultiverse(timelines)
    
    # Create telemetry, wave manager and anomaly tracker
    telemetry = MultiverseTelemetry(multiverse)
    wave_manager = TimewaveManager(multiverse)
    anomaly_tracker = TelemetryAnomalyTracker(telemetry)
    
    # Create the integrator
    integrator = TimeWaveAnomalyIntegrator(wave_manager, anomaly_tracker, telemetry)
    
    # Create some initial waves and anomalies
    print("\nCreating initial waves and anomalies...")
    
    # Create waves
    wave1 = wave_manager.create_timewave("Alpha", 2020, 1.2, "Quantum breakthrough experiment")[1]
    wave2 = wave_manager.create_timewave("Beta", 2025, 0.8, "Temporal anomaly detection")[1]
    
    print(f"Created wave: {wave1}")
    print(f"Created wave: {wave2}")
    
    # Create anomalies
    anomaly1 = anomaly_tracker.create_anomaly(
        "Alpha", 2021, 0.7, "Quantum field destabilization"
    )
    
    anomaly2 = anomaly_tracker.create_anomaly(
        "Gamma", 2035, 0.9, "Paradox singularity formation"
    )
    
    print(f"Created anomaly: {anomaly1}")
    print(f"Created anomaly: {anomaly2}")
    
    # Link anomalies to wave generation
    print("\nLinking anomalies to wave generation...")
    integrator.link_anomaly_to_waves(anomaly1.anomaly_id)
    integrator.link_anomaly_to_waves(anomaly2.anomaly_id)
    
    # Run several integration cycles
    print("\nRunning integration cycles...")
    for i in range(5):
        print(f"\n--- Cycle {i+1} ---")
        stats = integrator.update()
        
        print(f"New anomalies: {stats['new_anomalies']}")
        print(f"New waves: {stats['new_waves']}")
        print(f"Signals generated: {stats['signals_generated']}")
        print(f"Active anomalies: {stats['active_anomalies']}")
        print(f"Active waves: {stats['active_waves']}")
        
        # Propagate waves
        if wave_manager:
            effects = wave_manager.propagate_all_waves()
            if effects:
                print(f"\nTimewave effects: {len(effects)} timeline impacts")
                
        time.sleep(0.5)  # Short delay between cycles for demo
    
    # Try to contain an anomaly
    if anomaly_tracker and anomaly_tracker.get_active_anomalies():
        print("\nAttempting to contain an anomaly...")
        target = anomaly_tracker.get_active_anomalies()[0]
        result = anomaly_tracker.contain_anomaly(target.anomaly_id)
        
        if result["success"]:
            print(f"Containment method: {result['method']}")
            print(f"Effectiveness: {result['effectiveness']:.2f}")
            print(f"New containment level: {result['current_containment']:.2f}")
    
    # Generate final report
    print("\n" + integrator.get_integration_report())
    
    return integrator


if __name__ == "__main__":
    run_integration_demo()
