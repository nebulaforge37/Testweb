
"""
Machine Learning System Module
This module implements various machine learning and algorithmic techniques for the
multiverse simulation system, including Random Forest, Support Vector Machines,
K-means, KNN, Linear Regression, Naive Bayes, Gradient Boosting, and more.
"""

import random
import math
import numpy as np
from typing import List, Dict, Tuple, Optional, Any, Callable, Set, Union
from algorithm_system import AlgorithmSystem

class MachineLearningSystem:
    """
    Unified system for applying various machine learning techniques to the multiverse simulation
    """
    
    def __init__(self, algorithm_system: Optional[AlgorithmSystem] = None):
        """Initialize the machine learning system"""
        self.algorithm_system = algorithm_system or AlgorithmSystem()
        self.algorithms = {
            "classification": self.classification_algorithms(),
            "regression": self.regression_algorithms(),
            "clustering": self.clustering_algorithms(),
            "ensemble": self.ensemble_algorithms(),
            "optimization": self.optimization_algorithms(),
            "search": self.search_algorithms()
        }
        
        # Meta information for about page
        self.version = "1.0.0"
        self.product_id = "MLSystem-MV-2025"
        self.release_number = "R1.0.23.11"
        self.copyright = "© 2025 Multiverse Simulation Project"
        self.trademark = "Multiverse ML™ - Advanced Timeline Analysis"
        self.purpose = "Advanced machine learning system for multiverse timelines and quantum field analysis"
        self.author = "Multiverse Development Team"
        self.operating_system = "Cross-platform"
        self.original_filename = "machine_learning_system.py"
    
    def get_algorithm(self, category: str, name: str) -> Optional[Callable]:
        """Get a specific algorithm function by category and name"""
        if category in self.algorithms and name in self.algorithms[category]:
            return self.algorithms[category][name]
        return None
        
    def list_algorithms(self, category: Optional[str] = None) -> Dict[str, List[str]]:
        """List available algorithms, optionally filtered by category"""
        if category:
            if category in self.algorithms:
                return {category: list(self.algorithms[category].keys())}
            return {}
            
        return {category: list(algos.keys()) for category, algos in self.algorithms.items()}

    def get_about_info(self) -> Dict[str, str]:
        """Return information about the ML system for the about page"""
        return {
            "version": self.version,
            "product_id": self.product_id,
            "release_number": self.release_number,
            "copyright": self.copyright,
            "trademark": self.trademark,
            "purpose": self.purpose,
            "author": self.author,
            "operating_system": self.operating_system,
            "original_filename": self.original_filename
        }
    
    # ======== Classification Algorithms ========
    
    def classification_algorithms(self) -> Dict[str, Callable]:
        """Classification algorithms for various ML tasks"""
        return {
            "decision_tree": self._decision_tree_classifier,
            "naive_bayes": self._naive_bayes_classifier,
            "knn": self._k_nearest_neighbors,
            "svm": self._support_vector_machine,
            "logistic_regression": self._logistic_regression_classifier
        }
    
    def _decision_tree_classifier(self, training_data: List[List[float]], 
                              training_labels: List[int], 
                              test_data: List[List[float]],
                              max_depth: int = 5) -> List[int]:
        """
        Decision tree classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            max_depth: Maximum depth of the decision tree
            
        Returns:
            List of predicted labels for test data
        """
        # Build the decision tree
        tree = self._build_decision_tree(training_data, training_labels, max_depth)
        
        # Make predictions
        predictions = []
        for features in test_data:
            predictions.append(self._predict_with_tree(tree, features))
            
        return predictions
    
    def _build_decision_tree(self, data: List[List[float]], 
                         labels: List[int], 
                         max_depth: int,
                         current_depth: int = 0) -> Dict:
        """Build a decision tree recursively"""
        # Count the occurrences of each label
        label_counts = {}
        for label in labels:
            if label not in label_counts:
                label_counts[label] = 0
            label_counts[label] += 1
        
        # Base case: no data left, or all labels are the same, or max depth reached
        if not data or len(label_counts) == 1 or current_depth >= max_depth:
            # Return the most common label
            majority_label = max(label_counts.items(), key=lambda x: x[1])[0]
            return {"leaf": True, "label": majority_label}
        
        # Choose the best feature and threshold to split on
        n_features = len(data[0])
        best_feature, best_threshold, best_gini = -1, 0.0, float('inf')
        
        for feature_idx in range(n_features):
            # Get all values for this feature
            feature_values = [example[feature_idx] for example in data]
            unique_values = sorted(list(set(feature_values)))
            
            # Try all possible thresholds
            for i in range(len(unique_values) - 1):
                threshold = (unique_values[i] + unique_values[i + 1]) / 2
                
                # Split the data
                left_indices = [i for i in range(len(data)) if data[i][feature_idx] <= threshold]
                right_indices = [i for i in range(len(data)) if data[i][feature_idx] > threshold]
                
                # Skip if the split is degenerate
                if len(left_indices) == 0 or len(right_indices) == 0:
                    continue
                
                # Calculate Gini impurity for this split
                left_labels = [labels[i] for i in left_indices]
                right_labels = [labels[i] for i in right_indices]
                
                left_gini = self._calculate_gini_impurity(left_labels)
                right_gini = self._calculate_gini_impurity(right_labels)
                
                # Weighted average of Gini impurities
                weighted_gini = (len(left_labels) / len(labels)) * left_gini + \
                              (len(right_labels) / len(labels)) * right_gini
                
                # Update best split if this one is better
                if weighted_gini < best_gini:
                    best_gini = weighted_gini
                    best_feature = feature_idx
                    best_threshold = threshold
        
        # If no good split found, return a leaf
        if best_feature == -1:
            majority_label = max(label_counts.items(), key=lambda x: x[1])[0]
            return {"leaf": True, "label": majority_label}
        
        # Split the data based on the best feature and threshold
        left_indices = [i for i in range(len(data)) if data[i][best_feature] <= best_threshold]
        right_indices = [i for i in range(len(data)) if data[i][best_feature] > threshold]
        
        left_data = [data[i] for i in left_indices]
        left_labels = [labels[i] for i in left_indices]
        
        right_data = [data[i] for i in right_indices]
        right_labels = [labels[i] for i in right_indices]
        
        # Recursive step: build left and right subtrees
        left_subtree = self._build_decision_tree(left_data, left_labels, max_depth, current_depth + 1)
        right_subtree = self._build_decision_tree(right_data, right_labels, max_depth, current_depth + 1)
        
        return {
            "leaf": False,
            "feature": best_feature,
            "threshold": best_threshold,
            "left": left_subtree,
            "right": right_subtree
        }
    
    def _calculate_gini_impurity(self, labels: List[int]) -> float:
        """Calculate Gini impurity for a set of labels"""
        # Count occurrences of each label
        label_counts = {}
        for label in labels:
            if label not in label_counts:
                label_counts[label] = 0
            label_counts[label] += 1
        
        # Calculate Gini impurity
        total = len(labels)
        impurity = 1.0
        
        for count in label_counts.values():
            probability = count / total
            impurity -= probability ** 2
            
        return impurity
    
    def _predict_with_tree(self, tree: Dict, features: List[float]) -> int:
        """Make a prediction using a decision tree"""
        if tree["leaf"]:
            return tree["label"]
        
        if features[tree["feature"]] <= tree["threshold"]:
            return self._predict_with_tree(tree["left"], features)
        else:
            return self._predict_with_tree(tree["right"], features)
    
    def _naive_bayes_classifier(self, training_data: List[List[float]], 
                            training_labels: List[int],
                            test_data: List[List[float]]) -> List[int]:
        """
        Naive Bayes classifier implementation (Gaussian Naive Bayes)
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            
        Returns:
            List of predicted labels for test data
        """
        # Convert lists to numpy arrays for convenience
        X_train = np.array(training_data)
        y_train = np.array(training_labels)
        X_test = np.array(test_data)
        
        # Get unique classes and their prior probabilities
        classes = np.unique(y_train)
        n_classes = len(classes)
        n_samples, n_features = X_train.shape
        
        # Calculate prior probabilities
        priors = np.zeros(n_classes)
        for i, c in enumerate(classes):
            priors[i] = np.sum(y_train == c) / n_samples
        
        # Calculate means and variances for each feature for each class
        means = np.zeros((n_classes, n_features))
        variances = np.zeros((n_classes, n_features))
        
        for i, c in enumerate(classes):
            X_c = X_train[y_train == c]
            means[i, :] = X_c.mean(axis=0)
            variances[i, :] = X_c.var(axis=0) + 1e-10  # Add small value to avoid zero variance
        
        # Make predictions
        predictions = []
        for x in X_test:
            # Calculate posterior probabilities for each class
            posteriors = np.zeros(n_classes)
            
            for i, c in enumerate(classes):
                # Prior probability
                posterior = np.log(priors[i])
                
                # Add log of likelihoods for each feature (assuming Gaussian distribution)
                for j in range(n_features):
                    likelihood = self._gaussian_probability(x[j], means[i, j], variances[i, j])
                    posterior += np.log(likelihood + 1e-10)
                
                posteriors[i] = posterior
            
            # Choose class with highest posterior probability
            predictions.append(classes[np.argmax(posteriors)])
        
        return predictions.tolist()
    
    def _gaussian_probability(self, x: float, mean: float, variance: float) -> float:
        """Calculate probability using Gaussian distribution"""
        exponent = np.exp(-((x - mean) ** 2) / (2 * variance))
        return (1 / np.sqrt(2 * np.pi * variance)) * exponent
    
    def _k_nearest_neighbors(self, training_data: List[List[float]], 
                         training_labels: List[int],
                         test_data: List[List[float]],
                         k: int = 3) -> List[int]:
        """
        K-Nearest Neighbors classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            k: Number of neighbors to consider
            
        Returns:
            List of predicted labels for test data
        """
        predictions = []
        
        for test_point in test_data:
            # Calculate distances to all training points
            distances = []
            for i, training_point in enumerate(training_data):
                dist = np.sqrt(sum((a - b) ** 2 for a, b in zip(test_point, training_point)))
                distances.append((dist, training_labels[i]))
            
            # Sort by distance and take the k nearest
            distances.sort(key=lambda x: x[0])
            nearest_neighbors = distances[:k]
            
            # Count the occurrences of each label
            label_counts = {}
            for _, label in nearest_neighbors:
                if label not in label_counts:
                    label_counts[label] = 0
                label_counts[label] += 1
            
            # Find the most common label
            most_common_label = max(label_counts.items(), key=lambda x: x[1])[0]
            predictions.append(most_common_label)
        
        return predictions
    
    def _support_vector_machine(self, training_data: List[List[float]], 
                            training_labels: List[int],
                            test_data: List[List[float]],
                            learning_rate: float = 0.001,
                            lambda_param: float = 0.01,
                            n_iterations: int = 1000) -> List[int]:
        """
        Support Vector Machine classifier (simplified implementation)
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            learning_rate: Learning rate for gradient descent
            lambda_param: Regularization parameter
            n_iterations: Number of training iterations
            
        Returns:
            List of predicted labels for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        # Convert labels to -1 and 1 (binary classification)
        unique_labels = np.unique(training_labels)
        if len(unique_labels) != 2:
            raise ValueError("SVM implementation currently supports only binary classification")
            
        y_train = np.array([1 if label == unique_labels[1] else -1 for label in training_labels])
        X_test = np.array(test_data)
        
        n_samples, n_features = X_train.shape
        
        # Initialize weights and bias
        w = np.zeros(n_features)
        b = 0
        
        # Training using gradient descent
        for _ in range(n_iterations):
            for idx, x_i in enumerate(X_train):
                condition = y_train[idx] * (np.dot(x_i, w) - b) >= 1
                
                if condition:
                    w = w - learning_rate * (2 * lambda_param * w)
                else:
                    w = w - learning_rate * (2 * lambda_param * w - np.dot(x_i, y_train[idx]))
                    b = b - learning_rate * y_train[idx]
        
        # Make predictions
        predictions = []
        for x in X_test:
            prediction = np.sign(np.dot(x, w) - b)
            # Convert back to original label
            label = unique_labels[1] if prediction == 1 else unique_labels[0]
            predictions.append(label)
        
        return predictions
    
    def _logistic_regression_classifier(self, training_data: List[List[float]], 
                                     training_labels: List[int],
                                     test_data: List[List[float]],
                                     learning_rate: float = 0.01,
                                     n_iterations: int = 1000) -> List[int]:
        """
        Logistic Regression classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            learning_rate: Learning rate for gradient descent
            n_iterations: Number of training iterations
            
        Returns:
            List of predicted labels for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        # Handle binary and multi-class classification
        unique_labels = np.unique(training_labels)
        
        if len(unique_labels) == 2:
            # Binary classification
            y_train = np.array([1 if label == unique_labels[1] else 0 for label in training_labels])
            
            # Add bias term
            X_train = np.c_[np.ones(X_train.shape[0]), X_train]
            
            # Initialize weights
            weights = np.zeros(X_train.shape[1])
            
            # Training using gradient descent
            for _ in range(n_iterations):
                # Calculate probabilities
                z = np.dot(X_train, weights)
                predictions = self._sigmoid(z)
                
                # Calculate gradients
                error = predictions - y_train
                gradients = np.dot(X_train.T, error) / len(y_train)
                
                # Update weights
                weights -= learning_rate * gradients
            
            # Make predictions
            X_test = np.c_[np.ones(len(test_data)), np.array(test_data)]
            z = np.dot(X_test, weights)
            probabilities = self._sigmoid(z)
            
            predictions = []
            for prob in probabilities:
                if prob >= 0.5:
                    predictions.append(unique_labels[1])
                else:
                    predictions.append(unique_labels[0])
                    
            return predictions
        else:
            # Multi-class classification (one-vs-all)
            # Initialize weights for each class
            n_features = len(training_data[0])
            weights = np.zeros((len(unique_labels), n_features + 1))
            
            # Train a classifier for each class
            for i, label in enumerate(unique_labels):
                # Create binary labels
                binary_labels = np.array([1 if l == label else 0 for l in training_labels])
                
                # Add bias term
                X_with_bias = np.c_[np.ones(len(training_data)), np.array(training_data)]
                
                # Initialize weights for this class
                class_weights = np.zeros(n_features + 1)
                
                # Training using gradient descent
                for _ in range(n_iterations):
                    # Calculate probabilities
                    z = np.dot(X_with_bias, class_weights)
                    predictions = self._sigmoid(z)
                    
                    # Calculate gradients
                    error = predictions - binary_labels
                    gradients = np.dot(X_with_bias.T, error) / len(binary_labels)
                    
                    # Update weights
                    class_weights -= learning_rate * gradients
                
                weights[i] = class_weights
            
            # Make predictions
            X_test = np.c_[np.ones(len(test_data)), np.array(test_data)]
            
            predictions = []
            for x in X_test:
                # Calculate probabilities for each class
                class_probabilities = [self._sigmoid(np.dot(x, weights[i])) for i in range(len(unique_labels))]
                # Choose class with highest probability
                predicted_class = unique_labels[np.argmax(class_probabilities)]
                predictions.append(predicted_class)
                
            return predictions
    
    def _sigmoid(self, z):
        """Sigmoid activation function"""
        return 1 / (1 + np.exp(-np.clip(z, -500, 500)))
    
    # ======== Regression Algorithms ========
    
    def regression_algorithms(self) -> Dict[str, Callable]:
        """Regression algorithms for continuous output prediction"""
        return {
            "linear_regression": self._linear_regression,
            "polynomial_regression": self._polynomial_regression,
            "ridge_regression": self._ridge_regression,
            "lasso_regression": self._lasso_regression,
            "decision_tree_regressor": self._decision_tree_regressor
        }
    
    def _linear_regression(self, training_data: List[List[float]], 
                       training_targets: List[float],
                       test_data: List[List[float]]) -> List[float]:
        """
        Linear Regression implementation
        
        Args:
            training_data: List of feature vectors for training
            training_targets: List of target values for training data
            test_data: List of feature vectors to predict
            
        Returns:
            List of predicted values for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_targets)
        X_test = np.array(test_data)
        
        # Add bias term
        X_train = np.c_[np.ones(X_train.shape[0]), X_train]
        
        # Calculate weights using normal equation
        # w = (X^T X)^(-1) X^T y
        X_transpose = X_train.T
        weights = np.linalg.inv(X_transpose.dot(X_train)).dot(X_transpose).dot(y_train)
        
        # Make predictions
        X_test = np.c_[np.ones(X_test.shape[0]), X_test]
        predictions = X_test.dot(weights)
        
        return predictions.tolist()
    
    def _polynomial_regression(self, training_data: List[List[float]], 
                           training_targets: List[float],
                           test_data: List[List[float]],
                           degree: int = 2) -> List[float]:
        """
        Polynomial Regression implementation
        
        Args:
            training_data: List of feature vectors for training
            training_targets: List of target values for training data
            test_data: List of feature vectors to predict
            degree: Degree of the polynomial
            
        Returns:
            List of predicted values for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_targets)
        X_test = np.array(test_data)
        
        # Create polynomial features
        X_train_poly = self._create_polynomial_features(X_train, degree)
        
        # Add bias term
        X_train_poly = np.c_[np.ones(X_train_poly.shape[0]), X_train_poly]
        
        # Calculate weights using normal equation
        X_transpose = X_train_poly.T
        weights = np.linalg.inv(X_transpose.dot(X_train_poly)).dot(X_transpose).dot(y_train)
        
        # Make predictions
        X_test_poly = self._create_polynomial_features(X_test, degree)
        X_test_poly = np.c_[np.ones(X_test_poly.shape[0]), X_test_poly]
        predictions = X_test_poly.dot(weights)
        
        return predictions.tolist()
    
    def _create_polynomial_features(self, X: np.ndarray, degree: int) -> np.ndarray:
        """Create polynomial features up to the given degree"""
        n_samples, n_features = X.shape
        result = np.ones((n_samples, 1))
        
        for d in range(1, degree + 1):
            # For each degree, add all possible combinations of features
            for i in range(n_features):
                feature_power = X[:, i] ** d
                result = np.c_[result, feature_power]
                
                # Add interaction terms (only for degree > 1)
                if d > 1:
                    for j in range(i + 1, n_features):
                        interaction = (X[:, i] ** (d - 1)) * X[:, j]
                        result = np.c_[result, interaction]
        
        # Remove the first column (all ones)
        return result[:, 1:]
    
    def _ridge_regression(self, training_data: List[List[float]], 
                      training_targets: List[float],
                      test_data: List[List[float]],
                      alpha: float = 1.0) -> List[float]:
        """
        Ridge Regression implementation (L2 regularization)
        
        Args:
            training_data: List of feature vectors for training
            training_targets: List of target values for training data
            test_data: List of feature vectors to predict
            alpha: Regularization strength
            
        Returns:
            List of predicted values for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_targets)
        X_test = np.array(test_data)
        
        # Add bias term
        X_train = np.c_[np.ones(X_train.shape[0]), X_train]
        
        # Calculate weights using Ridge regression formula
        # w = (X^T X + alpha * I)^(-1) X^T y
        n_features = X_train.shape[1]
        identity = np.identity(n_features)
        identity[0, 0] = 0  # Don't regularize the bias term
        
        X_transpose = X_train.T
        weights = np.linalg.inv(X_transpose.dot(X_train) + alpha * identity).dot(X_transpose).dot(y_train)
        
        # Make predictions
        X_test = np.c_[np.ones(X_test.shape[0]), X_test]
        predictions = X_test.dot(weights)
        
        return predictions.tolist()
    
    def _lasso_regression(self, training_data: List[List[float]], 
                      training_targets: List[float],
                      test_data: List[List[float]],
                      alpha: float = 1.0,
                      n_iterations: int = 1000,
                      learning_rate: float = 0.01) -> List[float]:
        """
        Lasso Regression implementation (L1 regularization)
        
        Args:
            training_data: List of feature vectors for training
            training_targets: List of target values for training data
            test_data: List of feature vectors to predict
            alpha: Regularization strength
            n_iterations: Number of training iterations
            learning_rate: Learning rate for gradient descent
            
        Returns:
            List of predicted values for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_targets)
        X_test = np.array(test_data)
        
        # Standardize features
        X_mean = X_train.mean(axis=0)
        X_std = X_train.std(axis=0) + 1e-10  # Avoid division by zero
        X_train = (X_train - X_mean) / X_std
        
        # Add bias term
        X_train = np.c_[np.ones(X_train.shape[0]), X_train]
        
        # Initialize weights
        n_features = X_train.shape[1]
        weights = np.zeros(n_features)
        
        # Training using coordinate descent
        for _ in range(n_iterations):
            # Randomize the order of coordinates
            coordinate_order = np.random.permutation(n_features)
            
            for j in coordinate_order:
                # Calculate residuals without current feature
                weights_without_j = weights.copy()
                weights_without_j[j] = 0
                residuals = y_train - X_train.dot(weights_without_j)
                
                # Calculate correlation of feature with residuals
                correlation = X_train[:, j].dot(residuals)
                
                # Update weight with soft thresholding
                if j == 0:  # Bias term, no regularization
                    weights[j] = correlation / len(y_train)
                else:
                    if correlation > alpha:
                        weights[j] = (correlation - alpha) / len(y_train)
                    elif correlation < -alpha:
                        weights[j] = (correlation + alpha) / len(y_train)
                    else:
                        weights[j] = 0
        
        # Standardize test data
        X_test = (X_test - X_mean) / X_std
        X_test = np.c_[np.ones(X_test.shape[0]), X_test]
        
        # Make predictions
        predictions = X_test.dot(weights)
        
        return predictions.tolist()
    
    def _decision_tree_regressor(self, training_data: List[List[float]], 
                             training_targets: List[float],
                             test_data: List[List[float]],
                             max_depth: int = 5) -> List[float]:
        """
        Decision Tree Regressor implementation
        
        Args:
            training_data: List of feature vectors for training
            training_targets: List of target values for training data
            test_data: List of feature vectors to predict
            max_depth: Maximum depth of the decision tree
            
        Returns:
            List of predicted values for test data
        """
        # Build the regression tree
        tree = self._build_regression_tree(training_data, training_targets, max_depth)
        
        # Make predictions
        predictions = []
        for features in test_data:
            predictions.append(self._predict_with_regression_tree(tree, features))
            
        return predictions
    
    def _build_regression_tree(self, data: List[List[float]], 
                          targets: List[float], 
                          max_depth: int,
                          current_depth: int = 0) -> Dict:
        """Build a regression tree recursively"""
        # Base case: no data left or max depth reached
        if not data or current_depth >= max_depth:
            # Return the average target value
            return {"leaf": True, "value": sum(targets) / len(targets) if targets else 0}
        
        # Choose the best feature and threshold to split on
        n_features = len(data[0])
        best_feature, best_threshold, best_mse = -1, 0.0, float('inf')
        
        for feature_idx in range(n_features):
            # Get all values for this feature
            feature_values = [example[feature_idx] for example in data]
            unique_values = sorted(list(set(feature_values)))
            
            # Try all possible thresholds
            for i in range(len(unique_values) - 1):
                threshold = (unique_values[i] + unique_values[i + 1]) / 2
                
                # Split the data
                left_indices = [i for i in range(len(data)) if data[i][feature_idx] <= threshold]
                right_indices = [i for i in range(len(data)) if data[i][feature_idx] > threshold]
                
                # Skip if the split is degenerate
                if len(left_indices) == 0 or len(right_indices) == 0:
                    continue
                
                # Calculate MSE for this split
                left_targets = [targets[i] for i in left_indices]
                right_targets = [targets[i] for i in right_indices]
                
                left_mse = self._calculate_mse(left_targets)
                right_mse = self._calculate_mse(right_targets)
                
                # Weighted average of MSEs
                weighted_mse = (len(left_targets) / len(targets)) * left_mse + \
                             (len(right_targets) / len(targets)) * right_mse
                
                # Update best split if this one is better
                if weighted_mse < best_mse:
                    best_mse = weighted_mse
                    best_feature = feature_idx
                    best_threshold = threshold
        
        # If no good split found, return a leaf
        if best_feature == -1:
            return {"leaf": True, "value": sum(targets) / len(targets) if targets else 0}
        
        # Split the data based on the best feature and threshold
        left_indices = [i for i in range(len(data)) if data[i][best_feature] <= best_threshold]
        right_indices = [i for i in range(len(data)) if data[i][best_feature] > best_threshold]
        
        left_data = [data[i] for i in left_indices]
        left_targets = [targets[i] for i in left_indices]
        
        right_data = [data[i] for i in right_indices]
        right_targets = [targets[i] for i in right_indices]
        
        # Recursive step: build left and right subtrees
        left_subtree = self._build_regression_tree(left_data, left_targets, max_depth, current_depth + 1)
        right_subtree = self._build_regression_tree(right_data, right_targets, max_depth, current_depth + 1)
        
        return {
            "leaf": False,
            "feature": best_feature,
            "threshold": best_threshold,
            "left": left_subtree,
            "right": right_subtree
        }
    
    def _calculate_mse(self, targets: List[float]) -> float:
        """Calculate Mean Squared Error"""
        if not targets:
            return 0
            
        mean = sum(targets) / len(targets)
        mse = sum((target - mean) ** 2 for target in targets) / len(targets)
        return mse
    
    def _predict_with_regression_tree(self, tree: Dict, features: List[float]) -> float:
        """Make a prediction using a regression tree"""
        if tree["leaf"]:
            return tree["value"]
        
        if features[tree["feature"]] <= tree["threshold"]:
            return self._predict_with_regression_tree(tree["left"], features)
        else:
            return self._predict_with_regression_tree(tree["right"], features)
    
    # ======== Clustering Algorithms ========
    
    def clustering_algorithms(self) -> Dict[str, Callable]:
        """Clustering algorithms for unsupervised learning"""
        return {
            "k_means": self._k_means_clustering,
            "hierarchical_clustering": self._hierarchical_clustering,
            "dbscan": self._dbscan_clustering,
            "gaussian_mixture": self._gaussian_mixture_model,
            "spectral_clustering": self._spectral_clustering
        }
    
    def _k_means_clustering(self, data: List[List[float]], 
                        k: int = 3, 
                        max_iterations: int = 100) -> List[int]:
        """
        K-means clustering implementation
        
        Args:
            data: List of data points to cluster
            k: Number of clusters
            max_iterations: Maximum number of iterations
            
        Returns:
            List of cluster assignments (0 to k-1) for each data point
        """
        # Convert to numpy array
        X = np.array(data)
        n_samples, n_features = X.shape
        
        # Initialize centroids randomly
        random_indices = np.random.choice(n_samples, k, replace=False)
        centroids = X[random_indices]
        
        # Initialize cluster assignments
        labels = np.zeros(n_samples, dtype=int)
        
        # Main loop
        for _ in range(max_iterations):
            # Assign each point to nearest centroid
            old_labels = labels.copy()
            for i in range(n_samples):
                # Calculate distances to all centroids
                distances = np.sqrt(np.sum((centroids - X[i]) ** 2, axis=1))
                # Assign to nearest centroid
                labels[i] = np.argmin(distances)
            
            # Check for convergence
            if np.array_equal(old_labels, labels):
                break
            
            # Update centroids
            for j in range(k):
                # Get all points in this cluster
                cluster_points = X[labels == j]
                if len(cluster_points) > 0:
                    # Update centroid as mean of all points in the cluster
                    centroids[j] = np.mean(cluster_points, axis=0)
        
        return labels.tolist()
    
    def _hierarchical_clustering(self, data: List[List[float]], 
                             k: int = 3,
                             linkage: str = 'single') -> List[int]:
        """
        Hierarchical clustering implementation
        
        Args:
            data: List of data points to cluster
            k: Number of clusters
            linkage: Linkage criterion ('single', 'complete', 'average')
            
        Returns:
            List of cluster assignments (0 to k-1) for each data point
        """
        # Convert to numpy array
        X = np.array(data)
        n_samples = X.shape[0]
        
        # Initialize distance matrix
        distances = np.zeros((n_samples, n_samples))
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                distances[i, j] = distances[j, i] = np.sqrt(np.sum((X[i] - X[j]) ** 2))
        
        # Initialize clusters (each point in its own cluster)
        clusters = [[i] for i in range(n_samples)]
        
        # Merge clusters until we have k clusters
        while len(clusters) > k:
            # Find two closest clusters
            min_distance = float('inf')
            min_i, min_j = 0, 0
            
            for i in range(len(clusters)):
                for j in range(i + 1, len(clusters)):
                    # Calculate distance between clusters based on linkage criterion
                    if linkage == 'single':
                        # Minimum distance between any two points
                        cluster_distance = min(distances[p, q] for p in clusters[i] for q in clusters[j])
                    elif linkage == 'complete':
                        # Maximum distance between any two points
                        cluster_distance = max(distances[p, q] for p in clusters[i] for q in clusters[j])
                    elif linkage == 'average':
                        # Average distance between all pairs of points
                        cluster_distance = sum(distances[p, q] for p in clusters[i] for q in clusters[j])
                        cluster_distance /= (len(clusters[i]) * len(clusters[j]))
                    else:
                        raise ValueError(f"Unknown linkage criterion: {linkage}")
                    
                    if cluster_distance < min_distance:
                        min_distance = cluster_distance
                        min_i, min_j = i, j
            
            # Merge the two closest clusters
            clusters[min_i].extend(clusters[min_j])
            clusters.pop(min_j)
        
        # Convert clusters to labels
        labels = np.zeros(n_samples, dtype=int)
        for i, cluster in enumerate(clusters):
            for point_idx in cluster:
                labels[point_idx] = i
        
        return labels.tolist()
    
    def _dbscan_clustering(self, data: List[List[float]], 
                       eps: float = 0.5, 
                       min_samples: int = 5) -> List[int]:
        """
        DBSCAN clustering implementation
        
        Args:
            data: List of data points to cluster
            eps: Maximum distance between two samples for them to be considered neighbors
            min_samples: Minimum number of samples in a neighborhood for a point to be a core point
            
        Returns:
            List of cluster assignments (0 to n_clusters-1, -1 for noise) for each data point
        """
        # Convert to numpy array
        X = np.array(data)
        n_samples = X.shape[0]
        
        # Initialize labels (all points unvisited)
        labels = np.full(n_samples, -1)
        
        # Calculate distance matrix
        distances = np.zeros((n_samples, n_samples))
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                distances[i, j] = distances[j, i] = np.sqrt(np.sum((X[i] - X[j]) ** 2))
        
        # Find neighbors for each point
        neighbors = []
        for i in range(n_samples):
            neighbors.append(np.where(distances[i] <= eps)[0])
        
        # Identify core points
        core_points = []
        for i in range(n_samples):
            if len(neighbors[i]) >= min_samples:
                core_points.append(i)
        
        # Assign cluster labels
        cluster_label = 0
        
        for core_point in core_points:
            # Skip already processed points
            if labels[core_point] != -1:
                continue
            
            # Expand cluster from this core point
            labels[core_point] = cluster_label
            
            # Initialize queue with neighbors
            queue = list(neighbors[core_point])
            
            while queue:
                current_point = queue.pop(0)
                
                # If noise, add to cluster
                if labels[current_point] == -1:
                    labels[current_point] = cluster_label
                    
                    # If core point, add its neighbors to queue
                    if len(neighbors[current_point]) >= min_samples:
                        for neighbor in neighbors[current_point]:
                            if labels[neighbor] == -1:
                                queue.append(neighbor)
            
            # Move to next cluster
            cluster_label += 1
        
        return labels.tolist()
    
    def _gaussian_mixture_model(self, data: List[List[float]], 
                            k: int = 3, 
                            max_iterations: int = 100) -> List[int]:
        """
        Gaussian Mixture Model (GMM) clustering implementation
        
        Args:
            data: List of data points to cluster
            k: Number of Gaussian components (clusters)
            max_iterations: Maximum number of iterations
            
        Returns:
            List of cluster assignments (0 to k-1) for each data point
        """
        # Convert to numpy array
        X = np.array(data)
        n_samples, n_features = X.shape
        
        # Initialize parameters
        # Run k-means to get initial centroids
        kmeans_labels = self._k_means_clustering(data, k)
        
        # Calculate initial means, covariances, and mixing coefficients
        means = np.zeros((k, n_features))
        covariances = np.zeros((k, n_features, n_features))
        mixing_coeffs = np.zeros(k)
        
        for j in range(k):
            # Get all points in this cluster
            cluster_points = X[np.array(kmeans_labels) == j]
            if len(cluster_points) > 0:
                # Mean of the cluster
                means[j] = np.mean(cluster_points, axis=0)
                # Covariance matrix of the cluster
                covariances[j] = np.cov(cluster_points.T) + 1e-6 * np.eye(n_features)
                # Mixing coefficient (prior probability)
                mixing_coeffs[j] = len(cluster_points) / n_samples
            else:
                # Random initialization if cluster is empty
                means[j] = X[np.random.choice(n_samples)]
                covariances[j] = np.eye(n_features)
                mixing_coeffs[j] = 1.0 / k
        
        # Normalize mixing coefficients
        mixing_coeffs /= np.sum(mixing_coeffs)
        
        # EM algorithm
        for _ in range(max_iterations):
            # E-step: Calculate responsibilities
            responsibilities = np.zeros((n_samples, k))
            
            for j in range(k):
                # Calculate multivariate Gaussian density for each point
                # Using log probability for numerical stability
                diff = X - means[j]
                log_prob = -0.5 * np.sum(diff.dot(np.linalg.inv(covariances[j])) * diff, axis=1)
                log_prob -= 0.5 * (n_features * np.log(2 * np.pi) + np.log(np.linalg.det(covariances[j])))
                responsibilities[:, j] = mixing_coeffs[j] * np.exp(log_prob)
            
            # Normalize responsibilities
            responsibilities_sum = np.sum(responsibilities, axis=1, keepdims=True)
            responsibilities_sum = np.maximum(responsibilities_sum, 1e-10)  # Avoid division by zero
            responsibilities /= responsibilities_sum
            
            # M-step: Update parameters
            old_means = means.copy()
            
            for j in range(k):
                # Calculate effective number of points
                Nk = np.sum(responsibilities[:, j])
                Nk = max(Nk, 1e-10)  # Avoid division by zero
                
                # Update mean
                means[j] = np.sum(responsibilities[:, j, np.newaxis] * X, axis=0) / Nk
                
                # Update covariance
                diff = X - means[j]
                covariances[j] = np.dot(responsibilities[:, j] * diff.T, diff) / Nk
                covariances[j] += 1e-6 * np.eye(n_features)  # Add small value to diagonal for stability
                
                # Update mixing coefficient
                mixing_coeffs[j] = Nk / n_samples
            
            # Check for convergence
            if np.allclose(old_means, means, rtol=1e-3):
                break
        
        # Assign points to clusters (hard clustering)
        labels = np.argmax(responsibilities, axis=1)
        
        return labels.tolist()
    
    def _spectral_clustering(self, data: List[List[float]], 
                         k: int = 3, 
                         sigma: float = 1.0) -> List[int]:
        """
        Spectral clustering implementation
        
        Args:
            data: List of data points to cluster
            k: Number of clusters
            sigma: Parameter for Gaussian kernel
            
        Returns:
            List of cluster assignments (0 to k-1) for each data point
        """
        # Convert to numpy array
        X = np.array(data)
        n_samples = X.shape[0]
        
        # Compute affinity matrix using Gaussian kernel
        affinity = np.zeros((n_samples, n_samples))
        for i in range(n_samples):
            for j in range(i, n_samples):
                if i == j:
                    affinity[i, j] = 1.0
                else:
                    # Gaussian kernel: exp(-||x_i - x_j||^2 / (2 * sigma^2))
                    dist = np.sum((X[i] - X[j]) ** 2)
                    affinity[i, j] = affinity[j, i] = np.exp(-dist / (2 * sigma ** 2))
        
        # Compute degree matrix
        degree = np.diag(np.sum(affinity, axis=1))
        
        # Compute Laplacian matrix
        laplacian = degree - affinity
        
        # Compute normalized Laplacian
        degree_inv_sqrt = np.diag(1.0 / np.sqrt(np.diag(degree) + 1e-10))
        norm_laplacian = degree_inv_sqrt.dot(laplacian).dot(degree_inv_sqrt)
        
        # Compute eigenvectors and eigenvalues
        eigenvalues, eigenvectors = np.linalg.eigh(norm_laplacian)
        
        # Sort eigenvectors by eigenvalues
        indices = np.argsort(eigenvalues)
        eigenvectors = eigenvectors[:, indices]
        
        # Select k eigenvectors with smallest eigenvalues (excluding first)
        features = eigenvectors[:, 1:k+1]
        
        # Normalize each row to unit length
        row_norms = np.sqrt(np.sum(features ** 2, axis=1))
        features = features / row_norms[:, np.newaxis]
        
        # Apply k-means to the new features
        kmeans_labels = self._k_means_clustering(features.tolist(), k)
        
        return kmeans_labels
    
    # ======== Ensemble Algorithms ========
    
    def ensemble_algorithms(self) -> Dict[str, Callable]:
        """Ensemble algorithms combining multiple models"""
        return {
            "random_forest": self._random_forest,
            "gradient_boosting": self._gradient_boosting,
            "adaboost": self._adaboost,
            "bagging": self._bagging,
            "stacking": self._stacking
        }
    
    def _random_forest(self, training_data: List[List[float]], 
                   training_labels: List[int],
                   test_data: List[List[float]],
                   n_trees: int = 10,
                   max_depth: int = 5,
                   max_features: Optional[int] = None) -> List[int]:
        """
        Random Forest classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            n_trees: Number of decision trees in the forest
            max_depth: Maximum depth of each decision tree
            max_features: Maximum number of features to consider for each split
            
        Returns:
            List of predicted labels for test data
        """
        n_samples = len(training_data)
        n_features = len(training_data[0])
        
        if max_features is None:
            max_features = int(np.sqrt(n_features))
        
        # Train multiple decision trees
        trees = []
        for _ in range(n_trees):
            # Bootstrap sampling (sampling with replacement)
            indices = np.random.choice(n_samples, n_samples, replace=True)
            bootstrap_data = [training_data[i] for i in indices]
            bootstrap_labels = [training_labels[i] for i in indices]
            
            # Train decision tree with random feature selection
            tree = self._build_random_tree(bootstrap_data, bootstrap_labels, max_depth, max_features)
            trees.append(tree)
        
        # Make predictions by majority vote
        predictions = []
        for x in test_data:
            # Collect votes from all trees
            votes = {}
            for tree in trees:
                prediction = self._predict_with_tree(tree, x)
                if prediction not in votes:
                    votes[prediction] = 0
                votes[prediction] += 1
            
            # Choose class with most votes
            most_common = max(votes.items(), key=lambda x: x[1])[0]
            predictions.append(most_common)
        
        return predictions
    
    def _build_random_tree(self, data: List[List[float]], 
                       labels: List[int], 
                       max_depth: int,
                       max_features: int,
                       current_depth: int = 0) -> Dict:
        """Build a decision tree with random feature selection"""
        # Similar to _build_decision_tree but with random feature selection
        n_features = len(data[0])
        
        # Count the occurrences of each label
        label_counts = {}
        for label in labels:
            if label not in label_counts:
                label_counts[label] = 0
            label_counts[label] += 1
        
        # Base case: no data left, or all labels are the same, or max depth reached
        if not data or len(label_counts) == 1 or current_depth >= max_depth:
            # Return the most common label
            majority_label = max(label_counts.items(), key=lambda x: x[1])[0]
            return {"leaf": True, "label": majority_label}
        
        # Choose a random subset of features
        feature_indices = np.random.choice(n_features, min(max_features, n_features), replace=False)
        
        # Choose the best feature and threshold to split on
        best_feature, best_threshold, best_gini = -1, 0.0, float('inf')
        
        for feature_idx in feature_indices:
            # Get all values for this feature
            feature_values = [example[feature_idx] for example in data]
            unique_values = sorted(list(set(feature_values)))
            
            # Try all possible thresholds
            for i in range(len(unique_values) - 1):
                threshold = (unique_values[i] + unique_values[i + 1]) / 2
                
                # Split the data
                left_indices = [i for i in range(len(data)) if data[i][feature_idx] <= threshold]
                right_indices = [i for i in range(len(data)) if data[i][feature_idx] > threshold]
                
                # Skip if the split is degenerate
                if len(left_indices) == 0 or len(right_indices) == 0:
                    continue
                
                # Calculate Gini impurity for this split
                left_labels = [labels[i] for i in left_indices]
                right_labels = [labels[i] for i in right_indices]
                
                left_gini = self._calculate_gini_impurity(left_labels)
                right_gini = self._calculate_gini_impurity(right_labels)
                
                # Weighted average of Gini impurities
                weighted_gini = (len(left_labels) / len(labels)) * left_gini + \
                              (len(right_labels) / len(labels)) * right_gini
                
                # Update best split if this one is better
                if weighted_gini < best_gini:
                    best_gini = weighted_gini
                    best_feature = feature_idx
                    best_threshold = threshold
        
        # If no good split found, return a leaf
        if best_feature == -1:
            majority_label = max(label_counts.items(), key=lambda x: x[1])[0]
            return {"leaf": True, "label": majority_label}
        
        # Split the data based on the best feature and threshold
        left_indices = [i for i in range(len(data)) if data[i][best_feature] <= best_threshold]
        right_indices = [i for i in range(len(data)) if data[i][best_feature] > best_threshold]
        
        left_data = [data[i] for i in left_indices]
        left_labels = [labels[i] for i in left_indices]
        
        right_data = [data[i] for i in right_indices]
        right_labels = [labels[i] for i in right_indices]
        
        # Recursive step: build left and right subtrees
        left_subtree = self._build_random_tree(left_data, left_labels, max_depth, max_features, current_depth + 1)
        right_subtree = self._build_random_tree(right_data, right_labels, max_depth, max_features, current_depth + 1)
        
        return {
            "leaf": False,
            "feature": best_feature,
            "threshold": best_threshold,
            "left": left_subtree,
            "right": right_subtree
        }
    
    def _gradient_boosting(self, training_data: List[List[float]], 
                       training_targets: List[float],
                       test_data: List[List[float]],
                       n_estimators: int = 10,
                       learning_rate: float = 0.1,
                       max_depth: int = 3) -> List[float]:
        """
        Gradient Boosting Regressor implementation
        
        Args:
            training_data: List of feature vectors for training
            training_targets: List of target values for training data
            test_data: List of feature vectors to predict
            n_estimators: Number of weak learners (trees)
            learning_rate: Step size shrinkage
            max_depth: Maximum depth of each decision tree
            
        Returns:
            List of predicted values for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_targets)
        X_test = np.array(test_data)
        
        # Initialize predictions with the mean of the targets
        initial_prediction = np.mean(y_train)
        train_predictions = np.full_like(y_train, initial_prediction)
        test_predictions = np.full(X_test.shape[0], initial_prediction)
        
        # Train multiple weak learners sequentially
        for _ in range(n_estimators):
            # Calculate pseudo-residuals
            residuals = y_train - train_predictions
            
            # Train a regression tree on the residuals
            tree = self._build_regression_tree(training_data, residuals.tolist(), max_depth)
            
            # Update predictions
            for i, x in enumerate(X_train):
                train_predictions[i] += learning_rate * self._predict_with_regression_tree(tree, x)
            
            for i, x in enumerate(X_test):
                test_predictions[i] += learning_rate * self._predict_with_regression_tree(tree, x)
        
        return test_predictions.tolist()
    
    def _adaboost(self, training_data: List[List[float]], 
               training_labels: List[int],
               test_data: List[List[float]],
               n_estimators: int = 10) -> List[int]:
        """
        AdaBoost classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            n_estimators: Number of weak learners
            
        Returns:
            List of predicted labels for test data
        """
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_labels)
        X_test = np.array(test_data)
        
        # Convert labels to -1/+1 for binary classification
        unique_labels = np.unique(y_train)
        if len(unique_labels) != 2:
            raise ValueError("AdaBoost implementation currently supports only binary classification")
            
        y_binary = np.array([1 if label == unique_labels[1] else -1 for label in y_train])
        
        n_samples = X_train.shape[0]
        
        # Initialize sample weights
        weights = np.ones(n_samples) / n_samples
        
        # Initialize classifier parameters
        alphas = []  # Classifier weights
        classifiers = []  # Weak classifiers
        
        for _ in range(n_estimators):
            # Train a weak classifier (decision stump)
            classifier, error = self._train_decision_stump(X_train, y_binary, weights)
            
            # If error is too large, break
            if error >= 0.5:
                break
                
            # Calculate classifier weight
            alpha = 0.5 * np.log((1 - error) / max(error, 1e-10))
            alphas.append(alpha)
            classifiers.append(classifier)
            
            # Update sample weights
            predictions = np.array([self._predict_with_decision_stump(classifier, x) for x in X_train])
            misclassified = predictions != y_binary
            
            # Update weights
            weights *= np.exp(-alpha * y_binary * predictions)
            
            # Normalize weights
            weights /= np.sum(weights)
        
        # Make predictions
        predictions = []
        for x in X_test:
            # Weighted sum of predictions from all weak classifiers
            score = sum(alpha * self._predict_with_decision_stump(classifier, x) 
                        for alpha, classifier in zip(alphas, classifiers))
            prediction = 1 if score >= 0 else -1
            
            # Convert back to original labels
            label = unique_labels[1] if prediction == 1 else unique_labels[0]
            predictions.append(label)
        
        return predictions
    
    def _train_decision_stump(self, X: np.ndarray, y: np.ndarray, weights: np.ndarray) -> Tuple[Dict, float]:
        """Train a decision stump (one-level decision tree) for AdaBoost"""
        n_samples, n_features = X.shape
        
        # Initialize best stump parameters
        best_stump = None
        min_error = float('inf')
        
        for feature_idx in range(n_features):
            # Get all values for this feature
            feature_values = X[:, feature_idx]
            unique_values = np.unique(feature_values)
            
            # Try all possible thresholds
            for threshold in unique_values:
                # Try both directions
                for polarity in [1, -1]:
                    predictions = np.ones(n_samples)
                    if polarity == 1:
                        predictions[feature_values <= threshold] = -1
                    else:
                        predictions[feature_values > threshold] = -1
                    
                    # Calculate weighted error
                    misclassified = predictions != y
                    error = np.sum(weights[misclassified])
                    
                    if error < min_error:
                        min_error = error
                        best_stump = {
                            "feature": feature_idx,
                            "threshold": threshold,
                            "polarity": polarity
                        }
        
        return best_stump, min_error
    
    def _predict_with_decision_stump(self, stump: Dict, x: np.ndarray) -> int:
        """Make a prediction using a decision stump"""
        feature_value = x[stump["feature"]]
        polarity = stump["polarity"]
        threshold = stump["threshold"]
        
        if polarity == 1:
            return 1 if feature_value > threshold else -1
        else:
            return -1 if feature_value > threshold else 1
    
    def _bagging(self, training_data: List[List[float]], 
              training_labels: List[int],
              test_data: List[List[float]],
              n_estimators: int = 10,
              max_depth: int = 5) -> List[int]:
        """
        Bagging classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            n_estimators: Number of base classifiers
            max_depth: Maximum depth of each decision tree
            
        Returns:
            List of predicted labels for test data
        """
        # Similar to Random Forest but without random feature selection
        n_samples = len(training_data)
        
        # Train multiple decision trees
        trees = []
        for _ in range(n_estimators):
            # Bootstrap sampling (sampling with replacement)
            indices = np.random.choice(n_samples, n_samples, replace=True)
            bootstrap_data = [training_data[i] for i in indices]
            bootstrap_labels = [training_labels[i] for i in indices]
            
            # Train decision tree
            tree = self._build_decision_tree(bootstrap_data, bootstrap_labels, max_depth)
            trees.append(tree)
        
        # Make predictions by majority vote
        predictions = []
        for x in test_data:
            # Collect votes from all trees
            votes = {}
            for tree in trees:
                prediction = self._predict_with_tree(tree, x)
                if prediction not in votes:
                    votes[prediction] = 0
                votes[prediction] += 1
            
            # Choose class with most votes
            most_common = max(votes.items(), key=lambda x: x[1])[0]
            predictions.append(most_common)
        
        return predictions
    
    def _stacking(self, training_data: List[List[float]], 
               training_labels: List[int],
               test_data: List[List[float]]) -> List[int]:
        """
        Stacking classifier implementation
        
        Args:
            training_data: List of feature vectors for training
            training_labels: List of labels for training data
            test_data: List of feature vectors to classify
            
        Returns:
            List of predicted labels for test data
        """
        # Define base classifiers
        base_classifiers = [
            ("decision_tree", self._decision_tree_classifier, {"max_depth": 5}),
            ("knn", self._k_nearest_neighbors, {"k": 3}),
            ("naive_bayes", self._naive_bayes_classifier, {})
        ]
        
        # Convert to numpy arrays
        X_train = np.array(training_data)
        y_train = np.array(training_labels)
        X_test = np.array(test_data)
        
        # K-fold cross-validation for stacking
        k_folds = 5
        n_samples = X_train.shape[0]
        fold_size = n_samples // k_folds
        
        # Initialize meta-features
        meta_features_train = np.zeros((n_samples, len(base_classifiers)))
        meta_features_test = np.zeros((X_test.shape[0], len(base_classifiers)))
        
        # Generate meta-features using cross-validation
        for fold in range(k_folds):
            # Split data into training and validation
            start_idx = fold * fold_size
            end_idx = (fold + 1) * fold_size if fold < k_folds - 1 else n_samples
            
            val_indices = np.arange(start_idx, end_idx)
            train_indices = np.concatenate([np.arange(0, start_idx), np.arange(end_idx, n_samples)])
            
            X_fold_train = X_train[train_indices]
            y_fold_train = y_train[train_indices]
            X_fold_val = X_train[val_indices]
            
            # Train each base classifier and make predictions
            for i, (name, classifier_fn, params) in enumerate(base_classifiers):
                # Train the classifier
                predictions = classifier_fn(X_fold_train.tolist(), y_fold_train.tolist(), 
                                         X_fold_val.tolist(), **params)
                
                # Store predictions as meta-features
                meta_features_train[val_indices, i] = predictions
                
                # Make predictions on test data
                test_predictions = classifier_fn(X_train.tolist(), y_train.tolist(), 
                                               X_test.tolist(), **params)
                meta_features_test[:, i] += np.array(test_predictions) / k_folds
        
        # Train meta-classifier on meta-features
        meta_classifier_predictions = self._decision_tree_classifier(
            meta_features_train.tolist(), 
            y_train.tolist(), 
            meta_features_test.tolist(), 
            max_depth=3
        )
        
        return meta_classifier_predictions
    
    # ======== Optimization Algorithms ========
    
    def optimization_algorithms(self) -> Dict[str, Callable]:
        """Optimization algorithms for solving complex problems"""
        return {
            "dynamic_programming": self._dynamic_programming,
            "greedy": self._greedy_optimization,
            "genetic_algorithm": self._genetic_algorithm,
            "hill_climbing": self._hill_climbing,
            "simulated_annealing": self._simulated_annealing
        }
    
    def _dynamic_programming(self, weights: List[int], values: List[int], capacity: int) -> int:
        """
        Dynamic Programming solution for the Knapsack problem
        
        Args:
            weights: List of item weights
            values: List of item values
            capacity: Maximum weight capacity
            
        Returns:
            Maximum value achievable within the weight capacity
        """
        n = len(weights)
        
        # Create DP table
        dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]
        
        # Fill the dp table
        for i in range(1, n + 1):
            for w in range(capacity + 1):
                if weights[i-1] <= w:
                    # Either include the item or exclude it
                    dp[i][w] = max(values[i-1] + dp[i-1][w - weights[i-1]], dp[i-1][w])
                else:
                    # Cannot include the item
                    dp[i][w] = dp[i-1][w]
        
        return dp[n][capacity]
    
    def _greedy_optimization(self, items: List[Dict[str, Any]], constraint: float) -> List[Dict[str, Any]]:
        """
        Greedy optimization for the knapsack-like problems
        
        Args:
            items: List of items with 'value', 'weight', and other properties
            constraint: Maximum constraint value (e.g., weight capacity)
            
        Returns:
            List of selected items maximizing value while satisfying the constraint
        """
        # Calculate value-to-weight ratio for each item
        for item in items:
            item["ratio"] = item["value"] / max(item["weight"], 1e-10)
        
        # Sort items by value-to-weight ratio in descending order
        sorted_items = sorted(items, key=lambda x: x["ratio"], reverse=True)
        
        selected = []
        total_weight = 0
        total_value = 0
        
        for item in sorted_items:
            if total_weight + item["weight"] <= constraint:
                selected.append(item)
                total_weight += item["weight"]
                total_value += item["value"]
        
        return selected
    
    def _genetic_algorithm(self, fitness_fn: Callable[[List[int]], float], 
                       gene_length: int, 
                       population_size: int = 100, 
                       generations: int = 100,
                       mutation_rate: float = 0.01,
                       elite_size: int = 10) -> List[int]:
        """
        Genetic Algorithm implementation for optimization
        
        Args:
            fitness_fn: Function that evaluates fitness of an individual
            gene_length: Length of the genetic representation
            population_size: Size of the population
            generations: Number of generations
            mutation_rate: Probability of mutation
            elite_size: Number of top individuals to keep unchanged
            
        Returns:
            Best individual found
        """
        # Initialize population randomly
        population = []
        for _ in range(population_size):
            individual = [random.randint(0, 1) for _ in range(gene_length)]
            population.append(individual)
        
        for _ in range(generations):
            # Evaluate fitness for each individual
            fitness_scores = [fitness_fn(individual) for individual in population]
            
            # Sort population by fitness
            sorted_population = [x for _, x in sorted(zip(fitness_scores, population), key=lambda pair: pair[0], reverse=True)]
            
            # Keep elite individuals
            next_population = sorted_population[:elite_size]
            
            # Generate rest of the population through crossover and mutation
            while len(next_population) < population_size:
                # Tournament selection
                parent1 = self._tournament_selection(sorted_population, fitness_scores, tournament_size=3)
                parent2 = self._tournament_selection(sorted_population, fitness_scores, tournament_size=3)
                
                # Crossover
                child = self._crossover(parent1, parent2)
                
                # Mutation
                child = self._mutate(child, mutation_rate)
                
                next_population.append(child)
            
            population = next_population
        
        # Return the best individual from the final population
        final_fitness_scores = [fitness_fn(individual) for individual in population]
        best_idx = np.argmax(final_fitness_scores)
        
        return population[best_idx]
    
    def _tournament_selection(self, population: List[List[int]], fitness_scores: List[float], tournament_size: int) -> List[int]:
        """Tournament selection for genetic algorithm"""
        tournament_indices = np.random.choice(len(population), tournament_size, replace=False)
        tournament_fitness = [fitness_scores[i] for i in tournament_indices]
        winner_idx = tournament_indices[np.argmax(tournament_fitness)]
        return population[winner_idx]
    
    def _crossover(self, parent1: List[int], parent2: List[int]) -> List[int]:
        """One-point crossover for genetic algorithm"""
        crossover_point = random.randint(1, len(parent1) - 1)
        child = parent1[:crossover_point] + parent2[crossover_point:]
        return child
    
    def _mutate(self, individual: List[int], mutation_rate: float) -> List[int]:
        """Mutation for genetic algorithm"""
        mutated = individual.copy()
        for i in range(len(mutated)):
            if random.random() < mutation_rate:
                mutated[i] = 1 - mutated[i]  # Flip bit
        return mutated
    
    def _hill_climbing(self, fitness_fn: Callable[[List[int]], float], 
                   initial_state: List[int], 
                   max_iterations: int = 1000) -> List[int]:
        """
        Hill Climbing optimization algorithm
        
        Args:
            fitness_fn: Function that evaluates fitness of a state
            initial_state: Starting state
            max_iterations: Maximum number of iterations
            
        Returns:
            Best state found
        """
        current_state = initial_state.copy()
        current_fitness = fitness_fn(current_state)
        
        for _ in range(max_iterations):
            # Generate all neighbors by flipping one bit
            neighbors = []
            for i in range(len(current_state)):
                neighbor = current_state.copy()
                neighbor[i] = 1 - neighbor[i]  # Flip bit
                neighbors.append(neighbor)
            
            # Evaluate all neighbors
            neighbor_fitness = [fitness_fn(neighbor) for neighbor in neighbors]
            
            # Find the best neighbor
            best_idx = np.argmax(neighbor_fitness)
            best_neighbor = neighbors[best_idx]
            best_fitness = neighbor_fitness[best_idx]
            
            # If no improvement, we're at a local optimum
            if best_fitness <= current_fitness:
                break
            
            # Move to the best neighbor
            current_state = best_neighbor
            current_fitness = best_fitness
        
        return current_state
    
    def _simulated_annealing(self, fitness_fn: Callable[[List[int]], float], 
                         initial_state: List[int], 
                         max_iterations: int = 1000,
                         initial_temp: float = 100.0,
                         cooling_rate: float = 0.95) -> List[int]:
        """
        Simulated Annealing optimization algorithm
        
        Args:
            fitness_fn: Function that evaluates fitness of a state
            initial_state: Starting state
            max_iterations: Maximum number of iterations
            initial_temp: Initial temperature
            cooling_rate: Temperature cooling rate
            
        Returns:
            Best state found
        """
        current_state = initial_state.copy()
        current_fitness = fitness_fn(current_state)
        
        best_state = current_state.copy()
        best_fitness = current_fitness
        
        temperature = initial_temp
        
        for _ in range(max_iterations):
            # Generate a random neighbor by flipping one bit
            neighbor = current_state.copy()
            random_idx = random.randint(0, len(neighbor) - 1)
            neighbor[random_idx] = 1 - neighbor[random_idx]  # Flip bit
            
            # Evaluate the neighbor
            neighbor_fitness = fitness_fn(neighbor)
            
            # Decide whether to move to the neighbor
            if neighbor_fitness > current_fitness:
                # Always move to better solutions
                current_state = neighbor
                current_fitness = neighbor_fitness
                
                # Update best solution if needed
                if current_fitness > best_fitness:
                    best_state = current_state.copy()
                    best_fitness = current_fitness
            else:
                # Move to worse solutions with a probability that depends on temperature
                delta = neighbor_fitness - current_fitness
                acceptance_probability = np.exp(delta / temperature)
                
                if random.random() < acceptance_probability:
                    current_state = neighbor
                    current_fitness = neighbor_fitness
            
            # Cool down
            temperature *= cooling_rate
            
            # Stop if temperature is very low
            if temperature < 1e-10:
                break
        
        return best_state
    
    # ======== Search Algorithms ========
    
    def search_algorithms(self) -> Dict[str, Callable]:
        """Search algorithms for finding paths and elements"""
        return {
            "binary_search": self._binary_search,
            "depth_first_search": self._depth_first_search,
            "breadth_first_search": self._breadth_first_search,
            "a_star_search": self._a_star_search,
            "backtracking": self._backtracking_search
        }
    
    def _binary_search(self, sorted_array: List[int], target: int) -> int:
        """
        Binary Search algorithm for finding an element in a sorted array
        
        Args:
            sorted_array: Sorted array of elements
            target: Element to find
            
        Returns:
            Index of the element if found, -1 otherwise
        """
        left, right = 0, len(sorted_array) - 1
        
        while left <= right:
            mid = (left + right) // 2
            
            if sorted_array[mid] == target:
                return mid
            elif sorted_array[mid] < target:
                left = mid + 1
            else:
                right = mid - 1
        
        return -1
    
    def _depth_first_search(self, graph: Dict[int, List[int]], start: int, target: int) -> List[int]:
        """
        Depth-First Search algorithm for finding a path in a graph
        
        Args:
            graph: Adjacency list representation of the graph
            start: Starting node
            target: Target node
            
        Returns:
            Path from start to target if found, empty list otherwise
        """
        # Stack for DFS
        stack = [(start, [start])]
        visited = set()
        
        while stack:
            (node, path) = stack.pop()
            
            if node == target:
                return path
            
            if node not in visited:
                visited.add(node)
                
                # Add all neighbors to stack
                for neighbor in graph.get(node, []):
                    if neighbor not in visited:
                        stack.append((neighbor, path + [neighbor]))
        
        return []
    
    def _breadth_first_search(self, graph: Dict[int, List[int]], start: int, target: int) -> List[int]:
        """
        Breadth-First Search algorithm for finding the shortest path in a graph
        
        Args:
            graph: Adjacency list representation of the graph
            start: Starting node
            target: Target node
            
        Returns:
            Shortest path from start to target if found, empty list otherwise
        """
        # Queue for BFS
        queue = [(start, [start])]
        visited = set([start])
        
        while queue:
            (node, path) = queue.pop(0)
            
            if node == target:
                return path
            
            # Add all neighbors to queue
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        
        return []
    
    def _a_star_search(self, graph: Dict[int, Dict[int, float]], 
                   start: int, target: int, 
                   heuristic: Callable[[int], float]) -> List[int]:
        """
        A* Search algorithm for finding the optimal path in a weighted graph
        
        Args:
            graph: Weighted adjacency list representation of the graph
            start: Starting node
            target: Target node
            heuristic: Function that estimates the cost from a node to the target
            
        Returns:
            Optimal path from start to target if found, empty list otherwise
        """
        # Priority queue for A*
        open_set = {start: (0, [start])}  # node: (f_score, path)
        closed_set = set()
        
        g_score = {start: 0}  # Cost from start to node
        f_score = {start: heuristic(start)}  # Estimated total cost from start to target through node
        
        while open_set:
            # Get node with lowest f_score
            current = min(open_set, key=lambda x: open_set[x][0])
            current_f, current_path = open_set[current]
            
            # Remove from open set
            del open_set[current]
            
            # Add to closed set
            closed_set.add(current)
            
            # Check if target reached
            if current == target:
                return current_path
            
            # Explore neighbors
            for neighbor, weight in graph.get(current, {}).items():
                if neighbor in closed_set:
                    continue
                
                # Calculate tentative g_score
                tentative_g = g_score[current] + weight
                
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    # This path is better than any previous one
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + heuristic(neighbor)
                    open_set[neighbor] = (f_score[neighbor], current_path + [neighbor])
        
        return []
    
    def _backtracking_search(self, state: List[int], 
                         constraints: List[Callable[[List[int]], bool]],
                         is_complete: Callable[[List[int]], bool]) -> Optional[List[int]]:
        """
        Backtracking Search algorithm for constraint satisfaction problems
        
        Args:
            state: Initial state
            constraints: List of constraint functions
            is_complete: Function that checks if the state is a complete solution
            
        Returns:
            A valid complete state if found, None otherwise
        """
        def backtrack(current_state):
            # Check if the state is complete
            if is_complete(current_state):
                return current_state
            
            # Try all possible values for the next variable
            for value in [0, 1]:  # Assuming binary values
                # Make a copy of the current state
                new_state = current_state.copy()
                new_state.append(value)
                
                # Check if all constraints are satisfied
                if all(constraint(new_state) for constraint in constraints):
                    # Recursively search with the new state
                    result = backtrack(new_state)
                    if result is not None:
                        return result
            
            # No valid values found
            return None
        
        return backtrack(state)

# Example of using the MachineLearningSystem
def demonstrate_ml_system():
    """Demonstrate the machine learning system with simple examples"""
    ml_system = MachineLearningSystem()
    
    # Simple data for demonstration
    # Binary classification data
    X_train = [
        [1.0, 2.0, 3.0],
        [2.0, 3.0, 4.0],
        [3.0, 4.0, 5.0],
        [6.0, 7.0, 8.0],
        [7.0, 8.0, 9.0],
        [8.0, 9.0, 10.0]
    ]
    y_train = [0, 0, 0, 1, 1, 1]
    
    X_test = [
        [2.5, 3.5, 4.5],
        [7.5, 8.5, 9.5]
    ]
    
    # Decision Tree
    print("Decision Tree Prediction:")
    tree_predictions = ml_system.get_algorithm("classification", "decision_tree")(
        X_train, y_train, X_test, max_depth=3
    )
    print(f"Predictions: {tree_predictions}")
    
    # K-Nearest Neighbors
    print("\nKNN Prediction:")
    knn_predictions = ml_system.get_algorithm("classification", "knn")(
        X_train, y_train, X_test, k=3
    )
    print(f"Predictions: {knn_predictions}")
    
    # Simple regression data
    y_reg_train = [2.0, 3.0, 4.0, 7.0, 8.0, 9.0]
    
    # Linear Regression
    print("\nLinear Regression Prediction:")
    reg_predictions = ml_system.get_algorithm("regression", "linear_regression")(
        X_train, y_reg_train, X_test
    )
    print(f"Predictions: {reg_predictions}")
    
    # Simple clustering data
    print("\nK-means Clustering:")
    cluster_assignments = ml_system.get_algorithm("clustering", "k_means")(
        X_train, k=2
    )
    print(f"Cluster assignments: {cluster_assignments}")
    
    # Display about info
    print("\nAbout Machine Learning System:")
    about_info = ml_system.get_about_info()
    for key, value in about_info.items():
        print(f"{key}: {value}")

if __name__ == "__main__":
    demonstrate_ml_system()
