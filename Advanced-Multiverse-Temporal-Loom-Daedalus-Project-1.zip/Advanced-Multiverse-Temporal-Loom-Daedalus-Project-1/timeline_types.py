
"""
Timeline Types Module
This module implements various theoretical timeline types including static timelines,
dynamic timelines, and time loop systems.
"""

import random
import math
import time
from typing import List, Dict, Tuple, Optional, Set, Any, Union
from enum import Enum

class TimelineType(Enum):
    """Enumeration of theoretical timeline types"""
    STATIC = "static"        # Fixed, unchangeable timelines
    DYNAMIC = "dynamic"      # Mutable, changeable timelines
    PLASTIC = "plastic"      # Initially resistant but ultimately changeable
    LOOPED = "looped"        # Timeline that loops back on itself
    BRANCHING = "branching"  # Timeline that branches at decision points
    CONVERGING = "converging" # Timeline that tends to converge with others
    QUANTUM = "quantum"      # Timeline following quantum mechanics principles
    HYBRID = "hybrid"        # Timeline with mixed characteristics


class TimeLoopType(Enum):
    """Types of time loops that can occur in timelines"""
    CAUSAL = "causal"           # Loop where effect becomes its own cause
    PREDESTINATION = "predestination" # Loop where attempts to change create known outcome
    RESONANCE = "resonance"     # Loops that repeat with variations
    MOBIUS = "mobius"           # Single-sided loop with a twist
    KARMIC = "karmic"           # Loop tied to specific entities or events
    QUANTUM = "quantum"         # Loop created by quantum effects
    ETERNAL_RECURRENCE = "eternal" # Nietzschean eternal recurrence


class TimeLoop:
    """Models a time loop within a timeline"""
    
    def __init__(self, loop_type: TimeLoopType = None, start_year: int = None, 
                end_year: int = None, iterations: int = None, 
                decay_rate: float = None, description: str = None):
        """
        Initialize a time loop
        
        Args:
            loop_type: Type of time loop
            start_year: Year the loop begins
            end_year: Year the loop ends and returns to start
            iterations: Number of iterations (None = infinite)
            decay_rate: Rate at which loop stability decays per iteration
            description: Description of the loop's nature
        """
        self.loop_type = loop_type or random.choice(list(TimeLoopType))
        self.start_year = start_year or random.randint(1900, 2050)
        # Loop duration between 1 and one day below 100 years
        self.end_year = end_year or (self.start_year + random.randint(1, 99))
        self.iterations = iterations  # None means potentially infinite
        self.decay_rate = decay_rate or random.uniform(0.01, 0.1)
        self.description = description or self._generate_description()
        
        # Loop state
        self.current_iteration = 0
        self.stability = 1.0
        self.active = True
        self.variations = []  # Track variations between iterations
        self.entity_memory = {}  # Entities that retain memory between loops
        self.loop_events = []  # Events specific to the loop
        self.quantum_signature = random.random()  # Unique quantum signature
        self.last_iteration_time = time.time()  # Real-world time of last iteration
        
    def _generate_description(self) -> str:
        """Generate a description based on the loop type"""
        descriptions = {
            TimeLoopType.CAUSAL: [
                "A loop where the future creates the past",
                "Information passed to the past becomes the cause of itself",
                "Causality loop with no discernible origin point"
            ],
            TimeLoopType.PREDESTINATION: [
                "Attempts to change the timeline ensure it happens as remembered",
                "Self-fulfilling prophecy loop",
                "Predetermined events that cannot be avoided"
            ],
            TimeLoopType.RESONANCE: [
                "Events echo with variations across iterations",
                "Loop with harmonic variations",
                "Resonating timeline with fractal patterns"
            ],
            TimeLoopType.MOBIUS: [
                "Single-sided loop with a reality inversion",
                "Möbius strip of time where beginning becomes end",
                "Twisted loop with reality inversions"
            ],
            TimeLoopType.KARMIC: [
                "Loop tied to specific entities until resolution",
                "Karmic cycle requiring specific actions to break",
                "Entity-bound loop requiring personal growth"
            ],
            TimeLoopType.QUANTUM: [
                "Loop created by quantum observation effects",
                "Quantum entanglement across time creating recursive patterns",
                "Schrödinger loop existing in multiple states"
            ],
            TimeLoopType.ETERNAL_RECURRENCE: [
                "Universe doomed to repeat eternally",
                "Nietzschean eternal recurrence of all events",
                "Cosmic cycle of repetition"
            ]
        }
        
        return random.choice(descriptions.get(self.loop_type, ["Mysterious time loop"]))
        
    def iterate(self) -> Dict[str, Any]:
        """
        Advance the loop to the next iteration
        
        Returns:
            Information about the iteration
        """
        if not self.active:
            return {"active": False, "reason": "Loop already broken"}
            
        # Record time of this iteration
        now = time.time()
        time_since_last = now - self.last_iteration_time
        self.last_iteration_time = now
        
        # Increase iteration count
        self.current_iteration += 1
        
        # Check if we've reached iteration limit
        if self.iterations is not None and self.current_iteration >= self.iterations:
            self.active = False
            return {
                "active": False,
                "reason": f"Reached maximum iterations ({self.iterations})",
                "final_iteration": self.current_iteration
            }
            
        # Calculate stability decay
        # Faster iterations (in real time) decay more quickly
        time_factor = max(0.5, min(2.0, 10 / max(0.1, time_since_last)))
        stability_decay = self.decay_rate * time_factor
        self.stability = max(0.0, self.stability - stability_decay)
        
        # Generate random variations for this iteration
        variation_factor = (1.0 - self.stability) * 0.2
        variation = random.uniform(0, variation_factor)
        
        # Add to variations list
        self.variations.append({
            "iteration": self.current_iteration,
            "variation": variation,
            "stability": self.stability
        })
        
        # Check if loop breaks due to instability
        if self.stability < 0.1 and random.random() < 0.5:
            self.active = False
            return {
                "active": False,
                "reason": "Loop collapsed due to instability",
                "final_iteration": self.current_iteration,
                "final_stability": self.stability
            }
            
        # Return information about this iteration
        return {
            "active": True,
            "iteration": self.current_iteration,
            "stability": self.stability,
            "variation": variation,
            "loop_type": self.loop_type.value
        }
        
    def add_entity_memory(self, entity_id: str, memory_retention: float = None):
        """
        Add an entity that retains memory between loop iterations
        
        Args:
            entity_id: ID of the entity
            memory_retention: How much memory is retained (0.0-1.0)
        """
        retention = memory_retention or random.uniform(0.3, 1.0)
        self.entity_memory[entity_id] = {
            "retention": retention,
            "aware_since_iteration": self.current_iteration,
            "memories": []
        }
        
    def add_loop_event(self, year: int, description: str, variance: float = 0.0):
        """
        Add an event that occurs in the time loop
        
        Args:
            year: Year the event occurs
            description: Description of the event
            variance: How much the event varies between iterations (0.0-1.0)
        """
        if not (self.start_year <= year <= self.end_year):
            return False  # Event outside loop boundaries
            
        self.loop_events.append({
            "year": year,
            "description": description,
            "variance": variance,
            "iterations_present": [self.current_iteration]
        })
        
        return True
        
    def break_loop(self, reason: str) -> bool:
        """
        Break the time loop
        
        Args:
            reason: Reason for breaking the loop
            
        Returns:
            Whether the loop was successfully broken
        """
        if not self.active:
            return False
            
        self.active = False
        self.loop_events.append({
            "year": self.end_year,
            "description": f"LOOP BROKEN: {reason}",
            "variance": 0.0,
            "iterations_present": [self.current_iteration]
        })
        
        return True
        
    def get_duration(self) -> int:
        """Get the duration of the loop in years"""
        return self.end_year - self.start_year
        
    def get_loop_percentage(self, year: int) -> float:
        """
        Get position within the loop as a percentage
        
        Args:
            year: The year to check
            
        Returns:
            Percentage through the loop (0.0-1.0), or -1 if outside loop
        """
        if not (self.start_year <= year <= self.end_year):
            return -1.0
            
        return (year - self.start_year) / max(1, self.get_duration())
        
    def __str__(self) -> str:
        status = "ACTIVE" if self.active else "BROKEN"
        iter_info = f"{self.current_iteration}"
        if self.iterations is not None:
            iter_info += f"/{self.iterations}"
            
        return (f"{self.loop_type.value.title()} Loop ({status}): {self.start_year}-{self.end_year}, "
                f"Iterations: {iter_info}, Stability: {self.stability:.2f}")


class TimelineProgression:
    """Models how a timeline progresses and evolves over time"""
    
    class ProgressionType(Enum):
        """Types of timeline progression"""
        LINEAR = "linear"           # Straightforward progression
        EXPONENTIAL = "exponential" # Accelerating changes
        CYCLICAL = "cyclical"       # Repeating patterns
        SPIRAL = "spiral"           # Cyclical with evolution
        CHAOTIC = "chaotic"         # Unpredictable changes
        CONVERGENT = "convergent"   # Trending toward fixed points
        DIVERGENT = "divergent"     # Trending toward greater variance
    
    def __init__(self, progression_type: ProgressionType = None, 
                 rate: float = None, stability: float = None):
        """
        Initialize timeline progression model
        
        Args:
            progression_type: Type of progression
            rate: Rate of change (higher = faster changes)
            stability: Stability of the progression pattern
        """
        self.progression_type = progression_type or random.choice(list(self.ProgressionType))
        self.rate = rate or random.uniform(0.1, 2.0)
        self.stability = stability or random.uniform(0.4, 1.0)
        
        # Progression state
        self.last_update_time = time.time()
        self.total_change = 0.0
        self.change_history = []
        self.cycle_position = 0.0  # For cyclical types
        self.key_events = []
        self.convergence_points = []
        
        # Initialize based on type
        self._initialize_progression()
        
    def _initialize_progression(self):
        """Initialize specific progression type parameters"""
        if self.progression_type == self.ProgressionType.CYCLICAL:
            # Set up cycle parameters
            self.cycle_length = random.uniform(10, 100)  # Years
            self.cycle_amplitude = random.uniform(0.5, 1.0)
            
        elif self.progression_type == self.ProgressionType.SPIRAL:
            # Set up spiral parameters
            self.cycle_length = random.uniform(10, 100)
            self.cycle_amplitude = random.uniform(0.5, 1.0)
            self.evolution_rate = random.uniform(0.01, 0.1)
            
        elif self.progression_type == self.ProgressionType.CONVERGENT:
            # Set up convergence points
            num_points = random.randint(1, 5)
            for _ in range(num_points):
                self.convergence_points.append({
                    "value": random.uniform(0, 1),
                    "strength": random.uniform(0.1, 1.0),
                    "years_to_reach": random.uniform(10, 100)
                })
                
        elif self.progression_type == self.ProgressionType.CHAOTIC:
            # Set up chaotic parameters
            self.chaos_seed = random.random()
            self.chaos_factor = random.uniform(1.5, 4.0)  # Higher = more chaotic
            
    def update(self, years_elapsed: float) -> Dict[str, Any]:
        """
        Update the progression based on elapsed time
        
        Args:
            years_elapsed: Number of years that have passed
            
        Returns:
            Information about the progression update
        """
        now = time.time()
        real_time_elapsed = now - self.last_update_time
        self.last_update_time = now
        
        # Calculate change based on progression type
        change = self._calculate_change(years_elapsed, real_time_elapsed)
        
        # Update total change
        self.total_change += change
        
        # Update cycle position for cyclical types
        if self.progression_type in (self.ProgressionType.CYCLICAL, self.ProgressionType.SPIRAL):
            # Update cycle position
            self.cycle_position = (self.cycle_position + years_elapsed / self.cycle_length) % 1.0
            
        # Record in history
        self.change_history.append({
            "years_elapsed": years_elapsed,
            "change": change,
            "total_change": self.total_change,
            "timestamp": now
        })
        
        # Return update information
        return {
            "change": change,
            "total_change": self.total_change,
            "progression_type": self.progression_type.value,
            "cycle_position": getattr(self, "cycle_position", None)
        }
        
    def _calculate_change(self, years_elapsed: float, real_time_elapsed: float) -> float:
        """Calculate change based on progression type"""
        # Base change value
        base_change = years_elapsed * self.rate
        
        # Apply type-specific calculations
        if self.progression_type == self.ProgressionType.LINEAR:
            return base_change
            
        elif self.progression_type == self.ProgressionType.EXPONENTIAL:
            # Exponential growth based on total_change
            return base_change * (1.0 + self.total_change * 0.1)
            
        elif self.progression_type == self.ProgressionType.CYCLICAL:
            # Cyclical change using sine wave
            cycle_factor = math.sin(2 * math.pi * self.cycle_position)
            return base_change * (1.0 + cycle_factor * self.cycle_amplitude)
            
        elif self.progression_type == self.ProgressionType.SPIRAL:
            # Spiral combines cyclical with growth
            cycle_factor = math.sin(2 * math.pi * self.cycle_position)
            evolution = 1.0 + self.total_change * self.evolution_rate
            return base_change * (1.0 + cycle_factor * self.cycle_amplitude) * evolution
            
        elif self.progression_type == self.ProgressionType.CHAOTIC:
            # Use logistic map equation for chaos
            # Simplified chaos model
            x = (self.total_change + self.chaos_seed) % 1.0
            chaotic_factor = self.chaos_factor * x * (1 - x)
            return base_change * chaotic_factor * 2
            
        elif self.progression_type == self.ProgressionType.CONVERGENT:
            # Pull toward convergence points
            if not self.convergence_points:
                return base_change
                
            # Find closest convergence point
            closest = min(self.convergence_points, 
                          key=lambda p: abs(p["value"] - self.total_change))
            
            # Calculate pull toward convergence point
            distance = closest["value"] - self.total_change
            pull_strength = closest["strength"] * (years_elapsed / closest["years_to_reach"])
            convergence_change = distance * pull_strength
            
            return base_change + convergence_change
            
        elif self.progression_type == self.ProgressionType.DIVERGENT:
            # Increasingly divergent - more unstable over time
            instability = 1.0 + self.total_change * 0.05
            return base_change * instability * random.uniform(0.5, 1.5)
            
        # Default fallback
        return base_change
        
    def add_key_event(self, year: int, description: str, impact: float):
        """
        Add a key event that influences progression
        
        Args:
            year: Year of the event
            description: Description of the event
            impact: Impact on the progression (-1.0 to 1.0)
        """
        self.key_events.append({
            "year": year,
            "description": description,
            "impact": impact
        })
        
        # Sort by year
        self.key_events.sort(key=lambda e: e["year"])
        
    def predict_future_state(self, years_ahead: float) -> Dict[str, Any]:
        """
        Predict the future state of the progression
        
        Args:
            years_ahead: How many years to look ahead
            
        Returns:
            Predicted future state information
        """
        # Create a copy of current state
        future = {
            "total_change": self.total_change,
            "cycle_position": getattr(self, "cycle_position", 0.0),
            "stability": self.stability
        }
        
        # Simple prediction by simulating updates
        remaining_years = years_ahead
        step_size = min(5.0, years_ahead / 10)  # Use smaller steps for accuracy
        
        while remaining_years > 0:
            step = min(step_size, remaining_years)
            change = self._calculate_change(step, 0.1)  # Small real-time value
            
            future["total_change"] += change
            
            if hasattr(self, "cycle_position"):
                future["cycle_position"] = (
                    future["cycle_position"] + step / getattr(self, "cycle_length", 100)
                ) % 1.0
                
            remaining_years -= step
            
            # Apply random stability decay
            future["stability"] *= (1.0 - random.uniform(0, 0.01))
            
        # Return prediction
        future["years_ahead"] = years_ahead
        future["prediction_confidence"] = max(0.1, min(0.9, future["stability"]))
        
        return future
        
    def __str__(self) -> str:
        return (f"{self.progression_type.value.title()} Progression: "
                f"Rate={self.rate:.2f}, Stability={self.stability:.2f}, "
                f"Total Change={self.total_change:.2f}")


class TypedTimeline:
    """Timeline with advanced type and progression features"""
    
    def __init__(self, name: str, timeline_type: TimelineType = None, 
                stability: float = None, quantum_state = None):
        """
        Initialize a typed timeline
        
        Args:
            name: Timeline name
            timeline_type: Type of timeline
            stability: Initial stability
            quantum_state: Quantum state object (from main Timeline class)
        """
        self.name = name
        self.timeline_type = timeline_type or random.choice(list(TimelineType))
        self.stability = stability or random.uniform(0.5, 1.0)
        self.quantum_state = quantum_state
        
        # Events and connections
        self.events = []
        self.connected_timelines = []
        
        # Type-specific features
        self.time_loops = []
        self.progression = TimelineProgression()
        self.mutability = self._calculate_mutability()
        self.branch_points = []
        self.convergence_points = []
        self.origin_point = None
        self.end_point = None
        
        # Initialize based on type
        self._initialize_timeline_type()
        
    def _initialize_timeline_type(self):
        """Initialize specific features based on timeline type"""
        # Special initializations based on timeline type
        if self.timeline_type == TimelineType.STATIC:
            # Static timelines are highly stable but immutable
            self.stability = max(0.8, self.stability)
            self.mutability = 0.0
            
        elif self.timeline_type == TimelineType.DYNAMIC:
            # Dynamic timelines are mutable but less stable
            self.stability = min(0.7, self.stability)
            self.mutability = 1.0
            
        elif self.timeline_type == TimelineType.PLASTIC:
            # Plastic timelines start resistant but become more mutable
            self.progression = TimelineProgression(
                TimelineProgression.ProgressionType.EXPONENTIAL,
                random.uniform(0.05, 0.2),
                random.uniform(0.7, 0.9)
            )
            
        elif self.timeline_type == TimelineType.LOOPED:
            # Create at least one time loop
            self._create_time_loop()
            
        elif self.timeline_type == TimelineType.BRANCHING:
            # Create some branch points
            num_branches = random.randint(2, 5)
            for _ in range(num_branches):
                self._create_branch_point()
                
        elif self.timeline_type == TimelineType.CONVERGING:
            # Create some convergence points
            num_converge = random.randint(2, 5)
            for _ in range(num_converge):
                self._create_convergence_point()
                
        elif self.timeline_type == TimelineType.QUANTUM:
            # Quantum timelines use special progression
            self.progression = TimelineProgression(
                TimelineProgression.ProgressionType.CHAOTIC,
                random.uniform(0.1, 0.5),
                random.uniform(0.3, 0.7)
            )
            
        elif self.timeline_type == TimelineType.HYBRID:
            # Mix of features
            if random.random() < 0.5:
                self._create_time_loop()
            if random.random() < 0.5:
                self._create_branch_point()
            if random.random() < 0.5:
                self._create_convergence_point()
                
    def _calculate_mutability(self) -> float:
        """Calculate the timeline's mutability based on type and stability"""
        base_mutability = {
            TimelineType.STATIC: 0.0,
            TimelineType.DYNAMIC: 1.0,
            TimelineType.PLASTIC: 0.3,
            TimelineType.LOOPED: 0.5,
            TimelineType.BRANCHING: 0.8,
            TimelineType.CONVERGING: 0.6,
            TimelineType.QUANTUM: 0.7,
            TimelineType.HYBRID: 0.5
        }.get(self.timeline_type, 0.5)
        
        # Adjust based on stability - higher stability tends to mean lower mutability
        stability_factor = 1.0 - (self.stability * 0.5)
        
        return base_mutability * stability_factor
        
    def _create_time_loop(self) -> TimeLoop:
        """Create a time loop in this timeline"""
        # Choose a random loop type
        loop_type = random.choice(list(TimeLoopType))
        
        # Duration based on timeline type
        duration = random.randint(5, 50)
        
        # Select a random start year from events or generate one
        if self.events:
            start_year = random.choice(self.events)[0]
        else:
            start_year = 2000 + random.randint(-50, 50)
            
        end_year = start_year + duration
        
        # Create the loop
        loop = TimeLoop(
            loop_type=loop_type,
            start_year=start_year,
            end_year=end_year,
            iterations=None if random.random() < 0.3 else random.randint(3, 100),
            decay_rate=random.uniform(0.01, 0.1)
        )
        
        self.time_loops.append(loop)
        
        # Add loop metadata event
        self.add_event(f"TIME LOOP ORIGIN: {loop.description}", start_year)
        
        # If there's an end date within reasonable bounds, add end event
        if end_year < 2500:
            self.add_event(f"TIME LOOP NEXUS: Returns to {start_year}", end_year)
            
        return loop
        
    def _create_branch_point(self) -> Dict[str, Any]:
        """Create a branch point in this timeline"""
        # Generate year for branch point
        if self.events:
            year = random.choice(self.events)[0]
        else:
            year = 2000 + random.randint(-50, 50)
            
        # Create branch point
        branch = {
            "year": year,
            "probability": random.uniform(0.3, 0.8),
            "stability_impact": random.uniform(-0.2, 0.1),
            "description": f"Timeline branch point",
            "potential_branches": random.randint(2, 5),
            "realized_branches": 0
        }
        
        self.branch_points.append(branch)
        
        # Add branch event
        self.add_event(f"BRANCH POINT: {branch['description']} ({branch['potential_branches']} potential branches)", year)
        
        return branch
        
    def _create_convergence_point(self) -> Dict[str, Any]:
        """Create a convergence point in this timeline"""
        # Generate year for convergence
        if self.events:
            event_years = [year for year, _ in self.events]
            year = random.choice(event_years) + random.randint(10, 50)
        else:
            year = 2000 + random.randint(0, 100)
            
        # Create convergence point
        converge = {
            "year": year,
            "strength": random.uniform(0.3, 0.9),
            "stability_impact": random.uniform(0.0, 0.2),
            "description": f"Timeline convergence point",
            "potential_sources": random.randint(2, 5),
            "realized_sources": 0
        }
        
        self.convergence_points.append(converge)
        
        # Add convergence event
        self.add_event(f"CONVERGENCE POINT: {converge['description']}", year)
        
        return converge
        
    def add_event(self, event: str, year: int):
        """Add an event to the timeline"""
        self.events.append((year, event))
        self.events.sort(key=lambda x: x[0])  # Keep events sorted
        
        # Check for interaction with time loops
        for loop in self.time_loops:
            if loop.start_year <= year <= loop.end_year:
                # Event is within a time loop
                loop.add_loop_event(year, event)
                
        return True
        
    def update(self, years_elapsed: float) -> Dict[str, Any]:
        """
        Update the timeline state based on elapsed time
        
        Args:
            years_elapsed: Number of years that have passed
            
        Returns:
            Information about changes
        """
        # Update progression
        progression_update = self.progression.update(years_elapsed)
        
        # Update time loops
        loop_updates = []
        for loop in self.time_loops:
            if loop.active and loop.end_year - loop.start_year > 0:
                # Calculate how many iterations would occur in the elapsed time
                loop_duration = loop.end_year - loop.start_year
                iterations = years_elapsed / loop_duration
                
                # Process each iteration
                while iterations >= 1.0:
                    iteration_result = loop.iterate()
                    loop_updates.append(iteration_result)
                    iterations -= 1.0
                    
                    # If loop broke, stop iterating
                    if not iteration_result["active"]:
                        break
        
        # For PLASTIC timelines, update mutability based on progression
        if self.timeline_type == TimelineType.PLASTIC:
            self.mutability = min(1.0, self.mutability + progression_update["change"] * 0.1)
            
        # For STATIC timelines, maintain high stability
        if self.timeline_type == TimelineType.STATIC:
            self.stability = min(1.0, self.stability + years_elapsed * 0.01)
            
        # For DYNAMIC timelines, stability fluctuates
        if self.timeline_type == TimelineType.DYNAMIC:
            stability_change = random.uniform(-0.05, 0.05) * years_elapsed
            self.stability = max(0.2, min(0.8, self.stability + stability_change))
            
        # Return update information
        return {
            "progression": progression_update,
            "loops": loop_updates,
            "stability": self.stability,
            "mutability": self.mutability,
            "years_elapsed": years_elapsed
        }
        
    def check_time_loop_status(self, current_year: int) -> List[Dict[str, Any]]:
        """
        Check the status of time loops for a given year
        
        Args:
            current_year: Current year to check
            
        Returns:
            List of loop status information
        """
        loop_statuses = []
        
        for loop in self.time_loops:
            # Calculate position in loop
            position = loop.get_loop_percentage(current_year)
            
            status = {
                "loop": loop,
                "in_loop": position >= 0,
                "position": position,
                "current_iteration": loop.current_iteration,
                "active": loop.active,
                "stability": loop.stability
            }
            
            if position >= 0:
                # We're inside the loop
                # Check if we're near the end (>90%)
                if position > 0.9:
                    status["approaching_reset"] = True
                    status["years_to_reset"] = loop.end_year - current_year
                    
            loop_statuses.append(status)
                
        return loop_statuses
        
    def predict_future(self, years_ahead: float) -> Dict[str, Any]:
        """
        Predict the future state of this timeline
        
        Args:
            years_ahead: How many years to look ahead
            
        Returns:
            Prediction information
        """
        # Get progression prediction
        progression_future = self.progression.predict_future_state(years_ahead)
        
        # Predict stability based on type
        predicted_stability = self.stability
        if self.timeline_type == TimelineType.STATIC:
            # Static timelines maintain stability
            stability_change = min(0.1, years_ahead * 0.01)
            predicted_stability = min(1.0, self.stability + stability_change)
            
        elif self.timeline_type == TimelineType.DYNAMIC:
            # Dynamic timelines fluctuate unpredictably
            max_change = min(0.3, years_ahead * 0.02)
            stability_change = random.uniform(-max_change, max_change)
            predicted_stability = max(0.2, min(0.9, self.stability + stability_change))
            
        elif self.timeline_type == TimelineType.BRANCHING:
            # Check if we'll hit branch points
            future_branches = [b for b in self.branch_points 
                             if self._get_latest_year() <= b["year"] <= self._get_latest_year() + years_ahead]
            
            if future_branches:
                # Each branch point reduces stability
                branch_impact = sum(b["stability_impact"] for b in future_branches)
                predicted_stability = max(0.1, min(1.0, self.stability + branch_impact))
                
        elif self.timeline_type == TimelineType.CONVERGING:
            # Check for future convergence points
            future_converge = [c for c in self.convergence_points 
                              if self._get_latest_year() <= c["year"] <= self._get_latest_year() + years_ahead]
            
            if future_converge:
                # Convergence usually increases stability
                converge_impact = sum(c["stability_impact"] for c in future_converge)
                predicted_stability = max(0.1, min(1.0, self.stability + converge_impact))
        
        # Time loop predictions
        loop_predictions = []
        for loop in self.time_loops:
            if loop.active:
                # Estimate iterations
                if loop.end_year > loop.start_year:
                    loop_duration = loop.end_year - loop.start_year
                    estimated_iterations = years_ahead / loop_duration
                    
                    future_stability = loop.stability
                    for _ in range(int(estimated_iterations)):
                        future_stability = max(0.0, future_stability - loop.decay_rate)
                        
                        # Check if loop might break
                        if future_stability < 0.1:
                            break
                            
                    loop_predictions.append({
                        "loop": str(loop),
                        "estimated_iterations": estimated_iterations,
                        "predicted_stability": future_stability,
                        "predicted_to_break": future_stability < 0.1
                    })
        
        # Return combined prediction
        return {
            "timeline_type": self.timeline_type.value,
            "years_ahead": years_ahead,
            "current_stability": self.stability,
            "predicted_stability": predicted_stability,
            "progression": progression_future,
            "time_loops": loop_predictions,
            "confidence": progression_future["prediction_confidence"]
        }
        
    def _get_latest_year(self) -> int:
        """Get the latest year in the timeline's events"""
        if not self.events:
            return 2000  # Default
        return max(year for year, _ in self.events)
        
    def find_nearest_branch_point(self, year: int) -> Optional[Dict[str, Any]]:
        """Find the nearest branch point to a given year"""
        if not self.branch_points:
            return None
            
        # Find closest by absolute difference
        return min(self.branch_points, key=lambda b: abs(b["year"] - year))
        
    def find_nearest_convergence_point(self, year: int) -> Optional[Dict[str, Any]]:
        """Find the nearest convergence point to a given year"""
        if not self.convergence_points:
            return None
            
        # Find closest by absolute difference, but only for future points
        future_points = [c for c in self.convergence_points if c["year"] >= year]
        if not future_points:
            return None
            
        return min(future_points, key=lambda c: c["year"] - year)
        
    def __str__(self) -> str:
        loop_info = f", {len(self.time_loops)} time loops" if self.time_loops else ""
        branch_info = f", {len(self.branch_points)} branch points" if self.branch_points else ""
        converge_info = f", {len(self.convergence_points)} convergence points" if self.convergence_points else ""
        
        return (f"{self.name} ({self.timeline_type.value.title()}): "
                f"Stability={self.stability:.2f}, Mutability={self.mutability:.2f}"
                f"{loop_info}{branch_info}{converge_info}")


def run_typed_timeline_demo():
    """Run a demonstration of the timeline types and time loops"""
    print("=== Timeline Types and Time Loops Demonstration ===")
    
    # Create different types of timelines
    timelines = [
        TypedTimeline("Static Alpha", TimelineType.STATIC),
        TypedTimeline("Dynamic Beta", TimelineType.DYNAMIC),
        TypedTimeline("Looped Gamma", TimelineType.LOOPED),
        TypedTimeline("Branching Delta", TimelineType.BRANCHING),
        TypedTimeline("Quantum Epsilon", TimelineType.QUANTUM)
    ]
    
    # Add some events to each timeline
    for timeline in timelines:
        timeline.add_event("Timeline origin", 2000)
        timeline.add_event("Early development", 2010)
        timeline.add_event("Key historical moment", 2025)
        timeline.add_event("Technological breakthrough", 2040)
        timeline.add_event("Cultural renaissance", 2055)
        
    # Display initial state
    print("\nInitial Timeline States:")
    for timeline in timelines:
        print(f"\n{timeline}")
        
        # Show special features
        if timeline.time_loops:
            print("Time Loops:")
            for loop in timeline.time_loops:
                print(f"  {loop}")
                
        if timeline.branch_points:
            print("Branch Points:")
            for branch in timeline.branch_points:
                print(f"  Year {branch['year']}: {branch['description']} ({branch['potential_branches']} potential branches)")
                
        if timeline.convergence_points:
            print("Convergence Points:")
            for converge in timeline.convergence_points:
                print(f"  Year {converge['year']}: {converge['description']}")
    
    # Simulate the passage of time
    print("\n\n=== Simulating Timeline Progression (25 years) ===")
    
    for timeline in timelines:
        # Simulate 25 years passing
        years_elapsed = 25
        update_results = timeline.update(years_elapsed)
        
        print(f"\n{timeline.name} after {years_elapsed} years:")
        print(f"  New stability: {timeline.stability:.2f}")
        print(f"  Progression change: {update_results['progression']['change']:.3f}")
        
        # Show time loop updates if any
        if update_results['loops']:
            print("  Time Loop Updates:")
            for loop_update in update_results['loops']:
                if loop_update.get('active', False):
                    print(f"    Iteration {loop_update['iteration']}, " +
                          f"Stability: {loop_update['stability']:.2f}")
                else:
                    print(f"    Loop broken: {loop_update.get('reason', 'Unknown')}")
    
    # Make some predictions
    print("\n\n=== Timeline Future Predictions (50 years ahead) ===")
    
    for timeline in timelines:
        prediction = timeline.predict_future(50)
        
        print(f"\n{timeline.name} prediction (confidence: {prediction['confidence']:.2f}):")
        print(f"  Current stability: {prediction['current_stability']:.2f}")
        print(f"  Predicted stability: {prediction['predicted_stability']:.2f}")
        
        # Show time loop predictions
        if prediction['time_loops']:
            print("  Time Loop Predictions:")
            for loop_pred in prediction['time_loops']:
                status = "break" if loop_pred['predicted_to_break'] else "continue"
                print(f"    {loop_pred['loop']} expected to {status}")
                print(f"      Estimated iterations: {loop_pred['estimated_iterations']:.1f}")
                print(f"      Predicted stability: {loop_pred['predicted_stability']:.2f}")
    
    # Create a special time loop demonstration
    print("\n\n=== Detailed Time Loop Demonstration ===")
    
    # Create a timeline with multiple overlapping loops
    loop_timeline = TypedTimeline("Chronos Nexus", TimelineType.LOOPED)
    
    # Add some events
    loop_timeline.add_event("Timeline creation", 2000)
    loop_timeline.add_event("First temporal anomaly", 2012)
    loop_timeline.add_event("Time loop research begins", 2020)
    loop_timeline.add_event("Experimental time loop created", 2025)
    loop_timeline.add_event("Paradox containment breakthrough", 2040)
    
    # Manually create specific time loops
    loop1 = TimeLoop(TimeLoopType.CAUSAL, 2020, 2030, None, 0.05,
                   "Information loop passing research data back")
    loop2 = TimeLoop(TimeLoopType.PREDESTINATION, 2025, 2040, 5, 0.1,
                   "Self-fulfilling prophecy loop with 5 iterations")
    loop3 = TimeLoop(TimeLoopType.MOBIUS, 2030, 2050, None, 0.02,
                   "Möbius strip loop with reality inversion")
    
    loop_timeline.time_loops.extend([loop1, loop2, loop3])
    
    # Add awareness to some entities
    loop1.add_entity_memory("Dr. Marcus Chen", 0.8)
    loop2.add_entity_memory("Temporal Research Team", 0.6)
    loop3.add_entity_memory("AI System CHRONOS", 1.0)
    
    # Add loop-specific events
    loop1.add_loop_event(2022, "Dr. Chen receives equations from the future")
    loop1.add_loop_event(2028, "Dr. Chen sends equations back to 2022")
    
    loop2.add_loop_event(2026, "Team attempts to prevent lab explosion")
    loop2.add_loop_event(2030, "Actions to prevent explosion cause it to happen")
    
    loop3.add_loop_event(2035, "Reality inversion begins")
    loop3.add_loop_event(2045, "Inverted reality reaches peak")
    
    # Show the timeline
    print(f"\n{loop_timeline}")
    print("\nTime Loops:")
    for loop in loop_timeline.time_loops:
        print(f"  {loop}")
        print(f"    Duration: {loop.get_duration()} years")
        print(f"    Aware entities:")
        for entity_id, memory in loop.entity_memory.items():
            print(f"      {entity_id} (Memory retention: {memory['retention']:.2f})")
    
    # Simulate loop iterations
    print("\nSimulating time loop iterations:")
    
    # Iterate loop1 three times
    print("\nLoop 1 (Causal) iterations:")
    for i in range(3):
        result = loop1.iterate()
        print(f"  Iteration {result['iteration']}: Stability={result['stability']:.2f}")
    
    # Iterate loop2 until it completes
    print("\nLoop 2 (Predestination) iterations (should run 5 times):")
    iteration = 1
    while True:
        result = loop2.iterate()
        print(f"  Iteration {result['iteration']}: Stability={result['stability']:.2f}")
        if not result['active']:
            print(f"  Loop completed after {iteration} iterations: {result['reason']}")
            break
        iteration += 1
    
    # Check current status in different years
    print("\nTime loop status at different years:")
    test_years = [2015, 2022, 2028, 2035, 2045, 2055]
    
    for year in test_years:
        print(f"\nYear {year}:")
        loop_statuses = loop_timeline.check_time_loop_status(year)
        
        for status in loop_statuses:
            loop = status['loop']
            if status['in_loop']:
                position = f"{status['position']*100:.0f}% through"
                approaching = " (approaching reset)" if status.get('approaching_reset') else ""
                print(f"  In {loop.loop_type.value} loop: {position}{approaching}")
            else:
                relation = "before" if year < loop.start_year else "after"
                print(f"  {relation} {loop.loop_type.value} loop")
    
    # Break a loop
    print("\nBreaking the Möbius loop:")
    if loop3.break_loop("Quantum intervention by AI System CHRONOS"):
        print(f"  Successfully broke loop: {loop3}")
    
    # Timeline futures with loops
    print("\nPredicting timeline future with remaining active loops:")
    future = loop_timeline.predict_future(30)
    print(f"  Predicted stability: {future['predicted_stability']:.2f}")
    print("  Loop predictions:")
    for loop_pred in future['time_loops']:
        print(f"    {loop_pred['loop']}")
        print(f"      Estimated iterations: {loop_pred['estimated_iterations']:.1f}")
        print(f"      Predicted to break: {loop_pred['predicted_to_break']}")
    
    return timelines, loop_timeline


if __name__ == "__main__":
    run_typed_timeline_demo()
