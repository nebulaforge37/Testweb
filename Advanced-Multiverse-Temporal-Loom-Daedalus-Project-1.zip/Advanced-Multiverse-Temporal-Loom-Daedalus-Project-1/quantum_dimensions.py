
"""
Quantum Dimensions System
This module provides classes for modeling higher-dimensional spaces and quantum realities
beyond the regular multiverse timelines.
"""

import random
import math
from typing import Dict, List, Tuple, Optional, Set

class QuantumDimension:
    """Represents a quantum dimension with its own physical laws and properties"""
    
    def __init__(self, dimension_id: int, name: str = None, complexity: float = None, 
                stability: float = None, accessibility: float = None):
        """
        Initialize a quantum dimension
        
        Args:
            dimension_id: Unique identifier (1-10000)
            name: Name of this dimension
            complexity: How complex/different the physics are (0.0-1.0)
            stability: How stable this dimension is (0.0-1.0)
            accessibility: How easy it is to access from the prime dimension (0.0-1.0)
        """
        self.dimension_id = dimension_id
        self.name = name or f"Quantum Dimension {dimension_id}"
        self.complexity = complexity or random.uniform(0.1, 1.0)
        self.stability = stability or random.uniform(0.2, 1.0)
        self.accessibility = accessibility or random.uniform(0.05, 0.9)
        
        # Special dimensional properties
        self.time_flow_rate = random.uniform(0.5, 2.0)  # 1.0 = normal time flow, 2.0 = twice as fast
        self.spacial_dimensions = random.randint(3, 11)  # From 3D to 11D
        self.energy_density = random.uniform(0.5, 5.0)   # Energy density relative to prime dimension
        self.quantum_state_persistence = random.uniform(0.1, 1.0)  # How persistent quantum states are
        
        # Connection points to other dimensions
        self.dimensional_gates = set()
        
        # Realities that exist within this dimension
        self.realities = {}
        
    def add_gate(self, target_dimension_id: int, stability: float = None):
        """Add a dimensional gate to another quantum dimension"""
        gate_stability = stability or random.uniform(0.2, 0.9)
        self.dimensional_gates.add((target_dimension_id, gate_stability))
        return gate_stability
        
    def create_reality(self, reality_id: int) -> 'QuantumReality':
        """Create a new reality in this dimension"""
        reality = QuantumReality(reality_id, self.dimension_id)
        self.realities[reality_id] = reality
        return reality
    
    def calculate_travel_risk(self, origin_dimension_id: int = 1) -> float:
        """Calculate risk factor for traveling to this dimension from origin"""
        # Base risk based on complexity (higher complexity = higher risk)
        base_risk = self.complexity * 0.5
        
        # Modifier based on stability (lower stability = higher risk)
        stability_factor = (1.0 - self.stability) * 0.3
        
        # Modifier based on accessibility (lower accessibility = higher risk)
        accessibility_factor = (1.0 - self.accessibility) * 0.2
        
        # Extreme dimensions (very far from origin) are riskier
        distance_factor = min(0.4, abs(self.dimension_id - origin_dimension_id) / 10000 * 0.4)
        
        # Combine all factors
        return min(1.0, base_risk + stability_factor + accessibility_factor + distance_factor)
    
    def physical_laws_description(self) -> str:
        """Generate a description of the physical laws in this dimension"""
        descriptions = []
        
        # Time flow
        if self.time_flow_rate < 0.7:
            descriptions.append(f"Time flows {1/self.time_flow_rate:.1f}x slower than normal")
        elif self.time_flow_rate > 1.3:
            descriptions.append(f"Time flows {self.time_flow_rate:.1f}x faster than normal")
        else:
            descriptions.append("Time flows at a normal rate")
            
        # Spatial dimensions
        if self.spacial_dimensions > 3:
            extra_dims = self.spacial_dimensions - 3
            descriptions.append(f"Contains {extra_dims} additional spatial dimensions")
            
        # Energy density
        if self.energy_density < 0.7:
            descriptions.append("Low energy density environment")
        elif self.energy_density > 1.3:
            descriptions.append(f"High energy density ({self.energy_density:.1f}x normal)")
            
        # Quantum persistence
        if self.quantum_state_persistence > 0.8:
            descriptions.append("Quantum states persist unusually long")
        elif self.quantum_state_persistence < 0.3:
            descriptions.append("Quantum states collapse rapidly")
            
        return "; ".join(descriptions)
    
    def __str__(self) -> str:
        gate_count = len(self.dimensional_gates)
        reality_count = len(self.realities)
        return (f"Dimension {self.dimension_id}: {self.name} - " 
                f"Complexity: {self.complexity:.2f}, "
                f"Stability: {self.stability:.2f}, "
                f"Gates: {gate_count}, Realities: {reality_count}")


class QuantumReality:
    """Represents a specific reality within a quantum dimension"""
    
    def __init__(self, reality_id: int, dimension_id: int, name: str = None, 
                divergence: float = None, consistency: float = None):
        """
        Initialize a quantum reality
        
        Args:
            reality_id: Unique identifier
            dimension_id: The dimension this reality exists in
            name: Name of this reality
            divergence: How much this reality diverges from prime reality (0.0-1.0)
            consistency: How internally consistent this reality is (0.0-1.0)
        """
        self.reality_id = reality_id
        self.dimension_id = dimension_id
        self.name = name or f"Reality {reality_id} (D{dimension_id})"
        self.divergence = divergence or random.uniform(0.1, 1.0)
        self.consistency = consistency or random.uniform(0.3, 1.0)
        
        # Reality properties
        self.time_variance = random.uniform(0.0, 0.5)  # Time variance from dimension's base time
        self.physical_constants_shift = random.uniform(0.0, self.divergence)  # How much physical constants differ
        self.causality_integrity = random.uniform(max(0.2, 1.0 - self.divergence), 1.0)  # Integrity of cause-effect
        
        # Events specific to this reality
        self.events = []
        
    def add_event(self, description: str, year: int = None):
        """Add an event to this reality's history"""
        if year is None:
            # Generate random year between 1900-2200
            year = random.randint(1900, 2200)
        self.events.append((year, description))
        self.events.sort(key=lambda x: x[0])  # Keep events sorted by year
        
    def calculate_compatibility(self, other_reality: 'QuantumReality') -> float:
        """Calculate compatibility between this reality and another"""
        # Base compatibility starts at 1.0 (100% compatible)
        base_compatibility = 1.0
        
        # Different dimensions reduce compatibility significantly
        if self.dimension_id != other_reality.dimension_id:
            base_compatibility *= 0.5
            
        # Divergence difference matters (more similar divergence = more compatible)
        divergence_diff = abs(self.divergence - other_reality.divergence)
        divergence_factor = 1.0 - (divergence_diff * 0.5)
        
        # Physical constants difference
        constants_diff = abs(self.physical_constants_shift - other_reality.physical_constants_shift)
        constants_factor = 1.0 - (constants_diff * 0.3)
        
        # Combine all factors
        raw_compatibility = base_compatibility * divergence_factor * constants_factor
        
        # Return normalized 0-1 compatibility
        return max(0.0, min(1.0, raw_compatibility))
    
    def __str__(self) -> str:
        event_count = len(self.events)
        return (f"Reality {self.reality_id} ({self.name}): "
                f"Divergence: {self.divergence:.2f}, "
                f"Consistency: {self.consistency:.2f}, "
                f"Events: {event_count}")


class DimensionalRegistry:
    """Registry managing all quantum dimensions and realities"""
    
    def __init__(self):
        """Initialize the dimensional registry"""
        self.dimensions: Dict[int, QuantumDimension] = {}
        self.realities: Dict[int, QuantumReality] = {}
        self.prime_dimension = None
        self._next_reality_id = 1
        
    def initialize_dimensions(self, count: int = 100, max_id: int = 10000):
        """Initialize multiple dimensions with random properties"""
        # Create prime dimension (dimension 1)
        prime = self.create_dimension(1, "Prime Dimension", 0.1, 1.0, 1.0)
        self.prime_dimension = prime
        
        # Create additional dimensions
        created_dimensions = [prime]
        for _ in range(count - 1):
            # Generate random dimension ID between 2 and max_id
            dimension_id = random.randint(2, max_id)
            while dimension_id in self.dimensions:
                dimension_id = random.randint(2, max_id)
                
            dimension = self.create_dimension(dimension_id)
            created_dimensions.append(dimension)
        
        # Create dimensional gates (connections between dimensions)
        for dimension in created_dimensions:
            # Each dimension connects to 1-5 other dimensions
            gate_count = random.randint(1, min(5, count - 1))
            
            for _ in range(gate_count):
                # Choose a random dimension to connect to
                target = random.choice(created_dimensions)
                
                # Don't connect to self
                while target.dimension_id == dimension.dimension_id:
                    target = random.choice(created_dimensions)
                    
                # Create bidirectional gates
                dimension.add_gate(target.dimension_id)
                target.add_gate(dimension.dimension_id)
        
        # Create some initial realities in each dimension
        for dimension in created_dimensions:
            # Each dimension gets 1-3 realities initially
            reality_count = random.randint(1, 3)
            for _ in range(reality_count):
                self.create_reality(dimension.dimension_id)
        
        return created_dimensions
    
    def create_dimension(self, dimension_id: int, name: str = None, 
                        complexity: float = None, stability: float = None, 
                        accessibility: float = None) -> QuantumDimension:
        """Create a new quantum dimension"""
        dimension = QuantumDimension(dimension_id, name, complexity, stability, accessibility)
        self.dimensions[dimension_id] = dimension
        return dimension
    
    def create_reality(self, dimension_id: int, reality_id: int = None,
                      name: str = None, divergence: float = None, 
                      consistency: float = None) -> Optional[QuantumReality]:
        """Create a new reality in a specified dimension"""
        dimension = self.dimensions.get(dimension_id)
        if not dimension:
            return None
            
        # Generate reality ID if not provided
        if reality_id is None:
            reality_id = self._next_reality_id
            self._next_reality_id += 1
            
        # Create the reality through the dimension
        reality = dimension.create_reality(reality_id)
        
        # Update the name and properties if provided
        if name:
            reality.name = name
        if divergence is not None:
            reality.divergence = divergence
        if consistency is not None:
            reality.consistency = consistency
            
        # Register in the global reality registry
        self.realities[reality_id] = reality
        
        return reality
    
    def get_dimension(self, dimension_id: int) -> Optional[QuantumDimension]:
        """Get a dimension by ID"""
        return self.dimensions.get(dimension_id)
    
    def get_reality(self, reality_id: int) -> Optional[QuantumReality]:
        """Get a reality by ID"""
        return self.realities.get(reality_id)
    
    def find_path_between_dimensions(self, start_id: int, target_id: int, 
                                    max_jumps: int = 5) -> Optional[List[int]]:
        """Find a path between dimensions using dimensional gates"""
        if start_id not in self.dimensions or target_id not in self.dimensions:
            return None
            
        # Direct path
        if start_id == target_id:
            return [start_id]
            
        # Breadth-first search for a path
        queue = [(start_id, [start_id])]
        visited = {start_id}
        
        while queue:
            current_id, path = queue.pop(0)
            current = self.dimensions[current_id]
            
            # Don't exceed max jumps
            if len(path) > max_jumps:
                continue
                
            for gate_target, _ in current.dimensional_gates:
                if gate_target == target_id:
                    # Found the target
                    return path + [target_id]
                    
                if gate_target not in visited:
                    visited.add(gate_target)
                    queue.append((gate_target, path + [gate_target]))
        
        # No path found
        return None
    
    def calculate_dimensional_travel_difficulty(self, start_id: int, 
                                              target_id: int) -> Tuple[float, str]:
        """Calculate difficulty of traveling between dimensions and reasoning"""
        if start_id not in self.dimensions or target_id not in self.dimensions:
            return 1.0, "Invalid dimension IDs"
            
        # Same dimension is easy
        if start_id == target_id:
            return 0.1, "Same dimension travel"
            
        start = self.dimensions[start_id]
        target = self.dimensions[target_id]
        
        # Check if direct gate exists
        direct_gate = False
        gate_stability = 0.0
        for gate_id, stability in start.dimensional_gates:
            if gate_id == target_id:
                direct_gate = True
                gate_stability = stability
                break
                
        # Calculate base difficulty
        if direct_gate:
            # Direct gates make travel easier
            difficulty = 0.3 + (1.0 - gate_stability) * 0.4
            reason = f"Direct dimensional gate exists (stability: {gate_stability:.2f})"
        else:
            # No direct gate makes travel harder
            path = self.find_path_between_dimensions(start_id, target_id)
            if path:
                # Indirect route
                difficulty = 0.5 + (len(path) - 2) * 0.15
                reason = f"Indirect route available ({len(path)} jumps)"
            else:
                # No route
                difficulty = 0.9
                reason = "No known route between dimensions"
        
        # Target dimension properties affect difficulty
        target_factors = target.calculate_travel_risk(start_id)
        difficulty = (difficulty + target_factors) / 2
        
        return min(1.0, difficulty), reason
    
    def get_most_unstable_dimensions(self, count: int = 5) -> List[QuantumDimension]:
        """Get the most unstable quantum dimensions"""
        dimensions = list(self.dimensions.values())
        dimensions.sort(key=lambda d: d.stability)
        return dimensions[:count]
    
    def get_nearest_dimensions(self, dimension_id: int, count: int = 5) -> List[Tuple[QuantumDimension, int]]:
        """Get dimensions nearest to the specified dimension (by gate distance)"""
        if dimension_id not in self.dimensions:
            return []
            
        results = []
        dimension = self.dimensions[dimension_id]
        
        # Direct connections come first
        for gate_id, _ in dimension.dimensional_gates:
            if gate_id in self.dimensions:
                results.append((self.dimensions[gate_id], 1))
                
        # If we need more, do a BFS to find more distant connections
        visited = {dimension_id} | {d[0].dimension_id for d in results}
        queue = [(gate_id, 1) for gate_id, _ in dimension.dimensional_gates]
        
        while queue and len(results) < count:
            current_id, distance = queue.pop(0)
            
            if current_id in visited:
                continue
                
            visited.add(current_id)
            if current_id in self.dimensions:
                results.append((self.dimensions[current_id], distance))
                
            # Add the next level
            if len(results) < count and distance < 3:  # Limit to distance 3
                current = self.dimensions.get(current_id)
                if current:
                    for gate_id, _ in current.dimensional_gates:
                        if gate_id not in visited:
                            queue.append((gate_id, distance + 1))
        
        # Sort by distance
        results.sort(key=lambda x: x[1])
        return results[:count]
    
    def __str__(self) -> str:
        return f"Dimensional Registry: {len(self.dimensions)} dimensions, {len(self.realities)} realities"


# Utility function to generate creative names for dimensions and realities
def generate_dimension_name() -> str:
    """Generate a creative name for a quantum dimension"""
    prefixes = ["Alpha", "Beta", "Gamma", "Delta", "Sigma", "Omega", "Zeta", "Theta", 
               "Kappa", "Lambda", "Epsilon", "Neo", "Hyper", "Ultra", "Quantum", "Void",
               "Nexus", "Echo", "Flux", "Pulse", "Shift", "Rift", "Fold", "Veil"]
    
    suffixes = ["Continuum", "Realm", "Dimension", "Domain", "Matrix", "Cosmos", "Void",
               "Expanse", "Sphere", "Plane", "Reality", "Universe", "Lattice", "Field",
               "Manifold", "Construct", "Spectrum", "Paradigm", "Quanta", "Nexus"]
    
    descriptors = ["Twisted", "Shimmering", "Unstable", "Forgotten", "Forbidden",
                  "Infinite", "Eternal", "Impossible", "Paradoxical", "Luminous",
                  "Shadow", "Crystal", "Chaotic", "Harmonic", "Divergent", "Resonant"]
    
    name_type = random.randint(1, 3)
    
    if name_type == 1:
        # [Prefix] [Suffix]
        return f"{random.choice(prefixes)} {random.choice(suffixes)}"
    elif name_type == 2:
        # [Descriptor] [Suffix]
        return f"{random.choice(descriptors)} {random.choice(suffixes)}"
    else:
        # [Prefix]-[Number] [Suffix]
        return f"{random.choice(prefixes)}-{random.randint(1, 999)} {random.choice(suffixes)}"
