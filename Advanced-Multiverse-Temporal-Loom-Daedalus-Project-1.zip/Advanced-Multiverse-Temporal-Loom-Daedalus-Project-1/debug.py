
#!/usr/bin/env python3
"""
Multiverse Simulation System - Debug Module
This script helps to debug and test various components of the system.
"""

import sys
import time
from implementation_checklist import ImplementationChecker
from boot_loader import BootSequence

def debug_boot_sequence():
    """Test the boot sequence and identify any initialization issues"""
    print("=== Debugging Boot Sequence ===")
    boot = BootSequence()
    
    # Run boot in verbose mode to see detailed output
    success = boot.boot(verbose=True)
    
    if not success:
        print(f"\nBoot sequence failed with status: {boot.status}")
        return None
    
    print("\nBoot sequence completed successfully!")
    
    # Return the multiverse instance for further testing
    return boot.get_system("multiverse")

def debug_implementation_state():
    """Check the implementation status of all components"""
    print("=== Checking Implementation Status ===")
    checker = ImplementationChecker()
    checker.print_implementation_report()

def debug_timeline_functions(multiverse):
    """Test basic timeline operations"""
    if not multiverse:
        print("No multiverse instance available!")
        return
    
    print("=== Testing Timeline Functions ===")
    
    # Create a test timeline
    print("\nCreating test timeline...")
    test_timeline = multiverse.create_timeline("Debug-Timeline", 0.8)
    
    # Add some events
    print("Adding events to timeline...")
    test_timeline.add_event("Debug started", 2023)
    test_timeline.add_event("First test event", 2024)
    test_timeline.add_event("Second test event", 2025)
    
    # Display the timeline
    print("\nTimeline state:")
    test_timeline.display()
    
    # Test quantum state
    print("\nTesting quantum state...")
    test_timeline.quantum_state.enter_superposition()
    print(f"In superposition: {test_timeline.quantum_state.superposition}")
    test_timeline.quantum_state.update_quantum_field(0.5)
    print(f"Quantum field energy: {test_timeline.quantum_state.quantum_field_energy}")

def main():
    """Main debug function"""
    print("Multiverse Simulation System - Debug Mode")
    print("=" * 50)
    
    # Step 1: Check implementation state
    debug_implementation_state()
    
    # Step 2: Test boot sequence
    multiverse = debug_boot_sequence()
    
    # Step 3: Test timeline operations if multiverse was loaded
    if multiverse:
        debug_timeline_functions(multiverse)
    
    print("\nDebug session completed!")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nError during debugging: {e}")
        import traceback
        traceback.print_exc()
