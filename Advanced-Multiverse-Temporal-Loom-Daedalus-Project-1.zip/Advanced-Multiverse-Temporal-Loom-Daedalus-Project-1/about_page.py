
#!/usr/bin/env python3
"""
About Page for Multiverse Simulator
This module provides version information and system details for the
Multiverse Paradox Quantum Field Simulator.
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, scrolledtext
import platform

# System version information
VERSION_INFO = {
    "version": "1.0.0",
    "codename": "Temporal Nexus",
    "build_date": "2025-2-6",
    "release_type": "Alpha",
    "build_number": "A001",
    "api_compatibility": "1.0",
    "required_python_version": "3.7+",
}

# System credits
CREDITS = {
    "Lead Developer": "Temporal Dynamics Team",
    "Architecture Design": "Quantum Physics Division",
    "UI/UX Design": "Multiverse Interface Group",
    "Quantum Algorithms": "Quantum Computing Division",
    "Technical Documentation": "Temporal Archives Department",
}

# Core technologies
TECHNOLOGIES = [
    "Python 3 - Core Programming Language",
    "Tkinter - GUI Framework",
    "NumPy - Numerical Computation",
    "Matplotlib - Visualization",
    "SQLite - Local Database Storage",
]

class AboutPage:
    """About page showing version information and system details"""
    
    def __init__(self, root=None):
        """Initialize the about page"""
        self.standalone = root is None
        
        if self.standalone:
            # Create a new window if running standalone
            self.root = tk.Tk()
            self.root.title("About Multiverse Simulator")
            self.root.geometry("700x600")
            self.root.resizable(True, True)
            self.root.configure(bg="#1e1e2e")
            self.create_styles()
        else:
            # Use the provided root if embedded in another app
            self.root = root
        
        self.setup_ui()
        
        if self.standalone:
            self.root.mainloop()
    
    def create_styles(self):
        """Create ttk styles for the UI"""
        style = ttk.Style()
        
        # Try to use a theme that looks good
        available_themes = style.theme_names()
        if 'clam' in available_themes:
            style.theme_use('clam')
        elif 'alt' in available_themes:
            style.theme_use('alt')
        
        # Configure styles with enhanced color scheme
        style.configure('TFrame', background='#1e1e2e')
        style.configure('TLabel', background='#1e1e2e', foreground='#ffffff')
        style.configure('Header.TLabel', font=('Arial', 16, 'bold'), foreground='#78adff')
        style.configure('Subheader.TLabel', font=('Arial', 12, 'bold'), foreground='#aed8ff')
        style.configure('Version.TLabel', font=('Arial', 10), foreground='#b8ffb0')
        style.configure('Credits.TLabel', font=('Arial', 10), foreground='#ffffff')
        
        # Add button styles
        style.configure('TButton', background='#2d2d44', foreground='#ffffff')
        style.map('TButton', 
                 background=[('active', '#3d3d64'), ('pressed', '#252538')],
                 foreground=[('active', '#ffffff'), ('pressed', '#cccccc')])
        
        # Add styles for system info section
        style.configure('Info.TLabel', background='#252538', foreground='#f0f0f0', padding=5)
        style.configure('InfoTitle.TLabel', background='#252538', foreground='#78adff', 
                       font=('Arial', 10, 'bold'), padding=5)
    
    def setup_ui(self):
        """Set up the user interface"""
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title and logo section
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=10)
        
        title_label = ttk.Label(title_frame, 
                               text="Multiverse Paradox Quantum Field Simulator", 
                               style='Header.TLabel')
        title_label.pack(pady=5)
        
        version_text = f"Version {VERSION_INFO['version']} ({VERSION_INFO['codename']}) - {VERSION_INFO['release_type']}"
        version_label = ttk.Label(title_frame, text=version_text, style='Version.TLabel')
        version_label.pack()
        
        build_text = f"Build {VERSION_INFO['build_number']} - {VERSION_INFO['build_date']}"
        build_label = ttk.Label(title_frame, text=build_text)
        build_label.pack()
        
        # Create a notebook for tabbed organization
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # System Information Tab
        system_tab = ttk.Frame(notebook)
        notebook.add(system_tab, text="System Info")
        
        # System information section
        system_frame = ttk.LabelFrame(system_tab, text="System Information")
        system_frame.pack(fill=tk.X, pady=10, padx=5)
        
        # Get system info
        system_info = self.get_system_info()
        
        # Display system info in a grid
        row = 0
        for key, value in system_info.items():
            key_label = ttk.Label(system_frame, text=f"{key}:", anchor="e", style="InfoTitle.TLabel")
            key_label.grid(row=row, column=0, sticky="e", padx=5, pady=2)
            
            value_label = ttk.Label(system_frame, text=value, style="Info.TLabel")
            value_label.grid(row=row, column=1, sticky="w", padx=5, pady=2)
            
            row += 1
        
        # Configure grid column weights for system_frame
        system_frame.columnconfigure(0, weight=1)
        system_frame.columnconfigure(1, weight=3)
        
        # Technologies frame
        tech_frame = ttk.LabelFrame(system_tab, text="Core Technologies")
        tech_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=5)
        
        tech_text = scrolledtext.ScrolledText(tech_frame, wrap=tk.WORD, height=6)
        tech_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        for tech in TECHNOLOGIES:
            tech_text.insert(tk.END, f"• {tech}\n")
        tech_text.config(state=tk.DISABLED)
        
        # Credits Tab
        credits_tab = ttk.Frame(notebook)
        notebook.add(credits_tab, text="Credits")
        
        # Credits section
        credits_frame = ttk.LabelFrame(credits_tab, text="Development Team")
        credits_frame.pack(fill=tk.X, pady=10, padx=5)
        
        row = 0
        for role, name in CREDITS.items():
            role_label = ttk.Label(credits_frame, text=f"{role}:", anchor="e", style="InfoTitle.TLabel")
            role_label.grid(row=row, column=0, sticky="e", padx=5, pady=2)
            
            name_label = ttk.Label(credits_frame, text=name, style="Info.TLabel")
            name_label.grid(row=row, column=1, sticky="w", padx=5, pady=2)
            
            row += 1
        
        # Configure grid column weights for credits_frame
        credits_frame.columnconfigure(0, weight=1)
        credits_frame.columnconfigure(1, weight=3)
        
        # Full credits section
        full_credits_frame = ttk.LabelFrame(credits_tab, text="Additional Recognition")
        full_credits_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=5)
        
        full_credits_text = scrolledtext.ScrolledText(full_credits_frame, wrap=tk.WORD)
        full_credits_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Add some additional recognition text
        full_credits_text.insert(tk.INSERT, """# Development Contributors

## Core Development Team
- Temporal Dynamics Team - Core architecture and timeline algorithms
- Quantum Physics Division - Quantum mechanics simulation models
- Multiverse Interface Group - User experience and interface design
- Paradox Resolution Team - Paradox detection and resolution algorithms

## Special Thanks
- Quantum Computing Division - Quantum algorithms optimization
- Temporal Archives Department - Documentation and knowledge base
- Theoretical Physics Consultants - Scientific accuracy review
- Beta Testing Group - Extensive testing and feedback
""")
        full_credits_text.config(state=tk.DISABLED)
        
        # Description Tab
        description_tab = ttk.Frame(notebook)
        notebook.add(description_tab, text="Description")
        
        # Description section
        desc_frame = ttk.Frame(description_tab)
        desc_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=5)
        
        desc_text = scrolledtext.ScrolledText(desc_frame, wrap=tk.WORD)
        desc_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        desc_text.insert(tk.INSERT, self.get_description())
        desc_text.config(state=tk.DISABLED, bg='#252538', fg='#ffffff')
        
        # Bottom buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ok_button = ttk.Button(button_frame, text="OK", command=self.close_window)
        ok_button.pack(side=tk.RIGHT, padx=5)
        
        if self.standalone:
            # Only show these buttons in standalone mode            
            license_button = ttk.Button(button_frame, text="License", 
                                       command=self.show_license)
            license_button.pack(side=tk.RIGHT, padx=5)
            
            system_button = ttk.Button(button_frame, text="System Status", 
                                       command=self.show_system_status)
            system_button.pack(side=tk.RIGHT, padx=5)
    
    def get_system_info(self):
        """Get system information dictionary"""
        return {
            "Python Version": platform.python_version(),
            "OS Platform": platform.platform(),
            "Processor": platform.processor() or "Unknown",
            "System": platform.system(),
            "API Compatibility": VERSION_INFO["api_compatibility"],
            "Required Python": VERSION_INFO["required_python_version"],
        }
    
    def get_description(self):
        """Get the system description text"""
        return (
            "# Multiverse Paradox Quantum Field Simulator\n\n"
            "The Multiverse Paradox Quantum Field Simulator is an advanced system "
            "for modeling and simulating quantum multiverse mechanics, incorporating "
            "relativistic time dilation, paradox management, and quantum field theory.\n\n"
            "## Core Capabilities\n\n"
            "This simulator allows users to create and manipulate timelines, quantum "
            "dimensions, and realities, as well as simulate time travel and its consequences. "
            "Using advanced quantum field calculations, the system can predict timeline "
            "bifurcations, reality merges, and paradox resolutions with high accuracy.\n\n"
            "## Advanced Features\n\n"
            "- **Timeline Management**: Create, edit, and visualize multiple timelines\n"
            "- **Quantum Dimensions**: Explore alternate dimensions with different physical laws\n"
            "- **Paradox Resolution**: Automated detection and resolution of temporal paradoxes\n"
            "- **Reality Bifurcation**: Observe how quantum decisions create reality branches\n"
            "- **Time Travel Simulation**: Model the effects of backwards and forwards time travel\n\n"
            "## Scientific Foundation\n\n"
            "The system is designed for theoretical physics research and education "
            "purposes, providing tools to explore complex quantum and temporal concepts "
            "in an accessible interface. All simulations are based on established theoretical "
            "frameworks including:\n\n"
            "- Many-worlds interpretation of quantum mechanics\n"
            "- Novikov self-consistency principle\n"
            "- Wheeler-DeWitt equation for quantum gravity\n"
            "- Relativistic quantum field theory\n"
            "- Fifth-dimensional Kaluza-Klein mathematical models\n\n"
            "The simulator serves as both an educational tool and a theoretical playground "
            "for exploring the implications of multiverse theories and quantum mechanics."
        )
    
    def show_full_credits(self):
        """Show full credits in a new window"""
        credits_window = tk.Toplevel(self.root)
        credits_window.title("Full Credits")
        credits_window.geometry("500x400")
        
        credits_text = scrolledtext.ScrolledText(credits_window, wrap=tk.WORD)
        credits_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        credits_content = """# Full Credits

## Core Development Team
- Temporal Dynamics Team - Core architecture and timeline algorithms
- Quantum Physics Division - Quantum mechanics simulation and entanglement models
- Multiverse Interface Group - User experience and interface design
- Paradox Resolution Team - Paradox detection and resolution algorithms

## Special Thanks
- Quantum Computing Division - Quantum computing algorithms
- Temporal Archives Department - Documentation and knowledge management
- Theoretical Physics Consultants - Scientific accuracy review
- Beta Testing Group - Extensive testing and feedback

## Open Source Acknowledgements
This project makes use of several open source libraries and tools that have made
it possible. We extend our gratitude to the developers and contributors of:
- Python - Programming language
- NumPy - Numerical computation
- Matplotlib - Data visualization
- SQLite - Database engine
- Tkinter - GUI framework

## Academic Consultants
Special thanks to the theoretical physics departments that provided valuable
insights and consultation on multiverse theory, quantum mechanics, and
relativistic physics concepts.
"""
        
        credits_text.insert(tk.INSERT, credits_content)
        credits_text.config(state=tk.DISABLED)
    
    def show_license(self):
        """Show license information in a new window"""
        license_window = tk.Toplevel(self.root)
        license_window.title("License Information")
        license_window.geometry("500x400")
        license_window.configure(bg="#1e1e2e")
        
        license_text = scrolledtext.ScrolledText(license_window, wrap=tk.WORD)
        license_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        license_content = """# License Information

The Multiverse Paradox Quantum Field Simulator is a theoretical physics simulation
tool designed for educational and research purposes.

## Usage Terms
This software is provided for educational and theoretical research purposes only.
The simulation and its outputs should not be considered an accurate representation
of actual physical phenomena.

## Disclaimer
The concepts represented in this simulation are based on theoretical physics,
including multiverse theory, quantum mechanics, and relativistic physics. The
accuracy of these concepts in representing actual physical reality is subject
to ongoing scientific research and debate.

## Copyright
© 2025 Multiverse Simulation System Team
All rights reserved.

This software is protected by copyright law. Unauthorized reproduction or
distribution may result in civil and criminal penalties.

## Contact
For inquiries regarding this software, please contact:
temporal-support@multiverse-simulation.example.com
"""
        
        license_text.insert(tk.INSERT, license_content)
        license_text.config(state=tk.DISABLED, bg='#252538', fg='#ffffff')
    
    def show_system_status(self):
        """Show system status and diagnostics in a new window"""
        status_window = tk.Toplevel(self.root)
        status_window.title("System Status")
        status_window.geometry("600x500")
        status_window.configure(bg="#1e1e2e")
        
        # Create notebook for different status sections
        status_notebook = ttk.Notebook(status_window)
        status_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Diagnostic Tab
        diag_tab = ttk.Frame(status_notebook)
        status_notebook.add(diag_tab, text="Diagnostics")
        
        # Memory usage
        mem_frame = ttk.LabelFrame(diag_tab, text="Memory Usage")
        mem_frame.pack(fill=tk.X, padx=5, pady=5)
        
        try:
            import psutil
            process = psutil.Process(os.getpid())
            memory_usage = process.memory_info().rss / 1024 / 1024  # MB
            cpu_usage = psutil.cpu_percent()
            
            ttk.Label(mem_frame, text=f"Memory Usage: {memory_usage:.2f} MB", style="Info.TLabel").pack(anchor="w", padx=5, pady=2)
            ttk.Label(mem_frame, text=f"CPU Usage: {cpu_usage:.1f}%", style="Info.TLabel").pack(anchor="w", padx=5, pady=2)
        except ImportError:
            ttk.Label(mem_frame, text="psutil module not available for memory statistics", style="Info.TLabel").pack(anchor="w", padx=5, pady=2)
        
        # Module status
        module_frame = ttk.LabelFrame(diag_tab, text="Module Status")
        module_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        module_text = scrolledtext.ScrolledText(module_frame, wrap=tk.WORD)
        module_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Check for key modules
        module_text.insert(tk.END, "Module Status Check:\n\n")
        core_modules = [
            "temporal_physics", "quantum_dimensions", "alternate_realities",
            "timeline_types", "paradox_forecasting", "timeline_visualization"
        ]
        
        for module in core_modules:
            try:
                module_spec = importlib.util.find_spec(module)
                if module_spec is not None:
                    module_text.insert(tk.END, f"✅ {module} - Available\n")
                else:
                    module_text.insert(tk.END, f"❌ {module} - Not found\n")
            except (ImportError, AttributeError):
                module_text.insert(tk.END, f"❌ {module} - Import error\n")
        
        module_text.config(state=tk.DISABLED, bg='#252538', fg='#ffffff')
        
        # System Health Tab
        health_tab = ttk.Frame(status_notebook)
        status_notebook.add(health_tab, text="System Health")
        
        health_frame = ttk.Frame(health_tab)
        health_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        health_text = scrolledtext.ScrolledText(health_frame, wrap=tk.WORD)
        health_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Generate a simulated system health report
        health_text.insert(tk.END, "# System Health Report\n\n")
        health_text.insert(tk.END, "## Quantum Field Stability\n")
        
        # Generate random metrics for the simulation
        health_metrics = {
            "Quantum Field Stability": random.uniform(85, 99),
            "Timeline Integrity": random.uniform(90, 99),
            "Paradox Prevention": random.uniform(80, 98),
            "Multiverse Coherence": random.uniform(85, 97),
            "Dimension Boundary Integrity": random.uniform(88, 99)
        }
        
        for metric, value in health_metrics.items():
            status = "Optimal" if value > 95 else "Good" if value > 90 else "Acceptable" if value > 85 else "Needs Attention"
            health_text.insert(tk.END, f"{metric}: {value:.1f}% - {status}\n")
        
        health_text.insert(tk.END, "\n## Recommendations\n")
        if min(health_metrics.values()) < 90:
            health_text.insert(tk.END, "• Consider running system optimization\n")
            health_text.insert(tk.END, "• Check quantum field calibration\n")
        else:
            health_text.insert(tk.END, "• System operating within optimal parameters\n")
            health_text.insert(tk.END, "• Regular maintenance recommended\n")
        
        health_text.config(state=tk.DISABLED, bg='#252538', fg='#ffffff')
        
        # Close button
        close_button = ttk.Button(status_window, text="Close", command=status_window.destroy)
        close_button.pack(side=tk.BOTTOM, pady=10)
    
    def close_window(self):
        """Close the window if in standalone mode"""
        if self.standalone:
            self.root.destroy()


def show_about_dialog(parent=None):
    """
    Show the about dialog. Can be called from other modules.
    
    Args:
        parent: Optional parent window
    """
    if parent:
        dialog = tk.Toplevel(parent)
        dialog.title("About Multiverse Simulator")
        dialog.geometry("700x600")
        dialog.transient(parent)
        dialog.grab_set()
        
        about_page = AboutPage(dialog)
        
        # Make dialog modal
        dialog.focus_set()
        parent.wait_window(dialog)
    else:
        # Standalone mode
        AboutPage()


def main():
    """Main function when run as a script"""
    AboutPage()


if __name__ == "__main__":
    main()
