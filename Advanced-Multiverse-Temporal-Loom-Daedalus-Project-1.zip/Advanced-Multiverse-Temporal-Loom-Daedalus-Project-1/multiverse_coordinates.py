
"""
Multiverse Coordinates Integration
This module integrates the temporal coordinate system with the multiverse simulation.
"""

from temporal_coordinates import (
    SpatialCoordinate, TemporalCoordinate, 
    SpaceTimeCoordinate, CoordinateRegistry
)
from main import Multiverse, Timeline
import random
import math

class CoordinateEnhancedTimeline(Timeline):
    """Timeline enhanced with coordinate system capabilities"""
    
    def __init__(self, name, stability=1.0):
        super().__init__(name, stability)
        self.landmark_coordinates = {}
        self.default_reference_system = "Earth-Centered"
        
    def add_landmark(self, name, year, x, y, z, description=None):
        """Add a landmark coordinate to this timeline"""
        spatial = SpatialCoordinate(x, y, z, reference_system=self.default_reference_system)
        temporal = TemporalCoordinate.from_year(year)
        
        coordinate = SpaceTimeCoordinate(spatial, temporal, self.name)
        self.landmark_coordinates[name] = coordinate
        
        # Also add as an event for compatibility
        self.add_event(f"Landmark: {name}" + (f" - {description}" if description else ""), year)
        
        return coordinate
    
    def get_event_coordinate(self, event_description=None, year=None):
        """Generate a coordinate for a specific event or year"""
        if event_description and year:
            # Try to find the exact event
            for event_year, desc in self.events:
                if event_year == year and event_description in desc:
                    # Create coordinate for this event
                    spatial = SpatialCoordinate(
                        random.uniform(-6371, 6371),
                        random.uniform(-6371, 6371),
                        random.uniform(-6371, 6371),
                        uncertainty=0.1,
                        reference_system=self.default_reference_system
                    )
                    temporal = TemporalCoordinate(year)
                    return SpaceTimeCoordinate(spatial, temporal, self.name)
        
        # If specific event not found, create coordinate for the year
        if year:
            spatial = SpatialCoordinate(
                random.uniform(-6371, 6371),
                random.uniform(-6371, 6371),
                random.uniform(-6371, 6371),
                uncertainty=0.2,
                reference_system=self.default_reference_system
            )
            temporal = TemporalCoordinate(year)
            return SpaceTimeCoordinate(spatial, temporal, self.name)
        
        # If no year specified, pick a random event
        if self.events:
            event_year, _ = random.choice(self.events)
            spatial = SpatialCoordinate(
                random.uniform(-6371, 6371),
                random.uniform(-6371, 6371),
                random.uniform(-6371, 6371),
                uncertainty=0.3,
                reference_system=self.default_reference_system
            )
            temporal = TemporalCoordinate(event_year)
            return SpaceTimeCoordinate(spatial, temporal, self.name)
        
        # No events, create a default coordinate
        return SpaceTimeCoordinate(
            SpatialCoordinate(0, 0, 0, 0.5, self.default_reference_system),
            TemporalCoordinate(2000),
            self.name
        )


class CoordinateEnhancedMultiverse(Multiverse):
    """Multiverse enhanced with coordinate system capabilities"""
    
    def __init__(self, use_database=False):
        super().__init__(use_database)
        self.coordinate_registry = CoordinateRegistry()
        self.sync_fields = ["fixed_points", "divergence_points"]
        
        # Initialize standard reference frames
        self._initialize_reference_frames()
    
    def _initialize_reference_frames(self):
        """Initialize standard reference frame coordinates"""
        # These are key points that exist across most timelines
        for name in ["Earth-Prime-2000", "Mars-Colony-2050", "Quantum-Nexus-2100"]:
            self.coordinate_registry.add_coordinate(
                name, 
                SpaceTimeCoordinate.random_earth_coordinate(
                    year_range=(2000, 2100), 
                    timeline_name="Reference"
                )
            )
    
    def create_timeline(self, name, stability=1.0):
        """Create a new timeline with coordinate capabilities"""
        # Check for duplicate timeline names
        if name in self.timelines:
            print(f"Warning: Timeline '{name}' already exists.")
            return self.timelines[name]
            
        # Create the enhanced timeline
        timeline = CoordinateEnhancedTimeline(name, stability)
        self.timelines[name] = timeline
        
        # If using database, save the timeline
        if self.db and not self.loading_from_db:
            self.db.save_timeline(timeline)
            
        return timeline
    
    def create_fixed_point(self, timeline_name, name, year, x=None, y=None, z=None, description=None):
        """Create a fixed point in space-time that is consistent across timelines"""
        timeline = self.timelines.get(timeline_name)
        if not timeline or not isinstance(timeline, CoordinateEnhancedTimeline):
            return None
            
        # Generate random coordinates if not specified
        x = x if x is not None else random.uniform(-6371, 6371)
        y = y if y is not None else random.uniform(-6371, 6371)
        z = z if z is not None else random.uniform(-6371, 6371)
        
        # Create the coordinate
        coordinate = timeline.add_landmark(name, year, x, y, z, description)
        
        # Register as a fixed point in the multiverse
        self.coordinate_registry.add_historical_event(f"FixedPoint:{name}", coordinate)
        
        return coordinate
    
    def add_divergence_point(self, source_timeline, target_timeline, year, description):
        """Add a divergence point where one timeline splits from another"""
        if source_timeline not in self.timelines or target_timeline not in self.timelines:
            return None
            
        source = self.timelines[source_timeline]
        target = self.timelines[target_timeline]
        
        if not isinstance(source, CoordinateEnhancedTimeline) or not isinstance(target, CoordinateEnhancedTimeline):
            return None
            
        # Create an event in both timelines
        source.add_event(f"Divergence Point: {description} (leads to {target_timeline})", year)
        target.add_event(f"Timeline Origin: Diverged from {source_timeline} - {description}", year)
        
        # Create coordinates
        source_coord = source.get_event_coordinate(description, year)
        
        # Target has same coordinates but different quantum signature
        target_spatial = SpatialCoordinate(
            source_coord.spatial.x,
            source_coord.spatial.y,
            source_coord.spatial.z,
            source_coord.spatial.uncertainty,
            source_coord.spatial.reference_system
        )
        target_temporal = TemporalCoordinate(year)
        target_coord = SpaceTimeCoordinate(
            target_spatial, target_temporal, target_timeline,
            random.random()  # New quantum signature
        )
        
        # Register the divergence point
        self.coordinate_registry.add_historical_event(
            f"Divergence:{source_timeline}->{target_timeline}:{year}", 
            source_coord
        )
        
        return (source_coord, target_coord)
    
    def time_travel_with_coordinates(
            self, 
            origin_coord: SpaceTimeCoordinate, 
            destination_coord: SpaceTimeCoordinate,
            traveler_name: str,
            use_wormhole: bool = False
        ):
        """
        Perform time travel using exact coordinates instead of just timeline names
        """
        # Get the timelines
        origin_timeline = self.timelines.get(origin_coord.timeline_name)
        destination_timeline = self.timelines.get(destination_coord.timeline_name)
        
        if not origin_timeline or not destination_timeline:
            return (False, "Invalid timeline name in coordinates")
        
        # Calculate stability risk
        risk = origin_coord.stability_risk(destination_coord)
        energy_required = origin_coord.calculate_transit_energy(destination_coord)
        
        # Determine if a paradox will occur (higher risk = higher chance)
        paradox_occurs = random.random() < risk
        
        # Apply coordinate uncertainty
        actual_destination = SpaceTimeCoordinate(
            destination_coord.spatial.apply_uncertainty(),
            destination_coord.temporal.apply_uncertainty(),
            destination_coord.timeline_name,
            destination_coord.quantum_signature
        )
        
        # Log the travel event
        origin_timeline.add_event(
            f"Time traveler {traveler_name} departed to {destination_coord.timeline_name} year {destination_coord.temporal.year}",
            origin_coord.temporal.year
        )
        
        destination_timeline.add_event(
            f"Time traveler {traveler_name} arrived from {origin_coord.timeline_name} year {origin_coord.temporal.year}",
            actual_destination.temporal.year
        )
        
        result_message = (
            f"Time travel complete. Traveler: {traveler_name}\n"
            f"From: {origin_coord.timeline_name} ({origin_coord.temporal})\n"
            f"To: {destination_coord.timeline_name} ({actual_destination.temporal})\n"
            f"Energy used: {energy_required:.2f} units\n"
            f"Stability risk: {risk:.2f}"
        )
        
        # Handle paradox if it occurs
        if paradox_occurs:
            # Create a temporal paradox
            paradox_type = self.paradox_registry.get_random_paradox() 
            self._create_paradox(
                destination_timeline, 
                actual_destination.temporal.year,
                paradox_type, 
                f"Caused by {traveler_name}'s time travel from {origin_coord.timeline_name}"
            )
            
            result_message += f"\nWARNING: Paradox detected! Type: {paradox_type.name}"
        
        # Affect quantum states of both timelines
        if origin_timeline.name != destination_timeline.name:
            entanglement_increase = 0.05 + (0.1 * risk)
            origin_timeline.quantum_state.entanglement_level += entanglement_increase
            destination_timeline.quantum_state.entanglement_level += entanglement_increase
        
        # If using database, update both timelines
        if self.db:
            self.db.update_timeline(origin_timeline)
            self.db.update_timeline(destination_timeline)
        
        return (True, result_message)
    
    def find_stable_route(self, origin_timeline, destination_timeline, origin_year, destination_year):
        """Find a stable route between two points in the multiverse"""
        if origin_timeline not in self.timelines or destination_timeline not in self.timelines:
            return []
            
        # Get coordinates for origin and destination
        origin = self.timelines[origin_timeline].get_event_coordinate(year=origin_year)
        destination = self.timelines[destination_timeline].get_event_coordinate(year=destination_year)
        
        # Use the registry to find stable routes
        routes = self.coordinate_registry.find_stable_routes(origin, destination)
        
        return routes
