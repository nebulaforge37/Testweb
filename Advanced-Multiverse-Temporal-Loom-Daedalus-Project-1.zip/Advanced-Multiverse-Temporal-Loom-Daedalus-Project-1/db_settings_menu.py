"""
Multiverse Database Settings Menu
This module provides an interactive menu system for managing database settings.
"""

import os
import json
import time
from db_options import DatabaseOptionsManager

class CoordinateSystem:
    def __init__(self, x=0.0, y=0.0, z=0.0, system="Earth-Centered"):
        self.x = x
        self.y = y
        self.z = z
        self.system = system

    def __str__(self):
        return f"({self.x}, {self.y}, {self.z}) [{self.system}]"

    def to_dict(self):
        return {"x": self.x, "y": self.y, "z": self.z, "system": self.system}

    @staticmethod
    def from_dict(data):
        return CoordinateSystem(data["x"], data["y"], data["z"], data["system"])

class DateTime:
    def __init__(self, year=0, month=1, day=1, hour=0, minute=0, second=0):
        self.year = year
        self.month = month
        self.day = day
        self.hour = hour
        self.minute = minute
        self.second = second

    def __str__(self):
        return f"{self.year}-{self.month:02}-{self.day:02} {self.hour:02}:{self.minute:02}:{self.second:02}"

    def to_dict(self):
        return {"year": self.year, "month": self.month, "day": self.day, "hour": self.hour, "minute": self.minute, "second": self.second}

    @staticmethod
    def from_dict(data):
        return DateTime(data["year"], data["month"], data["day"], data["hour"], data["minute"], data["second"])


class DatabaseSettingsMenu:
    """Interactive menu for database settings and operations."""

    def __init__(self, settings=None, multiverse=None):
        """Initialize the database settings menu."""
        self.db_manager = DatabaseOptionsManager(settings)
        self.multiverse = multiverse

    def clear_screen(self):
        """Clear the terminal screen."""
        os.system('cls' if os.name == 'nt' else 'clear')

    def print_header(self, title):
        """Print a formatted header."""
        width = 60
        print("=" * width)
        print(f"{title:^{width}}")
        print("=" * width)

    def print_menu_option(self, key, description):
        """Print a formatted menu option."""
        print(f"  [{key}] {description}")

    def get_input(self, prompt, options=None):
        """Get user input with validation against options."""
        while True:
            user_input = input(f"{prompt}: ").lower().strip()
            if options is None or user_input in options:
                return user_input
            print(f"Invalid option. Please choose from: {', '.join(options)}")

    def get_number_input(self, prompt, min_val=None, max_val=None):
        """Get a numeric input with validation."""
        while True:
            try:
                value = float(input(f"{prompt}: "))
                if (min_val is not None and value < min_val) or (max_val is not None and value > max_val):
                    valid_range = ""
                    if min_val is not None:
                        valid_range += f">= {min_val} "
                    if max_val is not None:
                        valid_range += f"<= {max_val}"
                    print(f"Value must be {valid_range}")
                    continue
                return value
            except ValueError:
                print("Please enter a valid number")

    def confirm_action(self, message):
        """Ask for confirmation before proceeding with an action."""
        response = self.get_input(f"{message} (y/n)", ["y", "n"])
        return response == "y"

    def main_menu(self):
        """Display and handle the main database settings menu."""
        while True:
            self.clear_screen()
            self.print_header("Multiverse Database Settings")

            # Get current settings
            db_enabled = self.db_manager.is_database_enabled()
            db_path = self.db_manager.db_path
            auto_save = self.db_manager.settings.get('auto_save', True)
            save_interval = self.db_manager.settings.get('save_interval', 300)
            backup_enabled = self.db_manager.settings.get('backup_enabled', False)
            max_backups = self.db_manager.settings.get('max_backups', 5)

            # Display current settings
            print("\nCurrent Settings:")
            print(f"  Database Enabled: {db_enabled}")
            print(f"  Database Path: {db_path}")
            print(f"  Auto Save: {auto_save}")
            print(f"  Save Interval: {save_interval} seconds")
            print(f"  Backup Enabled: {backup_enabled}")
            print(f"  Max Backups: {max_backups}")

            # Menu options
            print("\nOptions:")
            self.print_menu_option("1", f"{'Disable' if db_enabled else 'Enable'} Database")
            self.print_menu_option("2", "Change Database Path")
            self.print_menu_option("3", f"{'Disable' if auto_save else 'Enable'} Auto Save")
            self.print_menu_option("4", "Change Save Interval")
            self.print_menu_option("5", f"{'Disable' if backup_enabled else 'Enable'} Backups")
            self.print_menu_option("6", "Change Max Backups")
            print("\nOperations:")
            self.print_menu_option("7", "Save Multiverse Now")
            self.print_menu_option("8", "Create Backup")
            self.print_menu_option("9", "Restore from Backup")
            self.print_menu_option("0", "Database Statistics")
            self.print_menu_option("d", "Database Management") # Added Database Management option
            self.print_menu_option("q", "Exit")

            choice = self.get_input("\nEnter your choice", ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "d", "q"])

            if choice == "1":
                # Toggle database enabled
                new_state = self.db_manager.enable_database(not db_enabled)
                print(f"Database {'enabled' if new_state else 'disabled'}.")
                input("Press Enter to continue...")

            elif choice == "2":
                # Change database path
                new_path = input("Enter new database path: ").strip()
                if new_path:
                    if self.confirm_action(f"Change database path to '{new_path}'?"):
                        self.db_manager.set_database_path(new_path)
                        print(f"Database path changed to '{new_path}'.")
                input("Press Enter to continue...")

            elif choice == "3":
                # Toggle auto save
                new_state = self.db_manager.toggle_auto_save()
                print(f"Auto save {'enabled' if new_state else 'disabled'}.")
                input("Press Enter to continue...")

            elif choice == "4":
                # Change save interval
                interval = int(self.get_number_input("Enter save interval in seconds", 10, 3600))
                self.db_manager.set_save_interval(interval)
                print(f"Save interval set to {interval} seconds.")
                input("Press Enter to continue...")

            elif choice == "5":
                # Toggle backups
                new_state = self.db_manager.toggle_backup_enabled()
                print(f"Backups {'enabled' if new_state else 'disabled'}.")
                input("Press Enter to continue...")

            elif choice == "6":
                # Change max backups
                count = int(self.get_number_input("Enter maximum number of backups to keep", 1, 20))
                self.db_manager.set_max_backups(count)
                print(f"Maximum backups set to {count}.")
                input("Press Enter to continue...")

            elif choice == "7":
                # Save multiverse now
                if self.multiverse is None:
                    print("No multiverse instance available. Cannot save.")
                else:
                    if self.db_manager.save_multiverse(self.multiverse, force=True):
                        print("Multiverse saved successfully.")
                    else:
                        print("Failed to save multiverse. Is the database enabled?")
                input("Press Enter to continue...")

            elif choice == "8":
                # Create backup
                if not db_enabled:
                    print("Database is disabled. Cannot create backup.")
                else:
                    backup_path = self.db_manager.create_backup()
                    if backup_path:
                        print(f"Backup created at '{backup_path}'.")
                    else:
                        print("Failed to create backup.")
                input("Press Enter to continue...")

            elif choice == "9":
                # Restore from backup
                if not db_enabled:
                    print("Database is disabled. Cannot restore from backup.")
                else:
                    backup_path = input("Enter backup file path: ").strip()
                    if backup_path and os.path.exists(backup_path):
                        if self.confirm_action(f"Restore from '{backup_path}'? This will overwrite current data."):
                            if self.db_manager.restore_backup(backup_path):
                                print("Restored successfully from backup.")
                            else:
                                print("Failed to restore from backup.")
                    else:
                        print(f"Backup file '{backup_path}' not found.")
                input("Press Enter to continue...")

            elif choice == "0":
                # Database statistics
                self.view_database_statistics()
            elif choice == "d":
                process_database_menu() #Added Database Management menu call

            elif choice == "q":
                # Return to main menu
                break

    def view_database_statistics(self):
        """View detailed database statistics."""
        self.clear_screen()
        self.print_header("Database Statistics")

        stats = self.db_manager.get_database_stats()

        if stats is None:
            print("\nDatabase is disabled or not available.")
            input("\nPress Enter to return...")
            return

        # Format size in KB/MB
        size_kb = stats["db_size"] / 1024
        size_str = f"{size_kb:.2f} KB" if size_kb < 1024 else f"{size_kb/1024:.2f} MB"

        # Format last save time
        last_save = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stats["last_save"]))

        print(f"\nDatabase Size: {size_str}")
        print(f"Last Save: {last_save}")
        print(f"Timeline Count: {stats['timeline_count']}")
        print(f"Unstable Timelines: {stats['unstable_timelines']}")
        print(f"Quantum Anomalies: {stats['quantum_anomalies']}")

        print("\nParadox Statistics:")
        if stats["paradox_stats"]:
            for paradox in stats["paradox_stats"]:
                print(f"  {paradox['type']}: {paradox['count']} (Resolved: {paradox['resolved']})")
        else:
            print("  No paradoxes recorded.")

        # Menu options
        print("\nOptions:")
        self.print_menu_option("1", "View Unstable Timelines")
        self.print_menu_option("2", "View Quantum Anomalies")
        self.print_menu_option("3", "Search Timeline Events")
        self.print_menu_option("b", "Back to Database Settings")

        choice = self.get_input("\nEnter your choice", ["1", "2", "3", "b"])

        if choice == "1":
            self.view_unstable_timelines()
        elif choice == "2":
            self.view_quantum_anomalies()
        elif choice == "3":
            self.search_timeline_events()
        # "b" will just return

    def view_unstable_timelines(self):
        """View details of unstable timelines."""
        self.clear_screen()
        self.print_header("Unstable Timelines")

        # Ask for stability threshold
        threshold = self.get_number_input("Enter stability threshold (0.0-1.0)", 0.0, 1.0)

        # Get unstable timelines
        unstable = self.db_manager.query_database("unstable_timelines", {"threshold": threshold})

        if not unstable:
            print(f"\nNo timelines found with stability below {threshold}.")
        else:
            print(f"\nFound {len(unstable)} unstable timelines:")
            for i, timeline in enumerate(unstable, 1):
                print(f"\n{i}. {timeline['name']}")
                print(f"   Stability: {timeline['stability']:.2f}")
                print(f"   Worldline Integrity: {timeline['worldline_integrity']:.2f}")

        input("\nPress Enter to return...")

    def view_quantum_anomalies(self):
        """View details of quantum anomalies."""
        self.clear_screen()
        self.print_header("Quantum Anomalies")

        # Get quantum anomalies
        anomalies = self.db_manager.query_database("quantum_anomalies")

        if not anomalies:
            print("\nNo quantum anomalies found.")
        else:
            print(f"\nFound {len(anomalies)} quantum anomalies:")
            for i, anomaly in enumerate(anomalies, 1):
                print(f"\n{i}. {anomaly['name']}")
                if anomaly['wave_function_collapse']:
                    print("   - Wave function collapse")
                print(f"   - Entanglement level: {anomaly['entanglement_level']:.2f}")
                if anomaly['superposition']:
                    print("   - Quantum superposition")

        input("\nPress Enter to return...")

    def search_timeline_events(self):
        """Search for events across all timelines."""
        self.clear_screen()
        self.print_header("Search Timeline Events")

        # Get search query
        query = input("\nEnter search term: ").strip()

        if not query:
            print("Search term cannot be empty.")
            input("\nPress Enter to return...")
            return

        # Search for events
        events = self.db_manager.query_database("search_events", {"query": query})

        if not events:
            print(f"\nNo events found matching '{query}'.")
        else:
            print(f"\nFound {len(events)} events matching '{query}':")
            for i, event in enumerate(events, 1):
                print(f"\n{i}. Timeline: {event['timeline_name']}")
                print(f"   Year: {event['year']}")
                print(f"   Description: {event['description']}")

        input("\nPress Enter to return...")

def run_db_settings_menu(settings=None, multiverse=None):
    """Run the database settings menu."""
    menu = DatabaseSettingsMenu(settings, multiverse)
    menu.main_menu()

if __name__ == "__main__":
    run_db_settings_menu()


# --- Added files below ---

# quantum_dimensions.py
class QuantumDimension:
    def __init__(self, dimension_id, name, description):
        self.dimension_id = dimension_id
        self.name = name
        self.description = description

    def to_dict(self):
        return {"dimension_id": self.dimension_id, "name": self.name, "description": self.description}

    @staticmethod
    def from_dict(data):
        return QuantumDimension(data["dimension_id"], data["name"], data["description"])

# reality_manager.py
class RealityManager:
    def __init__(self):
        self.realities = {} # Dictionary to store realities {reality_id: {dimension_id: value}}

    def add_reality(self, reality_id, quantum_dimensions):
        self.realities[reality_id] = quantum_dimensions

    def get_reality(self, reality_id):
        return self.realities.get(reality_id)

    def save_state(self, filepath="reality_data.json"):
        with open(filepath, 'w') as f:
            json.dump(self.realities, f, indent=4)

    def load_state(self, filepath="reality_data.json"):
        try:
            with open(filepath, 'r') as f:
                self.realities = json.load(f)
        except FileNotFoundError:
            print(f"File not found: {filepath}")
        except json.JSONDecodeError:
            print(f"Error decoding JSON file: {filepath}")


# db_options.py (Partial update - needs full context of original)
class DatabaseOptionsManager:
    # ... (Existing code) ...

    def save_quantum_dimensions(self, reality_manager):
        # Placeholder for saving reality_manager to the database
        # Requires implementation based on your database structure.  Example below assumes a JSON field:
        self.save_setting("quantum_dimensions", reality_manager.realities)

    def load_quantum_dimensions(self, reality_manager):
        # Placeholder for loading reality_manager from the database
        # Requires implementation based on your database structure.  Example below assumes a JSON field:
        loaded_data = self.load_setting("quantum_dimensions")
        if loaded_data:
            reality_manager.realities = loaded_data


    # ... (Rest of db_options.py) ...

# Placeholder functions.  Need context from original code to properly integrate

def get_multiverse_instance():
    # Placeholder: Replace with your actual multiverse instance retrieval
    return None

def save_multiverse_state(multiverse):
    # Placeholder: Replace with your actual multiverse save logic
    print("Saving multiverse state (placeholder)")

def load_multiverse_state(multiverse):
    # Placeholder: Replace with your actual multiverse load logic
    print("Loading multiverse state (placeholder)")

def import_multiverse_from_file(multiverse, filename):
    # Placeholder: Replace with your actual import logic
    print(f"Importing multiverse from {filename} (placeholder)")

def export_multiverse_to_file(multiverse, filename):
    # Placeholder: Replace with your actual export logic
    print(f"Exporting multiverse to {filename} (placeholder)")

def view_db_information(multiverse):
    # Placeholder: Replace with your actual database information viewing logic
    print("Viewing database information (placeholder)")

def get_reality_manager():
    return RealityManager()

def save_quantum_dimensions_state(reality_manager):
    reality_manager.save_state()

def load_quantum_dimensions_state(reality_manager):
    reality_manager.load_state()

def display_db_menu():
    """Display the database management menu."""
    print("\n=== Database Management Menu ===")
    print("1. Save current multiverse state to database")
    print("2. Load multiverse state from database")
    print("3. Import multiverse from file")
    print("4. Export multiverse to file")
    print("5. Save quantum dimensions to file")
    print("6. Load quantum dimensions from file")
    print("7. View database information")
    print("8. Return to main menu")
    print("================================")

def process_database_menu():
    """Process database menu options."""
    multiverse = get_multiverse_instance()

    display_db_menu()
    choice = input("\nEnter your choice (1-8): ")

    if choice == '1':
        # Save current multiverse
        save_multiverse_state(multiverse)
    elif choice == '2':
        # Load multiverse
        load_multiverse_state(multiverse)
    elif choice == '3':
        # Import multiverse
        filename = input("Enter import filename (or press Enter for default): ") or "multiverse_export.json"
        import_multiverse_from_file(multiverse, filename)
    elif choice == '4':
        # Export multiverse
        filename = input("Enter export filename (or press Enter for default): ") or "multiverse_export.json"
        export_multiverse_to_file(multiverse, filename)
    elif choice == '5':
        # Save quantum dimensions
        reality_manager = get_reality_manager()
        save_quantum_dimensions_state(reality_manager)
    elif choice == '6':
        # Load quantum dimensions
        reality_manager = get_reality_manager()
        load_quantum_dimensions_state(reality_manager)
    elif choice == '7':
        # View database info
        view_db_information(multiverse)
    elif choice == '8':
        # Return to main menu
        return
    else:
        print("Invalid choice. Please try again.")