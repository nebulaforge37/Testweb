
"""
Nexus Point Detection System
This module identifies critical decision points where timelines are likely to branch,
with probability calculations for different potential outcomes.
"""

import random
import time
import math
from typing import Dict, List, Any, Optional
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

class NexusPoint:
    """Represents a critical decision point where timelines may branch"""
    
    def __init__(self, name: str, timestamp: float, significance: float, timeline_id: str):
        """
        Initialize a nexus point
        
        Args:
            name: Descriptive name of the nexus point
            timestamp: Time value of when this point occurs
            significance: How significant this point is (0.0-1.0)
            timeline_id: ID of the timeline where this point exists
        """
        self.nexus_id = f"NX{int(time.time())}-{random.randint(1000, 9999)}"
        self.name = name
        self.timestamp = timestamp
        self.significance = significance
        self.timeline_id = timeline_id
        self.potential_outcomes = []
        self.stability_factor = random.uniform(0.2, 0.8)
        self.quantum_uncertainty = random.uniform(0.1, 0.5)
        self.detection_confidence = random.uniform(0.7, 0.95)
        self.created_at = time.time()
        
    def add_potential_outcome(self, description: str, probability: float, impact: float) -> Dict[str, Any]:
        """
        Add a potential outcome to this nexus point
        
        Args:
            description: Description of the outcome
            probability: Probability of this outcome (0.0-1.0)
            impact: Impact level of this outcome (0.0-1.0)
            
        Returns:
            The created outcome
        """
        outcome = {
            "id": len(self.potential_outcomes) + 1,
            "description": description,
            "probability": probability,
            "impact": impact,
            "timeline_stability_effect": (impact * 2) - 1.0  # Convert to range -1.0 to 1.0
        }
        
        self.potential_outcomes.append(outcome)
        return outcome
    
    def calculate_branching_probability(self) -> float:
        """Calculate the probability that this nexus point will cause a timeline branch"""
        if not self.potential_outcomes:
            return 0.0
            
        # Factors that influence branching probability:
        # 1. Significance of the nexus point
        # 2. Number of potential outcomes
        # 3. Average impact of outcomes
        # 4. Quantum uncertainty
        
        avg_impact = sum(outcome["impact"] for outcome in self.potential_outcomes) / len(self.potential_outcomes)
        outcome_diversity = min(1.0, len(self.potential_outcomes) / 5.0)  # More outcomes = more likely to branch
        
        branching_probability = (
            self.significance * 0.4 +
            outcome_diversity * 0.2 +
            avg_impact * 0.3 +
            self.quantum_uncertainty * 0.1
        )
        
        return min(1.0, max(0.0, branching_probability))
    
    def get_most_likely_outcome(self) -> Dict[str, Any]:
        """Get the most likely outcome for this nexus point"""
        if not self.potential_outcomes:
            return None
            
        return max(self.potential_outcomes, key=lambda x: x["probability"])
    
    def get_highest_impact_outcome(self) -> Dict[str, Any]:
        """Get the highest impact outcome for this nexus point"""
        if not self.potential_outcomes:
            return None
            
        return max(self.potential_outcomes, key=lambda x: x["impact"])
    
    def get_status(self) -> Dict[str, Any]:
        """Get the current status of this nexus point"""
        return {
            "nexus_id": self.nexus_id,
            "name": self.name,
            "timeline_id": self.timeline_id,
            "significance": self.significance,
            "stability_factor": self.stability_factor,
            "quantum_uncertainty": self.quantum_uncertainty,
            "detection_confidence": self.detection_confidence,
            "potential_outcomes": len(self.potential_outcomes),
            "branching_probability": self.calculate_branching_probability()
        }
    
    def __str__(self) -> str:
        return f"Nexus Point {self.name} ({self.nexus_id}): {self.calculate_branching_probability():.1%} branch probability"


class NexusPointDetector:
    """System for detecting and analyzing nexus points across timelines"""
    
    def __init__(self, multiverse=None):
        """
        Initialize the nexus point detector
        
        Args:
            multiverse: Optional multiverse object to connect with
        """
        self.multiverse = multiverse
        self.detected_points = []
        self.confidence_threshold = 0.6
        self.significance_threshold = 0.4
        self.scan_history = []
        self.warning_log = []
        
    def scan_timeline(self, timeline_id: str, scan_depth: float = 0.7) -> List[NexusPoint]:
        """
        Scan a timeline for potential nexus points
        
        Args:
            timeline_id: ID of the timeline to scan
            scan_depth: How deep to scan (0.0-1.0)
            
        Returns:
            List of detected nexus points
        """
        # Log the scan
        self.scan_history.append({
            "timeline_id": timeline_id,
            "scan_depth": scan_depth,
            "timestamp": time.time()
        })
        
        # For demo, generate some random nexus points
        detected_points = []
        num_points = random.randint(1, 3)
        
        for i in range(num_points):
            # Create a nexus point
            significance = random.uniform(self.significance_threshold, 0.95)
            timestamp = time.time() + random.randint(86400, 86400 * 30)  # 1-30 days in the future
            
            point = NexusPoint(
                f"Decision Point {i+1}",
                timestamp,
                significance,
                timeline_id
            )
            
            # Add some potential outcomes
            num_outcomes = random.randint(2, 4)
            probabilities = self._generate_probabilities(num_outcomes)
            
            outcomes = [
                ("Stable progression, minor advancements", 0.3),
                ("Technological breakthrough, rapid advancement", 0.8),
                ("Social upheaval, governmental changes", 0.7),
                ("Catastrophic event, significant population loss", 0.9),
                ("First contact with external civilization", 0.95),
                ("Major scientific discovery alters reality perception", 0.85),
                ("Quantum manipulation technology emerges", 0.75)
            ]
            
            for j in range(num_outcomes):
                outcome, base_impact = random.choice(outcomes)
                impact = min(1.0, base_impact * random.uniform(0.8, 1.2))
                point.add_potential_outcome(outcome, probabilities[j], impact)
            
            # Only add points that meet the confidence threshold
            if point.detection_confidence >= self.confidence_threshold:
                detected_points.append(point)
                self.detected_points.append(point)
        
        return detected_points
    
    def _generate_probabilities(self, count: int) -> List[float]:
        """Generate a list of probabilities that sum to approximately 1.0"""
        raw_values = [random.random() for _ in range(count)]
        total = sum(raw_values)
        return [val / total for val in raw_values]
    
    def analyze_nexus_point(self, nexus_id: str) -> Dict[str, Any]:
        """
        Perform detailed analysis on a specific nexus point
        
        Args:
            nexus_id: ID of the nexus point to analyze
            
        Returns:
            Analysis results
        """
        # Find the nexus point
        point = next((p for p in self.detected_points if p.nexus_id == nexus_id), None)
        if not point:
            return {"error": "Nexus point not found"}
        
        # Calculate branching probability
        branching_prob = point.calculate_branching_probability()
        
        # Calculate timeline stability impact
        outcomes = point.potential_outcomes
        avg_stability_effect = sum(o["timeline_stability_effect"] for o in outcomes) / len(outcomes) if outcomes else 0
        
        # Determine if this is a critical nexus point
        is_critical = branching_prob > 0.7 and point.significance > 0.7
        
        # Estimate number of potential timeline branches
        potential_branches = math.ceil(len(outcomes) * branching_prob)
        
        # Get most impactful outcome
        highest_impact = point.get_highest_impact_outcome()
        
        # Create analysis results
        analysis = {
            "nexus_id": point.nexus_id,
            "name": point.name,
            "timeline_id": point.timeline_id,
            "branching_probability": branching_prob,
            "potential_timeline_branches": potential_branches,
            "average_stability_effect": avg_stability_effect,
            "is_critical_point": is_critical,
            "highest_impact_outcome": highest_impact,
            "uncertainty_level": point.quantum_uncertainty,
            "recommended_actions": []
        }
        
        # Generate recommended actions
        if is_critical:
            analysis["recommended_actions"].append(
                "Immediate monitoring recommended - Critical nexus point detected"
            )
            
            if avg_stability_effect < -0.3:
                analysis["recommended_actions"].append(
                    "Prepare stability protocols - High risk of timeline destabilization"
                )
                
            # Log a warning for critical points
            self.warning_log.append({
                "timestamp": time.time(),
                "nexus_id": point.nexus_id,
                "message": f"Critical nexus point detected in timeline {point.timeline_id}"
            })
        
        if potential_branches > 2:
            analysis["recommended_actions"].append(
                f"Prepare for multiple branches ({potential_branches}) - " +
                "High timeline diversification likely"
            )
            
        if point.quantum_uncertainty > 0.4:
            analysis["recommended_actions"].append(
                "Enhance quantum field stabilizers - High uncertainty detected"
            )
        
        return analysis
    
    def get_critical_points(self) -> List[NexusPoint]:
        """Get all critical nexus points across all timelines"""
        return [p for p in self.detected_points 
               if p.calculate_branching_probability() > 0.7 and p.significance > 0.7]
    
    def visualize_nexus_point(self, nexus_id: str, save_path: Optional[str] = None):
        """
        Generate a visualization of a nexus point
        
        Args:
            nexus_id: ID of the nexus point to visualize
            save_path: Optional path to save the visualization
        """
        # Find the nexus point
        point = next((p for p in self.detected_points if p.nexus_id == nexus_id), None)
        if not point:
            print(f"Error: Nexus point {nexus_id} not found")
            return
            
        outcomes = point.potential_outcomes
        if not outcomes:
            print(f"Error: Nexus point {nexus_id} has no outcomes to visualize")
            return
        
        # Create figure
        plt.figure(figsize=(12, 8))
        
        # Plot 1: Probability vs Impact scatter plot
        plt.subplot(2, 2, 1)
        probabilities = [o["probability"] for o in outcomes]
        impacts = [o["impact"] for o in outcomes]
        plt.scatter(probabilities, impacts, s=100, alpha=0.7)
        
        for i, o in enumerate(outcomes):
            plt.annotate(f"Outcome {o['id']}", (probabilities[i], impacts[i]),
                       xytext=(5, 5), textcoords='offset points')
            
        plt.title(f"Outcome Analysis: {point.name}")
        plt.xlabel("Probability")
        plt.ylabel("Impact")
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Plot 2: Timeline stability effects
        plt.subplot(2, 2, 2)
        stability_effects = [o["timeline_stability_effect"] for o in outcomes]
        outcome_ids = [o["id"] for o in outcomes]
        
        colors = ['green' if effect >= 0 else 'red' for effect in stability_effects]
        bars = plt.bar(outcome_ids, stability_effects, color=colors, alpha=0.7)
        
        plt.title("Timeline Stability Effects")
        plt.xlabel("Outcome ID")
        plt.ylabel("Stability Effect")
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.axhline(y=0, color='k', linestyle='-', alpha=0.3)
        
        # Plot 3: Probability distribution
        plt.subplot(2, 2, 3)
        
        # Sort by probability
        sorted_outcomes = sorted(outcomes, key=lambda x: x["probability"], reverse=True)
        labels = [f"O{o['id']}" for o in sorted_outcomes]
        probs = [o["probability"] for o in sorted_outcomes]
        
        plt.pie(probs, labels=labels, autopct='%1.1f%%', startangle=90, shadow=True)
        plt.axis('equal')
        plt.title("Outcome Probability Distribution")
        
        # Plot 4: Nexus point information
        plt.subplot(2, 2, 4)
        plt.axis('off')
        
        branching_prob = point.calculate_branching_probability()
        
        info_text = f"Nexus Point: {point.name}\n"
        info_text += f"ID: {point.nexus_id}\n"
        info_text += f"Timeline: {point.timeline_id}\n\n"
        info_text += f"Significance: {point.significance:.2f}\n"
        info_text += f"Branching Probability: {branching_prob:.2f}\n"
        info_text += f"Quantum Uncertainty: {point.quantum_uncertainty:.2f}\n"
        info_text += f"Detection Confidence: {point.detection_confidence:.2f}\n\n"
        
        # Add timestamp info
        nexus_date = datetime.fromtimestamp(point.timestamp)
        info_text += f"Expected Occurrence: {nexus_date.strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        # Add critical status
        is_critical = branching_prob > 0.7 and point.significance > 0.7
        critical_text = "CRITICAL" if is_critical else "Non-critical"
        info_text += f"Status: {critical_text}"
        
        plt.text(0.1, 0.9, info_text, fontsize=10, va='top')
        
        # Adjust layout and show
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            print(f"Visualization saved to {save_path}")
        else:
            plt.show()
    
    def generate_status_report(self) -> str:
        """Generate a status report of all nexus point detection activities"""
        critical_points = self.get_critical_points()
        recent_scans = sorted(self.scan_history[-5:], key=lambda x: x["timestamp"], reverse=True)
        
        report = ["=== NEXUS POINT DETECTION SYSTEM STATUS REPORT ==="]
        
        # Overall statistics
        report.append(f"\nDetected Points: {len(self.detected_points)}")
        report.append(f"Critical Points: {len(critical_points)}")
        report.append(f"Recent Scans: {len(recent_scans)}")
        
        # Critical points
        if critical_points:
            report.append("\nCRITICAL NEXUS POINTS:")
            for point in critical_points:
                branching = point.calculate_branching_probability()
                report.append(f"- {point.name} (Timeline {point.timeline_id}): {branching:.1%} branching probability")
                
                # Add most likely outcome
                most_likely = point.get_most_likely_outcome()
                if most_likely:
                    report.append(f"  Most likely: {most_likely['description']} ({most_likely['probability']:.1%})")
        
        # Recent scans
        if recent_scans:
            report.append("\nRECENT SCAN ACTIVITY:")
            for scan in recent_scans:
                timestamp = datetime.fromtimestamp(scan["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
                report.append(f"- Timeline {scan['timeline_id']} scanned at {timestamp}, depth: {scan['scan_depth']:.1f}")
        
        # Warnings
        recent_warnings = self.warning_log[-3:] if self.warning_log else []
        if recent_warnings:
            report.append("\nRECENT WARNINGS:")
            for warning in recent_warnings:
                timestamp = datetime.fromtimestamp(warning["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
                report.append(f"- {timestamp}: {warning['message']}")
        
        return "\n".join(report)


def run_nexus_point_demo():
    """Run a demonstration of the Nexus Point Detection System"""
    print("=== Nexus Point Detection System Demonstration ===")
    
    # Initialize the detector
    detector = NexusPointDetector()
    
    # Scan a few timelines
    timelines = ["Alpha Prime", "Beta Variant", "Gamma Nexus"]
    detected_points = []
    
    for timeline in timelines:
        print(f"\nScanning timeline '{timeline}'...")
        points = detector.scan_timeline(timeline)
        
        print(f"Detected {len(points)} nexus points:")
        for point in points:
            branch_prob = point.calculate_branching_probability()
            print(f"- {point.name}: {branch_prob:.1%} branching probability")
            detected_points.append(point)
    
    # Analyze a nexus point in detail
    if detected_points:
        point = detected_points[0]
        print(f"\nAnalyzing nexus point '{point.name}' in detail...")
        analysis = detector.analyze_nexus_point(point.nexus_id)
        
        print("\nAnalysis Results:")
        print(f"Branching Probability: {analysis['branching_probability']:.1%}")
        print(f"Potential Timeline Branches: {analysis['potential_timeline_branches']}")
        print(f"Average Stability Effect: {analysis['average_stability_effect']:.2f}")
        print(f"Critical Point: {'Yes' if analysis['is_critical_point'] else 'No'}")
        
        if analysis['recommended_actions']:
            print("\nRecommended Actions:")
            for action in analysis['recommended_actions']:
                print(f"- {action}")
        
        # Visualize the nexus point
        try:
            print("\nGenerating visualization...")
            detector.visualize_nexus_point(point.nexus_id)
        except Exception as e:
            print(f"Visualization error: {e}")
    
    # Generate status report
    print("\nGenerating status report...")
    print(detector.generate_status_report())
    
    return detector


if __name__ == "__main__":
    run_nexus_point_demo()
