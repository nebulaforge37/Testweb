
"""
Modern Theme Module
Provides theme styling for the Multiverse Visualization Dashboard
"""

import tkinter as tk
from tkinter import ttk
import os

class ModernTheme:
    """Class to apply modern styling to tkinter interfaces"""
    
    def __init__(self, root, theme='dark'):
        """Initialize the theme"""
        self.root = root
        self.theme = theme
        
        # Apply theme
        self.set_theme(theme)
    
    def set_theme(self, theme):
        """Set the theme for the application"""
        self.theme = theme
        
        if theme == 'dark':
            self.apply_dark_theme()
        else:
            self.apply_light_theme()
    
    def apply_dark_theme(self):
        """Apply dark theme styling"""
        style = ttk.Style()
        
        # Configure colors
        bg_color = '#0F172A'
        fg_color = '#E2E8F0'
        accent_color = '#3B82F6'
        secondary_color = '#1E293B'
        
        # Configure ttk styles
        style.configure('TFrame', background=bg_color)
        style.configure('TLabel', background=bg_color, foreground=fg_color)
        style.configure('TButton', background=secondary_color, foreground=fg_color, borderwidth=0)
        style.map('TButton', 
                 background=[('active', accent_color), ('pressed', secondary_color)],
                 foreground=[('active', 'white')])
        style.configure('TCheckbutton', background=bg_color, foreground=fg_color)
        style.configure('TRadiobutton', background=bg_color, foreground=fg_color)
        style.configure('TEntry', fieldbackground=secondary_color, foreground=fg_color)
        style.configure('TCombobox', fieldbackground=secondary_color, foreground=fg_color)
        style.configure('Vertical.TScrollbar', background=secondary_color, troughcolor=bg_color)
        style.configure('Horizontal.TScrollbar', background=secondary_color, troughcolor=bg_color)
        style.configure('TNotebook', background=bg_color)
        style.configure('TNotebook.Tab', background=secondary_color, foreground=fg_color, padding=[10, 2])
        style.map('TNotebook.Tab', 
                 background=[('selected', accent_color)],
                 foreground=[('selected', 'white')])
        
        # Configure tk styles
        self.root.configure(bg=bg_color)
        
        # Apply to all children
        for widget in self.root.winfo_children():
            self._apply_theme_to_widget(widget, bg_color, fg_color)
    
    def apply_light_theme(self):
        """Apply light theme styling"""
        style = ttk.Style()
        
        # Configure colors
        bg_color = '#F8FAFC'
        fg_color = '#0F172A'
        accent_color = '#3B82F6'
        secondary_color = '#E2E8F0'
        
        # Configure ttk styles
        style.configure('TFrame', background=bg_color)
        style.configure('TLabel', background=bg_color, foreground=fg_color)
        style.configure('TButton', background=secondary_color, foreground=fg_color, borderwidth=0)
        style.map('TButton', 
                 background=[('active', accent_color), ('pressed', secondary_color)],
                 foreground=[('active', 'white')])
        style.configure('TCheckbutton', background=bg_color, foreground=fg_color)
        style.configure('TRadiobutton', background=bg_color, foreground=fg_color)
        style.configure('TEntry', fieldbackground=secondary_color, foreground=fg_color)
        style.configure('TCombobox', fieldbackground=secondary_color, foreground=fg_color)
        style.configure('Vertical.TScrollbar', background=secondary_color, troughcolor=bg_color)
        style.configure('Horizontal.TScrollbar', background=secondary_color, troughcolor=bg_color)
        style.configure('TNotebook', background=bg_color)
        style.configure('TNotebook.Tab', background=secondary_color, foreground=fg_color, padding=[10, 2])
        style.map('TNotebook.Tab', 
                 background=[('selected', accent_color)],
                 foreground=[('selected', 'white')])
        
        # Configure tk styles
        self.root.configure(bg=bg_color)
        
        # Apply to all children
        for widget in self.root.winfo_children():
            self._apply_theme_to_widget(widget, bg_color, fg_color)
    
    def _apply_theme_to_widget(self, widget, bg_color, fg_color):
        """Recursively apply theme to a widget and its children"""
        widget_class = widget.winfo_class()
        
        if widget_class in ('Frame', 'Labelframe', 'TFrame', 'TLabelframe'):
            widget.configure(bg=bg_color)
            for child in widget.winfo_children():
                self._apply_theme_to_widget(child, bg_color, fg_color)
                
        elif widget_class in ('Label', 'TLabel'):
            widget.configure(bg=bg_color, fg=fg_color)
            
        elif widget_class in ('Button', 'TButton'):
            # TTK widgets are handled by style
            if widget_class == 'Button':
                widget.configure(bg=bg_color, fg=fg_color)
                
        elif widget_class == 'Canvas':
            widget.configure(bg=bg_color)
            
        elif widget_class == 'Text':
            widget.configure(bg=bg_color, fg=fg_color)
