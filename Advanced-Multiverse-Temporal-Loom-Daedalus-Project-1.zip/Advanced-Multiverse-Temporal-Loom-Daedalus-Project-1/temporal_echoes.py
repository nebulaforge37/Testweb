
"""
Temporal Echoes Visualization
This module allows visualization of echoes from deleted or pruned timelines.
"""

import random
import time
import math
import tkinter as tk
from tkinter import ttk, Canvas, Frame, Label, Button, Scrollbar
from typing import Dict, List, Tuple, Optional, Any, Union

class TemporalEcho:
    """Represents an echo from a deleted timeline"""
    
    def __init__(self, source_timeline: str, year: int, event_description: str, intensity: float):
        """
        Initialize a temporal echo
        
        Args:
            source_timeline: Name of the source timeline that created this echo
            year: Year when the event occurred
            event_description: Description of the event
            intensity: Echo intensity (0.0-1.0)
        """
        self.source_timeline = source_timeline
        self.year = year
        self.event_description = event_description
        self.intensity = intensity  # How strong the echo is (0.0-1.0)
        self.discovery_time = time.time()
        self.decay_rate = random.uniform(0.001, 0.01)  # How quickly the echo fades
        self.frequency = random.uniform(0.5, 2.0)      # Oscillation frequency
        self.phase = random.uniform(0, 2 * math.pi)    # Initial phase
        self.color = self._generate_color()
        self.coords = (random.uniform(-10, 10), random.uniform(-10, 10), random.uniform(-10, 10))
        self.id = f"echo-{int(time.time())}-{random.randint(1000, 9999)}"
    
    def _generate_color(self) -> str:
        """Generate a color based on echo properties"""
        # Intensity affects brightness
        brightness = int(155 + 100 * self.intensity)
        
        # Use source timeline name to generate hue
        hue_seed = sum(ord(c) for c in self.source_timeline)
        r = (brightness + hue_seed * 13) % 256
        g = (brightness + hue_seed * 29) % 256
        b = (brightness + hue_seed * 71) % 256
        
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def get_current_intensity(self) -> float:
        """Calculate current intensity based on decay and oscillation"""
        time_elapsed = time.time() - self.discovery_time
        base_intensity = self.intensity * math.exp(-self.decay_rate * time_elapsed)
        oscillation = 0.2 * math.sin(self.frequency * time_elapsed + self.phase) + 1.0
        return base_intensity * oscillation
    
    def is_perceptible(self) -> bool:
        """Check if the echo is still perceptible"""
        return self.get_current_intensity() > 0.05
    
    def __str__(self) -> str:
        current_intensity = self.get_current_intensity()
        status = "Active" if self.is_perceptible() else "Fading"
        return f"Echo {self.id[:8]}: {self.year} - '{self.event_description}' from '{self.source_timeline}' - {current_intensity:.2f} intensity ({status})"


class EchoField:
    """Manages a collection of temporal echoes"""
    
    def __init__(self):
        """Initialize the echo field"""
        self.echoes: List[TemporalEcho] = []
        self.detection_threshold = 0.05  # Minimum intensity to detect
    
    def add_echo(self, echo: TemporalEcho) -> None:
        """Add a new echo to the field"""
        self.echoes.append(echo)
    
    def generate_random_echo(self) -> TemporalEcho:
        """Generate a random temporal echo for testing"""
        timelines = ["Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta", "Eta", "Theta"]
        events = [
            "Quantum breakthrough", "Timeline divergence", "Temporal anomaly",
            "Nexus event", "Reality shift", "Dimensional collapse", "Paradox resolution",
            "Causal loop formation", "Wave function collapse", "Quantum entanglement event"
        ]
        
        source = random.choice(timelines)
        year = random.randint(1900, 2100)
        event = random.choice(events)
        intensity = random.uniform(0.2, 0.9)
        
        echo = TemporalEcho(source, year, event, intensity)
        return echo
    
    def populate_with_random_echoes(self, count: int) -> None:
        """Populate the field with random echoes for testing"""
        for _ in range(count):
            self.add_echo(self.generate_random_echo())
    
    def cleanup_faint_echoes(self) -> int:
        """Remove echoes that are too faint to detect"""
        initial_count = len(self.echoes)
        self.echoes = [echo for echo in self.echoes if echo.is_perceptible()]
        return initial_count - len(self.echoes)
    
    def get_active_echoes(self) -> List[TemporalEcho]:
        """Get list of currently active echoes"""
        return [echo for echo in self.echoes if echo.is_perceptible()]
    
    def find_resonating_echoes(self) -> List[Tuple[TemporalEcho, TemporalEcho, float]]:
        """Find pairs of echoes that resonate with each other"""
        resonances = []
        active_echoes = self.get_active_echoes()
        
        for i, echo1 in enumerate(active_echoes):
            for echo2 in active_echoes[i+1:]:
                # Calculate resonance based on frequency similarity and proximity
                freq_diff = abs(echo1.frequency - echo2.frequency)
                year_diff = abs(echo1.year - echo2.year)
                
                # Normalize year difference (1-100 years)
                norm_year_diff = min(1.0, year_diff / 100)
                
                # Calculate spatial proximity
                distance = math.sqrt(sum((a - b) ** 2 for a, b in zip(echo1.coords, echo2.coords)))
                norm_distance = min(1.0, distance / 20)
                
                # Calculate resonance (0.0-1.0)
                resonance = 1.0 - (0.5 * freq_diff + 0.3 * norm_year_diff + 0.2 * norm_distance)
                
                if resonance > 0.7:  # Only consider strong resonances
                    resonances.append((echo1, echo2, resonance))
        
        return resonances
    
    def analyze_echo_patterns(self) -> Dict[str, Any]:
        """Analyze patterns in the temporal echoes"""
        active_echoes = self.get_active_echoes()
        
        if not active_echoes:
            return {"status": "No active echoes to analyze"}
        
        # Group by source timeline
        timeline_groups = {}
        for echo in active_echoes:
            if echo.source_timeline not in timeline_groups:
                timeline_groups[echo.source_timeline] = []
            timeline_groups[echo.source_timeline].append(echo)
        
        # Group by time period
        time_periods = {
            "Ancient": [],       # Before 1900
            "Modern": [],        # 1900-2000
            "Contemporary": [],  # 2000-2050
            "Future": []         # After 2050
        }
        
        for echo in active_echoes:
            if echo.year < 1900:
                time_periods["Ancient"].append(echo)
            elif echo.year < 2000:
                time_periods["Modern"].append(echo)
            elif echo.year < 2050:
                time_periods["Contemporary"].append(echo)
            else:
                time_periods["Future"].append(echo)
        
        # Find most common timeline
        if timeline_groups:
            most_common_timeline = max(timeline_groups.items(), key=lambda x: len(x[1]))
        else:
            most_common_timeline = ("None", [])
        
        # Find most intense echo
        most_intense = max(active_echoes, key=lambda e: e.get_current_intensity())
        
        # Calculate overall field intensity
        total_intensity = sum(echo.get_current_intensity() for echo in active_echoes)
        avg_intensity = total_intensity / len(active_echoes) if active_echoes else 0
        
        return {
            "total_echoes": len(active_echoes),
            "total_intensity": total_intensity,
            "average_intensity": avg_intensity,
            "most_intense_echo": str(most_intense),
            "timeline_distribution": {t: len(e) for t, e in timeline_groups.items()},
            "time_period_distribution": {p: len(e) for p, e in time_periods.items()},
            "most_common_timeline": most_common_timeline[0],
            "most_common_timeline_count": len(most_common_timeline[1])
        }


class TemporalEchoVisualizer:
    """GUI for visualizing temporal echoes"""
    
    def __init__(self, root, multiverse=None):
        """Initialize the visualizer"""
        self.root = root
        self.root.title("Temporal Echo Visualization")
        self.root.geometry("1000x700")
        self.root.configure(bg="#1e1e2e")
        
        self.multiverse = multiverse
        self.echo_field = EchoField()
        self.setup_ui()
        self.animation_speed = 50  # ms between frames
        self.rotation_angle = 0
        self.simulation_running = False
        
        # Load echoes if multiverse is available
        if self.multiverse:
            self.load_echoes_from_multiverse()
        else:
            # Create sample echoes for demonstration
            self.echo_field.populate_with_random_echoes(15)
    
    def setup_ui(self):
        """Set up the user interface"""
        # Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title
        title_label = ttk.Label(main_frame, text="Temporal Echo Visualization", 
                              font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        # Split into left (controls) and right (visualization) panels
        split_frame = ttk.Frame(main_frame)
        split_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left panel - Controls and data
        left_panel = ttk.Frame(split_frame, width=300)
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, padx=5, pady=5)
        
        # Make left panel keep its width
        left_panel.pack_propagate(False)
        
        # Control frame
        control_frame = ttk.LabelFrame(left_panel, text="Controls")
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Add some controls
        add_button = ttk.Button(control_frame, text="Add Random Echo", 
                              command=self.add_random_echo)
        add_button.pack(fill=tk.X, padx=5, pady=5)
        
        analyze_button = ttk.Button(control_frame, text="Analyze Echo Patterns", 
                                  command=self.show_analysis)
        analyze_button.pack(fill=tk.X, padx=5, pady=5)
        
        cleanup_button = ttk.Button(control_frame, text="Cleanup Faint Echoes", 
                                  command=self.cleanup_echoes)
        cleanup_button.pack(fill=tk.X, padx=5, pady=5)
        
        # Display active echoes
        echo_frame = ttk.LabelFrame(left_panel, text="Active Echoes")
        echo_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Scrollable echo list
        self.echo_listbox = tk.Listbox(echo_frame, bg="#2e2e4e", fg="white", 
                                    selectbackground="#4e4e8e", height=15)
        self.echo_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        scrollbar = ttk.Scrollbar(echo_frame, orient="vertical", 
                                command=self.echo_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.echo_listbox.config(yscrollcommand=scrollbar.set)
        
        # Echo details
        details_frame = ttk.LabelFrame(left_panel, text="Echo Details")
        details_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        self.details_text = tk.Text(details_frame, height=8, bg="#2e2e4e", fg="white", 
                                 wrap=tk.WORD)
        self.details_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Right panel - Visualization
        right_panel = ttk.Frame(split_frame)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Canvas for visualization
        canvas_frame = ttk.LabelFrame(right_panel, text="Echo Field Visualization")
        canvas_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.canvas = tk.Canvas(canvas_frame, bg="#121220", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, 
                             relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=5)
        
        # Bind events
        self.echo_listbox.bind("<<ListboxSelect>>", self.on_echo_selected)
        
        # Start the visualization
        self.start_visualization()
        
    def start_visualization(self):
        """Start the visualization animation"""
        self.simulation_running = True
        self.update_visualization()
        
    def stop_visualization(self):
        """Stop the visualization animation"""
        self.simulation_running = False
        
    def update_visualization(self):
        """Update the visualization frame"""
        if not self.simulation_running:
            return
        
        # Clear the canvas
        self.canvas.delete("all")
        
        # Get canvas dimensions
        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()
        
        # Skip if canvas is not ready
        if width < 10 or height < 10:
            self.root.after(100, self.update_visualization)
            return
        
        center_x = width / 2
        center_y = height / 2
        
        # Update the rotation angle
        self.rotation_angle += 0.01
        
        # Draw background grid
        self.draw_grid(width, height)
        
        # Draw echoes
        active_echoes = self.echo_field.get_active_echoes()
        for echo in active_echoes:
            # Calculate position based on 3D coords and rotation
            x, y, z = echo.coords
            
            # Apply rotation around Y axis
            x_rot = x * math.cos(self.rotation_angle) - z * math.sin(self.rotation_angle)
            z_rot = x * math.sin(self.rotation_angle) + z * math.cos(self.rotation_angle)
            
            # Project 3D to 2D
            scale = 20
            perspective = 5 + z_rot  # Perspective divisor (larger = smaller)
            perspective = max(1, perspective)  # Prevent division by zero
            
            screen_x = center_x + (x_rot * scale) / perspective
            screen_y = center_y + (y * scale) / perspective
            
            # Calculate size based on perspective and intensity
            current_intensity = echo.get_current_intensity()
            size = max(3, (20 / perspective) * current_intensity)
            
            # Calculate color based on intensity
            color = echo.color
            
            # Draw the echo as a circle
            self.canvas.create_oval(
                screen_x - size, screen_y - size,
                screen_x + size, screen_y + size,
                fill=color, outline="", tags="echo"
            )
            
            # Draw year indicator for strong echoes
            if current_intensity > 0.4 and size > 5:
                self.canvas.create_text(
                    screen_x, screen_y - size - 5,
                    text=str(echo.year),
                    fill="white", font=("Arial", 8), tags="text"
                )
        
        # Draw resonances between echoes
        resonances = self.echo_field.find_resonating_echoes()
        for echo1, echo2, strength in resonances:
            # Calculate screen positions for both echoes
            x1, y1, z1 = echo1.coords
            x2, y2, z2 = echo2.coords
            
            # Apply rotation around Y axis
            x1_rot = x1 * math.cos(self.rotation_angle) - z1 * math.sin(self.rotation_angle)
            z1_rot = x1 * math.sin(self.rotation_angle) + z1 * math.cos(self.rotation_angle)
            
            x2_rot = x2 * math.cos(self.rotation_angle) - z2 * math.sin(self.rotation_angle)
            z2_rot = x2 * math.sin(self.rotation_angle) + z2 * math.cos(self.rotation_angle)
            
            # Project to 2D
            scale = 20
            perspective1 = 5 + z1_rot
            perspective2 = 5 + z2_rot
            perspective1 = max(1, perspective1)
            perspective2 = max(1, perspective2)
            
            screen_x1 = center_x + (x1_rot * scale) / perspective1
            screen_y1 = center_y + (y1 * scale) / perspective1
            
            screen_x2 = center_x + (x2_rot * scale) / perspective2
            screen_y2 = center_y + (y2 * scale) / perspective2
            
            # Draw resonance line with appropriate color and thickness
            alpha = int(min(255, strength * 255))
            color = f"#{alpha:02x}{alpha:02x}ff"
            width = strength * 2
            
            self.canvas.create_line(
                screen_x1, screen_y1, screen_x2, screen_y2,
                fill=color, width=width, dash=(3, 3), tags="resonance"
            )
        
        # Update echo list
        self.update_echo_list()
        
        # Update status bar
        self.status_var.set(f"Active echoes: {len(active_echoes)} | Resonances: {len(resonances)}")
        
        # Schedule next update
        self.root.after(self.animation_speed, self.update_visualization)
    
    def draw_grid(self, width, height):
        """Draw a reference grid"""
        # Draw a circular reference grid
        center_x = width / 2
        center_y = height / 2
        
        # Draw concentric circles
        for r in range(20, 201, 40):
            self.canvas.create_oval(
                center_x - r, center_y - r,
                center_x + r, center_y + r,
                outline="#333355", dash=(2, 4), tags="grid"
            )
        
        # Draw radial lines
        for angle in range(0, 360, 30):
            rad = math.radians(angle)
            end_x = center_x + 200 * math.cos(rad)
            end_y = center_y + 200 * math.sin(rad)
            
            self.canvas.create_line(
                center_x, center_y, end_x, end_y,
                fill="#333355", dash=(2, 4), tags="grid"
            )
    
    def update_echo_list(self):
        """Update the echo list with current echoes"""
        # Store current selection
        selected_idx = self.echo_listbox.curselection()
        selected_id = None
        if selected_idx:
            selected_text = self.echo_listbox.get(selected_idx[0])
            selected_id = selected_text.split(":")[0].strip()
        
        self.echo_listbox.delete(0, tk.END)
        
        for echo in sorted(
            self.echo_field.get_active_echoes(), 
            key=lambda e: e.get_current_intensity(), 
            reverse=True
        ):
            intensity = echo.get_current_intensity()
            self.echo_listbox.insert(
                tk.END, 
                f"{echo.id[:8]}: {echo.year} - {intensity:.2f} - {echo.source_timeline}"
            )
        
        # Restore selection if possible
        if selected_id:
            for i in range(self.echo_listbox.size()):
                if self.echo_listbox.get(i).startswith(selected_id):
                    self.echo_listbox.selection_set(i)
                    self.echo_listbox.see(i)
                    break
    
    def on_echo_selected(self, event):
        """Handle echo selection"""
        selected_idx = self.echo_listbox.curselection()
        if not selected_idx:
            return
        
        selected_text = self.echo_listbox.get(selected_idx[0])
        selected_id = selected_text.split(":")[0].strip()
        
        # Find the selected echo
        for echo in self.echo_field.get_active_echoes():
            if echo.id.startswith(selected_id):
                self.show_echo_details(echo)
                break
    
    def show_echo_details(self, echo):
        """Show details for the selected echo"""
        self.details_text.delete(1.0, tk.END)
        
        current_intensity = echo.get_current_intensity()
        
        details = f"ID: {echo.id}\n\n"
        details += f"Timeline: {echo.source_timeline}\n"
        details += f"Year: {echo.year}\n"
        details += f"Event: {echo.event_description}\n\n"
        details += f"Current Intensity: {current_intensity:.4f}\n"
        details += f"Initial Intensity: {echo.intensity:.4f}\n"
        details += f"Frequency: {echo.frequency:.4f}\n"
        details += f"Decay Rate: {echo.decay_rate:.6f}\n"
        details += f"Discovered: {time.ctime(echo.discovery_time)}\n"
        
        # Calculate remaining lifespan
        if echo.decay_rate > 0:
            remaining_time = -math.log(0.05 / echo.intensity) / echo.decay_rate
            remaining_hours = remaining_time / 3600
            
            if remaining_hours < 1:
                details += f"Est. Remaining: {remaining_time:.1f} seconds\n"
            elif remaining_hours < 24:
                details += f"Est. Remaining: {remaining_hours:.1f} hours\n"
            else:
                details += f"Est. Remaining: {remaining_hours/24:.1f} days\n"
        
        self.details_text.insert(tk.END, details)
    
    def add_random_echo(self):
        """Add a random echo to the field"""
        echo = self.echo_field.generate_random_echo()
        self.echo_field.add_echo(echo)
        self.status_var.set(f"Added new echo: {echo.year} - {echo.event_description}")
    
    def cleanup_echoes(self):
        """Cleanup faint echoes"""
        removed = self.echo_field.cleanup_faint_echoes()
        self.status_var.set(f"Removed {removed} faint echoes")
    
    def show_analysis(self):
        """Show analysis of echo patterns"""
        analysis = self.echo_field.analyze_echo_patterns()
        
        # Create a popup window for analysis
        popup = tk.Toplevel(self.root)
        popup.title("Echo Pattern Analysis")
        popup.geometry("500x400")
        popup.transient(self.root)
        
        # Add analysis info
        frame = ttk.Frame(popup, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(frame, text="Temporal Echo Pattern Analysis", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Check if we have data
        if "status" in analysis and analysis["status"] == "No active echoes to analyze":
            ttk.Label(frame, text="No active echoes to analyze").pack(pady=20)
            return
        
        # Create text widget for analysis
        text = tk.Text(frame, wrap=tk.WORD, height=15)
        text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Add analysis data
        analysis_text = f"Total Echoes: {analysis['total_echoes']}\n"
        analysis_text += f"Total Field Intensity: {analysis['total_intensity']:.2f}\n"
        analysis_text += f"Average Echo Intensity: {analysis['average_intensity']:.2f}\n\n"
        
        analysis_text += f"Most Intense Echo: {analysis['most_intense_echo']}\n\n"
        
        analysis_text += "Timeline Distribution:\n"
        for timeline, count in analysis['timeline_distribution'].items():
            analysis_text += f"  - {timeline}: {count} echoes\n"
        
        analysis_text += "\nTime Period Distribution:\n"
        for period, count in analysis['time_period_distribution'].items():
            analysis_text += f"  - {period}: {count} echoes\n"
        
        analysis_text += f"\nMost Common Timeline: {analysis['most_common_timeline']} "
        analysis_text += f"({analysis['most_common_timeline_count']} echoes)"
        
        text.insert(tk.END, analysis_text)
        
        # Add close button
        ttk.Button(frame, text="Close", command=popup.destroy).pack(pady=10)
    
    def load_echoes_from_multiverse(self):
        """Load echoes from the multiverse if available"""
        if not self.multiverse:
            return
        
        # This would connect to actual multiverse data
        # For now, just generate random echoes
        self.echo_field.populate_with_random_echoes(10)
        
        # In a real implementation, we'd extract echo data from deleted timelines
        # For example:
        # for timeline_name, data in self.multiverse.deleted_timelines.items():
        #     for event in data.get("events", []):
        #         echo = TemporalEcho(
        #             timeline_name, 
        #             event.get("year", 2000),
        #             event.get("description", "Unknown event"),
        #             random.uniform(0.3, 0.9)
        #         )
        #         self.echo_field.add_echo(echo)


def run_temporal_echoes_demo():
    """Run the temporal echoes visualization demo"""
    try:
        # Try to import the multiverse
        from main import Multiverse
        multiverse = Multiverse()
    except ImportError:
        print("Multiverse module not available, running in standalone mode.")
        multiverse = None
    
    # Create and run the visualizer
    root = tk.Tk()
    visualizer = TemporalEchoVisualizer(root, multiverse)
    root.mainloop()
    
    return visualizer


if __name__ == "__main__":
    run_temporal_echoes_demo()
"""
Temporal Echoes System
This module implements regions that exist outside the normal space-time continuum
and allows for monitoring and interaction with these echo zones.
"""

import random
import math
import time
from typing import List, Dict, Optional, Tuple, Any, Union
from temporal_physics import TimeDilation, ParadoxRegistry

class TemporalEchoZone:
    """Represents a zone that exists outside normal space-time, where temporal echoes manifest"""
    
    def __init__(self, zone_id: str, name: str = None, stability: float = None):
        """
        Initialize a temporal echo zone
        
        Args:
            zone_id: Unique identifier for this zone
            name: Name of this echo zone
            stability: Stability of this zone (0.0-1.0)
        """
        self.zone_id = zone_id
        self.name = name or f"Echo Zone {zone_id}"
        self.stability = stability or random.uniform(0.3, 0.7)
        self.creation_time = time.time()
        
        # Echo zone properties
        self.time_flow_coefficient = random.uniform(-0.5, 0.5)  # Negative means reverse flow
        self.spatial_contiguity = random.uniform(0.2, 0.8)      # How "solid" space is
        self.echo_intensity = random.uniform(0.3, 1.0)          # Strength of temporal echoes
        self.reality_bleed = random.uniform(0.1, 0.4)           # How much reality bleeds through
        
        # Echo collections
        self.echoes = []  # List of temporal echoes present in this zone
        self.visitors = []  # Record of entities that have entered this zone
        self.anomalies = []  # Temporal anomalies present in this zone
    
    def add_echo(self, timeline_origin: str, year: int, event_description: str, intensity: float = None):
        """Add a temporal echo from a timeline to this zone"""
        echo_intensity = intensity or random.uniform(0.2, self.echo_intensity)
        
        echo = {
            "origin": timeline_origin,
            "year": year,
            "description": event_description,
            "intensity": echo_intensity,
            "decay_rate": random.uniform(0.01, 0.1),
            "created_at": time.time(),
            "last_manifestation": None,
            "manifestation_count": 0
        }
        
        self.echoes.append(echo)
        return echo
    
    def record_visitor(self, visitor_name: str, origin_timeline: str, entry_point: str = None):
        """Record a visitor to this echo zone"""
        visit_record = {
            "visitor": visitor_name,
            "origin": origin_timeline,
            "entry_point": entry_point,
            "entry_time": time.time(),
            "exit_time": None,
            "effects": []
        }
        
        self.visitors.append(visit_record)
        return visit_record
    
    def visitor_exit(self, visitor_name: str, effects: List[str] = None):
        """Record a visitor's exit from the echo zone"""
        for visit in reversed(self.visitors):  # Look from most recent backwards
            if visit["visitor"] == visitor_name and visit["exit_time"] is None:
                visit["exit_time"] = time.time()
                if effects:
                    visit["effects"] = effects
                return True
        
        return False  # Visitor not found
    
    def manifest_random_echo(self) -> Optional[Dict]:
        """Manifest a random temporal echo in this zone"""
        if not self.echoes:
            return None
            
        # Select a random echo, weighted by intensity
        weights = [e["intensity"] for e in self.echoes]
        echo = random.choices(self.echoes, weights=weights, k=1)[0]
        
        # Calculate manifestation strength
        base_strength = echo["intensity"] * self.echo_intensity
        time_since_creation = (time.time() - echo["created_at"]) / 86400  # days
        decay = echo["decay_rate"] * time_since_creation
        
        manifestation_strength = max(0.1, base_strength - decay)
        
        # Record the manifestation
        echo["last_manifestation"] = time.time()
        echo["manifestation_count"] += 1
        
        # Generate manifestation details
        manifestation = {
            "echo": echo,
            "strength": manifestation_strength,
            "duration": random.uniform(10, 60) * manifestation_strength,  # seconds
            "distortion": random.uniform(0, 0.5),
            "effects": []
        }
        
        # Determine random effects
        possible_effects = [
            "Visual temporal distortions",
            "Auditory echoes from the past",
            "Gravity fluctuations",
            "Spatial folding",
            "Time dilation",
            "Memory bleed-through",
            "Quantum state fluctuations",
            "Reality fragmenting",
            "Causal inversion"
        ]
        
        effect_count = random.randint(1, 3)
        manifestation["effects"] = random.sample(possible_effects, effect_count)
        
        return manifestation
    
    def update_stability(self, elapsed_time: float = 1.0):
        """Update the stability of this echo zone over time"""
        # Echo zones are inherently unstable
        stability_change = random.uniform(-0.1, 0.05) * elapsed_time
        
        # More echoes = less stability
        echo_factor = len(self.echoes) * 0.01 * elapsed_time
        
        # Visitors can affect stability
        active_visitors = sum(1 for v in self.visitors if v["exit_time"] is None)
        visitor_factor = active_visitors * 0.03 * elapsed_time
        
        # Apply changes
        self.stability = max(0.1, min(0.9, self.stability + stability_change - echo_factor - visitor_factor))
        
        # Adjust echo intensity based on stability
        self.echo_intensity = min(1.0, 1.2 - self.stability)
        
        # Return information about the change
        return {
            "old_stability": self.stability - stability_change + echo_factor + visitor_factor,
            "new_stability": self.stability,
            "factors": {
                "random": stability_change,
                "echo_count": -echo_factor,
                "visitors": -visitor_factor
            }
        }
    
    def __str__(self) -> str:
        return f"Echo Zone {self.zone_id}: {self.name} - Stability: {self.stability:.2f}, Echoes: {len(self.echoes)}"


class TemporalEchoSystem:
    """System for managing and monitoring temporal echo zones"""
    
    def __init__(self):
        """Initialize the temporal echo system"""
        self.echo_zones: Dict[str, TemporalEchoZone] = {}
        self.next_zone_id = 1
        self.last_update = time.time()
        self.detection_sensitivity = 0.7  # 0.0-1.0
        self.active_probes = []
    
    def create_echo_zone(self, name: str = None, stability: float = None) -> TemporalEchoZone:
        """Create a new temporal echo zone"""
        zone_id = f"EZ-{self.next_zone_id:04d}"
        self.next_zone_id += 1
        
        zone = TemporalEchoZone(zone_id, name, stability)
        self.echo_zones[zone_id] = zone
        
        return zone
    
    def deploy_probe(self, zone_id: str, probe_type: str = "standard") -> Dict:
        """Deploy a probe into an echo zone to monitor and gather data"""
        if zone_id not in self.echo_zones:
            return {"success": False, "error": "Echo zone not found"}
            
        zone = self.echo_zones[zone_id]
        
        # Define probe characteristics
        probe_types = {
            "standard": {"range": 0.6, "duration": 24, "stability_impact": -0.02},
            "advanced": {"range": 0.8, "duration": 48, "stability_impact": -0.05},
            "quantum": {"range": 0.9, "duration": 72, "stability_impact": -0.1}
        }
        
        if probe_type not in probe_types:
            probe_type = "standard"
            
        probe_spec = probe_types[probe_type]
        
        # Create and deploy probe
        probe = {
            "id": f"P-{len(self.active_probes)+1:03d}",
            "type": probe_type,
            "zone_id": zone_id,
            "deployed_at": time.time(),
            "duration": probe_spec["duration"] * 3600,  # Convert to seconds
            "range": probe_spec["range"],
            "readings": [],
            "active": True
        }
        
        self.active_probes.append(probe)
        
        # Impact zone stability
        zone.stability += probe_spec["stability_impact"]
        
        return {
            "success": True,
            "probe_id": probe["id"],
            "message": f"{probe_type.capitalize()} probe deployed to {zone.name}"
        }
    
    def probe_readings(self, probe_id: str) -> Dict:
        """Get readings from a specific probe"""
        for probe in self.active_probes:
            if probe["id"] == probe_id:
                if not probe["active"]:
                    return {"success": False, "error": "Probe is no longer active"}
                    
                zone_id = probe["zone_id"]
                if zone_id not in self.echo_zones:
                    return {"success": False, "error": "Target echo zone no longer exists"}
                    
                zone = self.echo_zones[zone_id]
                
                # Generate readings
                echo_count = len(zone.echoes)
                active_echoes = sum(1 for e in zone.echoes 
                                  if e["last_manifestation"] is not None and 
                                  time.time() - e["last_manifestation"] < 3600)
                
                readings = {
                    "stability": zone.stability,
                    "echo_intensity": zone.echo_intensity,
                    "echo_count": echo_count,
                    "active_echoes": active_echoes,
                    "time_flow": zone.time_flow_coefficient,
                    "spatial_integrity": zone.spatial_contiguity,
                    "anomalies_detected": len(zone.anomalies),
                    "timestamp": time.time()
                }
                
                probe["readings"].append(readings)
                
                return {
                    "success": True,
                    "probe_id": probe_id,
                    "zone_id": zone_id,
                    "latest_reading": readings,
                    "reading_count": len(probe["readings"])
                }
                
        return {"success": False, "error": "Probe not found"}
    
    def update_all_zones(self):
        """Update all echo zones"""
        current_time = time.time()
        elapsed_time = (current_time - self.last_update) / 3600  # Convert to hours
        
        for zone_id, zone in self.echo_zones.items():
            # Update stability
            zone.update_stability(elapsed_time)
            
            # Random chance of echo manifestation
            if random.random() < (zone.echo_intensity * 0.3 * elapsed_time):
                manifestation = zone.manifest_random_echo()
                if manifestation:
                    # Could log the manifestation here
                    pass
        
        # Update probes and remove expired ones
        active_probes = []
        for probe in self.active_probes:
            age = current_time - probe["deployed_at"]
            if age < probe["duration"]:
                probe["active"] = True
                active_probes.append(probe)
            else:
                probe["active"] = False
                
        self.active_probes = active_probes
        self.last_update = current_time
    
    def enter_echo_zone(self, zone_id: str, visitor_name: str, 
                       origin_timeline: str, entry_point: str = None) -> Dict:
        """Record an entity entering an echo zone"""
        if zone_id not in self.echo_zones:
            return {"success": False, "error": "Echo zone not found"}
            
        zone = self.echo_zones[zone_id]
        
        # Record the visit
        visit = zone.record_visitor(visitor_name, origin_timeline, entry_point)
        
        # Calculate risk factors
        risk_factors = {
            "zone_stability": 1.0 - zone.stability,
            "echo_intensity": zone.echo_intensity,
            "time_distortion": abs(zone.time_flow_coefficient),
            "reality_bleed": zone.reality_bleed
        }
        
        total_risk = sum(risk_factors.values()) / 4
        
        # Determine random effects on the visitor
        effects = []
        if random.random() < total_risk:
            possible_effects = [
                "Temporal disorientation",
                "Memory fragmentation",
                "Reality perception shift",
                "Quantum state alteration",
                "Timeline echo absorption",
                "Chronological displacement",
                "Causal decoupling"
            ]
            
            effect_count = min(3, max(1, int(total_risk * 5)))
            effects = random.sample(possible_effects, effect_count)
            
        return {
            "success": True,
            "visitor": visitor_name,
            "zone": zone.name,
            "risks": risk_factors,
            "total_risk": total_risk,
            "immediate_effects": effects
        }
    
    def exit_echo_zone(self, zone_id: str, visitor_name: str) -> Dict:
        """Record an entity exiting an echo zone"""
        if zone_id not in self.echo_zones:
            return {"success": False, "error": "Echo zone not found"}
            
        zone = self.echo_zones[zone_id]
        
        # Generate potential exit effects
        effects = []
        
        # Higher echo intensity = more exit effects
        if random.random() < zone.echo_intensity:
            possible_effects = [
                "Temporal afterimage",
                "Reality calibration lag",
                "Timeline memory retention",
                "Quantum state fluctuation",
                "Causal echo phenomenon",
                "Chronological realignment strain"
            ]
            
            effect_count = random.randint(1, 3)
            effects = random.sample(possible_effects, effect_count)
        
        # Record the exit
        success = zone.visitor_exit(visitor_name, effects)
        
        if not success:
            return {"success": False, "error": "Visitor not found in this zone"}
            
        return {
            "success": True,
            "visitor": visitor_name,
            "zone": zone.name,
            "exit_effects": effects
        }
    
    def get_zone_status(self, zone_id: str) -> Dict:
        """Get detailed status of an echo zone"""
        if zone_id not in self.echo_zones:
            return {"success": False, "error": "Echo zone not found"}
            
        zone = self.echo_zones[zone_id]
        
        # Calculate metrics
        active_visitors = sum(1 for v in zone.visitors if v["exit_time"] is None)
        total_visitors = len(zone.visitors)
        
        recent_manifestations = sum(1 for e in zone.echoes 
                                   if e["last_manifestation"] is not None and 
                                   time.time() - e["last_manifestation"] < 86400)  # Last 24 hours
        
        status = {
            "success": True,
            "zone_id": zone_id,
            "name": zone.name,
            "stability": zone.stability,
            "metrics": {
                "echo_count": len(zone.echoes),
                "active_visitors": active_visitors,
                "total_visitors": total_visitors,
                "recent_manifestations": recent_manifestations,
                "echo_intensity": zone.echo_intensity,
                "time_flow": zone.time_flow_coefficient,
                "spatial_contiguity": zone.spatial_contiguity,
                "reality_bleed": zone.reality_bleed
            },
            "status": "Stable" if zone.stability > 0.6 else "Unstable" if zone.stability > 0.3 else "Critical",
            "anomaly_count": len(zone.anomalies)
        }
        
        return status
    
    def scan_for_echo_zones(self, sensitivity: float = None) -> List[Dict]:
        """Scan for new unregistered echo zones"""
        scan_sensitivity = sensitivity or self.detection_sensitivity
        
        # Simulate finding new zones
        detection_count = random.randint(0, 2)  # 0-2 new zones per scan
        
        if detection_count == 0:
            return []
            
        detected_zones = []
        
        for _ in range(detection_count):
            # Only detect if random value is below sensitivity
            if random.random() > scan_sensitivity:
                continue
                
            # Create a detected zone signature
            detection = {
                "coordinates": (
                    random.uniform(-1000, 1000),
                    random.uniform(-1000, 1000),
                    random.uniform(-1000, 1000)
                ),
                "estimated_size": random.uniform(50, 500),
                "signal_strength": random.uniform(0.3, 0.9),
                "time_distortion": random.uniform(-0.5, 0.5),
                "stability_reading": random.uniform(0.2, 0.8),
                "detection_confidence": random.uniform(0.5, 0.95) * scan_sensitivity
            }
            
            detected_zones.append(detection)
            
        return detected_zones
    
    def __str__(self) -> str:
        return f"Temporal Echo System: {len(self.echo_zones)} echo zones, {len(self.active_probes)} active probes"


def run_echo_system_demo():
    """Run a demonstration of the temporal echo system"""
    print("=== Temporal Echo System Demonstration ===")
    
    # Create the system
    echo_system = TemporalEchoSystem()
    
    # Create some echo zones
    print("\nCreating temporal echo zones...")
    
    void_zone = echo_system.create_echo_zone("Void Nexus", 0.4)
    print(f"Created {void_zone}")
    
    limbo = echo_system.create_echo_zone("Limbo Expanse", 0.6)
    print(f"Created {limbo}")
    
    # Add echoes to zones
    print("\nPopulating echo zones with temporal echoes...")
    
    void_zone.add_echo("Alpha Prime", 2045, "Quantum revolution breakthrough", 0.7)
    void_zone.add_echo("Beta Variant", 2032, "Temporal crisis event", 0.8)
    void_zone.add_echo("Gamma Nexus", 2018, "First dimensional breach", 0.5)
    
    limbo.add_echo("Delta Flux", 2040, "AI singularity", 0.6)
    limbo.add_echo("Omega Point", 2060, "Time loop formation", 0.9)
    
    # Deploy probes
    print("\nDeploying monitoring probes...")
    
    void_probe = echo_system.deploy_probe(void_zone.zone_id, "quantum")
    print(f"Deployed probe: {void_probe['message']}")
    
    limbo_probe = echo_system.deploy_probe(limbo.zone_id, "standard")
    print(f"Deployed probe: {limbo_probe['message']}")
    
    # Simulate visitors
    print("\nSimulating visitors to echo zones...")
    
    void_entry = echo_system.enter_echo_zone(
        void_zone.zone_id, "Dr. Eliza Chen", "Alpha Prime", "Temporal breach #42"
    )
    
    print(f"Visitor {void_entry['visitor']} entered {void_entry['zone']}")
    print(f"Entry risk: {void_entry['total_risk']:.2f}")
    if void_entry['immediate_effects']:
        print(f"Immediate effects: {', '.join(void_entry['immediate_effects'])}")
    
    # Update system
    print("\nSimulating time passing...")
    echo_system.update_all_zones()
    
    # Get probe readings
    print("\nProbe readings:")
    void_readings = echo_system.probe_readings(void_probe['probe_id'])
    
    if void_readings['success']:
        reading = void_readings['latest_reading']
        print(f"Probe {void_readings['probe_id']} in {void_zone.name}:")
        print(f"  - Stability: {reading['stability']:.2f}")
        print(f"  - Echo intensity: {reading['echo_intensity']:.2f}")
        print(f"  - Echo count: {reading['echo_count']} ({reading['active_echoes']} active)")
        print(f"  - Time flow coefficient: {reading['time_flow']:.2f}")
    
    # Visitor exits
    print("\nVisitor exiting echo zone...")
    exit_result = echo_system.exit_echo_zone(void_zone.zone_id, "Dr. Eliza Chen")
    
    if exit_result['success']:
        print(f"Visitor {exit_result['visitor']} exited {exit_result['zone']}")
        if exit_result['exit_effects']:
            print(f"Exit effects: {', '.join(exit_result['exit_effects'])}")
    
    # Scan for new echo zones
    print("\nScanning for new echo zones...")
    detections = echo_system.scan_for_echo_zones(0.8)
    
    if detections:
        print(f"Detected {len(detections)} potential new echo zones:")
        for i, detection in enumerate(detections):
            print(f"  - Detection #{i+1}: Signal strength {detection['signal_strength']:.2f}, " + 
                 f"Confidence {detection['detection_confidence']:.2f}")
    else:
        print("No new echo zones detected")
    
    # Show final zone status
    print("\nEcho zone status reports:")
    for zone_id, zone in echo_system.echo_zones.items():
        status = echo_system.get_zone_status(zone_id)
        print(f"{status['name']}: {status['status']} - Stability {status['stability']:.2f}")
        print(f"  - Echoes: {status['metrics']['echo_count']}")
        print(f"  - Recent manifestations: {status['metrics']['recent_manifestations']}")
        print(f"  - Visitors: {status['metrics']['active_visitors']} active, {status['metrics']['total_visitors']} total")
    
    return echo_system


if __name__ == "__main__":
    run_echo_system_demo()
