
#!/bin/bash
# Run the Multiverse Simulation System Consolidated Application

echo "=================================================="
echo "  Multiverse Simulation System                    "
echo "  Consolidated Application Launcher               "
echo "=================================================="
echo

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is required but not found."
    exit 1
fi

# Run the application
echo "Starting Multiverse Simulation System..."
python3 multiverse_app.py "$@"
