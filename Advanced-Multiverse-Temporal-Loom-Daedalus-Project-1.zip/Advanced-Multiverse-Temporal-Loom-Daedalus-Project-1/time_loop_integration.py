
"""
Time Loop Integration Module
Integrates the timeline types, time loops, and progression systems with the main Multiverse system.
"""

import random
import time
from typing import Dict, List, Tuple, Optional, Any
from main import Multiverse, Timeline
from timeline_types import (
    TimelineType, TimeLoopType, TimeLoop, TypedTimeline, TimelineProgression
)

class TimeLoopSystem:
    """System for managing time loops across the multiverse"""
    
    def __init__(self, multiverse: Multiverse):
        """
        Initialize the time loop system
        
        Args:
            multiverse: The multiverse object to integrate with
        """
        self.multiverse = multiverse
        self.typed_timelines: Dict[str, TypedTimeline] = {}
        self.active_loops: List[Tuple[str, TimeLoop]] = []  # (timeline_name, loop)
        self.loop_events: List[Dict[str, Any]] = []
        self.last_update_time = time.time()
        
    def initialize(self):
        """Initialize the system by analyzing existing timelines"""
        print("Initializing Time Loop System...")
        
        # Convert existing timelines to typed timelines with time loop data
        for name, timeline in self.multiverse.timelines.items():
            # Determine timeline type based on properties
            timeline_type = self._determine_timeline_type(timeline)
            
            # Create typed timeline
            typed_timeline = TypedTimeline(
                name=name,
                timeline_type=timeline_type,
                stability=timeline.stability,
                quantum_state=timeline.quantum_state
            )
            
            # Copy events
            for year, event in timeline.events:
                typed_timeline.add_event(event, year)
                
            # Connect timelines
            typed_timeline.connected_timelines = timeline.connected_timelines
            
            # Store typed timeline
            self.typed_timelines[name] = typed_timeline
            
            # Add time loops based on type
            if timeline_type == TimelineType.LOOPED:
                # Add more loops for looped timelines
                loop_count = random.randint(1, 3)
                for _ in range(loop_count):
                    self._create_time_loop(typed_timeline)
            elif random.random() < 0.2:
                # 20% chance for other timeline types to have a loop
                self._create_time_loop(typed_timeline)
                
        # Track active loops
        self._update_active_loops()
        
        print(f"Time Loop System initialized with {len(self.active_loops)} active loops")
        
    def _determine_timeline_type(self, timeline: Timeline) -> TimelineType:
        """Determine the appropriate timeline type based on timeline properties"""
        # Check for quantum flags
        if hasattr(timeline, 'quantum_state'):
            if timeline.quantum_state.superposition:
                return TimelineType.QUANTUM
                
        # Check stability
        if timeline.stability > 0.9:
            return TimelineType.STATIC
        elif timeline.stability < 0.5:
            return TimelineType.DYNAMIC
            
        # Check for branching evidence in events
        if any("BRANCH" in event for year, event in timeline.events):
            return TimelineType.BRANCHING
            
        # Check for convergence evidence in events
        if any("CONVERGE" in event for year, event in timeline.events):
            return TimelineType.CONVERGING
            
        # Check for loop evidence in events
        if any("LOOP" in event for year, event in timeline.events):
            return TimelineType.LOOPED
            
        # Default to random type with some weighting
        type_weights = [
            (TimelineType.STATIC, 0.1),
            (TimelineType.DYNAMIC, 0.2),
            (TimelineType.PLASTIC, 0.1),
            (TimelineType.LOOPED, 0.15),
            (TimelineType.BRANCHING, 0.2),
            (TimelineType.CONVERGING, 0.1),
            (TimelineType.QUANTUM, 0.05),
            (TimelineType.HYBRID, 0.1)
        ]
        
        # Choose based on weights
        total_weight = sum(weight for _, weight in type_weights)
        r = random.uniform(0, total_weight)
        cumulative_weight = 0
        
        for timeline_type, weight in type_weights:
            cumulative_weight += weight
            if r <= cumulative_weight:
                return timeline_type
                
        # Default fallback
        return TimelineType.DYNAMIC
        
    def _create_time_loop(self, typed_timeline: TypedTimeline) -> TimeLoop:
        """Create a time loop for a typed timeline"""
        # Choose loop type with some weighting
        loop_types = list(TimeLoopType)
        loop_type = random.choice(loop_types)
        
        # Find potential start years from timeline events
        if typed_timeline.events:
            event_years = [year for year, _ in typed_timeline.events]
            start_year = random.choice(event_years)
        else:
            start_year = 2000 + random.randint(-50, 50)
            
        # Duration depends on loop type
        if loop_type == TimeLoopType.CAUSAL:
            # Causal loops tend to be shorter
            duration = random.randint(5, 20)
        elif loop_type == TimeLoopType.ETERNAL_RECURRENCE:
            # Eternal recurrence loops tend to be longer
            duration = random.randint(50, 100)
        else:
            # Other loops have medium duration
            duration = random.randint(10, 50)
            
        end_year = start_year + duration
        
        # Create the loop
        loop = TimeLoop(
            loop_type=loop_type,
            start_year=start_year,
            end_year=end_year,
            iterations=None if random.random() < 0.3 else random.randint(3, 100),
            decay_rate=random.uniform(0.01, 0.1)
        )
        
        # Add to timeline
        typed_timeline.time_loops.append(loop)
        
        # Add loop metadata to multiverse timeline
        if typed_timeline.name in self.multiverse.timelines:
            timeline = self.multiverse.timelines[typed_timeline.name]
            timeline.add_event(f"TIME LOOP DETECTED: {loop.description}", start_year)
            timeline.add_event(f"TIME LOOP NEXUS POINT: Returns to {start_year}", end_year)
            
        return loop
        
    def _update_active_loops(self):
        """Update the list of active time loops across all timelines"""
        self.active_loops = []
        
        for name, typed_timeline in self.typed_timelines.items():
            for loop in typed_timeline.time_loops:
                if loop.active:
                    self.active_loops.append((name, loop))
                    
    def update(self, years_elapsed: float = 1.0):
        """
        Update all typed timelines and time loops
        
        Args:
            years_elapsed: Years elapsed since last update
        """
        # Calculate real time elapsed
        now = time.time()
        real_time_elapsed = now - self.last_update_time
        self.last_update_time = now
        
        # Track active loop iterations
        loop_iterations = []
        
        # Update each typed timeline
        for name, typed_timeline in self.typed_timelines.items():
            update_results = typed_timeline.update(years_elapsed)
            
            # Record loop iterations
            for loop_result in update_results.get('loops', []):
                if 'iteration' in loop_result:
                    loop_iterations.append({
                        'timeline': name,
                        'iteration': loop_result['iteration'],
                        'stability': loop_result.get('stability', 0),
                        'active': loop_result.get('active', True)
                    })
                    
            # Apply stability changes to main timeline
            if name in self.multiverse.timelines:
                # Sync stability back to main timeline
                self.multiverse.timelines[name].stability = typed_timeline.stability
                
        # Update active loops list
        self._update_active_loops()
        
        # Log loop iterations
        for iteration in loop_iterations:
            self.loop_events.append({
                'timestamp': now,
                'timeline': iteration['timeline'],
                'iteration': iteration['iteration'],
                'stability': iteration['stability'],
                'active': iteration['active']
            })
            
        return {
            'years_elapsed': years_elapsed,
            'real_time_elapsed': real_time_elapsed,
            'loop_iterations': loop_iterations,
            'active_loops_count': len(self.active_loops)
        }
        
    def search_for_time_loops(self, timeline_name: str) -> List[Dict[str, Any]]:
        """
        Search for time loops in a specific timeline
        
        Args:
            timeline_name: Name of the timeline to search
            
        Returns:
            List of detected loops
        """
        if timeline_name not in self.multiverse.timelines:
            return []
            
        # If we already have typed timeline, return its loops
        if timeline_name in self.typed_timelines:
            typed_timeline = self.typed_timelines[timeline_name]
            return [{'loop': loop, 'timeline': timeline_name} for loop in typed_timeline.time_loops]
            
        # Otherwise, analyze timeline for potential loop signatures
        timeline = self.multiverse.timelines[timeline_name]
        potential_loops = []
        
        # Look for loop evidence in events
        loop_starts = [
            (year, event) for year, event in timeline.events
            if "LOOP" in event or "CYCLE" in event or "REPEAT" in event or "RECUR" in event
        ]
        
        # If loop evidence found, create typed timeline and predict loops
        if loop_starts:
            # Create typed timeline
            typed_timeline = TypedTimeline(
                name=timeline_name,
                timeline_type=TimelineType.LOOPED,
                stability=timeline.stability,
                quantum_state=timeline.quantum_state
            )
            
            # Copy events
            for year, event in timeline.events:
                typed_timeline.add_event(event, year)
                
            # Create loops based on evidence
            for start_year, event in loop_starts:
                # Look for potential end years
                potential_end_years = [
                    year for year, evt in timeline.events
                    if year > start_year and ("NEXUS" in evt or "RETURN" in evt or "LOOP END" in evt)
                ]
                
                end_year = min(potential_end_years) if potential_end_years else start_year + random.randint(10, 50)
                
                # Create the loop
                loop = TimeLoop(
                    loop_type=random.choice(list(TimeLoopType)),
                    start_year=start_year,
                    end_year=end_year,
                    iterations=None
                )
                
                typed_timeline.time_loops.append(loop)
                potential_loops.append({'loop': loop, 'timeline': timeline_name})
                
            # Store typed timeline for future use
            self.typed_timelines[timeline_name] = typed_timeline
            
        return potential_loops
        
    def create_time_loop(self, timeline_name: str, start_year: int, end_year: int, 
                       loop_type_str: str = None) -> Optional[Dict[str, Any]]:
        """
        Create a new time loop in a timeline
        
        Args:
            timeline_name: Name of the timeline
            start_year: Loop start year
            end_year: Loop end year
            loop_type_str: String name of loop type (or None for random)
            
        Returns:
            Information about the created loop
        """
        if timeline_name not in self.multiverse.timelines:
            return None
            
        # Get or create typed timeline
        if timeline_name not in self.typed_timelines:
            timeline = self.multiverse.timelines[timeline_name]
            typed_timeline = TypedTimeline(
                name=timeline_name,
                timeline_type=TimelineType.LOOPED,
                stability=timeline.stability,
                quantum_state=timeline.quantum_state
            )
            
            # Copy events
            for year, event in timeline.events:
                typed_timeline.add_event(event, year)
                
            self.typed_timelines[timeline_name] = typed_timeline
        else:
            typed_timeline = self.typed_timelines[timeline_name]
            
        # Parse loop type
        loop_type = None
        if loop_type_str:
            try:
                loop_type = TimeLoopType[loop_type_str.upper()]
            except KeyError:
                loop_type = random.choice(list(TimeLoopType))
        else:
            loop_type = random.choice(list(TimeLoopType))
            
        # Create the loop
        loop = TimeLoop(
            loop_type=loop_type,
            start_year=start_year,
            end_year=end_year,
            iterations=None if random.random() < 0.3 else random.randint(3, 100)
        )
        
        # Add to typed timeline
        typed_timeline.time_loops.append(loop)
        
        # Add to main timeline
        multiverse_timeline = self.multiverse.timelines[timeline_name]
        multiverse_timeline.add_event(f"TIME LOOP CREATED: {loop.description}", start_year)
        multiverse_timeline.add_event(f"TIME LOOP NEXUS POINT: Returns to {start_year}", end_year)
        
        # Update active loops
        self._update_active_loops()
        
        return {
            'timeline': timeline_name,
            'loop': loop,
            'start_year': start_year,
            'end_year': end_year,
            'duration': end_year - start_year,
            'description': loop.description
        }
        
    def predict_loop_stability(self, timeline_name: str, future_years: int = 50) -> Dict[str, Any]:
        """
        Predict stability of time loops in a timeline
        
        Args:
            timeline_name: Name of the timeline
            future_years: How many years to look ahead
            
        Returns:
            Prediction information
        """
        if timeline_name not in self.typed_timelines:
            return {
                'timeline': timeline_name,
                'has_loops': False,
                'prediction': "No time loops detected in this timeline."
            }
            
        typed_timeline = self.typed_timelines[timeline_name]
        
        # Make prediction
        prediction = typed_timeline.predict_future(future_years)
        
        # Summarize loop predictions
        loop_summaries = []
        for loop_pred in prediction.get('time_loops', []):
            loop_summaries.append({
                'description': loop_pred['loop'],
                'iterations': loop_pred['estimated_iterations'],
                'stability': loop_pred['predicted_stability'],
                'will_break': loop_pred['predicted_to_break']
            })
            
        return {
            'timeline': timeline_name,
            'has_loops': len(loop_summaries) > 0,
            'future_years': future_years,
            'predicted_stability': prediction.get('predicted_stability', 0),
            'confidence': prediction.get('confidence', 0),
            'loops': loop_summaries
        }
        
    def get_system_status(self) -> Dict[str, Any]:
        """Get the overall status of the time loop system"""
        total_timelines = len(self.typed_timelines)
        total_loops = sum(len(tl.time_loops) for tl in self.typed_timelines.values())
        active_loops = len(self.active_loops)
        
        # Timeline type statistics
        type_counts = {}
        for typed_timeline in self.typed_timelines.values():
            type_name = typed_timeline.timeline_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
            
        # Loop type statistics
        loop_type_counts = {}
        for name, typed_timeline in self.typed_timelines.items():
            for loop in typed_timeline.time_loops:
                type_name = loop.loop_type.value
                loop_type_counts[type_name] = loop_type_counts.get(type_name, 0) + 1
                
        # Recent loop events
        recent_events = self.loop_events[-10:] if self.loop_events else []
        
        return {
            'total_timelines': total_timelines,
            'total_loops': total_loops,
            'active_loops': active_loops,
            'timeline_types': type_counts,
            'loop_types': loop_type_counts,
            'recent_events': recent_events
        }
        
    def display_status(self):
        """Display the status of the time loop system"""
        status = self.get_system_status()
        
        print("=== TIME LOOP SYSTEM STATUS ===")
        print(f"Total Timelines: {status['total_timelines']}")
        print(f"Total Time Loops: {status['total_loops']}")
        print(f"Active Loops: {status['active_loops']}")
        
        print("\nTimeline Types:")
        for type_name, count in status['timeline_types'].items():
            print(f"  {type_name.title()}: {count}")
            
        print("\nLoop Types:")
        for type_name, count in status['loop_types'].items():
            print(f"  {type_name.title()}: {count}")
            
        print("\nRecent Loop Events:")
        for event in status['recent_events']:
            active = "active" if event['active'] else "broken"
            print(f"  Timeline '{event['timeline']}': Iteration {event['iteration']} ({active}, stability: {event['stability']:.2f})")


def integrate_with_multiverse():
    """
    Integrate the timeline types and time loops with an existing multiverse
    
    Returns:
        TimeLoopSystem instance
    """
    from main import Multiverse
    
    print("=== Integrating Time Loop System with Multiverse ===")
    
    # Create multiverse if one doesn't exist in the global scope
    try:
        multiverse
    except NameError:
        print("Creating new multiverse...")
        multiverse = Multiverse()
        
        # Add some timelines
        multiverse.create_timeline("Alpha Prime", 0.9)
        multiverse.create_timeline("Beta Variant", 0.75)
        multiverse.create_timeline("Gamma Nexus", 0.6)
        
    # Create and initialize the system
    time_loop_system = TimeLoopSystem(multiverse)
    time_loop_system.initialize()
    
    # Display initial status
    time_loop_system.display_status()
    
    # Simulate some updates
    print("\nSimulating timeline updates...")
    time_loop_system.update(5)  # 5 years elapsed
    
    # Search for loops in a specific timeline
    print("\nSearching for time loops in Alpha Prime...")
    loops = time_loop_system.search_for_time_loops("Alpha Prime")
    for loop_info in loops:
        print(f"Found: {loop_info['loop']}")
        
    # Create a new time loop
    print("\nCreating a new time loop in Beta Variant...")
    new_loop = time_loop_system.create_time_loop(
        "Beta Variant", 2030, 2050, "PREDESTINATION"
    )
    if new_loop:
        print(f"Created: {new_loop['loop']}")
        
    # Make predictions
    print("\nPredicting loop stability...")
    predictions = time_loop_system.predict_loop_stability("Beta Variant", 100)
    print(f"Timeline: {predictions['timeline']}")
    print(f"Future stability: {predictions['predicted_stability']:.2f}")
    
    if predictions['has_loops']:
        print("Loop predictions:")
        for loop in predictions['loops']:
            break_status = "will break" if loop['will_break'] else "will continue"
            print(f"  {loop['description']}: {break_status}")
            print(f"    Estimated iterations: {loop['iterations']:.1f}")
            print(f"    Predicted stability: {loop['stability']:.2f}")
            
    # Final status
    print("\nFinal Time Loop System Status:")
    time_loop_system.display_status()
    
    return time_loop_system


if __name__ == "__main__":
    integrate_with_multiverse()
