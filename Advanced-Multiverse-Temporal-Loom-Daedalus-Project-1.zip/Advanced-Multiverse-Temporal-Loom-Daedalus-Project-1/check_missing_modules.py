
from missing_modules import get_missing_modules, clear_missing_modules

def main():
    # Import some modules to see what's missing
    try:
        import matplotlib
        print("matplotlib is available")
    except ImportError:
        print("matplotlib is missing")
    
    try:
        import numpy
        print("numpy is available")
    except ImportError:
        print("numpy is missing")
    
    # Print any modules registered as missing
    missing = get_missing_modules()
    if missing:
        print(f"Modules registered as missing: {', '.join(missing)}")
    else:
        print("No modules registered as missing")

if __name__ == "__main__":
    main()
