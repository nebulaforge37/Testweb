
"""
Quantum Archaeology System
This module provides tools to recover traces of collapsed timelines
and reconstruct events from quantum echoes in the multiverse.
"""

import random
import math
import time
from typing import List, Dict, Tuple, Optional, Any, Union

class QuantumRemnant:
    """A recovered fragment of a collapsed timeline"""
    
    def __init__(self, remnant_id: int, origin_timeline: str = "Unknown", fragment_type: str = None):
        """
        Initialize a quantum remnant
        
        Args:
            remnant_id: Unique identifier
            origin_timeline: Original timeline name if known
            fragment_type: Type of fragment (Event, Entity, Object, Location)
        """
        self.remnant_id = remnant_id
        self.origin_timeline = origin_timeline
        self.fragment_type = fragment_type or random.choice(["Event", "Entity", "Object", "Location"])
        self.estimated_year = random.randint(1800, 2200)
        self.discovery_timestamp = time.time()
        self.stability = random.uniform(0.2, 0.8)  # How stable this remnant is
        self.clarity = random.uniform(0.1, 0.9)  # How clear/complete the data is
        self.data_fragments = []  # Recovered data pieces
        self.reconstruction_level = 0.0  # How completely it's been reconstructed
        
        # Generate appropriate content based on fragment type
        self._generate_content()
        
    def _generate_content(self):
        """Generate appropriate content based on fragment type"""
        if self.fragment_type == "Event":
            events = [
                "Timeline bifurcation point",
                "Quantum singularity experiment",
                "First contact with extradimensional beings",
                "Reality collapse cascade",
                "Temporal war battle",
                "Paradox resolution event",
                "Multiversal convergence meeting",
                "Quantum field breakthrough",
                "Timewave zero moment",
                "Dimensional barrier breach"
            ]
            self.name = random.choice(events)
            self.description = f"A {random.choice(['critical', 'significant', 'pivotal', 'catastrophic', 'revolutionary'])} event in timeline {self.origin_timeline}."
            
        elif self.fragment_type == "Entity":
            titles = ["Dr.", "Professor", "Agent", "Director", "Traveler", "Warden", "Archivist"]
            first_names = ["Alex", "Morgan", "Taylor", "Jordan", "Quinn", "Avery", "Riley"]
            last_names = ["Chen", "Smith", "Novikov", "Zhang", "Patel", "Kim", "Reyes", "Müller"]
            self.name = f"{random.choice(titles)} {random.choice(first_names)} {random.choice(last_names)}"
            roles = ["Temporal physicist", "Reality engineer", "Quantum theorist", "Paradox resolver", 
                     "Dimensional explorer", "Timeline guardian", "Multiverse diplomat"]
            self.description = f"A {random.choice(roles)} from timeline {self.origin_timeline}."
            
        elif self.fragment_type == "Object":
            objects = [
                "Quantum stabilizer",
                "Temporal compass",
                "Reality anchor",
                "Paradox inverter",
                "Dimensional key",
                "Timeline differentiation crystal",
                "Entanglement node",
                "Causal chain recorder",
                "Probability modifier",
                "Multiverse mapper"
            ]
            self.name = random.choice(objects)
            self.description = f"A {random.choice(['rare', 'unique', 'powerful', 'ancient', 'advanced'])} device from timeline {self.origin_timeline}."
            
        else:  # Location
            locations = [
                "Quantum research facility",
                "Temporal nexus point",
                "Dimensional gateway",
                "Paradox containment zone",
                "Reality engineering laboratory",
                "Multiverse observation post",
                "Timewave monitoring station",
                "Causal reconfiguration chamber",
                "Probability matrix calculation center",
                "Entanglement amplification array"
            ]
            self.name = random.choice(locations)
            self.description = f"A {random.choice(['mysterious', 'classified', 'critical', 'abandoned', 'essential'])} location in timeline {self.origin_timeline}."
    
    def add_data_fragment(self, fragment_text: str, reliability: float = 0.5):
        """Add a recovered data fragment"""
        self.data_fragments.append({
            "text": fragment_text,
            "reliability": reliability,
            "recovery_time": time.time()
        })
        
        # Update reconstruction level based on new data
        self._recalculate_reconstruction()
        
    def _recalculate_reconstruction(self):
        """Recalculate the reconstruction level"""
        if not self.data_fragments:
            self.reconstruction_level = 0.0
            return
            
        # Calculate based on number and reliability of fragments
        reliability_sum = sum(f["reliability"] for f in self.data_fragments)
        fragment_count = min(10, len(self.data_fragments))  # Cap at 10 fragments
        
        # More reliable fragments give better reconstruction
        self.reconstruction_level = min(1.0, (reliability_sum / 10) + (fragment_count / 20))
        
    def stabilize(self, amount: float = 0.1):
        """Try to stabilize this remnant"""
        old_stability = self.stability
        self.stability = min(1.0, self.stability + amount)
        return self.stability - old_stability
        
    def enhance_clarity(self, amount: float = 0.1):
        """Try to enhance the clarity of this remnant"""
        old_clarity = self.clarity
        self.clarity = min(1.0, self.clarity + amount)
        return self.clarity - old_clarity
        
    def get_reconstruction_summary(self) -> Dict[str, Any]:
        """Get a summary of the reconstruction progress"""
        return {
            "name": self.name,
            "type": self.fragment_type,
            "origin": self.origin_timeline,
            "year": self.estimated_year,
            "stability": self.stability,
            "clarity": self.clarity,
            "reconstruction": self.reconstruction_level,
            "fragments": len(self.data_fragments)
        }
        
    def __str__(self) -> str:
        status = "Stable" if self.stability > 0.7 else "Unstable" if self.stability < 0.4 else "Partially Stable"
        recon = f"[{self.reconstruction_level*100:.0f}% Reconstructed]"
        return f"{self.name} ({self.fragment_type}, {status}) {recon} - {self.description}"


class TimelineEcho:
    """A faint echo of a collapsed timeline in the quantum field"""
    
    def __init__(self, echo_id: int, timeline_name: str = None):
        """
        Initialize a timeline echo
        
        Args:
            echo_id: Unique identifier
            timeline_name: Name of the original timeline if known
        """
        self.echo_id = echo_id
        self.timeline_name = timeline_name or f"Timeline-{random.randint(1000, 9999)}"
        self.quantum_signature = random.random()
        self.discovery_timestamp = time.time()
        self.estimated_collapse_time = time.time() - random.uniform(86400, 86400*365)  # 1 day to 1 year ago
        self.resonance_strength = random.uniform(0.1, 0.6)  # How strong the echo is
        self.decay_rate = random.uniform(0.001, 0.01)  # How quickly it's fading
        self.events = []  # Echoes of events
        self.entities = []  # Echoes of entities
        
        # Generate some random echo data
        self._generate_echo_data()
        
    def _generate_echo_data(self):
        """Generate random echo data"""
        # Create some echo events
        event_count = random.randint(3, 8)
        years = sorted([random.randint(1900, 2100) for _ in range(event_count)])
        
        events = [
            "Timeline origin point",
            "Quantum computing breakthrough",
            "First contact with extradimensional beings",
            "Temporal mechanics discovery",
            "Reality engineering advancement",
            "Dimensional barrier breakthrough",
            "Paradox resolution protocol establishment",
            "Timewave detection system creation",
            "Multiverse mapping project initiation",
            "Quantum entanglement amplification",
            "Timeline collapse event",
            "Dimensional refuge construction",
            "Temporal war outbreak",
            "Reality anchor deployment",
            "Causality violation incident"
        ]
        
        for i in range(event_count):
            event = random.choice(events)
            events.remove(event)  # Don't reuse events
            if not events:  # If we run out of events
                events = ["Unidentified temporal event", "Unknown quantum occurrence", "Mysterious dimensional phenomenon"]
                
            self.events.append({
                "year": years[i],
                "description": event,
                "clarity": random.uniform(0.1, 0.8)
            })
            
        # Create some echo entities
        entity_count = random.randint(1, 4)
        titles = ["Dr.", "Professor", "Agent", "Director", "Commander", "Warden", "Archivist"]
        first_names = ["Alex", "Morgan", "Taylor", "Jordan", "Quinn", "Avery", "Riley", "Cameron", "Jamie", "Parker"]
        last_names = ["Chen", "Smith", "Novikov", "Zhang", "Patel", "Kim", "Reyes", "Müller", "Ivanov", "Nakamura"]
        
        for i in range(entity_count):
            name = f"{random.choice(titles)} {random.choice(first_names)} {random.choice(last_names)}"
            roles = ["Temporal physicist", "Reality engineer", "Quantum theorist", "Paradox resolver", 
                    "Dimensional explorer", "Timeline guardian", "Multiverse diplomat", "Timewave technician"]
            
            self.entities.append({
                "name": name,
                "role": random.choice(roles),
                "clarity": random.uniform(0.1, 0.8)
            })
    
    def get_current_resonance(self) -> float:
        """Get the current resonance strength after decay"""
        time_elapsed = (time.time() - self.discovery_timestamp) / 86400  # Days since discovery
        decayed_strength = self.resonance_strength * math.exp(-self.decay_rate * time_elapsed)
        return max(0.01, decayed_strength)  # Minimum 0.01 resonance
        
    def extract_data_fragment(self) -> Optional[Dict[str, Any]]:
        """Try to extract a data fragment from this echo"""
        resonance = self.get_current_resonance()
        
        # 50% chance of success, modified by resonance
        if random.random() < (0.5 * resonance):
            # Determine fragment type (event or entity)
            if self.events and (not self.entities or random.random() < 0.7):
                # Extract from events
                event = random.choice(self.events)
                return {
                    "type": "Event",
                    "text": f"In year {event['year']}: {event['description']}",
                    "reliability": event["clarity"] * resonance,
                    "year": event["year"]
                }
            elif self.entities:
                # Extract from entities
                entity = random.choice(self.entities)
                return {
                    "type": "Entity",
                    "text": f"{entity['name']}, {entity['role']}",
                    "reliability": entity["clarity"] * resonance
                }
        
        return None
        
    def amplify_resonance(self, amount: float = 0.1) -> float:
        """Try to amplify the resonance of this echo"""
        old_resonance = self.resonance_strength
        self.resonance_strength = min(0.9, self.resonance_strength + amount)
        return self.resonance_strength - old_resonance
        
    def reduce_decay(self, amount: float = 0.001) -> float:
        """Try to reduce the decay rate of this echo"""
        old_decay = self.decay_rate
        self.decay_rate = max(0.0001, self.decay_rate - amount)
        return old_decay - self.decay_rate
        
    def __str__(self) -> str:
        resonance = self.get_current_resonance()
        status = "Strong" if resonance > 0.5 else "Fading" if resonance < 0.2 else "Moderate"
        return f"Echo of {self.timeline_name} [{status}, {resonance:.2f}] - {len(self.events)} events, {len(self.entities)} entities"


class QuantumArchaeology:
    """Main system for recovering and analyzing collapsed timeline data"""
    
    def __init__(self, multiverse = None):
        """Initialize the quantum archaeology system"""
        self.multiverse = multiverse
        self.echoes = {}  # echo_id -> TimelineEcho
        self.remnants = {}  # remnant_id -> QuantumRemnant
        self.next_echo_id = 1
        self.next_remnant_id = 1
        self.scan_history = []
        self.recovery_history = []
        
    def scan_for_echoes(self, scan_power: float = 0.5, 
                       focus_timeline: str = None) -> List[TimelineEcho]:
        """
        Scan the quantum field for timeline echoes
        
        Args:
            scan_power: Power of the scan (0.0-1.0)
            focus_timeline: Optional timeline to focus scan around
            
        Returns:
            List of newly discovered echoes
        """
        # Record the scan
        scan_record = {
            "timestamp": time.time(),
            "power": scan_power,
            "focus": focus_timeline,
            "discoveries": []
        }
        
        # Determine number of potential discoveries
        base_count = random.randint(0, 3)
        power_bonus = int(scan_power * 4)
        total_possible = base_count + power_bonus
        
        # Determine success chance for each potential discovery
        success_chance = 0.3 + (scan_power * 0.5)
        if focus_timeline and self.multiverse:
            # Focused scan has better chance
            success_chance += 0.2
        
        # Make discovery attempts
        discovered_echoes = []
        
        for _ in range(total_possible):
            if random.random() < success_chance:
                # Create a new echo
                timeline_name = None
                if focus_timeline:
                    # Variation on the focus timeline name
                    suffix = random.choice(["Prime", "Alpha", "Beta", "Variant", "Divergent", "Collapsed"])
                    timeline_name = f"{focus_timeline}-{suffix}"
                
                echo = TimelineEcho(self.next_echo_id, timeline_name)
                self.next_echo_id += 1
                
                # Store the echo
                self.echoes[echo.echo_id] = echo
                discovered_echoes.append(echo)
                
                # Record in scan history
                scan_record["discoveries"].append(echo.echo_id)
        
        self.scan_history.append(scan_record)
        return discovered_echoes
        
    def extract_remnant_from_echo(self, echo_id: int) -> Optional[QuantumRemnant]:
        """
        Try to extract a quantum remnant from an echo
        
        Returns:
            Extracted remnant or None if failed
        """
        echo = self.echoes.get(echo_id)
        if not echo:
            return None
            
        # Check if extraction is possible based on resonance
        resonance = echo.get_current_resonance()
        if resonance < 0.1:
            # Too weak to extract anything
            return None
            
        # Determine fragment type
        fragment_types = ["Event", "Entity"]
        
        # Add Object and Location types for stronger echoes
        if resonance > 0.3:
            fragment_types.extend(["Object", "Location"])
            
        fragment_type = random.choice(fragment_types)
        
        # Create the remnant
        remnant = QuantumRemnant(self.next_remnant_id, echo.timeline_name, fragment_type)
        self.next_remnant_id += 1
        
        # Adjust properties based on echo strength
        remnant.stability = min(0.8, resonance + random.uniform(-0.1, 0.2))
        remnant.clarity = min(0.8, resonance + random.uniform(-0.2, 0.1))
        
        # Extract an initial data fragment
        fragment = echo.extract_data_fragment()
        if fragment:
            remnant.add_data_fragment(fragment["text"], fragment["reliability"])
            
            # Set estimated year if available
            if "year" in fragment:
                remnant.estimated_year = fragment["year"]
        
        # Store the remnant
        self.remnants[remnant.remnant_id] = remnant
        
        # Record the recovery
        self.recovery_history.append({
            "timestamp": time.time(),
            "echo_id": echo_id,
            "remnant_id": remnant.remnant_id,
            "resonance": resonance,
            "fragment_type": fragment_type
        })
        
        return remnant
        
    def analyze_remnant(self, remnant_id: int) -> Dict[str, Any]:
        """
        Analyze a quantum remnant for additional information
        
        Returns:
            Analysis results
        """
        remnant = self.remnants.get(remnant_id)
        if not remnant:
            return {"success": False, "message": "Remnant not found"}
            
        # Results dictionary
        results = {
            "success": True,
            "remnant_id": remnant_id,
            "name": remnant.name,
            "type": remnant.fragment_type,
            "origin": remnant.origin_timeline,
            "year": remnant.estimated_year,
            "stability": remnant.stability,
            "clarity": remnant.clarity,
            "reconstruction": remnant.reconstruction_level,
            "analysis": []
        }
        
        # Generate analysis insights based on remnant type
        if remnant.fragment_type == "Event":
            # Event analysis
            timelines = []
            if self.multiverse and hasattr(self.multiverse, 'timelines'):
                timelines = list(self.multiverse.timelines.keys())
                
            if timelines:
                # Find potential connection to existing timeline
                similar_timeline = random.choice(timelines)
                similarity = random.uniform(0.3, 0.8)
                
                results["analysis"].append({
                    "type": "Timeline Similarity",
                    "text": f"This event shows {similarity:.0%} similarity with events in timeline {similar_timeline}.",
                    "confidence": similarity
                })
                
            # Event significance
            significance = min(1.0, remnant.clarity * random.uniform(0.8, 1.2))
            significance_text = "critical" if significance > 0.8 else "significant" if significance > 0.5 else "minor"
            
            results["analysis"].append({
                "type": "Event Significance", 
                "text": f"This appears to be a {significance_text} event in its native timeline.",
                "confidence": remnant.clarity
            })
            
            # Bifurcation analysis
            if "bifurcation" in remnant.name.lower() or random.random() < 0.3:
                results["analysis"].append({
                    "type": "Bifurcation Analysis",
                    "text": f"This event may have been a timeline bifurcation point, creating 2-{random.randint(3, 7)} branch timelines.",
                    "confidence": remnant.clarity * 0.8
                })
                
        elif remnant.fragment_type == "Entity":
            # Entity analysis
            role_importance = min(1.0, remnant.clarity * random.uniform(0.7, 1.3))
            importance_text = "pivotal" if role_importance > 0.8 else "significant" if role_importance > 0.5 else "supporting"
            
            results["analysis"].append({
                "type": "Entity Importance",
                "text": f"This entity appears to have played a {importance_text} role in timeline {remnant.origin_timeline}.",
                "confidence": remnant.clarity
            })
            
            # Temporal presence
            time_range = random.randint(5, 30)
            results["analysis"].append({
                "type": "Temporal Presence",
                "text": f"Entity was active for approximately {time_range} years around {remnant.estimated_year}.",
                "confidence": remnant.clarity * 0.7
            })
            
            # Connections
            if random.random() < 0.4:
                other_remnants = [r for r in self.remnants.values() if r.remnant_id != remnant_id]
                if other_remnants:
                    related_remnant = random.choice(other_remnants)
                    results["analysis"].append({
                        "type": "Entity Connection",
                        "text": f"Possible connection to {related_remnant.fragment_type.lower()} '{related_remnant.name}'.",
                        "confidence": min(remnant.clarity, related_remnant.clarity) * 0.6
                    })
                    
        elif remnant.fragment_type == "Object":
            # Object analysis
            tech_level = min(1.0, remnant.clarity * random.uniform(0.8, 1.3))
            tech_text = "highly advanced" if tech_level > 0.8 else "advanced" if tech_level > 0.5 else "standard"
            
            results["analysis"].append({
                "type": "Technology Level",
                "text": f"This object represents {tech_text} technology for its era.",
                "confidence": remnant.clarity
            })
            
            # Purpose analysis
            purposes = [
                "temporal manipulation",
                "reality stabilization",
                "quantum field manipulation",
                "paradox resolution",
                "dimensional travel",
                "timeline observation",
                "causal enforcement",
                "probability modification"
            ]
            
            purpose = random.choice(purposes)
            results["analysis"].append({
                "type": "Object Purpose",
                "text": f"The object appears designed for {purpose}.",
                "confidence": remnant.clarity * 0.9
            })
            
            # Origin analysis
            if random.random() < 0.3:
                alt_origin = f"Timeline-{random.randint(1000, 9999)}"
                results["analysis"].append({
                    "type": "Alternative Origin",
                    "text": f"This object may have originated in {alt_origin} rather than {remnant.origin_timeline}.",
                    "confidence": 0.4
                })
                
        else:  # Location
            # Location analysis
            importance = min(1.0, remnant.clarity * random.uniform(0.7, 1.2))
            importance_text = "critical" if importance > 0.8 else "significant" if importance > 0.5 else "minor"
            
            results["analysis"].append({
                "type": "Location Significance",
                "text": f"This location had {importance_text} importance in timeline {remnant.origin_timeline}.",
                "confidence": remnant.clarity
            })
            
            # Purpose analysis
            purposes = [
                "quantum research",
                "temporal stabilization",
                "reality engineering",
                "dimensional exploration",
                "paradox containment",
                "multiverse observation",
                "timeline protection"
            ]
            
            purpose = random.choice(purposes)
            results["analysis"].append({
                "type": "Location Purpose",
                "text": f"The location was primarily used for {purpose}.",
                "confidence": remnant.clarity * 0.8
            })
            
            # Temporal window
            start_year = remnant.estimated_year - random.randint(5, 50)
            end_year = remnant.estimated_year + random.randint(5, 50)
            
            results["analysis"].append({
                "type": "Operational Period",
                "text": f"The location was active from approximately {start_year} to {end_year}.",
                "confidence": remnant.clarity * 0.6
            })
        
        return results
        
    def recover_more_data(self, remnant_id: int, echo_id: int) -> bool:
        """
        Try to recover more data for a remnant from an echo
        
        Returns:
            Success (True) or failure (False)
        """
        remnant = self.remnants.get(remnant_id)
        echo = self.echoes.get(echo_id)
        
        if not remnant or not echo:
            return False
            
        # Extract a data fragment
        fragment = echo.extract_data_fragment()
        if not fragment:
            return False
            
        # Add to the remnant
        remnant.add_data_fragment(fragment["text"], fragment["reliability"])
        return True
        
    def attempt_reconstruction(self, remnant_ids: List[int]) -> Optional[Dict[str, Any]]:
        """
        Attempt to reconstruct a more complete picture from multiple remnants
        
        Returns:
            Reconstruction data or None if failed
        """
        if len(remnant_ids) < 2:
            return None
            
        # Get the remnants
        remnants = []
        for remnant_id in remnant_ids:
            remnant = self.remnants.get(remnant_id)
            if remnant:
                remnants.append(remnant)
                
        if len(remnants) < 2:
            return None
            
        # Check for compatible timeline origins
        origins = set(r.origin_timeline for r in remnants)
        
        # Determine reconstruction success chance
        average_stability = sum(r.stability for r in remnants) / len(remnants)
        average_clarity = sum(r.clarity for r in remnants) / len(remnants)
        compatibility = 1.0 if len(origins) == 1 else 0.6  # Same timeline is better
        
        success_chance = average_stability * average_clarity * compatibility
        
        if random.random() > success_chance:
            return None  # Failed reconstruction
            
        # Create reconstruction data
        timeline_name = list(origins)[0] if len(origins) == 1 else f"Composite-{random.randint(1000, 9999)}"
        
        reconstruction = {
            "success": True,
            "timeline_name": timeline_name,
            "confidence": success_chance,
            "reconstruction_level": min(1.0, average_clarity * compatibility * 1.2),
            "remnant_count": len(remnants),
            "remnant_ids": remnant_ids,
            "summary": "",
            "events": [],
            "entities": [],
            "details": []
        }
        
        # Build reconstruction details
        if "Event" in [r.fragment_type for r in remnants]:
            # Event timeline
            events = [r for r in remnants if r.fragment_type == "Event"]
            for event in events:
                year = event.estimated_year
                reconstruction["events"].append({
                    "year": year,
                    "description": event.name,
                    "clarity": event.clarity
                })
                
        if "Entity" in [r.fragment_type for r in remnants]:
            # Entities
            entities = [r for r in remnants if r.fragment_type == "Entity"]
            for entity in entities:
                reconstruction["entities"].append({
                    "name": entity.name,
                    "description": entity.description,
                    "clarity": entity.clarity
                })
                
        # Create a narrative summary
        fragments = []
        for remnant in remnants:
            if remnant.data_fragments:
                # Use most reliable fragments
                sorted_fragments = sorted(remnant.data_fragments, 
                                        key=lambda f: f["reliability"], 
                                        reverse=True)
                fragments.extend(sorted_fragments[:2])  # Top 2 from each remnant
                
        if fragments:
            # Compile fragments into a narrative
            narrative = []
            
            for category, group in [("Events", reconstruction["events"]), 
                                   ("Key Individuals", reconstruction["entities"])]:
                if group:
                    narrative.append(f"**{category}**:")
                    for item in group:
                        narrative.append(f"- {item['description']}")
                    narrative.append("")
                    
            narrative.append("**Recovered Data Fragments:**")
            for i, fragment in enumerate(fragments[:5]):  # Limit to 5 fragments
                narrative.append(f"{i+1}. {fragment['text']}")
                
            reconstruction["summary"] = "\n".join(narrative)
            
        # Add additional details based on remnant types
        for remnant in remnants:
            if remnant.fragment_type == "Object":
                reconstruction["details"].append({
                    "type": "Artifact",
                    "name": remnant.name,
                    "description": remnant.description
                })
            elif remnant.fragment_type == "Location":
                reconstruction["details"].append({
                    "type": "Key Location",
                    "name": remnant.name,
                    "description": remnant.description
                })
        
        return reconstruction
    
    def get_echoes_report(self) -> str:
        """Generate a report on discovered timeline echoes"""
        if not self.echoes:
            return "No timeline echoes discovered."
            
        report = ["=== QUANTUM ARCHAEOLOGY: TIMELINE ECHOES ==="]
        report.append(f"Total discovered echoes: {len(self.echoes)}")
        
        # Count echoes by strength
        strong = 0
        moderate = 0
        weak = 0
        
        for echo in self.echoes.values():
            resonance = echo.get_current_resonance()
            if resonance > 0.5:
                strong += 1
            elif resonance > 0.2:
                moderate += 1
            else:
                weak += 1
                
        report.append(f"Strong echoes: {strong}")
        report.append(f"Moderate echoes: {moderate}")
        report.append(f"Weak echoes: {weak}")
        
        # List notable echoes
        if strong > 0:
            report.append("\nNotable Timeline Echoes:")
            for echo in sorted(self.echoes.values(), 
                              key=lambda e: e.get_current_resonance(), 
                              reverse=True)[:3]:  # Top 3
                resonance = echo.get_current_resonance()
                if resonance > 0.3:  # Only show reasonably strong ones
                    report.append(f"- {echo.timeline_name}: Resonance {resonance:.2f}, {len(echo.events)} events")
                    
                    # Show a sample event
                    if echo.events:
                        clearest_event = max(echo.events, key=lambda e: e["clarity"])
                        report.append(f"  Sample event ({clearest_event['year']}): {clearest_event['description']}")
        
        return "\n".join(report)
    
    def get_remnants_report(self) -> str:
        """Generate a report on recovered quantum remnants"""
        if not self.remnants:
            return "No quantum remnants recovered."
            
        report = ["=== QUANTUM ARCHAEOLOGY: RECOVERED REMNANTS ==="]
        report.append(f"Total recovered remnants: {len(self.remnants)}")
        
        # Count by type
        type_counts = {}
        for remnant in self.remnants.values():
            frag_type = remnant.fragment_type
            type_counts[frag_type] = type_counts.get(frag_type, 0) + 1
            
        report.append("\nRemnant types:")
        for frag_type, count in sorted(type_counts.items()):
            report.append(f"- {frag_type}: {count}")
            
        # Most reconstructed remnants
        well_reconstructed = [r for r in self.remnants.values() if r.reconstruction_level > 0.5]
        if well_reconstructed:
            report.append("\nBest reconstructed remnants:")
            for remnant in sorted(well_reconstructed, 
                                key=lambda r: r.reconstruction_level, 
                                reverse=True)[:3]:  # Top 3
                recon = f"{remnant.reconstruction_level*100:.0f}%"
                report.append(f"- {remnant.name} ({remnant.fragment_type}): {recon} reconstructed")
                
                # Show a sample data fragment
                if remnant.data_fragments:
                    best_fragment = max(remnant.data_fragments, key=lambda f: f["reliability"])
                    report.append(f"  Sample data: {best_fragment['text']}")
        
        return "\n".join(report)


def run_quantum_archaeology_demo(multiverse=None):
    """Run a demonstration of the quantum archaeology system"""
    print("=== Quantum Archaeology Demonstration ===")
    
    # Create archaeology system
    archaeology = QuantumArchaeology(multiverse)
    
    # Scan for timeline echoes
    print("\nScanning for timeline echoes...")
    echoes = archaeology.scan_for_echoes(scan_power=0.7)
    
    for echo in echoes:
        print(f"Discovered: {echo}")
    
    if not echoes:
        print("No echoes discovered in this scan.")
        # Create some manually for the demo
        echo = TimelineEcho(archaeology.next_echo_id, "Atlantis-Prime")
        archaeology.next_echo_id += 1
        archaeology.echoes[echo.echo_id] = echo
        echoes = [echo]
        print(f"Manually created echo for demonstration: {echo}")
    
    # Extract remnants
    print("\nExtracting quantum remnants from echoes...")
    remnants = []
    
    for echo in echoes:
        remnant = archaeology.extract_remnant_from_echo(echo.echo_id)
        if remnant:
            remnants.append(remnant)
            print(f"Extracted: {remnant}")
    
    if not remnants:
        print("Failed to extract any remnants.")
        # Create manually for the demo
        remnant = QuantumRemnant(archaeology.next_remnant_id, echoes[0].timeline_name)
        archaeology.next_remnant_id += 1
        archaeology.remnants[remnant.remnant_id] = remnant
        remnants = [remnant]
        print(f"Manually created remnant for demonstration: {remnant}")
    
    # Recover more data
    if echoes and remnants:
        print("\nAttempting to recover more data...")
        for _ in range(3):  # Try a few times
            for remnant in remnants:
                echo = random.choice(list(archaeology.echoes.values()))
                success = archaeology.recover_more_data(remnant.remnant_id, echo.echo_id)
                if success:
                    fragment = remnant.data_fragments[-1]
                    print(f"Recovered data for {remnant.name}: {fragment['text']}")
    
    # Analyze a remnant
    if remnants:
        print("\nAnalyzing a quantum remnant...")
        remnant = random.choice(remnants)
        analysis = archaeology.analyze_remnant(remnant.remnant_id)
        
        if analysis["success"]:
            print(f"Analysis of {remnant.name} ({remnant.fragment_type}):")
            for insight in analysis["analysis"]:
                confidence = f"{insight['confidence']*100:.0f}%"
                print(f"- {insight['type']} [{confidence}]: {insight['text']}")
    
    # Attempt reconstruction if multiple remnants
    if len(remnants) >= 2:
        print("\nAttempting composite reconstruction...")
        remnant_ids = [r.remnant_id for r in remnants]
        reconstruction = archaeology.attempt_reconstruction(remnant_ids)
        
        if reconstruction and reconstruction["success"]:
            print(f"Successfully reconstructed data for {reconstruction['timeline_name']}!")
            print(f"Confidence: {reconstruction['confidence']:.2f}")
            print(f"Reconstruction level: {reconstruction['reconstruction_level']:.2f}")
            print("\nReconstruction Summary:")
            print(reconstruction["summary"])
        else:
            print("Reconstruction attempt failed. Insufficient compatible data.")
    
    # Generate reports
    print("\n" + archaeology.get_echoes_report())
    print("\n" + archaeology.get_remnants_report())
    
    return archaeology


if __name__ == "__main__":
    run_quantum_archaeology_demo()
