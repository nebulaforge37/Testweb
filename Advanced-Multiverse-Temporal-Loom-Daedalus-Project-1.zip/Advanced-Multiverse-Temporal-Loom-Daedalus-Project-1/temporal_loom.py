
"""
Temporal Loom Control System
This module implements the Temporal Loom that controls and weaves the fabric of time
across the multiverse.
"""

import random
import time
import math
from typing import List, Dict, Optional, Tuple, Any, Union
from sacred_timeline import SacredTimeline, TemporalRadiation

class TemporalThread:
    """Represents a thread in the fabric of time that can be manipulated by the Loom"""
    
    def __init__(self, thread_id: str, origin_timeline: str, target_timeline: str = None):
        """
        Initialize a temporal thread
        
        Args:
            thread_id: Unique identifier for this thread
            origin_timeline: Origin timeline name
            target_timeline: Target timeline (if different from origin)
        """
        self.thread_id = thread_id
        self.origin_timeline = origin_timeline
        self.target_timeline = target_timeline or origin_timeline
        self.tension = random.uniform(0.3, 0.7)  # Thread tension 
        self.integrity = random.uniform(0.7, 0.9)  # Thread structural integrity
        self.quantum_resonance = random.uniform(0.4, 0.6)  # Thread's quantum properties
        self.created_at = time.time()
        self.last_adjusted = time.time()
        self.color = random.choice(["gold", "silver", "red", "blue", "green", "purple"])
        self.thickness = random.uniform(0.5, 2.0)  # Thread thickness
        
    def adjust_tension(self, amount: float) -> float:
        """
        Adjust the tension of this thread
        
        Args:
            amount: Amount to adjust tension by (-1.0 to 1.0)
            
        Returns:
            New tension value
        """
        old_tension = self.tension
        self.tension = max(0.1, min(0.9, self.tension + amount))
        self.last_adjusted = time.time()
        
        # Adjusting tension too much can damage integrity
        if abs(amount) > 0.3:
            damage = abs(amount) * 0.2
            self.integrity = max(0.1, self.integrity - damage)
        
        return self.tension
    
    def calculate_resonance(self) -> float:
        """Calculate the current quantum resonance of the thread"""
        age_factor = min(1.0, (time.time() - self.created_at) / (86400))  # Age in days
        tension_factor = 1.0 - abs(self.tension - 0.5) * 2  # Optimal tension is 0.5
        
        return self.quantum_resonance * (1 - (age_factor * 0.1)) * tension_factor
    
    def is_connecting_timelines(self) -> bool:
        """Check if this thread connects different timelines"""
        return self.origin_timeline != self.target_timeline
    
    def get_status(self) -> Dict[str, Any]:
        """Get the current status of this thread"""
        return {
            "thread_id": self.thread_id,
            "origin": self.origin_timeline,
            "target": self.target_timeline,
            "tension": self.tension,
            "integrity": self.integrity,
            "resonance": self.calculate_resonance(),
            "color": self.color,
            "thickness": self.thickness,
            "connecting_timelines": self.is_connecting_timelines()
        }
    
    def __str__(self) -> str:
        connector = "->" if self.is_connecting_timelines() else ""
        target = f"{connector}{self.target_timeline}" if self.is_connecting_timelines() else ""
        return f"{self.color} Thread #{self.thread_id} ({self.origin_timeline}{target}): {self.tension:.2f} tension, {self.integrity:.2f} integrity"


class TemporalLoom:
    """Main Temporal Loom control system that manages the fabric of time"""
    
    def __init__(self, sacred_timeline: Optional[SacredTimeline] = None):
        """
        Initialize the Temporal Loom
        
        Args:
            sacred_timeline: Optional connection to Sacred Timeline system
        """
        self.sacred_timeline = sacred_timeline
        self.threads = {}
        self.patterns = {}
        self.active_weaves = []
        self.thread_count = 0
        self.pattern_count = 0
        self.weave_count = 0
        self.loom_integrity = 1.0
        self.last_maintenance = time.time()
        self.energy_level = 0.8
        self.radiation_threshold = 0.3
        self.warning_log = []
        self.archived_threads = []
        self.operation_log = []
        
    def create_thread(self, origin_timeline: str, target_timeline: str = None) -> TemporalThread:
        """
        Create a new temporal thread
        
        Args:
            origin_timeline: Origin timeline name
            target_timeline: Optional target timeline
            
        Returns:
            Newly created thread
        """
        self.thread_count += 1
        thread_id = f"T{self.thread_count:04d}"
        
        thread = TemporalThread(thread_id, origin_timeline, target_timeline)
        self.threads[thread_id] = thread
        
        self.log_operation("thread_creation", f"Created thread {thread_id} from {origin_timeline}")
        return thread
    
    def create_pattern(self, name: str, thread_ids: List[str]) -> Dict[str, Any]:
        """
        Create a pattern from multiple threads
        
        Args:
            name: Pattern name
            thread_ids: List of thread IDs to include
            
        Returns:
            The created pattern
        """
        # Verify all threads exist
        valid_threads = [tid for tid in thread_ids if tid in self.threads]
        
        if not valid_threads:
            return None
            
        self.pattern_count += 1
        pattern_id = f"P{self.pattern_count:04d}"
        
        # Calculate resonant frequency based on thread properties
        resonance_values = [self.threads[tid].calculate_resonance() for tid in valid_threads]
        avg_resonance = sum(resonance_values) / len(resonance_values)
        
        # Calculate pattern strength based on thread integrity
        integrity_values = [self.threads[tid].integrity for tid in valid_threads]
        avg_integrity = sum(integrity_values) / len(integrity_values)
        
        pattern = {
            "pattern_id": pattern_id,
            "name": name,
            "thread_ids": valid_threads,
            "created_at": time.time(),
            "resonance": avg_resonance,
            "integrity": avg_integrity,
            "complexity": len(valid_threads),
            "stability": avg_integrity * (1 - (0.05 * len(valid_threads))),  # More complex = less stable
            "active": False
        }
        
        self.patterns[pattern_id] = pattern
        self.log_operation("pattern_creation", f"Created pattern {name} ({pattern_id}) with {len(valid_threads)} threads")
        
        return pattern
    
    def start_weaving(self, pattern_id: str) -> Dict[str, Any]:
        """
        Start weaving a pattern into the fabric of time
        
        Args:
            pattern_id: ID of the pattern to weave
            
        Returns:
            Weave information
        """
        pattern = self.patterns.get(pattern_id)
        if not pattern:
            return None
            
        if pattern["active"]:
            return None  # Already active
            
        # Check if we have enough energy
        required_energy = 0.1 * pattern["complexity"]
        if self.energy_level < required_energy:
            self.log_warning(
                f"Insufficient energy to weave pattern {pattern['name']}. " +
                f"Need {required_energy:.2f}, have {self.energy_level:.2f}."
            )
            return None
            
        self.weave_count += 1
        weave_id = f"W{self.weave_count:04d}"
        
        # Create the weave
        weave = {
            "weave_id": weave_id,
            "pattern_id": pattern_id,
            "started_at": time.time(),
            "radiation": None,
            "completion": 0.0,
            "status": "Initializing",
            "energy_consumed": 0.0,
            "estimated_duration": pattern["complexity"] * random.uniform(10, 30)
        }
        
        # Reduce energy
        self.energy_level -= required_energy
        
        # Set pattern to active
        pattern["active"] = True
        
        # Add to active weaves
        self.active_weaves.append(weave)
        
        # Adjust thread tension for all involved threads
        for thread_id in pattern["thread_ids"]:
            thread = self.threads.get(thread_id)
            if thread:
                # Slightly increase tension when weaving starts
                thread.adjust_tension(random.uniform(0.05, 0.15))
        
        self.log_operation("weave_start", f"Started weaving pattern {pattern['name']} ({pattern_id})")
        
        return weave
    
    def update_weaving_progress(self):
        """Update the progress of all active weaves"""
        updated_weaves = []
        completed_weaves = []
        
        for weave in self.active_weaves:
            # Calculate progress based on time
            elapsed = time.time() - weave["started_at"]
            progress = min(1.0, elapsed / weave["estimated_duration"])
            weave["completion"] = progress
            
            # Update status
            if progress < 0.1:
                weave["status"] = "Initializing"
            elif progress < 0.5:
                weave["status"] = "Weaving"
            elif progress < 0.9:
                weave["status"] = "Stabilizing"
            else:
                weave["status"] = "Completing"
                
            # Update energy consumed
            pattern = self.patterns.get(weave["pattern_id"])
            if pattern:
                energy_rate = 0.01 * pattern["complexity"]
                energy_increment = energy_rate * min(0.2, elapsed - weave.get("last_update", 0))
                weave["energy_consumed"] = weave.get("energy_consumed", 0) + energy_increment
                
            # Record update time
            weave["last_update"] = elapsed
            
            # Check for completion
            if progress >= 1.0:
                weave["status"] = "Completed"
                self.complete_weave(weave)
                completed_weaves.append(weave)
            else:
                updated_weaves.append(weave)
        
        # Remove completed weaves from active list
        self.active_weaves = [w for w in self.active_weaves if w not in completed_weaves]
        
        return updated_weaves, completed_weaves
    
    def complete_weave(self, weave: Dict[str, Any]):
        """Complete a weaving process"""
        pattern_id = weave["pattern_id"]
        pattern = self.patterns.get(pattern_id)
        
        if not pattern:
            return
            
        # Mark pattern as inactive
        pattern["active"] = False
        
        # Generate radiation
        radiation_intensity = pattern["complexity"] * random.uniform(0.05, 0.15)
        radiation = TemporalRadiation(
            radiation_intensity,
            decay_rate=0.1,
            isotope_signature=f"Loom-{pattern['name']}-{pattern_id}"
        )
        
        weave["radiation"] = radiation
        
        # Check radiation levels
        if radiation_intensity > self.radiation_threshold:
            self.log_warning(
                f"High radiation detected from completed weave {weave['weave_id']}. " +
                f"Intensity: {radiation_intensity:.2f}"
            )
            
            # If connected to Sacred Timeline, add warning
            if self.sacred_timeline:
                affected_timelines = set()
                for thread_id in pattern["thread_ids"]:
                    thread = self.threads.get(thread_id)
                    if thread:
                        affected_timelines.add(thread.origin_timeline)
                        if thread.target_timeline != thread.origin_timeline:
                            affected_timelines.add(thread.target_timeline)
                
                for timeline in affected_timelines:
                    self.sacred_timeline.add_red_line_warning(
                        timeline,
                        f"High temporal radiation detected from Loom weaving pattern {pattern['name']}"
                    )
        
        # Reset thread tensions slightly
        for thread_id in pattern["thread_ids"]:
            thread = self.threads.get(thread_id)
            if thread:
                thread.adjust_tension(-0.1)
                
        # Log completion
        self.log_operation(
            "weave_complete", 
            f"Completed weaving pattern {pattern['name']} ({pattern_id}). " +
            f"Radiation: {radiation_intensity:.2f}"
        )
    
    def log_warning(self, warning: str):
        """Log a warning message"""
        self.warning_log.append({
            "timestamp": time.time(),
            "warning": warning
        })
    
    def log_operation(self, operation_type: str, description: str):
        """Log an operation in the system"""
        self.operation_log.append({
            "timestamp": time.time(),
            "type": operation_type,
            "description": description
        })
    
    def perform_maintenance(self) -> Dict[str, Any]:
        """Perform maintenance on the Loom system"""
        # Calculate time since last maintenance
        time_since = time.time() - self.last_maintenance
        days_since = time_since / 86400
        
        # More frequent maintenance keeps integrity higher
        integrity_loss = 0.01 * days_since
        self.loom_integrity = max(0.5, min(1.0, self.loom_integrity - integrity_loss))
        
        # Calculate repair amount
        repair_amount = 0.2 + random.uniform(0, 0.1)
        new_integrity = min(1.0, self.loom_integrity + repair_amount)
        improvement = new_integrity - self.loom_integrity
        
        # Apply repair
        self.loom_integrity = new_integrity
        self.last_maintenance = time.time()
        
        # Refresh energy
        energy_boost = random.uniform(0.1, 0.3)
        self.energy_level = min(1.0, self.energy_level + energy_boost)
        
        # Repair damaged threads
        repaired_threads = []
        for thread_id, thread in self.threads.items():
            if thread.integrity < 0.5:
                old_integrity = thread.integrity
                thread.integrity = min(1.0, thread.integrity + random.uniform(0.2, 0.4))
                repaired_threads.append({
                    "thread_id": thread_id,
                    "old_integrity": old_integrity,
                    "new_integrity": thread.integrity
                })
                
        self.log_operation(
            "maintenance", 
            f"Performed maintenance. Integrity improved by {improvement:.2f}. " +
            f"Repaired {len(repaired_threads)} threads."
        )
        
        return {
            "new_integrity": self.loom_integrity,
            "improvement": improvement,
            "energy_boost": energy_boost,
            "repaired_threads": repaired_threads
        }
    
    def archive_thread(self, thread_id: str) -> bool:
        """Archive a thread that is no longer needed"""
        thread = self.threads.get(thread_id)
        if not thread:
            return False
            
        # Check if thread is used in any active patterns
        for pattern_id, pattern in self.patterns.items():
            if pattern["active"] and thread_id in pattern["thread_ids"]:
                self.log_warning(f"Cannot archive thread {thread_id} that is in active pattern {pattern_id}")
                return False
                
        # Move to archived threads
        self.archived_threads.append({
            "thread": thread,
            "archived_at": time.time()
        })
        
        # Remove from active threads
        del self.threads[thread_id]
        
        self.log_operation("thread_archive", f"Archived thread {thread_id}")
        return True
    
    def get_status_report(self) -> str:
        """Generate a status report for the Temporal Loom"""
        # Update weaving progress
        self.update_weaving_progress()
        
        report = ["=== TEMPORAL LOOM STATUS REPORT ==="]
        
        # Overall status
        report.append(f"Loom Integrity: {self.loom_integrity:.2f}")
        report.append(f"Energy Level: {self.energy_level:.2f}")
        
        # Thread statistics
        active_threads = len(self.threads)
        archived_threads = len(self.archived_threads)
        report.append(f"Active Threads: {active_threads}")
        report.append(f"Archived Threads: {archived_threads}")
        
        # Pattern statistics
        active_patterns = sum(1 for p in self.patterns.values() if p["active"])
        report.append(f"Patterns: {len(self.patterns)} ({active_patterns} active)")
        
        # Active weaves
        if self.active_weaves:
            report.append("\nActive Weaving Operations:")
            for weave in self.active_weaves:
                pattern = self.patterns.get(weave["pattern_id"], {"name": "Unknown"})
                report.append(
                    f"- {weave['weave_id']}: {pattern['name']} - " +
                    f"{weave['status']} ({weave['completion']*100:.0f}%)"
                )
        
        # Recent warnings
        recent_warnings = [w for w in self.warning_log[-5:]]
        if recent_warnings:
            report.append("\nRecent Warnings:")
            for warning in recent_warnings:
                report.append(f"- {warning['warning']}")
                
        # Thread integrity issues
        damaged_threads = [t for t in self.threads.values() if t.integrity < 0.5]
        if damaged_threads:
            report.append("\nDamaged Threads:")
            for thread in damaged_threads[:3]:  # Show top 3
                report.append(f"- {thread.thread_id}: {thread.integrity:.2f} integrity")
                
        # Maintenance status
        days_since = (time.time() - self.last_maintenance) / 86400
        if days_since > 1:
            report.append(f"\nMaintenance: {days_since:.1f} days since last maintenance")
            if days_since > 3:
                report.append("WARNING: Maintenance overdue!")
        
        return "\n".join(report)
    
    def __str__(self) -> str:
        active_patterns = sum(1 for p in self.patterns.values() if p["active"])
        return f"Temporal Loom: {self.loom_integrity:.2f} integrity, {len(self.threads)} threads, {active_patterns} active patterns"


def run_temporal_loom_demo():
    """Run a demonstration of the Temporal Loom control system"""
    print("=== Temporal Loom Control System Demonstration ===")
    
    # Create a Sacred Timeline for the demo
    sacred = SacredTimeline("Alpha Sacred Timeline", 0.9)
    
    # Create the Temporal Loom
    loom = TemporalLoom(sacred)
    
    print(f"Created: {loom}")
    
    # Create some threads
    print("\nCreating temporal threads...")
    threads = []
    
    # Create threads from various timelines
    timelines = ["Alpha Prime", "Beta Variant", "Delta Nexus", "Sacred Timeline"]
    
    for i in range(10):
        origin = random.choice(timelines)
        # Some threads connect timelines, others stay within one
        target = random.choice(timelines) if random.random() < 0.3 else origin
        thread = loom.create_thread(origin, target)
        threads.append(thread)
        print(f"Created {thread}")
    
    # Create some patterns
    print("\nCreating temporal patterns...")
    
    # Basic pattern with 3 threads
    pattern1_threads = [t.thread_id for t in random.sample(threads, 3)]
    pattern1 = loom.create_pattern("Triadic Stability", pattern1_threads)
    print(f"Created pattern {pattern1['name']} with {len(pattern1['thread_ids'])} threads")
    
    # Complex pattern with 5 threads
    pattern2_threads = [t.thread_id for t in random.sample(threads, 5)]
    pattern2 = loom.create_pattern("Quantum Pentagram", pattern2_threads)
    print(f"Created pattern {pattern2['name']} with {len(pattern2['thread_ids'])} threads")
    
    # Start weaving one pattern
    print("\nStarting weaving process...")
    weave = loom.start_weaving(pattern1["pattern_id"])
    if weave:
        print(f"Started weaving {pattern1['name']} - estimated duration: {weave['estimated_duration']:.1f}s")
    
    # Simulate time passing and update progress
    print("\nSimulating weaving progress...")
    
    # Speed up time for demo purposes
    weave["started_at"] = time.time() - (weave["estimated_duration"] * 0.7)
    
    for i in range(3):
        # Update progress
        updated, completed = loom.update_weaving_progress()
        
        # Show status
        for w in updated:
            pattern = loom.patterns.get(w["pattern_id"])
            print(f"Weave {w['weave_id']} ({pattern['name']}): {w['status']} - {w['completion']*100:.0f}% complete")
            
        # Simulate more time passing
        if updated:
            updated[0]["started_at"] -= weave["estimated_duration"] * 0.2
            
        time.sleep(0.5)  # Small real delay
    
    # Try to archive a thread
    if threads:
        thread_to_archive = threads[0].thread_id
        print(f"\nAttempting to archive thread {thread_to_archive}...")
        result = loom.archive_thread(thread_to_archive)
        print(f"Archive result: {result}")
    
    # Perform maintenance
    print("\nPerforming loom maintenance...")
    maintenance = loom.perform_maintenance()
    print(f"Maintenance improved integrity by {maintenance['improvement']:.2f}")
    print(f"Repaired {len(maintenance['repaired_threads'])} threads")
    
    # Show final status
    print("\n" + loom.get_status_report())
    
    return loom


if __name__ == "__main__":
    run_temporal_loom_demo()
