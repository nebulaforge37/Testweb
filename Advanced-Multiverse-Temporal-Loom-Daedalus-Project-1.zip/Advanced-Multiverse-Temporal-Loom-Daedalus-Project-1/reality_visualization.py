
"""
Reality Visualization Module
This module provides graphical visualization tools for multiverse structures,
timeline events, and quantum relationships between realities.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, Canvas
import random
import math
from typing import Dict, List, Tuple, Optional, Any

# Try to import optional visualization enhancements
try:
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

class RealityMapCanvas:
    """Canvas for displaying multiverse reality maps with interactive elements"""
    
    def __init__(self, parent, width=800, height=600):
        """Initialize the reality map canvas"""
        self.parent = parent
        self.width = width
        self.height = height
        
        # Create canvas
        self.canvas = Canvas(parent, width=width, height=height, bg='#0F182B')
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Tracking variables
        self.dimensions = {}  # dimension_id -> {'x', 'y', 'radius', 'color', 'obj_id'}
        self.realities = {}   # (dimension_id, reality_id) -> {'x', 'y', 'radius', 'color', 'obj_id'}
        self.connections = [] # [(from_id, to_id, line_id, strength)]
        self.travelers = {}   # traveler_name -> {'x', 'y', 'obj_id', 'label_id', 'current_dim', 'current_reality'}
        self.selected = None
        self.hover_text_id = None
        
        # Set up event bindings
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<Button-1>", self.on_click)
        
        # Animation variables
        self.is_animating = False
        self.animation_targets = {}
        
    def clear(self):
        """Clear all elements from the canvas"""
        self.canvas.delete("all")
        self.dimensions = {}
        self.realities = {}
        self.connections = []
        self.travelers = {}
        self.selected = None
        self.hover_text_id = None
        
    def add_dimension(self, dimension_id, name, stability, x=None, y=None):
        """Add a quantum dimension to the map"""
        if x is None:
            x = random.randint(100, self.width - 100)
        if y is None:
            y = random.randint(100, self.height - 100)
            
        # Size based on number of realities (will be updated when realities are added)
        radius = 50
        
        # Color based on stability
        r = min(255, int(255 * (1.0 - stability)))
        g = min(255, int(200 * stability))
        b = 100 + min(155, int(155 * stability))
        color = f"#{r:02x}{g:02x}{b:02x}"
        
        # Create the circle
        obj_id = self.canvas.create_oval(
            x - radius, y - radius, x + radius, y + radius, 
            fill=color, outline="white", width=2, tags=f"dim_{dimension_id}"
        )
        
        # Add text label
        label_id = self.canvas.create_text(
            x, y, text=f"D{dimension_id}: {name}", fill="white", 
            font=("Arial", 12), tags=f"dim_label_{dimension_id}"
        )
        
        # Store the dimension info
        self.dimensions[dimension_id] = {
            'x': x, 'y': y, 'radius': radius, 'color': color, 'obj_id': obj_id, 
            'label_id': label_id, 'name': name, 'stability': stability,
            'realities': []
        }
        
        return obj_id
        
    def add_reality(self, dimension_id, reality_id, name, consistency, quantum_entanglement=0.0):
        """Add a reality to a dimension"""
        if dimension_id not in self.dimensions:
            return None
            
        dim = self.dimensions[dimension_id]
        
        # Angle around the dimension
        num_realities = len(dim['realities'])
        angle = (num_realities * (2 * math.pi / max(1, num_realities + 1)))
        
        # Position relative to dimension
        distance = dim['radius'] * 1.5
        x = dim['x'] + distance * math.cos(angle)
        y = dim['y'] + distance * math.sin(angle)
        
        # Size based on consistency
        radius = 20 + int(consistency * 15)
        
        # Color based on quantum entanglement
        r = min(255, int(100 + quantum_entanglement * 155))
        g = min(255, int(100 + consistency * 155))
        b = min(255, int(200 + quantum_entanglement * 55))
        color = f"#{r:02x}{g:02x}{b:02x}"
        
        # Create the circle
        obj_id = self.canvas.create_oval(
            x - radius, y - radius, x + radius, y + radius, 
            fill=color, outline="white", width=1, tags=f"reality_{dimension_id}_{reality_id}"
        )
        
        # Add text label
        label = f"R{reality_id}"
        label_id = self.canvas.create_text(
            x, y, text=label, fill="white", 
            font=("Arial", 10), tags=f"reality_label_{dimension_id}_{reality_id}"
        )
        
        # Store the reality info
        reality_key = (dimension_id, reality_id)
        self.realities[reality_key] = {
            'x': x, 'y': y, 'radius': radius, 'color': color, 'obj_id': obj_id,
            'label_id': label_id, 'name': name, 'consistency': consistency,
            'quantum_entanglement': quantum_entanglement, 'dimension_id': dimension_id
        }
        
        # Add to dimension's reality list
        dim['realities'].append(reality_id)
        
        # Connect to its parent dimension
        line_id = self.canvas.create_line(
            dim['x'], dim['y'], x, y,
            fill="white", width=1, dash=(3, 3),
            tags=f"dim_reality_connection_{dimension_id}_{reality_id}"
        )
        
        self.connections.append(((dimension_id, None), reality_key, line_id, 1.0))
        
        return obj_id
    
    def connect_dimensions(self, from_id, to_id, strength=1.0, gate_type="standard"):
        """Connect two dimensions with a gate"""
        if from_id not in self.dimensions or to_id not in self.dimensions:
            return None
            
        from_dim = self.dimensions[from_id]
        to_dim = self.dimensions[to_id]
        
        # Determine line style based on gate type
        if gate_type == "quantum_entangled":
            line_color = "#FF00FF"  # Magenta for quantum entanglement
            line_width = 2
            line_dash = (5, 3)
        elif gate_type == "unstable":
            line_color = "#FF4500"  # OrangeRed for unstable connections
            line_width = 2
            line_dash = (8, 4, 2, 4)
        else:  # standard
            line_color = "#4080FF"  # Blue for normal connections
            line_width = 2
            line_dash = None
            
        # Adjust color alpha (transparency) based on strength
        alpha = int(min(255, max(40, strength * 255)))
        line_color = line_color[0:7] + f"{alpha:02x}"
            
        # Create the connection line
        line_id = self.canvas.create_line(
            from_dim['x'], from_dim['y'], to_dim['x'], to_dim['y'],
            fill=line_color, width=line_width, dash=line_dash,
            tags=f"dim_connection_{from_id}_{to_id}"
        )
        
        self.connections.append(((from_id, None), (to_id, None), line_id, strength))
        
        return line_id
    
    def connect_realities(self, from_dim, from_reality, to_dim, to_reality, strength=1.0, connection_type="standard"):
        """Connect two realities"""
        from_key = (from_dim, from_reality)
        to_key = (to_dim, to_reality)
        
        if from_key not in self.realities or to_key not in self.realities:
            return None
            
        from_real = self.realities[from_key]
        to_real = self.realities[to_key]
        
        # Determine line style based on connection type
        if connection_type == "quantum_entangled":
            line_color = "#FF00FF"  # Magenta for quantum entanglement
            line_width = 1
            line_dash = (5, 3)
        elif connection_type == "temporal_bridge":
            line_color = "#00FFFF"  # Cyan for temporal bridges
            line_width = 1
            line_dash = (4, 2)
        elif connection_type == "reality_breach":
            line_color = "#FFFF00"  # Yellow for reality breach
            line_width = 1
            line_dash = (7, 3, 1, 3)
        else:  # standard
            line_color = "#40FF80"  # Green for normal connections
            line_width = 1
            line_dash = None
            
        # Adjust color alpha (transparency) based on strength
        alpha = int(min(255, max(40, strength * 255)))
        line_color = line_color[0:7] + f"{alpha:02x}"
            
        # Create the connection line
        line_id = self.canvas.create_line(
            from_real['x'], from_real['y'], to_real['x'], to_real['y'],
            fill=line_color, width=line_width, dash=line_dash,
            tags=f"reality_connection_{from_dim}_{from_reality}_{to_dim}_{to_reality}"
        )
        
        self.connections.append((from_key, to_key, line_id, strength))
        
        return line_id
    
    def add_traveler(self, name, current_dim, current_reality=None):
        """Add a reality traveler to the map"""
        # Find the traveler's current location
        if current_reality is not None:
            key = (current_dim, current_reality)
            if key in self.realities:
                loc = self.realities[key]
                x, y = loc['x'], loc['y']
            else:
                return None
        else:
            if current_dim in self.dimensions:
                loc = self.dimensions[current_dim]
                x, y = loc['x'], loc['y']
            else:
                return None
                
        # Create the traveler representation (a small triangle)
        size = 10
        obj_id = self.canvas.create_polygon(
            x, y - size, x - size, y + size, x + size, y + size,
            fill="#FFFF00", outline="black", width=1,
            tags=f"traveler_{name}"
        )
        
        # Add traveler label
        label_id = self.canvas.create_text(
            x, y + size + 10, text=name, fill="#FFFF00",
            font=("Arial", 8), tags=f"traveler_label_{name}"
        )
        
        # Store traveler info
        self.travelers[name] = {
            'x': x, 'y': y, 'obj_id': obj_id, 'label_id': label_id,
            'current_dim': current_dim, 'current_reality': current_reality
        }
        
        # Ensure traveler is on top
        self.canvas.tag_raise(obj_id)
        self.canvas.tag_raise(label_id)
        
        return obj_id
    
    def move_traveler(self, name, new_dim, new_reality=None, animate=True):
        """Move a traveler to a new location"""
        if name not in self.travelers:
            return False
            
        # Find the target location
        if new_reality is not None:
            key = (new_dim, new_reality)
            if key in self.realities:
                target = self.realities[key]
                target_x, target_y = target['x'], target['y']
            else:
                return False
        else:
            if new_dim in self.dimensions:
                target = self.dimensions[new_dim]
                target_x, target_y = target['x'], target['y']
            else:
                return False
                
        traveler = self.travelers[name]
        
        if animate:
            # Set up animation
            self.animation_targets[name] = {
                'start_x': traveler['x'], 'start_y': traveler['y'],
                'end_x': target_x, 'end_y': target_y,
                'progress': 0.0, 'duration': 20,  # 20 frames
                'obj_id': traveler['obj_id'], 'label_id': traveler['label_id']
            }
            
            if not self.is_animating:
                self.is_animating = True
                self.animate()
        else:
            # Move instantly
            dx = target_x - traveler['x']
            dy = target_y - traveler['y']
            self.canvas.move(traveler['obj_id'], dx, dy)
            self.canvas.move(traveler['label_id'], dx, dy)
            
            # Update traveler info
            traveler['x'] = target_x
            traveler['y'] = target_y
            traveler['current_dim'] = new_dim
            traveler['current_reality'] = new_reality
            
        return True
    
    def animate(self):
        """Animate active travelers"""
        still_animating = False
        
        for name, anim in list(self.animation_targets.items()):
            # Update progress
            anim['progress'] += 1.0 / anim['duration']
            
            if anim['progress'] >= 1.0:
                # Animation complete
                traveler = self.travelers[name]
                
                # Move to final position
                dx = anim['end_x'] - traveler['x']
                dy = anim['end_y'] - traveler['y']
                self.canvas.move(anim['obj_id'], dx, dy)
                self.canvas.move(anim['label_id'], dx, dy)
                
                # Update traveler info
                traveler['x'] = anim['end_x']
                traveler['y'] = anim['end_y']
                
                # Update dimension/reality
                for dim_id, dim in self.dimensions.items():
                    if abs(dim['x'] - anim['end_x']) < dim['radius'] and abs(dim['y'] - anim['end_y']) < dim['radius']:
                        traveler['current_dim'] = dim_id
                        traveler['current_reality'] = None
                        break
                        
                for (dim_id, reality_id), reality in self.realities.items():
                    if abs(reality['x'] - anim['end_x']) < reality['radius'] and abs(reality['y'] - anim['end_y']) < reality['radius']:
                        traveler['current_dim'] = dim_id
                        traveler['current_reality'] = reality_id
                        break
                
                # Remove from animation targets
                del self.animation_targets[name]
            else:
                # Continue animation
                still_animating = True
                
                # Calculate current position
                t = anim['progress']  # 0.0 to 1.0
                
                # Use ease-in-out function
                t = 0.5 - 0.5 * math.cos(math.pi * t)
                
                current_x = anim['start_x'] + (anim['end_x'] - anim['start_x']) * t
                current_y = anim['start_y'] + (anim['end_y'] - anim['start_y']) * t
                
                traveler = self.travelers[name]
                
                # Move to new position
                dx = current_x - traveler['x']
                dy = current_y - traveler['y']
                self.canvas.move(anim['obj_id'], dx, dy)
                self.canvas.move(anim['label_id'], dx, dy)
                
                # Update traveler info
                traveler['x'] = current_x
                traveler['y'] = current_y
        
        # Continue animation if needed
        if still_animating:
            self.parent.after(30, self.animate)  # ~30fps
        else:
            self.is_animating = False
    
    def on_mouse_move(self, event):
        """Handle mouse movement for hover effects"""
        # Clear previous hover text
        if self.hover_text_id:
            self.canvas.delete(self.hover_text_id)
            self.hover_text_id = None
            
        # Check for object under mouse
        item_id = self.canvas.find_closest(event.x, event.y)
        if not item_id:
            return
            
        item_id = item_id[0]
        tags = self.canvas.gettags(item_id)
        
        # Show information for dimensions
        for tag in tags:
            if tag.startswith("dim_") and not tag.startswith("dim_label_") and not tag.startswith("dim_reality_"):
                dim_id = int(tag[4:])
                if dim_id in self.dimensions:
                    dim = self.dimensions[dim_id]
                    info = f"Dimension {dim_id}: {dim['name']}\nStability: {dim['stability']:.2f}\nRealities: {len(dim['realities'])}"
                    self.hover_text_id = self.canvas.create_text(
                        event.x, event.y - 30, text=info, fill="white", 
                        font=("Arial", 10), anchor="s"
                    )
                    return
                    
            # Show information for realities
            elif tag.startswith("reality_") and not tag.startswith("reality_label_") and not tag.startswith("reality_connection_"):
                parts = tag.split("_")
                if len(parts) >= 3:
                    dim_id = int(parts[1])
                    reality_id = int(parts[2])
                    key = (dim_id, reality_id)
                    if key in self.realities:
                        reality = self.realities[key]
                        info = f"Reality {reality_id}\nConsistency: {reality['consistency']:.2f}\nEntanglement: {reality['quantum_entanglement']:.2f}"
                        self.hover_text_id = self.canvas.create_text(
                            event.x, event.y - 30, text=info, fill="white", 
                            font=("Arial", 10), anchor="s"
                        )
                        return
                        
            # Show information for travelers
            elif tag.startswith("traveler_") and not tag.startswith("traveler_label_"):
                name = tag[9:]
                if name in self.travelers:
                    traveler = self.travelers[name]
                    location = f"Dimension {traveler['current_dim']}"
                    if traveler['current_reality'] is not None:
                        location += f", Reality {traveler['current_reality']}"
                    info = f"{name}\nLocation: {location}"
                    self.hover_text_id = self.canvas.create_text(
                        event.x, event.y - 30, text=info, fill="white", 
                        font=("Arial", 10), anchor="s"
                    )
                    return
    
    def on_click(self, event):
        """Handle mouse clicks for selection"""
        # Find closest item
        item_id = self.canvas.find_closest(event.x, event.y)
        if not item_id:
            return
            
        item_id = item_id[0]
        tags = self.canvas.gettags(item_id)
        
        # Clear previous selection
        if self.selected:
            if self.selected['type'] == 'dimension':
                dim_id = self.selected['id']
                if dim_id in self.dimensions:
                    dim = self.dimensions[dim_id]
                    self.canvas.itemconfig(dim['obj_id'], width=2)
            elif self.selected['type'] == 'reality':
                dim_id, reality_id = self.selected['id']
                key = (dim_id, reality_id)
                if key in self.realities:
                    reality = self.realities[key]
                    self.canvas.itemconfig(reality['obj_id'], width=1)
            elif self.selected['type'] == 'traveler':
                name = self.selected['id']
                if name in self.travelers:
                    traveler = self.travelers[name]
                    self.canvas.itemconfig(traveler['obj_id'], width=1)
        
        # Select new item
        selected_item = None
        
        # Check for dimensions
        for tag in tags:
            if tag.startswith("dim_") and not tag.startswith("dim_label_") and not tag.startswith("dim_reality_") and not tag.startswith("dim_connection_"):
                dim_id = int(tag[4:])
                if dim_id in self.dimensions:
                    dim = self.dimensions[dim_id]
                    self.canvas.itemconfig(dim['obj_id'], width=4)  # Thicker outline for selection
                    selected_item = {'type': 'dimension', 'id': dim_id}
                    break
                    
            # Check for realities
            elif tag.startswith("reality_") and not tag.startswith("reality_label_") and not tag.startswith("reality_connection_"):
                parts = tag.split("_")
                if len(parts) >= 3:
                    dim_id = int(parts[1])
                    reality_id = int(parts[2])
                    key = (dim_id, reality_id)
                    if key in self.realities:
                        reality = self.realities[key]
                        self.canvas.itemconfig(reality['obj_id'], width=3)  # Thicker outline for selection
                        selected_item = {'type': 'reality', 'id': (dim_id, reality_id)}
                        break
                        
            # Check for travelers
            elif tag.startswith("traveler_") and not tag.startswith("traveler_label_"):
                name = tag[9:]
                if name in self.travelers:
                    traveler = self.travelers[name]
                    self.canvas.itemconfig(traveler['obj_id'], width=2)  # Thicker outline for selection
                    selected_item = {'type': 'traveler', 'id': name}
                    break
        
        self.selected = selected_item
        
        # Trigger selection event if we have a callback
        if hasattr(self, 'on_selection_change') and self.selected:
            self.on_selection_change(self.selected)


class TimelineVisualizerApp:
    """Application for visualizing multiverse timelines and realities"""
    
    def __init__(self, root=None, multiverse=None):
        """Initialize the visualizer app"""
        # Create root window if not provided
        if root is None:
            self.root = tk.Tk()
            self.root.title("Multiverse Timeline Visualizer")
            self.root.geometry("1200x800")
            self.own_root = True
        else:
            self.root = root
            self.own_root = False
        
        self.multiverse = multiverse
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        # Create main frame
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create top control panel
        self.control_panel = ttk.Frame(self.main_frame, padding=5)
        self.control_panel.pack(fill=tk.X)
        
        # Add buttons
        self.load_button = ttk.Button(self.control_panel, text="Load Multiverse", command=self.load_multiverse)
        self.load_button.grid(row=0, column=0, padx=5)
        
        self.refresh_button = ttk.Button(self.control_panel, text="Refresh View", command=self.refresh_view)
        self.refresh_button.grid(row=0, column=1, padx=5)
        
        self.toggle_button = ttk.Button(self.control_panel, text="Toggle View", command=self.toggle_view)
        self.toggle_button.grid(row=0, column=2, padx=5)
        
        self.simulate_button = ttk.Button(self.control_panel, text="Simulate Travel", command=self.simulate_travel)
        self.simulate_button.grid(row=0, column=3, padx=5)
        
        # Search box
        ttk.Label(self.control_panel, text="Search:").grid(row=0, column=4, padx=5)
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(self.control_panel, textvariable=self.search_var, width=20)
        self.search_entry.grid(row=0, column=5, padx=5)
        self.search_entry.bind("<Return>", self.search)
        
        # Create main notebook
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Reality Map tab
        self.map_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.map_frame, text="Reality Map")
        
        # Timeline tab
        self.timeline_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.timeline_frame, text="Timelines")
        
        # Event tab
        self.event_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.event_frame, text="Events")
        
        # Set up reality map
        self.map_canvas = RealityMapCanvas(self.map_frame)
        
        # Add dimension selection dropdown
        self.map_controls = ttk.Frame(self.map_frame)
        self.map_controls.pack(fill=tk.X, pady=5)
        
        ttk.Label(self.map_controls, text="Dimension:").grid(row=0, column=0, padx=5)
        self.dimension_var = tk.StringVar()
        self.dimension_combo = ttk.Combobox(self.map_controls, textvariable=self.dimension_var, state="readonly")
        self.dimension_combo.grid(row=0, column=1, padx=5)
        self.dimension_combo.bind("<<ComboboxSelected>>", self.on_dimension_selected)
        
        ttk.Label(self.map_controls, text="Traveler:").grid(row=0, column=2, padx=5)
        self.traveler_var = tk.StringVar()
        self.traveler_combo = ttk.Combobox(self.map_controls, textvariable=self.traveler_var, state="readonly")
        self.traveler_combo.grid(row=0, column=3, padx=5)
        
        # Information panel
        self.info_frame = ttk.LabelFrame(self.main_frame, text="Information", padding=5)
        self.info_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.info_text = scrolledtext.ScrolledText(self.info_frame, height=6, wrap=tk.WORD)
        self.info_text.pack(fill=tk.X, expand=True)
        
        # Set up selection callback
        self.map_canvas.on_selection_change = self.on_map_selection
        
        # If multiverse provided, load it
        if self.multiverse:
            self.refresh_view()
    
    def load_multiverse(self):
        """Load or initialize a multiverse"""
        if not self.multiverse:
            # For now, just create a sample multiverse
            self.create_sample_multiverse()
        
        self.refresh_view()
    
    def create_sample_multiverse(self):
        """Create a sample multiverse for demonstration"""
        from quantum_dimensions import QuantumDimension, QuantumReality, DimensionalRegistry
        
        # Create registry
        registry = DimensionalRegistry()
        
        # Initialize some dimensions
        dimensions = registry.initialize_dimensions(count=5)
        
        # Create some additional realities
        for dimension in dimensions:
            for _ in range(random.randint(1, 3)):
                registry.create_reality(dimension.dimension_id)
        
        # Add a few extra connections
        for _ in range(3):
            dim1 = random.choice(dimensions)
            dim2 = random.choice(dimensions)
            if dim1.dimension_id != dim2.dimension_id:
                dim1.add_gate(dim2.dimension_id, stability=random.uniform(0.5, 0.9))
        
        # Create travelers
        travelers = [
            ("Dr. Eliza Chen", 1, 1),
            ("Quantum Agent Smith", 2, None),
            ("Professor Paradox", 3, 2)
        ]
        
        self.demo_registry = registry
        self.demo_travelers = travelers
    
    def refresh_view(self):
        """Refresh the visualization"""
        self.map_canvas.clear()
        
        if hasattr(self, 'demo_registry'):
            registry = self.demo_registry
            
            # Add dimensions
            for dim_id, dimension in registry.dimensions.items():
                self.map_canvas.add_dimension(
                    dim_id, dimension.name, dimension.stability
                )
            
            # Add realities
            for reality_id, reality in registry.realities.items():
                dim_id = reality.dimension_id
                self.map_canvas.add_reality(
                    dim_id, reality.reality_id, reality.name, reality.consistency
                )
            
            # Add dimension connections
            for dim_id, dimension in registry.dimensions.items():
                for gate_id, stability in dimension.dimensional_gates:
                    if dim_id < gate_id:  # Only add connections once
                        self.map_canvas.connect_dimensions(
                            dim_id, gate_id, stability,
                            "quantum_entangled" if stability > 0.8 else "standard"
                        )
            
            # Add travelers
            for name, dim_id, reality_id in self.demo_travelers:
                self.map_canvas.add_traveler(name, dim_id, reality_id)
            
            # Update dimension dropdown
            self.dimension_combo['values'] = [
                f"D{dim_id}: {dimension.name}" for dim_id, dimension in registry.dimensions.items()
            ]
            
            # Update traveler dropdown
            self.traveler_combo['values'] = [name for name, _, _ in self.demo_travelers]
            
            # Add information
            self.update_info("Multiverse loaded with " + 
                           f"{len(registry.dimensions)} dimensions and " +
                           f"{len(registry.realities)} realities.")
        else:
            self.info_text.delete(1.0, tk.END)
            self.info_text.insert(tk.END, "No multiverse loaded. Click 'Load Multiverse' to create a sample.")
    
    def toggle_view(self):
        """Toggle between different view modes"""
        current_tab = self.notebook.index(self.notebook.select())
        next_tab = (current_tab + 1) % self.notebook.index("end")
        self.notebook.select(next_tab)
    
    def on_dimension_selected(self, event):
        """Handle dimension selection"""
        selection = self.dimension_var.get()
        if not selection:
            return
            
        # Extract dimension ID
        dim_id = int(selection.split(":")[0][1:])
        
        # Update info with dimension details
        if hasattr(self, 'demo_registry'):
            registry = self.demo_registry
            if dim_id in registry.dimensions:
                dimension = registry.dimensions[dim_id]
                info = (f"Dimension {dim_id}: {dimension.name}\n" +
                        f"Stability: {dimension.stability:.2f}\n" +
                        f"Spacial Dimensions: {dimension.spacial_dimensions}\n" +
                        f"Energy Density: {dimension.energy_density:.2f}\n" +
                        f"Realities: {len([r for r in registry.realities.values() if r.dimension_id == dim_id])}")
                self.update_info(info)
    
    def simulate_travel(self):
        """Simulate a traveler moving between realities"""
        traveler_name = self.traveler_var.get()
        if not traveler_name:
            self.update_info("Please select a traveler first.")
            return
            
        # Get random destination
        if hasattr(self, 'demo_registry'):
            registry = self.demo_registry
            
            # Pick random dimension
            dim_id = random.choice(list(registry.dimensions.keys()))
            
            # Decide whether to go to a reality or just the dimension
            realities = [r for r in registry.realities.values() if r.dimension_id == dim_id]
            if realities and random.random() < 0.7:
                reality = random.choice(realities)
                reality_id = reality.reality_id
                
                self.update_info(f"Moving {traveler_name} to Dimension {dim_id}, Reality {reality_id}...")
                self.map_canvas.move_traveler(traveler_name, dim_id, reality_id)
            else:
                self.update_info(f"Moving {traveler_name} to Dimension {dim_id}...")
                self.map_canvas.move_traveler(traveler_name, dim_id)
    
    def search(self, event=None):
        """Search for an item in the visualization"""
        search_text = self.search_var.get().lower()
        if not search_text:
            return
            
        found = False
        
        # Search dimensions
        for dim_id, dim in self.map_canvas.dimensions.items():
            if search_text in dim['name'].lower() or search_text == f"d{dim_id}":
                self.update_info(f"Found Dimension {dim_id}: {dim['name']}")
                
                # Select in the map
                self.map_canvas.selected = {'type': 'dimension', 'id': dim_id}
                self.map_canvas.canvas.itemconfig(dim['obj_id'], width=4)
                
                # Center view on this dimension
                self.map_canvas.canvas.xview_moveto((dim['x'] - 100) / self.map_canvas.width)
                self.map_canvas.canvas.yview_moveto((dim['y'] - 100) / self.map_canvas.height)
                
                found = True
                break
                
        # Search realities
        if not found:
            for (dim_id, reality_id), reality in self.map_canvas.realities.items():
                if (search_text in reality['name'].lower() or 
                    search_text == f"r{reality_id}" or
                    search_text == f"d{dim_id}r{reality_id}"):
                    
                    self.update_info(f"Found Reality {reality_id} in Dimension {dim_id}")
                    
                    # Select in the map
                    self.map_canvas.selected = {'type': 'reality', 'id': (dim_id, reality_id)}
                    self.map_canvas.canvas.itemconfig(reality['obj_id'], width=3)
                    
                    found = True
                    break
                    
        # Search travelers
        if not found:
            for name, traveler in self.map_canvas.travelers.items():
                if search_text in name.lower():
                    self.update_info(f"Found Traveler: {name}")
                    
                    # Select in the map
                    self.map_canvas.selected = {'type': 'traveler', 'id': name}
                    self.map_canvas.canvas.itemconfig(traveler['obj_id'], width=2)
                    
                    found = True
                    break
                    
        if not found:
            self.update_info(f"No items found matching '{search_text}'")
    
    def on_map_selection(self, selected):
        """Handle selection change in the map"""
        if not selected:
            return
            
        if selected['type'] == 'dimension':
            dim_id = selected['id']
            if hasattr(self, 'demo_registry'):
                registry = self.demo_registry
                if dim_id in registry.dimensions:
                    dimension = registry.dimensions[dim_id]
                    info = (f"Dimension {dim_id}: {dimension.name}\n" +
                            f"Stability: {dimension.stability:.2f}\n" +
                            f"Spacial Dimensions: {dimension.spacial_dimensions}\n" +
                            f"Energy Density: {dimension.energy_density:.2f}\n" +
                            f"Realities: {len([r for r in registry.realities.values() if r.dimension_id == dim_id])}")
                    self.update_info(info)
                    
        elif selected['type'] == 'reality':
            dim_id, reality_id = selected['id']
            if hasattr(self, 'demo_registry'):
                registry = self.demo_registry
                for r in registry.realities.values():
                    if r.dimension_id == dim_id and r.reality_id == reality_id:
                        info = (f"Reality {reality_id}: {r.name}\n" +
                                f"Dimension: {dim_id}\n" +
                                f"Consistency: {r.consistency:.2f}\n" +
                                f"Events: {len(r.events)}")
                        self.update_info(info)
                        
        elif selected['type'] == 'traveler':
            name = selected['id']
            if name in self.map_canvas.travelers:
                traveler = self.map_canvas.travelers[name]
                location = f"Dimension {traveler['current_dim']}"
                if traveler['current_reality'] is not None:
                    location += f", Reality {traveler['current_reality']}"
                info = f"Traveler: {name}\nLocation: {location}"
                self.update_info(info)
    
    def update_info(self, text):
        """Update the information panel with new text"""
        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(tk.END, text)
    
    def run(self):
        """Run the application"""
        if self.own_root:
            self.root.mainloop()


def run_visualization_demo():
    """Run a demonstration of the reality visualization"""
    app = TimelineVisualizerApp()
    app.run()


if __name__ == "__main__":
    run_visualization_demo()
