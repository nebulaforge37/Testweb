
"""
Interdimensional Beings Module
This module introduces entities that exist across multiple quantum dimensions
and realities, with the ability to affect timeline stability.
"""

import random
import math
from typing import List, Dict, Tuple, Optional, Any, Set
from quantum_dimensions import QuantumDimension, QuantumReality, DimensionalRegistry
from alternate_realities import RealityManager, RealityCoordinate

class InterdimensionalEntityType:
    """Classification of interdimensional entities"""
    
    def __init__(self, name: str, description: str, rarity: float, 
                stability_effect: float, detection_difficulty: float):
        """
        Initialize an entity type
        
        Args:
            name: Name of this entity type
            description: Description of its nature and behavior
            rarity: How rare this entity is (0.0-1.0, higher = rarer)
            stability_effect: Effect on reality stability (-1.0 to 1.0)
            detection_difficulty: How hard it is to detect (0.0-1.0)
        """
        self.name = name
        self.description = description
        self.rarity = rarity
        self.stability_effect = stability_effect
        self.detection_difficulty = detection_difficulty
        self.typical_abilities = []
        
    def add_ability(self, name: str, description: str):
        """Add a typical ability for this entity type"""
        self.typical_abilities.append({
            "name": name,
            "description": description
        })
        
    def __str__(self) -> str:
        rarity_desc = "Common" if self.rarity < 0.4 else "Uncommon" if self.rarity < 0.7 else "Rare" if self.rarity < 0.9 else "Extremely Rare"
        effect_desc = "Stabilizing" if self.stability_effect > 0.1 else "Destabilizing" if self.stability_effect < -0.1 else "Neutral"
        return f"{self.name} ({rarity_desc}, {effect_desc}): {self.description}"


class InterdimensionalEntity:
    """An entity that exists across multiple dimensions/realities"""
    
    def __init__(self, entity_id: int, name: str, entity_type: InterdimensionalEntityType):
        """
        Initialize an interdimensional entity
        
        Args:
            entity_id: Unique identifier for this entity
            name: Name or designation of this entity
            entity_type: Type of interdimensional entity
        """
        self.entity_id = entity_id
        self.name = name
        self.entity_type = entity_type
        self.current_locations = []  # List of (dimension_id, reality_id) tuples
        self.quantum_signature = random.random()  # Unique quantum signature
        self.temporal_variance = random.uniform(0.2, 0.8)  # How much it varies temporally
        self.manifestation_strength = random.uniform(0.4, 1.0)  # Strength of manifestation
        self.abilities = []  # Additional abilities specific to this entity
        self.encounter_history = []  # Record of interactions/encounters
        
    def add_ability(self, name: str, description: str, power_level: float = 0.5):
        """Add a specific ability to this entity"""
        self.abilities.append({
            "name": name,
            "description": description,
            "power_level": power_level
        })
        
    def add_location(self, dimension_id: int, reality_id: Optional[int] = None):
        """Add a location where this entity exists"""
        location = (dimension_id, reality_id)
        if location not in self.current_locations:
            self.current_locations.append(location)
            
    def remove_location(self, dimension_id: int, reality_id: Optional[int] = None):
        """Remove a location"""
        location = (dimension_id, reality_id)
        if location in self.current_locations:
            self.current_locations.remove(location)
            
    def can_affect(self, dimension_id: int, reality_id: Optional[int] = None) -> bool:
        """Determine if the entity can affect a specific dimension/reality"""
        # Can directly affect locations where it exists
        if (dimension_id, reality_id) in self.current_locations:
            return True
            
        # Can affect a dimension if it exists in any reality in that dimension
        if reality_id is not None:
            for dim_id, _ in self.current_locations:
                if dim_id == dimension_id:
                    return True
        
        # For some entities with high manifestation strength, they can affect nearby dimensions
        if self.manifestation_strength > 0.8:
            for dim_id, _ in self.current_locations:
                # Arbitrary distance measure between dimensions
                if abs(dim_id - dimension_id) < 3:
                    return random.random() < (self.manifestation_strength - 0.7)
                    
        return False
        
    def calculate_stability_impact(self, dimension_id: int, reality_id: Optional[int] = None) -> float:
        """Calculate the stability impact this entity has on a dimension/reality"""
        if not self.can_affect(dimension_id, reality_id):
            return 0.0
            
        # Base impact from entity type
        base_impact = self.entity_type.stability_effect
        
        # Scale by manifestation strength
        impact = base_impact * self.manifestation_strength
        
        # More direct presence = stronger effect
        presence_multiplier = 1.0
        if (dimension_id, reality_id) in self.current_locations:
            presence_multiplier = 1.5
        elif reality_id is not None:
            for dim_id, real_id in self.current_locations:
                if dim_id == dimension_id:
                    presence_multiplier = 1.2
                    break
        
        return impact * presence_multiplier
    
    def encounter(self, dimension_id: int, reality_id: Optional[int], 
                traveler_name: str) -> Dict[str, Any]:
        """
        Process an encounter with a reality traveler
        
        Returns:
            Encounter details dictionary
        """
        # Determine if the entity can be encountered here
        if not self.can_affect(dimension_id, reality_id):
            return {
                "success": False,
                "message": f"{traveler_name} sensed something, but {self.name} could not manifest here."
            }
            
        # Calculate manifestation strength in this location
        location_strength = self.manifestation_strength
        if (dimension_id, reality_id) not in self.current_locations:
            location_strength *= 0.6
            
        # Determine encounter type
        encounter_type = self._determine_encounter_type(location_strength)
        
        # Generate effects based on the entity type and abilities
        effects = []
        
        # Apply base effect from entity type
        stability_effect = self.calculate_stability_impact(dimension_id, reality_id)
        if abs(stability_effect) > 0.05:
            effect_type = "increase" if stability_effect > 0 else "decrease"
            effects.append(f"Reality stability {effect_type} of {abs(stability_effect):.2f}")
        
        # Random additional effects based on abilities
        all_abilities = self.abilities + self.entity_type.typical_abilities
        if all_abilities:
            # Choose 1-3 abilities to manifest
            num_abilities = min(3, max(1, int(location_strength * 3)))
            for ability in random.sample(all_abilities, min(num_abilities, len(all_abilities))):
                effects.append(f"{ability['name']}: {ability['description']}")
        
        # Record the encounter
        encounter_record = {
            "dimension_id": dimension_id,
            "reality_id": reality_id,
            "traveler": traveler_name,
            "encounter_type": encounter_type,
            "manifestation_strength": location_strength,
            "effects": effects
        }
        
        self.encounter_history.append(encounter_record)
        
        # Generate encounter message
        message = f"{traveler_name} encountered {self.name} in dimension {dimension_id}"
        if reality_id is not None:
            message += f", reality {reality_id}"
        message += f". Type: {encounter_type}\n"
        
        if effects:
            message += "Effects:\n- " + "\n- ".join(effects)
        
        return {
            "success": True,
            "message": message,
            "encounter": encounter_record
        }
    
    def _determine_encounter_type(self, strength: float) -> str:
        """Determine the type of encounter based on manifestation strength"""
        if strength < 0.3:
            return "Faint Presence"
        elif strength < 0.5:
            return "Partial Manifestation"
        elif strength < 0.7:
            return "Full Manifestation"
        elif strength < 0.9:
            return "Powerful Manifestation"
        else:
            return "Complete Dimensional Convergence"
            
    def __str__(self) -> str:
        locations = [f"D{d}:R{r if r is not None else '*'}" for d, r in self.current_locations]
        return f"{self.name} ({self.entity_type.name}) - Locations: {', '.join(locations)}"


class InterdimensionalBeingRegistry:
    """Registry for tracking and managing interdimensional entities"""
    
    def __init__(self, dimensional_registry: DimensionalRegistry = None):
        """Initialize the registry"""
        self.dimensional_registry = dimensional_registry
        self.entity_types = self._initialize_entity_types()
        self.entities: Dict[int, InterdimensionalEntity] = {}
        self.next_entity_id = 1
        self.debug_mode = False
        
    def _initialize_entity_types(self) -> Dict[str, InterdimensionalEntityType]:
        """Initialize the standard entity types"""
        entity_types = {}
        
        # Quantum Observers - generally beneficial
        observers = InterdimensionalEntityType(
            "Quantum Observer",
            "Sentient beings that observe and maintain quantum coherence across realities",
            rarity=0.6,
            stability_effect=0.2,
            detection_difficulty=0.7
        )
        observers.add_ability("Reality Stabilization", "Can strengthen weakened reality boundaries")
        observers.add_ability("Quantum Sight", "Can perceive all quantum states simultaneously")
        observers.add_ability("Temporal Anchoring", "Can stabilize temporal anomalies")
        entity_types["observer"] = observers
        
        # Void Dwellers - dangerous entities that erode reality
        void_dwellers = InterdimensionalEntityType(
            "Void Dweller",
            "Entities that exist primarily in the spaces between realities, feeding on dimensional energy",
            rarity=0.8,
            stability_effect=-0.3,
            detection_difficulty=0.5
        )
        void_dwellers.add_ability("Reality Drain", "Siphons quantum stability from realities")
        void_dwellers.add_ability("Phase Shifting", "Can move between dimensions without gates")
        void_dwellers.add_ability("Void Projection", "Creates pockets of non-reality")
        entity_types["void_dweller"] = void_dwellers
        
        # Quantum Echoes - remnants of collapsed timelines
        echoes = InterdimensionalEntityType(
            "Quantum Echo",
            "Residual patterns from collapsed or destroyed realities that continue to exist",
            rarity=0.5,
            stability_effect=-0.1,
            detection_difficulty=0.9
        )
        echoes.add_ability("Timeline Replay", "Forces events from destroyed timelines to repeat")
        echoes.add_ability("Memory Imprint", "Can implant memories from other realities")
        echoes.add_ability("Resonance Cascading", "Creates chain reactions of quantum fluctuations")
        entity_types["echo"] = echoes
        
        # Dimensional Custodians - maintain dimensional boundaries
        custodians = InterdimensionalEntityType(
            "Dimensional Custodian",
            "Ancient entities that maintain the structure of the multiverse",
            rarity=0.9,
            stability_effect=0.4,
            detection_difficulty=0.8
        )
        custodians.add_ability("Reality Repair", "Can mend damaged dimensional boundaries")
        custodians.add_ability("Paradox Resolution", "Neutralizes temporal paradoxes")
        custodians.add_ability("Dimensional Restructuring", "Can reorganize quantum dimensions")
        entity_types["custodian"] = custodians
        
        # Boundary Lurkers - exist at dimensional boundaries
        lurkers = InterdimensionalEntityType(
            "Boundary Lurker",
            "Entities that exist at the edges between dimensions, neither helping nor harming",
            rarity=0.4,
            stability_effect=0.0,
            detection_difficulty=0.6
        )
        lurkers.add_ability("Gateway Creation", "Can temporarily open paths between realities")
        lurkers.add_ability("Dimensional Sensing", "Can detect activity across multiple dimensions")
        lurkers.add_ability("Reality Mimicry", "Can take on properties of nearby realities")
        entity_types["lurker"] = lurkers
        
        return entity_types
        
    def get_entity_type(self, type_name: str) -> Optional[InterdimensionalEntityType]:
        """Get an entity type by name"""
        return self.entity_types.get(type_name.lower())
    
    def create_entity(self, name: str, type_name: str, 
                    dimension_ids: List[int] = None,
                    reality_ids: List[Tuple[int, int]] = None) -> Optional[InterdimensionalEntity]:
        """
        Create a new interdimensional entity
        
        Args:
            name: Name for the entity
            type_name: Type of entity
            dimension_ids: List of dimension IDs where it exists (no specific reality)
            reality_ids: List of (dimension_id, reality_id) tuples where it exists
            
        Returns:
            The created entity or None if failed
        """
        entity_type = self.get_entity_type(type_name)
        if not entity_type:
            if self.debug_mode:
                print(f"Unknown entity type: {type_name}")
            return None
            
        # Create the entity
        entity = InterdimensionalEntity(self.next_entity_id, name, entity_type)
        self.next_entity_id += 1
        
        # Add locations
        if dimension_ids:
            for dim_id in dimension_ids:
                entity.add_location(dim_id)
                
        if reality_ids:
            for dim_id, reality_id in reality_ids:
                entity.add_location(dim_id, reality_id)
                
        # Add to registry
        self.entities[entity.entity_id] = entity
        
        if self.debug_mode:
            print(f"Created entity: {entity}")
            
        return entity
    
    def get_entity(self, entity_id: int) -> Optional[InterdimensionalEntity]:
        """Get an entity by ID"""
        return self.entities.get(entity_id)
    
    def get_entities_in_location(self, dimension_id: int, 
                               reality_id: Optional[int] = None) -> List[InterdimensionalEntity]:
        """Get all entities that can affect a specific location"""
        return [entity for entity in self.entities.values() 
                if entity.can_affect(dimension_id, reality_id)]
    
    def apply_entity_effects(self, dimension_id: int, reality_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Apply the combined effects of all entities in a location
        
        Returns:
            Dictionary with effect information
        """
        entities = self.get_entities_in_location(dimension_id, reality_id)
        if not entities:
            return {"stability_change": 0.0, "entities": [], "effects": []}
            
        # Calculate combined stability effect
        stability_change = sum(entity.calculate_stability_impact(dimension_id, reality_id) 
                               for entity in entities)
                               
        # Apply effect to dimension/reality if registry available
        if self.dimensional_registry:
            if reality_id is not None:
                reality = self.dimensional_registry.get_reality(reality_id)
                if reality and reality.dimension_id == dimension_id:
                    old_stability = reality.stability
                    reality.stability = max(0.1, min(1.0, reality.stability + stability_change))
                    if self.debug_mode:
                        print(f"Reality {reality_id} stability changed from {old_stability:.2f} to {reality.stability:.2f}")
            else:
                dimension = self.dimensional_registry.get_dimension(dimension_id)
                if dimension:
                    old_stability = dimension.stability
                    dimension.stability = max(0.1, min(1.0, dimension.stability + stability_change))
                    if self.debug_mode:
                        print(f"Dimension {dimension_id} stability changed from {old_stability:.2f} to {dimension.stability:.2f}")
        
        # Collect effects descriptions
        effects = []
        for entity in entities:
            impact = entity.calculate_stability_impact(dimension_id, reality_id)
            if abs(impact) > 0.01:
                direction = "increasing" if impact > 0 else "decreasing"
                effects.append(f"{entity.name} ({entity.entity_type.name}) is {direction} stability by {abs(impact):.2f}")
        
        return {
            "stability_change": stability_change,
            "entities": [e.entity_id for e in entities],
            "effects": effects
        }
    
    def create_random_entity(self, dimension_count: int = 3, 
                           reality_count: int = 2) -> Optional[InterdimensionalEntity]:
        """Create a random entity spanning multiple dimensions/realities"""
        # Select a random entity type
        entity_type_name = random.choice(list(self.entity_types.keys()))
        entity_type = self.entity_types[entity_type_name]
        
        # Generate a name
        prefixes = ["Azura", "Vex", "Quant", "Zeph", "Chron", "Ether", "Nex", "Lum", "Vort", "Echo"]
        suffixes = ["watcher", "weaver", "stalker", "drifter", "guardian", "keeper", "wanderer", "sentinel"]
        name = random.choice(prefixes) + random.choice(suffixes)
        
        # Determine locations
        dimension_ids = []
        reality_ids = []
        
        # Decide how many dimensions this entity spans
        span_count = max(1, min(dimension_count, random.randint(1, 3)))
        
        if self.dimensional_registry:
            # Use dimensions from the registry
            all_dimensions = list(self.dimensional_registry.dimensions.keys())
            if all_dimensions:
                for _ in range(span_count):
                    dim_id = random.choice(all_dimensions)
                    
                    # Sometimes occupy specific realities
                    if random.random() < 0.7:
                        dimension = self.dimensional_registry.get_dimension(dim_id)
                        if dimension and dimension.realities:
                            reality_keys = list(dimension.realities.keys())
                            reality_count = min(len(reality_keys), random.randint(1, 2))
                            for _ in range(reality_count):
                                reality_id = random.choice(reality_keys)
                                reality_ids.append((dim_id, reality_id))
                    else:
                        # Occupy entire dimension
                        dimension_ids.append(dim_id)
        else:
            # Generate random dimension IDs
            max_dim_id = 100
            for _ in range(span_count):
                dimension_ids.append(random.randint(1, max_dim_id))
                
                # Sometimes add specific realities
                if random.random() < 0.7:
                    for _ in range(random.randint(1, reality_count)):
                        reality_ids.append((dimension_ids[-1], random.randint(1, 20)))
        
        # Create the entity
        entity = self.create_entity(name, entity_type_name, dimension_ids, reality_ids)
        
        # Add some random abilities
        ability_count = random.randint(1, 3)
        ability_prefixes = ["Quantum", "Void", "Temporal", "Spatial", "Dimensional", "Reality", "Phase"]
        ability_types = ["Shift", "Manipulation", "Perception", "Distortion", "Projection", "Absorption", "Weaving"]
        ability_effects = [
            "bends local temporal flow", 
            "creates spatial distortions",
            "allows perception across dimensions",
            "manipulates quantum probability",
            "affects causal relationships",
            "creates stable pocket dimensions",
            "alters object quantum signatures"
        ]
        
        for _ in range(ability_count):
            ability_name = f"{random.choice(ability_prefixes)} {random.choice(ability_types)}"
            description = random.choice(ability_effects)
            power_level = random.uniform(0.3, 0.9)
            
            entity.add_ability(ability_name, description, power_level)
        
        return entity
    
    def generate_entity_report(self, entity_id: Optional[int] = None) -> str:
        """Generate a report on entities"""
        if entity_id is not None:
            # Report on specific entity
            entity = self.get_entity(entity_id)
            if not entity:
                return f"Entity with ID {entity_id} not found."
                
            report = [f"=== ENTITY REPORT: {entity.name} (ID: {entity_id}) ==="]
            report.append(f"Type: {entity.entity_type.name}")
            report.append(f"Description: {entity.entity_type.description}")
            
            locations = [f"D{d}:{('R'+str(r)) if r is not None else '*'}" for d, r in entity.current_locations]
            report.append(f"Manifestation Locations: {', '.join(locations)}")
            
            report.append(f"Manifestation Strength: {entity.manifestation_strength:.2f}")
            report.append(f"Temporal Variance: {entity.temporal_variance:.2f}")
            
            report.append("\nAbilities:")
            all_abilities = entity.abilities + entity.entity_type.typical_abilities
            for ability in all_abilities:
                report.append(f"  - {ability['name']}: {ability['description']}")
                
            if entity.encounter_history:
                report.append("\nRecent Encounters:")
                for encounter in entity.encounter_history[-3:]:  # Show last 3 encounters
                    location = f"D{encounter['dimension_id']}"
                    if encounter['reality_id'] is not None:
                        location += f":R{encounter['reality_id']}"
                        
                    report.append(f"  - {encounter['traveler']} in {location}: {encounter['encounter_type']}")
                    
            return "\n".join(report)
        else:
            # Summary report of all entities
            if not self.entities:
                return "No interdimensional entities registered."
                
            report = ["=== INTERDIMENSIONAL ENTITY REGISTRY SUMMARY ==="]
            report.append(f"Total Entities: {len(self.entities)}")
            
            # Count by type
            type_counts = {}
            for entity in self.entities.values():
                type_name = entity.entity_type.name
                type_counts[type_name] = type_counts.get(type_name, 0) + 1
                
            report.append("\nEntity Types:")
            for type_name, count in type_counts.items():
                report.append(f"  - {type_name}: {count}")
                
            # Dimension coverage
            dimension_coverage = {}
            for entity in self.entities.values():
                for dim_id, _ in entity.current_locations:
                    dimension_coverage[dim_id] = dimension_coverage.get(dim_id, 0) + 1
                    
            most_active_dims = sorted(dimension_coverage.items(), key=lambda x: x[1], reverse=True)[:3]
            if most_active_dims:
                report.append("\nMost Active Dimensions:")
                for dim_id, count in most_active_dims:
                    report.append(f"  - Dimension {dim_id}: {count} entities")
            
            return "\n".join(report)


def run_entity_demo(dimensional_registry: DimensionalRegistry = None):
    """Run a demonstration of interdimensional entities"""
    print("=== Interdimensional Entities Demonstration ===")
    
    # Create registry if not provided
    if not dimensional_registry:
        dimensional_registry = DimensionalRegistry()
        dimensions = dimensional_registry.initialize_dimensions(count=3)
    
    # Create an entity registry
    entity_registry = InterdimensionalBeingRegistry(dimensional_registry)
    entity_registry.debug_mode = True
    
    # Show available entity types
    print("\nAvailable Entity Types:")
    for name, entity_type in entity_registry.entity_types.items():
        print(f"- {entity_type}")
    
    # Create some random entities
    print("\nCreating random interdimensional entities...")
    entities = []
    for i in range(4):
        entity = entity_registry.create_random_entity()
        if entity:
            entities.append(entity)
            print(f"Created: {entity}")
    
    # Show the effects of entities on dimensions
    if dimensional_registry.dimensions:
        print("\nEntity Effects on Dimensions:")
        for dimension_id in list(dimensional_registry.dimensions.keys())[:3]:  # Check first 3 dimensions
            effects = entity_registry.apply_entity_effects(dimension_id)
            print(f"\nDimension {dimension_id}:")
            print(f"Combined Stability Change: {effects['stability_change']:.3f}")
            for effect in effects['effects']:
                print(f"  - {effect}")
    
    # Simulate an encounter with a traveler
    if entities:
        print("\nSimulating Encounter:")
        traveler_name = "Dr. Eliza Chen"
        entity = random.choice(entities)
        dimension_id, reality_id = entity.current_locations[0] if entity.current_locations else (1, None)
        
        encounter_result = entity.encounter(dimension_id, reality_id, traveler_name)
        print(encounter_result['message'])
    
    # Print detailed report for one entity
    if entities:
        entity = random.choice(entities)
        print("\n" + entity_registry.generate_entity_report(entity.entity_id))
    
    # Print summary report
    print("\n" + entity_registry.generate_entity_report())
    
    return entity_registry


def integrate_with_reality_manager(entity_registry: InterdimensionalBeingRegistry, 
                                 reality_manager: RealityManager):
    """Integrate entity registry with reality manager"""
    print("=== Integrating Interdimensional Entities with Reality Manager ===")
    
    if not entity_registry.entities:
        print("No entities registered. Creating some...")
        for _ in range(3):
            entity_registry.create_random_entity()
    
    # Extend reality travel to check for entity encounters
    original_travel_method = reality_manager.perform_reality_travel
    
    def enhanced_reality_travel(traveler_name, destination_dimension, destination_reality, use_breach=False):
        # Call original method
        result = original_travel_method(traveler_name, destination_dimension, destination_reality, use_breach)
        
        # Check for entity encounters
        entities = entity_registry.get_entities_in_location(destination_dimension, destination_reality)
        if entities and random.random() < 0.7:  # 70% chance to encounter if entities present
            entity = random.choice(entities)
            encounter = entity.encounter(destination_dimension, destination_reality, traveler_name)
            
            if encounter['success']:
                print("\n" + "="*40)
                print("INTERDIMENSIONAL ENTITY ENCOUNTER")
                print("="*40)
                print(encounter['message'])
                print("="*40 + "\n")
                
                # Apply effects to reality if successful
                for effect in encounter['encounter']['effects']:
                    if "stability increase" in effect.lower():
                        # Extract the value from the effect text
                        try:
                            value = float(effect.split()[-1])
                            # Apply to reality
                            reality = reality_manager.registry.get_reality(destination_reality)
                            if reality:
                                reality.stability = min(1.0, reality.stability + value)
                        except:
                            pass
                    elif "stability decrease" in effect.lower():
                        try:
                            value = float(effect.split()[-1])
                            # Apply to reality
                            reality = reality_manager.registry.get_reality(destination_reality)
                            if reality:
                                reality.stability = max(0.1, reality.stability - value)
                        except:
                            pass
        
        return result
    
    # Replace the travel method
    reality_manager.perform_reality_travel = enhanced_reality_travel
    print("Reality travel system enhanced with entity encounters")
    
    # Apply entity effects to all current realities
    for reality_id, reality in reality_manager.registry.realities.items():
        effects = entity_registry.apply_entity_effects(reality.dimension_id, reality_id)
        if effects['stability_change'] != 0:
            print(f"Reality {reality_id} affected by interdimensional entities:")
            for effect in effects['effects']:
                print(f"  - {effect}")
    
    return reality_manager


if __name__ == "__main__":
    run_entity_demo()
