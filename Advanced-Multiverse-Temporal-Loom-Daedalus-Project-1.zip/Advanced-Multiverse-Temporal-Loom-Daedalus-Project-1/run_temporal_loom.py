
from temporal_loom import run_temporal_loom_demo
from sacred_timeline import SacredTimeline

# Import required for TemporalRadiation which is used in the temporal_loom module
import random
import time
import math
from typing import List, Dict, Optional, Tuple, Any, Union

if __name__ == "__main__":
    print("=== Temporal Loom Control System ===")
    print("Initializing Temporal Loom demonstration...")
    
    # Run the demonstration
    loom = run_temporal_loom_demo()
    
    # Show the status report again
    print("\nFinal Temporal Loom Status:")
    print(loom.get_status_report())
