
"""
Timewave Module
This module implements temporal waves that propagate through the multiverse,
affecting timelines and causing ripple effects across dimensions.
"""

import random
import math
import time
from typing import List, Dict, Optional, Tuple, Any, Union
from temporal_physics import TimeDilation, ParadoxRegistry

class Timewave:
    """Represents a temporal wave that propagates through the multiverse"""
    
    def __init__(self, origin_timeline, year: int, strength: float, description: str):
        """
        Initialize a timewave
        
        Args:
            origin_timeline: The timeline where the wave originated
            year: The year when the wave originated
            strength: Initial strength of the wave (0.0-2.0)
            description: Description of the event that caused the wave
        """
        self.origin = origin_timeline.name if hasattr(origin_timeline, 'name') else str(origin_timeline)
        self.origin_timeline = origin_timeline
        self.year = year
        self.strength = strength
        self.description = description
        self.created_at = time.time()
        self.decay_rate = random.uniform(0.1, 0.3)  # How quickly the wave loses strength
        self.propagation_speed = random.uniform(0.5, 1.5)  # Relative speed of propagation
        self.affected_timelines = []  # List of timelines this wave has affected
        self.current_phase = 0.0  # Phase of the wave (0.0 - 2π)
        self.frequency = random.uniform(0.5, 2.0)  # Higher = faster oscillation
        self.harmonic_pattern = [random.uniform(0.5, 1.5) for _ in range(5)]  # Unique resonance pattern
        self.quantum_signature = random.random()  # Quantum signature of this wave
        
    def propagate(self, timelines: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Propagate this wave through available timelines
        
        Args:
            timelines: Dictionary of available timelines
            
        Returns:
            List of effects on timelines
        """
        if self.strength <= 0:
            return []
            
        effects = []
        
        # Number of timelines to affect in this propagation cycle
        # More powerful waves affect more timelines
        num_to_affect = max(1, min(3, int(self.strength * 2)))
        
        # Convert to list if needed and exclude already affected timelines
        available_timelines = []
        for name, timeline in timelines.items():
            if name not in [effect.get('timeline_name') for effect in self.affected_timelines]:
                available_timelines.append(timeline)
                
        # If no more timelines to affect, just decay
        if not available_timelines:
            self._decay()
            return []
            
        # Select random timelines to affect
        timelines_to_affect = random.sample(
            available_timelines, 
            min(len(available_timelines), num_to_affect)
        )
        
        # Calculate phase-based influence modifier
        # This creates wave-like effects that can be constructive or destructive
        phase_modifier = math.sin(self.current_phase) * 0.5 + 0.5  # 0.0 to 1.0
        
        # Affect each timeline
        for timeline in timelines_to_affect:
            # Calculate base influence (how much this wave affects the timeline)
            base_influence = self.strength * random.uniform(0.05, 0.2)
            
            # Apply phase modifier
            influence = base_influence * phase_modifier
            
            # Determine if influence is positive or negative for stability
            stability_effect = influence * random.choice([-1, 1])
            
            # Apply effect to timeline
            old_stability = timeline.stability
            timeline.stability = max(0.1, min(1.0, timeline.stability + stability_effect))
            
            # Determine if this should create a significant event
            if random.random() < (self.strength * 0.3):
                event_year = self.year + int(random.uniform(-5, 15))
                event_desc = f"Timewave effect: {self.description}"
                timeline.add_event(event_desc, event_year)
                
                # Possibility of quantum effects on stronger waves
                if self.strength > 1.0 and hasattr(timeline, 'quantum_state'):
                    if random.random() < (self.strength * 0.2):
                        # Increase quantum entanglement
                        timeline.quantum_state.entanglement_level = min(
                            1.0, 
                            timeline.quantum_state.entanglement_level + (self.strength * 0.1)
                        )
                        
                        # Small chance of superposition
                        if (random.random() < (self.strength * 0.1) and 
                            hasattr(timeline.quantum_state, 'superposition')):
                            timeline.quantum_state.superposition = True
            
            # Record effect
            effect = {
                'timeline_name': timeline.name,
                'timeline': timeline,
                'influence': influence,
                'stability_effect': stability_effect,
                'old_stability': old_stability,
                'new_stability': timeline.stability,
                'time': time.time()
            }
            
            self.affected_timelines.append(effect)
            effects.append(effect)
            
        # Update wave properties
        self._decay()
        self._update_phase()
        
        return effects
    
    def _decay(self):
        """Decay the wave strength"""
        self.strength = max(0.0, self.strength - self.decay_rate * random.uniform(0.8, 1.2))
        
    def _update_phase(self):
        """Update the wave phase"""
        self.current_phase = (self.current_phase + (self.frequency * 0.2)) % (2 * math.pi)
        
    def get_wave_amplitude(self) -> float:
        """Get the current amplitude of the wave based on phase"""
        return self.strength * (math.sin(self.current_phase) * 0.5 + 0.5)
        
    def get_status(self) -> Dict[str, Any]:
        """Get the current status of this wave"""
        return {
            'origin': self.origin,
            'year': self.year,
            'strength': self.strength,
            'description': self.description,
            'decay_rate': self.decay_rate,
            'created_at': self.created_at,
            'current_phase': self.current_phase,
            'amplitude': self.get_wave_amplitude(),
            'affected_timelines': len(self.affected_timelines)
        }
        
    def is_active(self) -> bool:
        """Check if this wave is still active"""
        return self.strength > 0.01
        
    def __str__(self) -> str:
        return f"Timewave from {self.origin} ({self.year}): {self.strength:.2f} strength, '{self.description}'"


class TimewaveManager:
    """Manages all timewaves in the multiverse"""
    
    def __init__(self, multiverse = None):
        """Initialize the timewave manager"""
        self.multiverse = multiverse
        self.timewaves = []
        self.active_wave_count = 0
        self.total_wave_count = 0
        self.last_propagation = time.time()
        self.propagation_interval = 0.5  # Seconds between propagations
        self.resonance_map = {}  # Maps timelines to resonance profiles
        
    def create_timewave(self, origin_timeline_name: str, year: int, 
                       strength: float, description: str) -> Tuple[bool, Optional[Timewave]]:
        """
        Create a new timewave
        
        Args:
            origin_timeline_name: Name of the timeline where the wave originates
            year: Year when the wave originates
            strength: Initial strength of the wave (0.0-2.0)
            description: Description of the event that caused the wave
            
        Returns:
            Success flag and the created wave (if successful)
        """
        # Verify timeline exists if multiverse is provided
        if self.multiverse and hasattr(self.multiverse, 'timelines'):
            if origin_timeline_name not in self.multiverse.timelines:
                return False, None
                
            origin_timeline = self.multiverse.timelines[origin_timeline_name]
        else:
            # If no multiverse, just use the name as a string identifier
            origin_timeline = origin_timeline_name
            
        # Create the wave
        wave = Timewave(origin_timeline, year, strength, description)
        self.timewaves.append(wave)
        self.total_wave_count += 1
        self.active_wave_count += 1
        
        # If multiverse is available, add an event to the origin timeline
        if self.multiverse and hasattr(self.multiverse, 'timelines'):
            origin_timeline.add_event(f"Timewave Originated: {description}", year)
            
        return True, wave
        
    def propagate_all_waves(self) -> List[Dict[str, Any]]:
        """
        Propagate all active waves through the multiverse
        
        Returns:
            List of all effects from this propagation cycle
        """
        if not self.multiverse or not hasattr(self.multiverse, 'timelines'):
            return []
            
        all_effects = []
        active_waves = [wave for wave in self.timewaves if wave.is_active()]
        self.active_wave_count = len(active_waves)
        
        # Nothing to do if no active waves
        if not active_waves:
            return []
            
        # Propagate each wave
        for wave in active_waves:
            effects = wave.propagate(self.multiverse.timelines)
            all_effects.extend(effects)
            
        self.last_propagation = time.time()
        
        # Check for resonance patterns
        self._check_for_resonance(all_effects)
        
        return all_effects
        
    def _check_for_resonance(self, effects: List[Dict[str, Any]]):
        """
        Check for resonance patterns among waves
        
        Args:
            effects: List of wave effects from this propagation cycle
        """
        # Group effects by timeline
        timeline_effects = {}
        for effect in effects:
            timeline_name = effect['timeline_name']
            if timeline_name not in timeline_effects:
                timeline_effects[timeline_name] = []
            timeline_effects[timeline_name].append(effect)
            
        # Check each timeline for multiple effects
        for timeline_name, timeline_effects_list in timeline_effects.items():
            if len(timeline_effects_list) > 1:
                # Calculate cumulative effect
                cumulative = sum(effect['stability_effect'] for effect in timeline_effects_list)
                
                # If significant resonance (constructive or destructive), apply special effect
                if abs(cumulative) > 0.15:
                    timeline = self.multiverse.timelines[timeline_name]
                    
                    # Strong resonance can cause quantum effects
                    if hasattr(timeline, 'quantum_state'):
                        # Increase quantum field energy
                        if hasattr(timeline.quantum_state, 'quantum_field_energy'):
                            timeline.quantum_state.quantum_field_energy += abs(cumulative) * 2
                            
                        # Possibility of wave function effects
                        if random.random() < abs(cumulative):
                            # Increase probability of special quantum events
                            if hasattr(timeline.quantum_state, 'wave_function_stability'):
                                timeline.quantum_state.wave_function_stability -= abs(cumulative) * 0.5
                    
                    # Add resonance event
                    if cumulative > 0:
                        event_desc = "Constructive timewave resonance detected"
                    else:
                        event_desc = "Destructive timewave resonance detected"
                        
                    current_year = max(effect['timeline'].events[-1][0] for effect in timeline_effects_list 
                                       if effect['timeline'].events)
                    timeline.add_event(event_desc, current_year)
        
    def get_active_waves(self) -> List[Timewave]:
        """Get all currently active waves"""
        return [wave for wave in self.timewaves if wave.is_active()]
        
    def cleanup_inactive_waves(self) -> int:
        """
        Remove inactive waves from tracking
        
        Returns:
            Number of waves removed
        """
        initial_count = len(self.timewaves)
        self.timewaves = [wave for wave in self.timewaves if wave.is_active()]
        self.active_wave_count = len(self.timewaves)
        return initial_count - len(self.timewaves)
        
    def get_status_report(self) -> str:
        """Generate a status report for all timewaves"""
        if not self.timewaves:
            return "No timewaves detected in the multiverse."
            
        report = ["=== TIMEWAVE STATUS REPORT ==="]
        report.append(f"Active Waves: {self.active_wave_count}")
        report.append(f"Total Waves: {self.total_wave_count}")
        
        # Report on active waves
        active_waves = self.get_active_waves()
        if active_waves:
            report.append("\nActive Timewaves:")
            for i, wave in enumerate(active_waves):
                amp = wave.get_wave_amplitude()
                affected = len(wave.affected_timelines)
                report.append(f"{i+1}. Origin: {wave.origin}, Year: {wave.year}, Strength: {wave.strength:.2f}, Amplitude: {amp:.2f}")
                report.append(f"   Description: {wave.description}")
                report.append(f"   Affected {affected} timelines")
                
        # Report on timelines with most effects
        if self.multiverse and hasattr(self.multiverse, 'timelines'):
            # Count effects per timeline
            timeline_effect_count = {}
            for wave in self.timewaves:
                for effect in wave.affected_timelines:
                    timeline = effect.get('timeline_name', 'Unknown')
                    if timeline not in timeline_effect_count:
                        timeline_effect_count[timeline] = 0
                    timeline_effect_count[timeline] += 1
                    
            # Show most affected timelines
            if timeline_effect_count:
                report.append("\nMost Affected Timelines:")
                sorted_timelines = sorted(timeline_effect_count.items(), 
                                       key=lambda x: x[1], reverse=True)
                for timeline, count in sorted_timelines[:3]:  # Top 3
                    report.append(f"- {timeline}: {count} wave effects")
        
        return "\n".join(report)
        
    def __str__(self) -> str:
        return f"Timewave Manager: {self.active_wave_count} active waves out of {self.total_wave_count} total"


def run_timewave_demo():
    """Run a demonstration of the timewave system"""
    from sacred_timeline import SacredTimeline
    
    print("=== Timewave Propagation Demonstration ===")
    
    # Create some mock timelines for the demo
    timelines = {
        "Alpha": SacredTimeline("Alpha", 0.8),
        "Beta": SacredTimeline("Beta", 0.7),
        "Gamma": SacredTimeline("Gamma", 0.9),
        "Delta": SacredTimeline("Delta", 0.6)
    }
    
    # Add some events to the timelines
    timelines["Alpha"].add_nexus_point(2020, "Quantum Revolution", 0.8)
    timelines["Beta"].add_nexus_point(2025, "Temporal Disruption", 0.7)
    timelines["Gamma"].add_nexus_point(2030, "Dimensional Shift", 0.9)
    
    # Create a mock multiverse with these timelines
    class MockMultiverse:
        def __init__(self, timelines):
            self.timelines = timelines
    
    multiverse = MockMultiverse(timelines)
    
    # Create the timewave manager
    manager = TimewaveManager(multiverse)
    
    # Create some waves
    print("\nCreating timewaves:")
    wave1 = manager.create_timewave("Alpha", 2020, 1.5, "Quantum breakthrough experiment")[1]
    print(f"Created {wave1}")
    
    wave2 = manager.create_timewave("Beta", 2025, 0.8, "Temporal anomaly detection")[1]
    print(f"Created {wave2}")
    
    # Propagate waves over several cycles
    print("\nPropagating waves through the multiverse:")
    for i in range(3):
        print(f"\n--- Propagation Cycle {i+1} ---")
        effects = manager.propagate_all_waves()
        
        # Show effects
        for effect in effects:
            timeline_name = effect['timeline_name']
            old_stability = effect['old_stability']
            new_stability = effect['new_stability']
            change = new_stability - old_stability
            change_str = f"+{change:.3f}" if change >= 0 else f"{change:.3f}"
            
            print(f"Timeline {timeline_name}: Stability {old_stability:.3f} → {new_stability:.3f} ({change_str})")
    
    # Show final status
    print("\n" + manager.get_status_report())
    
    # Show timeline states
    print("\nFinal timeline states:")
    for name, timeline in timelines.items():
        print(f"{name}: {timeline.stability:.3f} stability")
        
        # Show recent events
        if timeline.events:
            print("  Recent events:")
            for year, desc in sorted(timeline.events[-3:], key=lambda x: x[0]):
                print(f"  - {year}: {desc}")
    
    return manager


if __name__ == "__main__":
    run_timewave_demo()
